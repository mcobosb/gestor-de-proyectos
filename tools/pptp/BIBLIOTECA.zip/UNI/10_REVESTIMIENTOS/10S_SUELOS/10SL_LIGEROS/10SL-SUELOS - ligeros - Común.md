# SUELOS - ligeros - Común

**Clasificación:** 10SL. **Capítulo:** revestimientos. **Familia:** suelos.

## Descripción

Revestimientos y acabados de suelos, paredes, techos, peldaños y remates sobre un soporte apto para el sistema seleccionado.

El objeto de esta ficha es «ligeros», dentro de «suelos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar soporte, humedad y planeidad; aprobar muestra y replanteo. Ejecutar adherencia o fijación y juntas según el sistema, resolver encuentros y proteger el acabado hasta su recepción.

Comprobar humedad y regularidad del soporte, juntas de movimiento y aptitud del pavimento para las cargas y el uso.

Para la variante «ligeros» se comprobarán expresamente carga, desgaste, deslizamiento, humedad y espesor. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar adherencia o fijaciones, planeidad, juntas, aspecto y, en zonas de paso, resbaladicidad y accesibilidad exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de revestimiento con regla de deducción de huecos; peldaños, rodapiés y remates en m o ud tipificada. Definir si preparación, adhesivos, rejuntados y protección quedan incluidos; no medir capas duplicadas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
