# Enfoscados y enlucidos de cemento - Común

**Clasificación:** 10CL. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Revestimientos de mortero para regularizar y terminar paramentos de fábrica u hormigón.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 922–922. Transcripción para trazabilidad.

## Ejecución

Comprobar estabilidad, limpieza y textura del soporte; retirar desencofrantes y partes débiles, humedecer sin encharcar y aplicar mortero compatible con el soporte y ambiente. Respetar espesores y tiempos de capa del sistema, tratar encuentros y proteger el curado contra desecación y heladas. No aplicar sobre un soporte fresco o inadecuado sólo por la frase genérica del original.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 923–925. Transcripción para trazabilidad.

Sobre el ladrillo y hormigones se ejecutarán embebiendo previamente de agua las superficies de la fábrica.
Los enlucidos sobre hormigones se ejecutarán cuando estos estén todavía frescos, resecando previamente la superficie para obtener una buena adherencia. Al tiempo de aplicar el mortero a la superficie que se enluzca, se hallará esta húmeda, pero sin escaso de agua que pudiera deslavar los morteros.
Los enlucidos se mantendrán húmedos por medio de riegos muy frecuentes durante el tiempo necesario para que no sea de temer la formación de grietas de desecación.

## Medición y valoración

Por m² realmente ejecutados según 5.15, con materiales y colocación, salvo inclusión en la unidad de arqueta u otro elemento completo.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1154–1156. Transcripción para trazabilidad.

Los enlucidos de las obras de fábrica, ya sea en hormigón o ladrillo se medirán por metro cuadrado (m2) realmente ejecutado.
El abono se efectuará aplicando a estas mediciones los precios que se indican en el presupuesto, en los que se incluyen los materiales y la colocación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
