# Puesta a tierra del alumbrado - Común

**Clasificación:** 08EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Red de protección de las masas metálicas del alumbrado, exigida por las prescripciones de cuadros y soportes y por el REBT.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 353–353. Transcripción para trazabilidad.

Las partes metálicas del cuadro irán conectada a tierra.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 385–385. Transcripción para trazabilidad.

Los soportes que lo requieran, deberán poseer una abertura de dimensiones adecuadas al equipo eléctrico para acceder a los elementos de protección y maniobra; la parte inferior de dicha abertura estará situada, como mínimo, a 0,30 m de la rasante y estará dotada de puerta o trampilla con grado de protección IP44 según UNE 20324 (EN 60529) e IK 10 según UNE EN 50102. La puerta solamente se podrá abrir mediante el empleo de útiles especiales y dispondrán de un borne a tierra cuando sea metálico.

## Ejecución

Diseñar y ejecutar la red de tierra y las conexiones equipotenciales conforme a ITC-BT-09 y 18, con materiales y uniones protegidos frente a corrosión. Conectar masas, verificar continuidad y medir resistencia y coordinación con las protecciones antes de la puesta en servicio. No sustituir el cálculo y las medidas por un único valor genérico.

## Medición y valoración

El original no define abono separado. Incluir en las unidades correspondientes si así lo prevén sus precios; sólo medir electrodos y conductores por separado cuando existan partidas aprobadas.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
