# Derivación individual de alumbrado

**Clasificación:** 08ED. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Enlace entre los equipos de medida y el cuadro del suministro de alumbrado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 345–345. Transcripción para trazabilidad.

Desde cada uno de los contadores hasta el cuadro de protección, situado en la misma hornacina, se instalarán conductores del tipo Cu 750 v de secciones según proceda, en el interior de tubos según ITC Bt 21, cumpliendo las normas UNE EN50086 2 1, siempre a través de la correspondiente caja para I.C.P antes de su conexión en el cuadro.

## Ejecución

Dimensionar conforme a ITC-BT-15 y a la instalación, seleccionar conductores y canalizaciones adecuados y ejecutar sin empalmes no permitidos. Identificar circuitos y realizar verificaciones de continuidad, aislamiento y protecciones antes de la conexión.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 346–347. Transcripción para trazabilidad.

EJECUCIÓN DE OBRA
La instalación interior se hará según norma del Ayuntamiento, cumpliendo con el R.B.T. y la empresa suministradora.

## Medición y valoración

Se integra en la ud conjunta de módulos y derivación de 3.17.2, salvo partida independiente aprobada. No duplicar el abono al utilizar las dos fichas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 348–349. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
El modulo de contadores y derivación individual se medirá como Uds. De obra completamente terminada, realmente ejecutada, se incluirá la hornacina donde va colocada estos elementos.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
