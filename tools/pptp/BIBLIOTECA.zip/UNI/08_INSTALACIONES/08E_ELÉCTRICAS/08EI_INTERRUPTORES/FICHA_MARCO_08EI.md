# interruptores

**Clasificación:** 08EI. **Capítulo:** instalaciones. **Familia:** eléctricas.

## Descripción

Componentes de instalaciones y equipos, sus soportes y conexiones, integrados en el sistema definido por el proyecto y su reglamentación sectorial.

El objeto de esta ficha es «interruptores», dentro de «eléctricas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar el diseño, la compatibilidad de equipos y la coordinación con otras redes. Montar con personal y empresa habilitados cuando sea exigible, dejando accesos de mantenimiento. Realizar las pruebas y la puesta en servicio reglamentarias antes de entregar la instalación.

Verificar dimensionado y protecciones, identificación de circuitos y continuidad de protección; ensayar antes de energizar por personal habilitado.

Para la variante «interruptores» se comprobarán expresamente tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar identificación de equipos, controles previos al cierre, ajustes, pruebas funcionales y documentación de puesta en servicio y mantenimiento.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Tendidos en m y equipos, aparatos o conjuntos en ud con composición definida. Soportes, conexiones y pruebas se incluyen sólo según la partida aprobada; una instalación completa no se abonará además por sus componentes ya incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
