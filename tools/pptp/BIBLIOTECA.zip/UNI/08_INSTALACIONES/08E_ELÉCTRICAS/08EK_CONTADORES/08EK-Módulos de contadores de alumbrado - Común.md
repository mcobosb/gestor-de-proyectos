# Módulos de contadores de alumbrado - Común

**Clasificación:** 08EK. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Envolventes y equipos de medida del suministro de alumbrado exterior.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 341–344. Transcripción para trazabilidad.

DESCRIPCIÓN
Los equipos de medida estarán situados en hornacinas y compuestos por contador trifásico de activa con discriminación horaria y reloj, permisible para la contratación de tarifa nocturna, estos elementos serán a instalar por la Cía. Suministradora en régimen de alquiler. Todo ello, dispuesto en el interior de módulos homologados por la S.A. Sevillana de Electricidad, construidos en material aislante clase A, resistente a los álcalis, auto extinguibles y precintables, con un IP 403 para la caja, las tapas serán de poliéster y dispondrán de dos ventanas trasparentes situadas delante de los diales de los contadores y relojes, y con un IP cuya tercera cifra no sea menor de 7.
Los conjuntos estarán situados de forma tal que los diales de los contadores queden a una altura comprendida entre 0,50 y 1,80 metros, de forma que se facilite la lectura de los mismos. Dispondrán de ventilación para evitar condensaciones. En su interior alojará tres cortacircuitos ZR 2 con sus correspondientes cartuchos de los valores nominales indicados en los esquemas.

## Ejecución

Aplicar ITC-BT-16 y las condiciones aprobadas de la distribuidora. Verificar accesibilidad de lectura y mantenimiento, protección, ventilación, precintado y segregación de circuitos. Instalar y comprobar por personal habilitado, sin atribuir al contratista equipos en alquiler que corresponda aportar a la distribuidora.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 345–347. Transcripción para trazabilidad.

Desde cada uno de los contadores hasta el cuadro de protección, situado en la misma hornacina, se instalarán conductores del tipo Cu 750 v de secciones según proceda, en el interior de tubos según ITC Bt 21, cumpliendo las normas UNE EN50086 2 1, siempre a través de la correspondiente caja para I.C.P antes de su conexión en el cuadro.
EJECUCIÓN DE OBRA
La instalación interior se hará según norma del Ayuntamiento, cumpliendo con el R.B.T. y la empresa suministradora.

## Medición y valoración

El original mide conjuntamente módulos y derivación individual por ud completa con hornacina. Mantener esa unidad agrupada salvo que el presupuesto los separe; esta ficha y la de derivación no crean dos abonos.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 348–349. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
El modulo de contadores y derivación individual se medirá como Uds. De obra completamente terminada, realmente ejecutada, se incluirá la hornacina donde va colocada estos elementos.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
