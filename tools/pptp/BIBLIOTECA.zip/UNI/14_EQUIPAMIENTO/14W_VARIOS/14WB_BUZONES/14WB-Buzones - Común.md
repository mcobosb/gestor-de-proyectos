# Buzones - Común

**Clasificación:** 14WB. **Capítulo:** equipamiento. **Familia:** varios.

## Descripción

Equipamiento y mobiliario definido por sus prestaciones, dimensiones, uso y condiciones de instalación.

El objeto de esta ficha es «buzones», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar accesos, ubicación y compatibilidad con los servicios. Montar, nivelar y anclar conforme al diseño, sin obstaculizar recorridos accesibles ni evacuación. Ajustar componentes y entregar instrucciones y garantías.

Comprobar accesibilidad, fijaciones y mantenimiento de elementos decorativos y de señalización.

Para la variante «buzones» se comprobarán expresamente elemento concreto, emplazamiento y prestaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar estabilidad, fijación, funcionamiento, acabado, ausencia de aristas peligrosas y documentación del equipo.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

ud de elemento completo de tipología, dimensiones y prestaciones definidas, instalado y con la recepción exigida. Precisar conexiones, anclajes, pruebas y obra civil incluidos, evitando certificar de nuevo componentes del conjunto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
