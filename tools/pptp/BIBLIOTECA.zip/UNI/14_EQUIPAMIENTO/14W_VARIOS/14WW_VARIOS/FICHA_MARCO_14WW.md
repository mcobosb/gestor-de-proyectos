# varios

**Clasificación:** 14WW. **Capítulo:** equipamiento. **Familia:** varios.

## Descripción

Equipamiento y mobiliario definido por sus prestaciones, dimensiones, uso y condiciones de instalación.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar accesos, ubicación y compatibilidad con los servicios. Montar, nivelar y anclar conforme al diseño, sin obstaculizar recorridos accesibles ni evacuación. Ajustar componentes y entregar instrucciones y garantías.

Comprobar accesibilidad, fijaciones y mantenimiento de elementos decorativos y de señalización.

Para la variante «varios» se comprobarán expresamente elemento concreto, emplazamiento y prestaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar estabilidad, fijación, funcionamiento, acabado, ausencia de aristas peligrosas y documentación del equipo.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

ud de equipo o conjunto completo tipificado; superficies de decoración en m² y elementos continuos en m si lo establece la partida. Relacionar accesorios, montaje y conexiones incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
