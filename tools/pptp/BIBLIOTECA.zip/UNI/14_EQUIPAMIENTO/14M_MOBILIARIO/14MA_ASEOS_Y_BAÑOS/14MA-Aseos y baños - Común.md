# Aseos y baños - Común

**Clasificación:** 14MA. **Capítulo:** equipamiento. **Familia:** mobiliario.

## Descripción

Equipamiento y mobiliario definido por sus prestaciones, dimensiones, uso y condiciones de instalación.

El objeto de esta ficha es «aseos y baños», dentro de «mobiliario». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar accesos, ubicación y compatibilidad con los servicios. Montar, nivelar y anclar conforme al diseño, sin obstaculizar recorridos accesibles ni evacuación. Ajustar componentes y entregar instrucciones y garantías.

Comprobar ergonomía, estabilidad y anclajes de mobiliario; coordinar conexiones cuando el equipo las precise.

Para la variante «aseos y baños» se comprobarán expresamente dimensiones, uso, cargas, acabado y fijaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar estabilidad, fijación, funcionamiento, acabado, ausencia de aristas peligrosas y documentación del equipo.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

ud de equipo o conjunto completo tipificado; superficies de decoración en m² y elementos continuos en m si lo establece la partida. Relacionar accesorios, montaje y conexiones incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
