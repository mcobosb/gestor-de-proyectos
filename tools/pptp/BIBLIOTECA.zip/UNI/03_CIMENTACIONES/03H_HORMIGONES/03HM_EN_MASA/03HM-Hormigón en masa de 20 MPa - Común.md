# Hormigón en masa de 20 MPa - Común

**Clasificación:** 03HM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Hormigón en masa de 20 N/mm² utilizado en elementos no armados y otros apoyos definidos expresamente en el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 859–860. Transcripción para trazabilidad.

- Hormigón con una resistencia de 20 N/mm2:
- Pozos de registro sin armar in situ .

## Ejecución

Verificar función, exposición y designación antes de suministrar. No utilizar como hormigón armado. Preparar apoyo, colocar y compactar sin contaminación, ejecutar juntas y curado y realizar controles del Código Estructural cuando el elemento sea estructural.

## Medición y valoración

Según la partida: m³ del hormigón o incluido en el elemento completo, sin duplicar ambos.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
