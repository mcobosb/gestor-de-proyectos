"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# En masa - Varios

**Clasificación BCCA:** `03HMW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **En masa**.
Aplicable a las partidas cuyo código BCCA comienza por `03HMW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03HMW00101 - HORMIGÓN CICLOPEO HM-20/P/40/X0 EN CIMIENTOS

**Unidad:** m3.

Hormigón ciclópeo HM-20/P/40/X0, consistencia plástica y tamaño máximo del árido 40 mm, en cimientos, formado por el 25% de piedra silícea en rama y el 75% de hormigón, suministrado y puesto en obra, incluso p.p. de picado; según CodE y CTE. Medido el volumen teórico ejecutado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Hormigón en masa de 20 MPa

**Clasificación:** 03HM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Hormigón en masa de 20 N/mm² utilizado en elementos no armados y otros apoyos definidos expresamente en el proyecto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 859–860. Transcripción para trazabilidad.
"""

- Hormigón con una resistencia de 20 N/mm2:
- Pozos de registro sin armar in situ .

#### Ejecución

Verificar función, exposición y designación antes de suministrar. No utilizar como hormigón armado. Preparar apoyo, colocar y compactar sin contaminación, ejecutar juntas y curado y realizar controles del Código Estructural cuando el elemento sea estructural.

#### Medición y valoración

Según la partida: m³ del hormigón o incluido en el elemento completo, sin duplicar ambos.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
