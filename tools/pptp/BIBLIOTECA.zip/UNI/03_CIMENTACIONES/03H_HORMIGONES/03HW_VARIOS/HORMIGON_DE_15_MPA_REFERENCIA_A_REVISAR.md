# Hormigón de 15 MPa: referencia del original a revisar

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Material de 15 N/mm² mencionado en el original para diversos usos; la relación se conserva como antecedente, no como autorización de uso estructural.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 861–869. Transcripción para trazabilidad.

- Hormigón con una resistencia de 15 N/mm2:
- Aceras de hormigón.
- Soleras reforzadas de aceras.
- Arquetas de tomas de agua.
- Sumideros.
- Rellenos en muretes de bloques.
- Cimentación de cerramientos.
- Macizos de contrarresto.
- Rellenos reforzados.

## Ejecución

Antes del suministro, reclasificar cada aplicación por su función. No emplearlo como hormigón estructural en masa, armado o pretensado, al ser inferior a los mínimos del Código Estructural. Para usos realmente no estructurales, definir producto, condiciones y prestaciones en una especificación aprobada; las operaciones de vertido, compactación y curado deben adaptarse a esa solución.

## Medición y valoración

No generar una nueva partida por esta ficha. Aplicar el precio de la solución aprobada y tramitar cualquier sustitución contractual por el procedimiento correspondiente.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
