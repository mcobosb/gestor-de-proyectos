# Hormigón de 6 MPa- referencia del original a revisar - Común

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Material de 6 N/mm² citado para sustitución de terrenos degradados y trasdosados, conservado únicamente como referencia del pliego de origen.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 876–878. Transcripción para trazabilidad.

- Hormigón con una resistencia de 6 N/mm2:
- Sustitución de terrenos degradados.
- Trasdosados.

## Ejecución

No utilizarlo como hormigón estructural. Si se pretende un relleno fluido o material de mejora, definir con estudio específico su composición, resistencia, retracción, comportamiento y compatibilidad con el terreno y los drenajes. Ejecutar sólo tras aprobación de esa solución, con controles y secuencia de vertido establecidos.

## Medición y valoración

Valorar únicamente mediante la partida de la solución aprobada. No se crea un precio autónomo ni una autorización técnica con esta ficha.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
