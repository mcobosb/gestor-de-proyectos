# Hormigón de 12,5 MPa: referencia del original a revisar

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Hormigón de 12,5 N/mm² citado para soleras, asientos, rellenos, envolventes y limpieza; no es una designación estructural admisible.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 870–875. Transcripción para trazabilidad.

- Hormigón con una resistencia de 12,5 N/mm2:
- Soleras de aceras.
- Asiento de tuberías.
- Rellenos.
- Envuelta de conductos.
- Capa de limpieza.

## Ejecución

Distinguir cada uso y definir la especificación vigente que proceda para limpieza, relleno o protección no estructural. No adoptar esta resistencia para funciones resistentes sujetas al Código Estructural. Preparar apoyo, extender y curar de acuerdo con la solución aprobada, sin atribuirle una clase de producto por semejanza.

## Medición y valoración

Incluido en la unidad principal o por su partida específica aprobada. La ficha no autoriza el suministro ni modifica un precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
