"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Varios

**Clasificación BCCA:** `03HWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `03HWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

"""
### Hormigón de 12,5 MPa- referencia del original a revisar
"""

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Hormigón de 12,5 N/mm² citado para soleras, asientos, rellenos, envolventes y limpieza; no es una designación estructural admisible.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 870–875. Transcripción para trazabilidad.
"""

- Hormigón con una resistencia de 12,5 N/mm2:
- Soleras de aceras.
- Asiento de tuberías.
- Rellenos.
- Envuelta de conductos.
- Capa de limpieza.

#### Ejecución

Distinguir cada uso y definir la especificación vigente que proceda para limpieza, relleno o protección no estructural. No adoptar esta resistencia para funciones resistentes sujetas al Código Estructural. Preparar apoyo, extender y curar de acuerdo con la solución aprobada, sin atribuirle una clase de producto por semejanza.

#### Medición y valoración

Incluido en la unidad principal o por su partida específica aprobada. La ficha no autoriza el suministro ni modifica un precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Hormigón de 15 MPa- referencia del original a revisar
"""

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Material de 15 N/mm² mencionado en el original para diversos usos; la relación se conserva como antecedente, no como autorización de uso estructural.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 861–869. Transcripción para trazabilidad.
"""

- Hormigón con una resistencia de 15 N/mm2:
- Aceras de hormigón.
- Soleras reforzadas de aceras.
- Arquetas de tomas de agua.
- Sumideros.
- Rellenos en muretes de bloques.
- Cimentación de cerramientos.
- Macizos de contrarresto.
- Rellenos reforzados.

#### Ejecución

Antes del suministro, reclasificar cada aplicación por su función. No emplearlo como hormigón estructural en masa, armado o pretensado, al ser inferior a los mínimos del Código Estructural. Para usos realmente no estructurales, definir producto, condiciones y prestaciones en una especificación aprobada; las operaciones de vertido, compactación y curado deben adaptarse a esa solución.

#### Medición y valoración

No generar una nueva partida por esta ficha. Aplicar el precio de la solución aprobada y tramitar cualquier sustitución contractual por el procedimiento correspondiente.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Hormigón de 6 MPa- referencia del original a revisar
"""

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Material de 6 N/mm² citado para sustitución de terrenos degradados y trasdosados, conservado únicamente como referencia del pliego de origen.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 876–878. Transcripción para trazabilidad.
"""

- Hormigón con una resistencia de 6 N/mm2:
- Sustitución de terrenos degradados.
- Trasdosados.

#### Ejecución

No utilizarlo como hormigón estructural. Si se pretende un relleno fluido o material de mejora, definir con estudio específico su composición, resistencia, retracción, comportamiento y compatibilidad con el terreno y los drenajes. Ejecutar sólo tras aprobación de esa solución, con controles y secuencia de vertido establecidos.

#### Medición y valoración

Valorar únicamente mediante la partida de la solución aprobada. No se crea un precio autónomo ni una autorización técnica con esta ficha.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
