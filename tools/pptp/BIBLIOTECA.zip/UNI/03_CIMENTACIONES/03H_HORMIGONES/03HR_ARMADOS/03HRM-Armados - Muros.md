"""
# Armados - Muros

**Clasificación BCCA:** `03HRM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Muros**, dentro de **Armados**.
Aplicable a las partidas cuyo código BCCA comienza por `03HRM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03HRM80000 - HORM. ARM. HA-25/P/20/XC2 B400S EN MURO CONT. I/ENC. 1C. V/MAN.

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido manual, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80010 - HORM. ARM. HA-30/P/20/XC2 B500S EN MURO CONT. I/ENC. 1C. V/MAN.

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido manual, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80030 - HORM. ARM. HA-25/P/20/XC2 B400S EN MURO CONT. I/ENC. 1C. V/GRÚA

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con grúa, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80040 - HORM. ARM. HA-30/P/20/XC2 B500S EN MURO CONT. I/ENC. 1C. V/GRÚA

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con grúa, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80060 - HORM. ARM. HA-25/B/15/XC2 B400S EN MURO CONT. I/ENC. 1C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-25/B/15/XC2, consistencia blanda y tamaño máximo del árido 15 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80070 - HORM. ARM. HA-25/B/20/XC2 B400S EN MURO CONT. I/ENC. 1C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-25/B/20/XC2, consistencia blanda y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80080 - HORM. ARM. HA-30/B/15/XC2 B500S EN MURO CONT. I/ENC. 1C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-30/B/15/XC2, consistencia blanda y tamaño máximo del árido 15 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80090 - HORM. ARM. HA-30/B/20/XC2 B500S EN MURO CONT. I/ENC. 1C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-30/B/20/XC2, consistencia blanda y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80120 - HORM. ARM. HA-25/P/20/XC2 B400S EN MURO CONT. I/ENC. 2C. V/MAN.

**Unidad:** m3.

Hormigón armado HA-25/P/20/IIa, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido manual, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80130 - HORM. ARM. HA-30/P/20/XC2 B500S EN MURO CONT. I/ENC. 2C. V/MAN.

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido manual, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80150 - HORM. ARM. HA-25/P/20/XC2 B400S EN MURO CONT. I/ENC. 2C. V/GRÚA

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con grúa, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80160 - HORM. ARM. HA-30/P/20/XC2 B500S EN MURO CONT. I/ENC. 2C. V/GRÚA

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con grúa, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80180 - HORM. ARM. HA-25/B/15/XC2 B400S EN MURO CONT. I/ENC. 2C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-25/B/15/XC2, consistencia blanda y tamaño máximo del árido 15 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80190 - HORM. ARM. HA-25/B/20/XC2 B400S EN MURO CONT. I/ENC. 2C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-25/B/20/XC2, consistencia blanda y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 400 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80210 - HORM. ARM. HA-30/B/15/XC2 B500S EN MURO CONT. I/ENC. 2C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-30/B/15/XC2, consistencia blanda y tamaño máximo del árido 15 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a dos caras con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

### 03HRM80220 - HORM. ARM. HA-30/B/20/XC2 B500S EN MURO CONT. I/ENC. 2C. V/BOMBA

**Unidad:** m3.

Hormigón armado HA-30/B/20/XC2, consistencia blanda y tamaño máximo del árido 20 mm, en muros de contención con espesor medio de 0,35 cm, suministrado y puesta en obra, vertido con bomba, armadura de acero B 500 S con una cuantía de 60 Kg/m3, incluso p.p. de encofrado a una cara con chapa metálica, desencofrado, ferrallado, separadores, vibrado y curado; según CodE y CTE. Medido el volumén teórico ejecutado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Armados

**Clasificación:** 03HR. **Capítulo:** cimentaciones. **Familia:** hormigones.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

El objeto de esta ficha es «armados», dentro de «hormigones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

Comprobar dosificación prescrita por prestaciones, recepción, puesta en obra, compactación y curado; registrar interrupciones y juntas.

Para la variante «armados» se comprobarán expresamente clase resistente, exposición, consistencia y plan de hormigonado. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
