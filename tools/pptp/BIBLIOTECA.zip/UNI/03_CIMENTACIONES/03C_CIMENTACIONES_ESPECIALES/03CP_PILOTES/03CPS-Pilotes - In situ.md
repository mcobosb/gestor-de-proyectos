"""
# Pilotes - In situ

**Clasificación BCCA:** `03CPS`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **In situ**, dentro de **Pilotes**.
Aplicable a las partidas cuyo código BCCA comienza por `03CPS`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03CPS00002 - PILOTE "IN SITU" ENT. REC/AZUCHE HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante hinca de entubación recuperable con azuche en punta, incluso el descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00004 - PILOTE "IN SITU" ENT. REC/AZUCHE HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante hinca de entubación recuperable con azuche en punta, incluso el descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00006 - PILOTE "IN SITU" ENT. REC/AZUCHE HA-30/F/20/XC2 DIÁM. 55 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 8,947 kg/m, de 55 cm de diámetro, ejecutado mediante hinca de entubación recuperable con azuche en punta, incluso el descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00007 - PILOTE "IN SITU" ENT. REC/AZUCHE HA-30/F/20/XC2 DIÁM. 65 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 10,467 kg/m, de 65 cm de diámetro, ejecutado mediante hinca de entubación recuperable con azuche en punta, incluso el descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00052 - PILOTE "IN SITU" ENT. REC/TAPON GR. HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante hinca de entubación recuperable con tapón de gravas, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00056 - PILOTE "IN SITU" ENT. REC/TAPON GR HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante hinca de entubación recuperable con tapón de gravas, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00102 - PILOTE "IN SITU" ENT. REC. HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante excavación de tierras con entubación recuperable, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00106 - PILOTE "IN SITU" ENT. REC HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante excavación de tierras con entubación recuperable, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00108 - PILOTE "IN SITU" ENT. REC HA-30/F/20/XC2 DIÁM. 55 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 8,947 kg/m, de 55 cm de diámetro, ejecutado mediante excavación de tierras con entubación recuperable, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00109 - PILOTE "IN SITU" ENT. REC HA-30/F/20/XC2 DIÁM. 65 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 10,467 kg/m, de 65 cm de diámetro, ejecutado mediante excavación de tierras con entubación recuperable, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00110 - PILOTE "IN SITU" ENT. REC HA-30/F/20/XC2 DIÁM. 80 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 13,607 kg/m, de 80 cm de diámetro, ejecutado mediante excavación de tierras con entubación recuperable, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00111 - PILOTE "IN SITU" ENT. REC HA-30/F/20/XC2 DIÁM. 100 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 17,880 kg/m, de 100 cm de diámetro, ejecutado mediante excavación de tierras con entubación recuperable, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00152 - PILOTE "IN SITU" ENT. PERD. HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante excavación de tierras con entubación perdida, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00156 - PILOTE "IN SITU" ENT. PERD HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante excavación de tierras con entubación perdida, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00202 - PILOTE "IN SITU" LODOS HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante perforación con lodos tixotrópicos, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00202N - PILOTE "IN SITU" LODOS HA-25/F/20/XC2 DIÁM. 55 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 8,947 kg/m, de 55 cm de diámetro, ejecutado mediante perforación con lodos tixotrópicos, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00206 - PILOTE "IN SITU" LODOS HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante perforación con lodos tixotrópicos, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00206N - PILOTE "IN SITU" LODOS HA-30/F/20/XC2 DIÁM. 55 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 8,947 kg/m, de 55 cm de diámetro, ejecutado mediante perforación con lodos tixotrópicos, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPS00252 - PILOTE "IN SITU" SIN ENT. HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante barrenado sin entubación, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00256 - PILOTE "IN SITU" SIN ENT. HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante barrenado sin entubación, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00310 - PILOTE "IN SITU" BARREN. HA-25/F/20/XC2 DIÁM. 35 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 6,227 kg/m, de 35 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00311 - PILOTE "IN SITU" BARREN. HA-25/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00312 - PILOTE "IN SITU" BARREN. HA-25/F/20/XC2 DIÁM. 55 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 8,947 kg/m, de 55 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00313 - PILOTE "IN SITU" BARREN. HA-25/F/20/XC2 DIÁM. 65 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 10,467 kg/m, de 65 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00315 - PILOTE "IN SITU" BARREN. HA-30/F/20/XC2 DIÁM. 35 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 6,227 kg/m, de 35 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00316 - PILOTE "IN SITU" BARREN. HA-30/F/20/XC2 DIÁM. 45 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 7,587 kg/m, de 45 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00317 - PILOTE "IN SITU" BARREN. HA-30/F/20/XC2 DIÁM. 55 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 8,947 kg/m, de 55 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00318 - PILOTE "IN SITU" BARREN. HA-30/F/20/XC2 DIÁM. 65 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 10,467 kg/m, de 65 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00319N - PILOTE "IN SITU" BARREN. HA-25/F/20/XC2 DIÁM. 75 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 12,147 kg/m, de 75 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00320N - PILOTE "IN SITU" BARREN. HA-25/F/20/XC2 DIÁM. 85 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 13,967 kg/m, de 85 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00321N - PILOTE "IN SITU" BARREN. HA-30/F/20/XC2 DIÁM. 75 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 12,147 kg/m, de 75 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

### 03CPS00322N - PILOTE "IN SITU" BARREN. HA-30/F/20/XC2 DIÁM. 85 cm

**Unidad:** m.

Pilote "in situ" de hormigón armado HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, con acero B 500 S y una cuantía de 13,967 kg/m, de 85 cm de diámetro, ejecutado mediante barrenado, incluso descabezado, limpieza y doblado de las armaduras; construido según NCSR-02, CodE y CTE. Medida la longitud hasta la plataforma de apoyo del equipo.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Pilotes

**Clasificación:** 03CP. **Capítulo:** cimentaciones. **Familia:** cimentaciones especiales.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

El objeto de esta ficha es «pilotes», dentro de «cimentaciones especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

El procedimiento de cimentación profunda o consolidación necesita proyecto específico y registro individual de los elementos ejecutados. Identificar cada pilote y registrar profundidad, terreno y ejecución; verificar integridad o carga según el plan aprobado.

Para la variante «pilotes» se comprobarán expresamente terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; tipología, capacidad, longitud y pruebas. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
