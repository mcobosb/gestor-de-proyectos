"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Pilotes - Prefabricados

**Clasificación BCCA:** `03CPP`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Prefabricados**, dentro de **Pilotes**.
Aplicable a las partidas cuyo código BCCA comienza por `03CPP`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03CPP00001 - PILOTE PREFABRIC. PROF. HASTA 12 m DIÁM. 35 cm

**Unidad:** m.

Pilote prefabricado, hasta 12 m de profundidad, de hormigón armado HA-35 con acero B 500 S, de diámetro equivalente 35 cm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00001N - PILOTE PREFABRIC. PROF. HASTA 12 m DIÁM. 30 cm

**Unidad:** m.

Pilote prefabricado, hasta 12 m de profundidad, de hormigón armado HA-35 con acero B 500 S, de diámetro equivalente 30 cm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00002 - PILOTE PREFABRIC. PROF. MAYOR DE 12 m DIÁM. 35 cm

**Unidad:** m.

Pilote prefabricado, a profundidad mayor de 12 m, de hormigón armado HA-35 con acero B 500 S, de diámetro equivalente 35 cm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00002N - PILOTE PREFABRIC. PROF. MAYOR DE 12 m DIÁM. 30 cm

**Unidad:** m.

Pilote prefabricado, a profundidad mayor de 12 m, de hormigón armado HA-35 con acero B 500 S, de diámetro equivalente 30 cm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00003N - PILOTE PREFABRICADO SECCIÓN 200X200 mm

**Unidad:** m.

Pilote prefabricado de hormigón armado HA-35 con acero B 500 S, de sección 200x200 mm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00004N - PILOTE PREFABRICADO SECCIÓN 235X235 mm

**Unidad:** m.

Pilote prefabricado de hormigón armado HA-35 con acero B 500 S, de sección 235x235 mm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00005N - PILOTE PREFABRICADO SECCIÓN 270X270 mm

**Unidad:** m.

Pilote prefabricado de hormigón armado HA-35 con acero B 500 S, de sección 270x270 mm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00006N - PILOTE PREFABRICADO SECCIÓN 300X300 mm

**Unidad:** m.

Pilote prefabricado de hormigón armado HA-35 con acero B 500 S, de sección 300x300 mm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00007N - PILOTE PREFABRICADO SECCIÓN 350X350 mm

**Unidad:** m.

Pilote prefabricado de hormigón armado HA-35 con acero B 500 S, de sección 350x350 mm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CPP00008N - PILOTE PREFABRICADO SECCIÓN 400X400 mm

**Unidad:** m.

Pilote prefabricado de hormigón armado HA-35 con acero B 500 S, de sección 400x400 mm, y con elemento especial en la punta para la hinca, incluso descabezado, limpieza y doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Pilotes

**Clasificación:** 03CP. **Capítulo:** cimentaciones. **Familia:** cimentaciones especiales.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

El objeto de esta ficha es «pilotes», dentro de «cimentaciones especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

El procedimiento de cimentación profunda o consolidación necesita proyecto específico y registro individual de los elementos ejecutados. Identificar cada pilote y registrar profundidad, terreno y ejecución; verificar integridad o carga según el plan aprobado.

Para la variante «pilotes» se comprobarán expresamente terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; tipología, capacidad, longitud y pruebas. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
