"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Varios

**Clasificación BCCA:** `03CWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `03CWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03CWW00010 - ANCLAJE INYECCIÓN PERMANENTE HASTA 45 t

**Unidad:** m.

Anclaje mediante inyección permanente para muros, cimentaciónes y taludes hasta 45º, formado por: cabeza de anclaje cable de 4 torones ST-170/190 de 0,6 de diámetro, tensado con gato multifilar en una sola fase, blocaje con cuña triangular de fricción, inyección de cemento CEM II/A-L 32,5 N hasta 45 kg/m para protección y formación de bulbo, incluso p.p. de placas, cabezas, cuñas, caperuza de protección; según NCSR-02, CTE. Medida la longitud desde la placa de anclaje hasta el extremo del bulbo.

### 03CWW80000 - ARRIOSTRAMIENTO PANTALLAS ENTRAMADO MET. HASTA 200 kN

**Unidad:** m2.

Arristramiento de pantallas contínuas o de pilotes, con entramado metálico de vigas de celosía, para una carga de 200 kN, incluso montaje y desmontaje; según CTE. Medida la repercusión por unidad de superficie real de pantalla.

### 03CWW80130 - ENLACE FORJ/LOSA A MURO PANTALLA C/RESINA INYECCIÓN

**Unidad:** u.

Conexión de forjado o losa a muro pantalla de diámetro 450 a 500 mm, con distancia inferior a 1,00 m mediante barras corrugadas B 500 S de 16 mm de diámetro, incluso p.p. de taladros de 20 mm, inyección de resinas y armaduras de anclaje a forjado o losa; según CTE. Medida la cantidad ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### CIMENTACIONES ESPECIALES - varios

**Clasificación:** 03CW. **Capítulo:** cimentaciones. **Familia:** cimentaciones especiales.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

El procedimiento de cimentación profunda o consolidación necesita proyecto específico y registro individual de los elementos ejecutados.

Para la variante «varios» se comprobarán expresamente terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
