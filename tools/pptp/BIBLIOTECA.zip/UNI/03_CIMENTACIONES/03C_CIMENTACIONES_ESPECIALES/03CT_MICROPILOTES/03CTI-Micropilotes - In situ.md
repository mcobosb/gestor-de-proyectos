"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Micropilotes - In situ

**Clasificación BCCA:** `03CTI`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **In situ**, dentro de **Micropilotes**.
Aplicable a las partidas cuyo código BCCA comienza por `03CTI`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03CTI80010N - MICROPILOTE "IN SITU" C/CAMISA ACERO DIÁM. 48 mm

**Unidad:** m.

Micropilote fabricado "in situ" de diámetro exterior 48,25 mm, armado con camisa de acero de 42,05 mm de diámetro interior y 3,10 mm de espesor de pared, hasta 15 m de profundidad con lodos toxotrópicos, incluso limpieza y transporte de equipo mecánico; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada desde la plataforma de apoyo del equipo.

### 03CTI80020N - MICROPILOTE "IN SITU" C/CAMISA ACERO DIÁM. 60 mm

**Unidad:** m.

Micropilote fabricado "in situ" de diámetro exterior 60 mm, armado con camisa de acero de 53,40 mm de diámetro interior y 3,30 mm de espesor de pared, hasta 15 m de profundidad con lodos toxotrópicos, incluso limpieza y transporte de equipo mecánico; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada desde la plataforma de apoyo del equipo.

### 03CTI80030N - MICROPILOTE "IN SITU" C/CAMISA ACERO DIÁM. 75,50 mm

**Unidad:** m.

Micropilote fabricado "in situ" de diámetro exterior 75,50 mm, armado con camisa de acero de 68 mm de diámetro interior y 10 mm de espesor de pared, hasta 15 m de profundidad con lodos toxotrópicos, incluso limpieza y transporte de equipo mecánico; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada desde la plataforma de apoyo del equipo.

### 03CTI80040N - MICROPILOTE "IN SITU" C/CAMISA ACERO DIÁM. 100 mm

**Unidad:** m.

Micropilote fabricado "in situ" de diámetro exterior 100 mm, armado con camisa de acero de 80 mm de diámetro interior y 10 mm de espesor de pared, hasta 15 m de profundidad con lodos toxotrópicos, incluso limpieza y transporte de equipo mecánico; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada desde la plataforma de apoyo del equipo.

### 03CTI80050 - MICROPILOTE "IN SITU" C/CAMISA ACERO DIÁM. 150 mm

**Unidad:** m.

Micropilote "in situ" de diámetro exterior 150 mm, armado con camisa de acero de 120 mm de diámetro interior y 10 mm de espesor de pared, hasta 15 m de profundidad, incluso limpieza; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada desde la plataforma de apoyo del equipo.

### 03CTI80050N - MICROPILOTE "IN SITU" C/CAMISA ACERO DIÁM. 150 mm

**Unidad:** m.

Micropilote fabricado "in situ" de diámetro exterior 150 mm, armado con camisa de acero de 120 mm de diámetro interior y 10 mm de espesor de pared, hasta 15 m de profundidad con lodos toxotrópicos, incluso limpieza y transporte de equipo mecánico; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada desde la plataforma de apoyo del equipo.

### 03CTI80060N - MICROPILOTE "IN SITU" AIRE A PRESIÓN 120 mm 14,33 t

**Unidad:** m.

Micropilote "in situ" de diámetro 120 mm, armado con grupo de barras de acero B 500 S, 14,33 t, con inyección de cemento CEM II/A-L 32,5 N, mediante golpes de aire con presión controlada, incluso doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CTI80070 - MICROPILOTE "IN SITU" AIRE A PRESIÓN 150 mm

**Unidad:** m.

Micropilote "in situ" de diámetro 150 mm, armado con grupo de barras de acero B 500 S, con inyección de cemento CEM II/A-L 32,5 N, mediante golpes de aire con presión controlada, incluso doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CTI80070N - MICROPILOTE "IN SITU" AIRE A PRESIÓN 150 mm 18 t

**Unidad:** m.

Micropilote "in situ" de diámetro 150 mm, armado con grupo de barras de acero B 500 S, 18 t, con inyección de cemento CEM II/A-L 32,5 N, mediante golpes de aire con presión controlada, incluso doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CTI80080N - MICROPILOTE "IN SITU" AIRE A PRESIÓN 150 mm 22 t

**Unidad:** m.

Micropilote "in situ" de diámetro 150 mm, armado con grupo de barras de acero B 500 S, 22 t, con inyección de cemento CEM II/A-L 32,5 N, mediante golpes de aire con presión controlada, incluso doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

### 03CTI80090N - MICROPILOTE "IN SITU" AIRE A PRESIÓN 170 mm 34,5 t

**Unidad:** m.

Micropilote "in situ" de diámetro 170 mm, armado con grupo de barras de acero B 500 S, 34,5 t, con inyección de cemento CEM II/A-L 32,5 N, mediante golpes de aire con presión controlada, incluso doblado de las armaduras; construido según CodE, NCSR-02 y CTE. Medida la longitud ejecutada hasta la plataforma de apoyo del equipo.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Micropilotes

**Clasificación:** 03CT. **Capítulo:** cimentaciones. **Familia:** cimentaciones especiales.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

El objeto de esta ficha es «micropilotes», dentro de «cimentaciones especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

El procedimiento de cimentación profunda o consolidación necesita proyecto específico y registro individual de los elementos ejecutados. Registrar perforación, armadura e inyección conforme al procedimiento específico sin extrapolar parámetros entre terrenos.

Para la variante «micropilotes» se comprobarán expresamente terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; diámetro, longitud, armadura, lechada y criterios de inyección. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
