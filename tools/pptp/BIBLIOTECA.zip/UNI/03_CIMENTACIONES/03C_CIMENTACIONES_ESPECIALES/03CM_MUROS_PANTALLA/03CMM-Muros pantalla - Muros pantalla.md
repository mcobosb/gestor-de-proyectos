"""
# Muros pantalla - Muros pantalla

**Clasificación BCCA:** `03CMM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Muros pantalla**, dentro de **Muros pantalla**.
Aplicable a las partidas cuyo código BCCA comienza por `03CMM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03CMM00002 - MURO PANTALLA 45 cm ESP. CUCH. MEC. Y 6 m PROF. (HA-25)

**Unidad:** m2.

Muro pantalla de 45 cm de espesor con cuchara mecánica y 6 m de profundidad formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de la coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00004 - MURO PANTALLA 45 cm ESP. CUCH. MEC. Y 6 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 45 cm de espesor con cuchara mecánica y 6 m de profundidad formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de la coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00007 - MURO PANTALLA 50 cm ESP. CUCH. HIDR. Y 6 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 50 cm de espesor con cuchara hidráulica y 6 m de profundidad formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de la coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00012 - MURO PANTALLA 45 cm ESP. CUCH. MEC. Y DE 6 A 15 m PROF. (HA-25)

**Unidad:** m2.

Muro pantalla CCP de 45 cm de espesor con cuchara mecánica y de 6 a 15 m de profundidad, formado por: excavación en zanja, lodos tixotropicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00014 - MURO PANTALLA 45 cm ESP. CUCH. MEC. Y DE 6 A 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 45 cm de espesor con cuchara mecánica y de 6 a 15 m de profundidad, formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00017 - MURO PANTALLA 50 cm ESP. CUCH. HIDR. Y DE 6 A 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 50 cm de espesor con cuchara hidráulica y de 6 a 15 m de profundidad, formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00022 - MURO PANTALLA 45 cm ESP. CUCH. MEC. Y MÁS DE 15 m PROF. (HA-25)

**Unidad:** m2.

Muro pantalla CCP de 45 cm de espesor con cuchara mecánica y más de 15 m de profundidad, formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00024 - MURO PANTALLA 45 cm ESP. CUCH. MEC. Y MÁS DE 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 45 cm de espesor con cuchara mecánica y más de 15 m de profundidad, formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00027 - MURO PANTALLA 50 cm ESP. CUCH. HIDR. Y MÁS DE 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 50 cm de espesor con cuchara hidráulica y más de 15 m de profundidad, formado por: excavación en zanja, lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00092 - MURO PANTALLA 60 cm ESP. CUCH. HIDR. Y 6 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 60 cm de espesor con cuchara hidráulica y 6 m de profundidad formado por: excavación en zanja, con lodos tixotropicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00102 - MURO PANTALLA 65 cm ESP. CUCH. MEC. Y 6 m PROF. (HA-25)

**Unidad:** m2.

Muro pantalla CCP de 65 cm de espesor con cuchara mecánica y 6 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00106 - MURO PANTALLA 65 cm ESP. CUCH. MEC. Y 6 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 65 cm de espesor con cuchara mecánica y 6 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduraso; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00109 - MURO PANTALLA 60 cm ESP. CUCH. HIDR. Y DE 6 A 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 60 cm de espesor con cuchara hidráulica y de 6 a 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00112 - MURO PANTALLA 65 cm ESP. CUCH. MEC. Y DE 6 A 15 m PROF. (HA-25)

**Unidad:** m2.

Muro pantalla CCP de 65 cm de espesor con cuchara mecánica y de 6 a 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00116 - MURO PANTALLA 65 cm ESP. CUCH. MEC. Y DE 6 A 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 65 cm de espesor con cuchara mecánica y de 6 a 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00119 - MURO PANTALLA 60 cm ESP. CUCH. HIDR. Y MÁS DE 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 60 cm de espesor con cuchara hidráulica y más de 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00122 - MURO PANTALLA 65 cm ESP. CUCH. MEC. Y MÁS DE 15 m PROF. (HA-25)

**Unidad:** m2.

Muro pantalla CCP de 65 cm de espesor con cuchara mecánica y más de 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-25/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM00126 - MURO PANTALLA 65 cm ESP. CUCH. MEC. Y MÁS DE 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 65 cm de espesor con cuchara mecánica y más de 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTEC. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

### 03CMM80010 - MURO PANTALLA 70 cm ESP. CUCH. MEC. Y MÁS DE 15 m PROF. (HA-30)

**Unidad:** m2.

Muro pantalla CCP de 70 cm de espesor con cuchara mecánica y más de 15 m de profundidad formado por: excavación en zanja, con lodos tixotrópicos, colocación de armadura (sin incluir esta), hormigónado del panel con hormigón para armar HA-30/F/20/XC2, consistencia fluida y tamaño máximo del árido 20 mm, incluso p.p. de encofrado de junta lateral, formación de murete guía, demolición del mismo y de coronación de pantalla, limpieza y doblado de armaduras; construido según NCSR-02, CodE y CTE. Medida la superficie ejecutada hasta la plataforma de apoyo del equipo.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Muros pantalla

**Clasificación:** 03CM. **Capítulo:** cimentaciones. **Familia:** cimentaciones especiales.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

El objeto de esta ficha es «muros pantalla», dentro de «cimentaciones especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

El procedimiento de cimentación profunda o consolidación necesita proyecto específico y registro individual de los elementos ejecutados. Registrar excavación por panel, estabilidad, limpieza de fondo, lodos si se utilizan, juntas y continuidad del hormigonado.

Para la variante «muros pantalla» se comprobarán expresamente terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; paneles, juntas, fluido de sostenimiento y tolerancias. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
