"""
# Recuperables - Metálicos

**Clasificación BCCA:** `03ERT`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Metálicos**, dentro de **Recuperables**.
Aplicable a las partidas cuyo código BCCA comienza por `03ERT`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03ERT00001 - ENCOFRADO METÁLICO EN ZUNCHOS, ZAPATAS Y ENCEPADOS

**Unidad:** m2.

Encofrado metálico en zunchos, zapatas y encepados, incluso limpieza, aplicación del desencofrante, desencofrado, y p.p. de elementos complementarios para su estabilidad y adecuada ejecución; construido según CodE. Medida la superficie de encofrado útil.

### 03ERT80050 - ENCOFRADO METÁLICO 1 C. EN MURO DE CONTENCIÓN

**Unidad:** m2.

Encofrado metálico en muro de contención a una cara, incluso limpieza, aplicación del desencofrante, desencofrado y p.p. de elementos complementarios para su estabilidad y adecuada ejecución; construido según CodE. Medida la superficie de encofrado útil.

### 03ERT80060 - ENCOFRADO METÁLICO 2 C. EN MURO DE CONTENCIÓN

**Unidad:** m2.

Encofrado metálico en muro de contención a dos caras, incluso limpieza, aplicación del desencofrante, desencofrado y p.p. de elementos complementarios para su estabilidad y adecuada ejecución; construido según CodE. Medida la superficie de encofrado útil.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Recuperables

**Clasificación:** 03ER. **Capítulo:** cimentaciones. **Familia:** encofrados.

"""
#### Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

El objeto de esta ficha es «recuperables», dentro de «encofrados». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

Verificar rigidez, estanqueidad y estabilidad del molde, así como su compatibilidad con juntas y desencofrado.

Para la variante «recuperables» se comprobarán expresamente presiones de hormigonado, apoyos, acabado y plazo de retirada. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

m² de superficie de encofrado en contacto con el hormigón según planos y geometría aceptada. Precisar si apeos, desencofrante, juntas, retirada y acabado quedan incluidos; no medir caras que no requieren molde.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
