# varios

**Clasificación:** 03AW. **Capítulo:** cimentaciones. **Familia:** armaduras.

## Descripción

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

Controlar certificados, diámetros, doblados, empalmes y posición; utilizar separadores adecuados y aceptar el armado antes de hormigonar.

Para la variante «varios» se comprobarán expresamente tipo de acero, despiece, anclajes, solapes y recubrimiento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

kg de acero conforme a despiece aprobado y a la regla contractual sobre longitudes y masa nominal; fijar tratamiento de empalmes, tornillos, soldaduras y mermas. No añadir pérdidas de taller ni protección si ya están incluidas en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
