# Sub bases - Común

**Clasificación:** 03WS  
**Capítulo:** Cimentaciones  
**Familia:** Varios  

## Descripción
Ejecución de capas auxiliares de apoyo y regularización (sub-bases granulares, capas de hormigón de limpieza o soleras de nivelación) sobre el fondo de excavación para la posterior recepción de elementos de cimentación.

## Ejecución
1. **Previos:** Replantear cotas, comprobar el estado del fondo de excavación (ausencia de agua, barro o suelo alterado) y verificar la capacidad portante del plano de apoyo según las especificaciones del estudio geotécnico.
2. **Puesta en obra:** Extendido, nivelación y compactación del material granular, o vertido y regleado del hormigón de limpieza, manteniendo las cotas, espesores y pendientes previstas en el proyecto.
3. **Control y recepción:** Comprobación del espesor final, cota de acabado y nivelación antes de autorizar el montaje de armaduras o el vertido de los elementos estructurales de cimentación.

## Medición
* **Unidad de medida:** Metro cúbico (m³) o metro cuadrado (m²) de sub-base ejecutada, según la naturaleza del material y el desglose del cuadro de precios.
* **Criterio:** Volumen o superficie neta realmente ejecutada y aceptada sobre la geometría teórica del plano de cimentación.

## Valoración
El precio unitario (€/m³ o €/m²) incluye:
* Mano de obra, herramientas, maquinaria de extendido, compactación o vertido y medios auxiliares.
* Suministro, transporte, descarga y colocación del material (árido/hormigón).
* Preparación, refino, limpieza y nivelación del plano de apoyo.