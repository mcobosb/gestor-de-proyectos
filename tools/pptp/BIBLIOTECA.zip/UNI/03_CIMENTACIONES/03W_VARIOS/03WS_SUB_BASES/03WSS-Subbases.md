"""
## Registro de cambios
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Sub-bases

**Clasificación BCCA:** `03WSS`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Sub-bases**, dentro de **Sub-bases**.
Aplicable a las partidas cuyo código BCCA comienza por `03WSS`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 03WSS00011 - RELLENO DE GRAVA GRUESA LIMPIA EN ELEM. CIMENT.

**Unidad:** m3.

Relleno de grava gruesa limpia en elementos de cimentación, incluso compactado de base y extendido con medios manuales. Medido el volumen ejecutado.

### 03WSS00012 - RELLENO DE GRAVA GRUESA LIMPIA EN LOSAS

**Unidad:** m3.

Relleno de grava gruesa limpia en losas, incluso compactado de base y extendido con medios manuales. Medido el volumen teórico ejecutado.

### 03WSS00013 - RELLENO DE GRAVA GRUESA LIMPIA EN TRASDOSADO

**Unidad:** m3.

Relleno de grava gruesa limpia en trasdósado, incluso extendido con medios manuales. Medido el volumen teorico ejecutado.

### 03WSS00131 - SUB-BASE DE ZAHORRA NATURAL

**Unidad:** m3.

Subbase de zahorra natural, realizada con medios mecánicos, incluso compactado y refino de base,relleno en tongadas de 20 cm comprendido extendido, regado y compactado al 95% proctor. Medido el volumen teórico ejecutado.

### 03WSS00331 - SUB-BASE DE ALBERO EN RAMA

**Unidad:** m3.

Subbase de albero en rama, realizada con medios mecánicos, incluso compactado y refino de base, relleno en tongadas de 20 cm comprendido extendido, regado y compactado al 95% proctor. Medido el volumen teórico ejecutado.

### 03WSS80000 - CAPA DE HORMIGÓN DE LIMPIEZA 10 cm ESP. MEDIO

**Unidad:** m2.

Capa de hormigón de limpieza HM-20/P/20/X0, consistencia plástica y tamaño máximo del árido 20 mm, de 10 cm de espesor mínimo, en elementos de cimentación, suministrado y puesto en obra, incluso p.p. de alisado de la superficie; según CodE y CTE. Medida la superficie ejecutada.

### 03WSS80020 - CAPA DE HORMIGÓN DE LIMPIEZA 10 cm RESIST. SULFATOS

**Unidad:** m2.

Capa de hormigón de limpieza HM-30/P/20/XC2+XA2, consistencia plástica y tamaño máximo del árido 20 mm, resistente a los sulfatos, de 10 cm de espesor mínimo, en elementos de cimentación, suministrado y puesto en obra, incluso p.p. de alisado de la superficie; según CodE y CTE. Medida la superficie ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Sub bases

**Clasificación:** 03WS  
**Capítulo:** Cimentaciones  
**Familia:** Varios  

"""
#### Descripción
Ejecución de capas auxiliares de apoyo y regularización (sub-bases granulares, capas de hormigón de limpieza o soleras de nivelación) sobre el fondo de excavación para la posterior recepción de elementos de cimentación.

#### Ejecución
	**1. Previos:** Replantear cotas, comprobar el estado del fondo de excavación (ausencia de agua, barro o suelo alterado) y verificar la capacidad portante del plano de apoyo según las especificaciones del estudio geotécnico.
	**2. Puesta en obra:** Extendido, nivelación y compactación del material granular, o vertido y regleado del hormigón de limpieza, manteniendo las cotas, espesores y pendientes previstas en el proyecto.
	**3. Control y recepción:** Comprobación del espesor final, cota de acabado y nivelación antes de autorizar el montaje de armaduras o el vertido de los elementos estructurales de cimentación.

#### Medición
	* **Unidad de medida:** Metro cúbico (m³) o metro cuadrado (m²) de sub-base ejecutada, según la naturaleza del material y el desglose del cuadro de precios.
	* **Criterio:** Volumen o superficie neta realmente ejecutada y aceptada sobre la geometría teórica del plano de cimentación.

#### Valoración
El precio unitario (€/m³ o €/m²) incluye:
	* Mano de obra, herramientas, maquinaria de extendido, compactación o vertido y medios auxiliares.
	* Suministro, transporte, descarga y colocación del material (árido/hormigón).
	* Preparación, refino, limpieza y nivelación del plano de apoyo.
