"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Rellenos - A brazo

**Clasificación BCCA:** `02RRB`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **A brazo**, dentro de **Rellenos**.
Aplicable a las partidas cuyo código BCCA comienza por `02RRB`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02RRB00001 - RELLENO CON TIERRAS REALIZADO CON MEDIOS MANUALES

**Unidad:** m3.

Relleno con tierras realizado con medios manuales, extendido en tongadas de 20 cm, comprendiendo: extendido, regado y compactado con pisón mecánico al 95% proctor, en 20 cm de profundidad. Medido el volumen en perfil compactado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

"""
### Relleno de trasdós con material seleccionado
"""

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Relleno compactado junto a muros con material seleccionado de préstamos.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 501–505. Transcripción para trazabilidad.
"""

Se definen los siguientes rellenos en trasdós de muro:
- Relleno de trasdós de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos.

#### Ejecución

Esperar la resistencia y autorización del muro, disponer drenaje y extender tongadas sin dañar impermeabilización ni generar empujes excesivos de compactación. Usar equipos adecuados a la distancia al paramento y verificar humedad y densidad con el criterio aprobado para el trasdós.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 570–576. Transcripción para trazabilidad.
"""

Los materiales de relleno se extenderán en tongadas sucesivas de espesor uniforme y sensiblemente horizontales. El espesor de estas tongadas será lo suficientemente reducido para que, con los medios disponibles, se obtenga en toda ella el mismo grado de compactación exigido.
Los materiales de cada tongada serán de características uniformes o, si no lo fueran, se conseguirá esta uniformidad mezclándose convenientemente con los medios adecuados.
Una vez extendida la tongada, se procederá a su humectación, si es necesario. El contenido óptimo de humedad se determinará en obra, a la vista de la maquinaria disponible y de los resultados que se obtengan de los ensayos realizados.
En los casos especiales en que la humedad natural del material sea excesiva para conseguir la compactación prevista, se tomarán las medidas adecuadas, procediendo incluso a la desecación por oreo, o por adición y mezcla de materiales secos o sustancias apropiadas.
Conseguida la humectación más conveniente, se procederá a la compactación mecánica de la tongada. El grado de compactación a alcanzar en cada tongada en ningún caso será inferior al mayor del que posean los terrenos o materiales adyacentes, a su mismo nivel y siempre igual o superior al ochenta  y cinco por ciento (85 %) del Ensayo Próctor.
Las zonas que, por su forma, pudieran retener aguas en su superficie, se corregirán inmediatamente por el contratista.

#### Medición y valoración

Por m³ colocados y compactados, con transporte, humectación y compactación incluidos conforme a 3.26.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 506–507. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1137–1139. Transcripción para trazabilidad.
"""

Los rellenos se medirán por metro cúbico (m3) compactado, adaptando los perfiles teóricos de zanja de los planos a los datos del terreno resultante de los replanteos definitivos. El abono se efectuará por aplicación de los precios correspondientes del presupuesto, cualquiera que sea la procedencia de los materiales y la distancia de transporte.
En dicho precio están incluidos todos los materiales, equipo y operaciones necesarias para la completa terminación de la unidad de referencia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Relleno filtrante de trasdós
"""

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Material granular drenante colocado detrás de los muros para evacuar agua y limitar presiones hidrostáticas.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 501–505. Transcripción para trazabilidad.
"""

Se definen los siguientes rellenos en trasdós de muro:
- Relleno de trasdós de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos.

#### Ejecución

Definir compatibilidad de filtro con el suelo, conexión con drenajes y necesidad de separación. Extender sin contaminar el árido ni dañar los elementos de drenaje y asegurar salida efectiva y mantenible del agua. Controlar espesor y compactación compatibles con el muro.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 570–576. Transcripción para trazabilidad.
"""

Los materiales de relleno se extenderán en tongadas sucesivas de espesor uniforme y sensiblemente horizontales. El espesor de estas tongadas será lo suficientemente reducido para que, con los medios disponibles, se obtenga en toda ella el mismo grado de compactación exigido.
Los materiales de cada tongada serán de características uniformes o, si no lo fueran, se conseguirá esta uniformidad mezclándose convenientemente con los medios adecuados.
Una vez extendida la tongada, se procederá a su humectación, si es necesario. El contenido óptimo de humedad se determinará en obra, a la vista de la maquinaria disponible y de los resultados que se obtengan de los ensayos realizados.
En los casos especiales en que la humedad natural del material sea excesiva para conseguir la compactación prevista, se tomarán las medidas adecuadas, procediendo incluso a la desecación por oreo, o por adición y mezcla de materiales secos o sustancias apropiadas.
Conseguida la humectación más conveniente, se procederá a la compactación mecánica de la tongada. El grado de compactación a alcanzar en cada tongada en ningún caso será inferior al mayor del que posean los terrenos o materiales adyacentes, a su mismo nivel y siempre igual o superior al ochenta  y cinco por ciento (85 %) del Ensayo Próctor.
Las zonas que, por su forma, pudieran retener aguas en su superficie, se corregirán inmediatamente por el contratista.

#### Medición y valoración

Por m³ según 3.26, con suministro, transporte y operaciones incluidas; drenajes o geotextiles sólo se separan si así lo prevé su partida.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 506–507. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Relleno localizado con material filtrante
"""

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Relleno granular permeable destinado a permitir drenaje sin arrastre del terreno adyacente.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 425–429. Transcripción para trazabilidad.
"""

Se definen los siguientes rellenos localizados:
- Relleno localizado de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos

#### Ejecución

Definir granulometría, permeabilidad y compatibilidad de filtro con el suelo y los drenajes. Recibir material limpio y extender evitando contaminación, segregación y daño de tubos o geotextiles, si están previstos. Compactar con el método aprobado y comprobar continuidad de la evacuación.

#### Medición y valoración

Por m³ colocados según 3.21; suministro, transporte y operaciones incluidos, con geotextil o drenajes separados sólo si el presupuesto lo establece.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 430–431. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Relleno localizado con material seleccionado
"""

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Aportación y compactación localizada de material seleccionado procedente de préstamos en zonas de dimensiones reducidas.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 425–429. Transcripción para trazabilidad.
"""

Se definen los siguientes rellenos localizados:
- Relleno localizado de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 565–569. Transcripción para trazabilidad.
"""

Se define como relleno la extensión y compactación de materiales pétreos o terrosos para relleno de zanjas, trasdós de obras de fábrica, o cualquier otra zona cuyas dimensiones no permitan la utilización de los grandes equipos de maquinaria con que se lleva a cabo la ejecución de terraplenes o pedraplenes.

Los suelos para rellenos en general serán de los clasificados como adecuados o tolerables en el PG

#### Ejecución

Aprobar procedencia y características del suelo conforme al proyecto y al PG-3 incorporado. Preparar apoyo y drenaje, extender tongadas compatibles con el equipo ligero, ajustar humedad y verificar densidad. No cargar estructuras ni conducciones antes de su resistencia o autorización.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 570–576. Transcripción para trazabilidad.
"""

Los materiales de relleno se extenderán en tongadas sucesivas de espesor uniforme y sensiblemente horizontales. El espesor de estas tongadas será lo suficientemente reducido para que, con los medios disponibles, se obtenga en toda ella el mismo grado de compactación exigido.
Los materiales de cada tongada serán de características uniformes o, si no lo fueran, se conseguirá esta uniformidad mezclándose convenientemente con los medios adecuados.
Una vez extendida la tongada, se procederá a su humectación, si es necesario. El contenido óptimo de humedad se determinará en obra, a la vista de la maquinaria disponible y de los resultados que se obtengan de los ensayos realizados.
En los casos especiales en que la humedad natural del material sea excesiva para conseguir la compactación prevista, se tomarán las medidas adecuadas, procediendo incluso a la desecación por oreo, o por adición y mezcla de materiales secos o sustancias apropiadas.
Conseguida la humectación más conveniente, se procederá a la compactación mecánica de la tongada. El grado de compactación a alcanzar en cada tongada en ningún caso será inferior al mayor del que posean los terrenos o materiales adyacentes, a su mismo nivel y siempre igual o superior al ochenta  y cinco por ciento (85 %) del Ensayo Próctor.
Las zonas que, por su forma, pudieran retener aguas en su superficie, se corregirán inmediatamente por el contratista.

#### Medición y valoración

Por m³ realmente colocados y compactados, con transporte, humectación y compactación incluidos conforme a 3.21.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 430–431. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1137–1139. Transcripción para trazabilidad.
"""

Los rellenos se medirán por metro cúbico (m3) compactado, adaptando los perfiles teóricos de zanja de los planos a los datos del terreno resultante de los replanteos definitivos. El abono se efectuará por aplicación de los precios correspondientes del presupuesto, cualquiera que sea la procedencia de los materiales y la distancia de transporte.
En dicho precio están incluidos todos los materiales, equipo y operaciones necesarias para la completa terminación de la unidad de referencia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Relleno y compactación de zanjas
"""

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Relleno de la envolvente y del resto de la zanja tras la colocación y aceptación de las tuberías, con materiales compatibles con cada zona.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 565–569. Transcripción para trazabilidad.
"""

Se define como relleno la extensión y compactación de materiales pétreos o terrosos para relleno de zanjas, trasdós de obras de fábrica, o cualquier otra zona cuyas dimensiones no permitan la utilización de los grandes equipos de maquinaria con que se lleva a cabo la ejecución de terraplenes o pedraplenes.

Los suelos para rellenos en general serán de los clasificados como adecuados o tolerables en el PG

#### Ejecución

No cubrir sin los controles y autorización previstos. Ejecutar el apoyo y relleno lateral simétrico sin desplazar el tubo; compactar por tongadas con equipos que no lo dañen y ajustar el recubrimiento antes de usar maquinaria pesada. La humedad, el ensayo de referencia y el grado de compactación se fijarán por zona en el procedimiento aprobado.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 123–126. Transcripción para trazabilidad.
"""

Cuando en los trabajos de excavación aparezcan servicios existentes, los trabajos se ejecutarán con medios adecuados para no dañar la instalación completándose con el colgado o calzado de dichas instalaciones. Todo ello no dará lugar a compensación económica alguna.
El relleno se ejecutará de acuerdo a lo especificado en planos de proyecto, teniendo en cuenta que el material en contacto con la tubería no tendrá áridos con tamaño superior a 2 cm. Si en el presupuesto no se incluye partida especifica para cama o protección de arena, esta se considera incluida en los precios, si el Director de obra considera necesario su colocación.
La compactación de las zanjas se hará con el mismo grado que el exigido a los terraplenes, es decir al 98% del Proctor Modificado.
Previo al relleno de las zanjas será necesaria la aprobación expresa de la Dirección Facultativa. En caso contrario podrá exigirse el descubrimiento de la tubería con cargo al Contratista.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 577–583. Transcripción para trazabilidad.
"""

En general, se considera de aplicación lo indicado en III.2.2., con un grado de compactación no inferior al (95%) del Próctor Normal, tanto en rellenos ordinarios como seleccionados.
No serán rellenadas las zanjas hasta que se hayan realizado todas las pruebas necesarias sobre la conducción y lo autorice el Director de las obras.
Sin embargo, si, teniendo en cuenta las características de la tubería, existe peligro de flotación en el caso de llenarse las zanjas por fuertes lluvias o por agua freática, deberá efectuarse un relleno parcial de las mismas hasta contrarrestar este peligro, pero teniendo en cuenta de que si al efectuar las pruebas correspondientes no resultasen satisfactorias, todas las maniobras de excavar de nuevo el relleno o su posterior colocación correrán por cuenta del contratista.
Tanto el relleno de arena, como el relleno seleccionado de productos de excavación, se realizarán cuidadosamente por tongadas no mayores de quince (15) centímetros de espesor, las cuales se compactarán con mecanismos adecuados, manuales o mecánicos, hasta que la tubería esté cubierta por un espesor mínimo de treinta (30) centímetros. Se pondrá especial cuidado en la compactación de los flancos del tubo.
La superficie de arena para asiento de la tubería estará perfectamente enrasada con una tolerancia no superior a un (1) centímetro en la longitud del tubo, de forma que permita que éstos se apoyen sin discontinuidad a lo largo de su generatriz inferior, salvo en las zonas de juntas.
En zona de cultivos el relleno superior de tierra vegetal se efectuará con una compactación ligera, dejando una sobre elevación sobre el terreno circundante de unos diez (10) centímetros para que permita el asentamiento natural de aquel.

#### Medición y valoración

Medir en m³ compactados según la sección teórica aprobada, deduciendo los volúmenes según la partida. Incluir suministro, transporte, humectación y compactación que el precio contemple; no duplicar cama y protección si ya forman parte de la conducción.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 127–130. Transcripción para trazabilidad.
"""

La excavación se abonará por metros cúbicos (m³) y la medición de la excavación se realizará sobre los perfiles teóricos de proyecto, no habiendo lugar al abono de la sobre excavación, quedando incluido dentro del precio el agotamiento y entibación de las mismas, así como el calzado de los servicios existentes.
El precio fijado en el proyecto será independiente de las características geotécnicas del terreno. La medición del relleno de las zanjas se hará de acuerdo a las secciones tipo teóricas definidas en proyecto y el abono se hará por metros cúbicos (m³).
En el precio del relleno se encuentran incluidos la aportación de materiales procedentes de prestamos, incluida su excavación y trasporte, la compactación por tongadas no superiores a 20 cms de espesor obteniendo una densidad superior al 95% de la máxima obtenida en el ensayo Proctor Modificado.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1137–1139. Transcripción para trazabilidad.
"""

Los rellenos se medirán por metro cúbico (m3) compactado, adaptando los perfiles teóricos de zanja de los planos a los datos del terreno resultante de los replanteos definitivos. El abono se efectuará por aplicación de los precios correspondientes del presupuesto, cualquiera que sea la procedencia de los materiales y la distancia de transporte.
En dicho precio están incluidos todos los materiales, equipo y operaciones necesarias para la completa terminación de la unidad de referencia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
