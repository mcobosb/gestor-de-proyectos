# Relleno localizado con material filtrante

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Relleno granular permeable destinado a permitir drenaje sin arrastre del terreno adyacente.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 425–429. Transcripción para trazabilidad.

Se definen los siguientes rellenos localizados:
- Relleno localizado de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos

## Ejecución

Definir granulometría, permeabilidad y compatibilidad de filtro con el suelo y los drenajes. Recibir material limpio y extender evitando contaminación, segregación y daño de tubos o geotextiles, si están previstos. Compactar con el método aprobado y comprobar continuidad de la evacuación.

## Medición y valoración

Por m³ colocados según 3.21; suministro, transporte y operaciones incluidos, con geotextil o drenajes separados sólo si el presupuesto lo establece.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 430–431. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
