# Relleno y compactación de zanjas - Común

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Relleno de la envolvente y del resto de la zanja tras la colocación y aceptación de las tuberías, con materiales compatibles con cada zona.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 565–569. Transcripción para trazabilidad.

Se define como relleno la extensión y compactación de materiales pétreos o terrosos para relleno de zanjas, trasdós de obras de fábrica, o cualquier otra zona cuyas dimensiones no permitan la utilización de los grandes equipos de maquinaria con que se lleva a cabo la ejecución de terraplenes o pedraplenes.

Los suelos para rellenos en general serán de los clasificados como adecuados o tolerables en el PG

## Ejecución

No cubrir sin los controles y autorización previstos. Ejecutar el apoyo y relleno lateral simétrico sin desplazar el tubo; compactar por tongadas con equipos que no lo dañen y ajustar el recubrimiento antes de usar maquinaria pesada. La humedad, el ensayo de referencia y el grado de compactación se fijarán por zona en el procedimiento aprobado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 123–126. Transcripción para trazabilidad.

Cuando en los trabajos de excavación aparezcan servicios existentes, los trabajos se ejecutarán con medios adecuados para no dañar la instalación completándose con el colgado o calzado de dichas instalaciones. Todo ello no dará lugar a compensación económica alguna.
El relleno se ejecutará de acuerdo a lo especificado en planos de proyecto, teniendo en cuenta que el material en contacto con la tubería no tendrá áridos con tamaño superior a 2 cm. Si en el presupuesto no se incluye partida especifica para cama o protección de arena, esta se considera incluida en los precios, si el Director de obra considera necesario su colocación.
La compactación de las zanjas se hará con el mismo grado que el exigido a los terraplenes, es decir al 98% del Proctor Modificado.
Previo al relleno de las zanjas será necesaria la aprobación expresa de la Dirección Facultativa. En caso contrario podrá exigirse el descubrimiento de la tubería con cargo al Contratista.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 577–583. Transcripción para trazabilidad.

En general, se considera de aplicación lo indicado en III.2.2., con un grado de compactación no inferior al (95%) del Próctor Normal, tanto en rellenos ordinarios como seleccionados.
No serán rellenadas las zanjas hasta que se hayan realizado todas las pruebas necesarias sobre la conducción y lo autorice el Director de las obras.
Sin embargo, si, teniendo en cuenta las características de la tubería, existe peligro de flotación en el caso de llenarse las zanjas por fuertes lluvias o por agua freática, deberá efectuarse un relleno parcial de las mismas hasta contrarrestar este peligro, pero teniendo en cuenta de que si al efectuar las pruebas correspondientes no resultasen satisfactorias, todas las maniobras de excavar de nuevo el relleno o su posterior colocación correrán por cuenta del contratista.
Tanto el relleno de arena, como el relleno seleccionado de productos de excavación, se realizarán cuidadosamente por tongadas no mayores de quince (15) centímetros de espesor, las cuales se compactarán con mecanismos adecuados, manuales o mecánicos, hasta que la tubería esté cubierta por un espesor mínimo de treinta (30) centímetros. Se pondrá especial cuidado en la compactación de los flancos del tubo.
La superficie de arena para asiento de la tubería estará perfectamente enrasada con una tolerancia no superior a un (1) centímetro en la longitud del tubo, de forma que permita que éstos se apoyen sin discontinuidad a lo largo de su generatriz inferior, salvo en las zonas de juntas.
En zona de cultivos el relleno superior de tierra vegetal se efectuará con una compactación ligera, dejando una sobre elevación sobre el terreno circundante de unos diez (10) centímetros para que permita el asentamiento natural de aquel.

## Medición y valoración

Medir en m³ compactados según la sección teórica aprobada, deduciendo los volúmenes según la partida. Incluir suministro, transporte, humectación y compactación que el precio contemple; no duplicar cama y protección si ya forman parte de la conducción.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 127–130. Transcripción para trazabilidad.

La excavación se abonará por metros cúbicos (m³) y la medición de la excavación se realizará sobre los perfiles teóricos de proyecto, no habiendo lugar al abono de la sobre excavación, quedando incluido dentro del precio el agotamiento y entibación de las mismas, así como el calzado de los servicios existentes.
El precio fijado en el proyecto será independiente de las características geotécnicas del terreno. La medición del relleno de las zanjas se hará de acuerdo a las secciones tipo teóricas definidas en proyecto y el abono se hará por metros cúbicos (m³).
En el precio del relleno se encuentran incluidos la aportación de materiales procedentes de prestamos, incluida su excavación y trasporte, la compactación por tongadas no superiores a 20 cms de espesor obteniendo una densidad superior al 95% de la máxima obtenida en el ensayo Proctor Modificado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1137–1139. Transcripción para trazabilidad.

Los rellenos se medirán por metro cúbico (m3) compactado, adaptando los perfiles teóricos de zanja de los planos a los datos del terreno resultante de los replanteos definitivos. El abono se efectuará por aplicación de los precios correspondientes del presupuesto, cualquiera que sea la procedencia de los materiales y la distancia de transporte.
En dicho precio están incluidos todos los materiales, equipo y operaciones necesarias para la completa terminación de la unidad de referencia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
