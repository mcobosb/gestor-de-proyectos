# Relleno filtrante de trasdós

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Material granular drenante colocado detrás de los muros para evacuar agua y limitar presiones hidrostáticas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 501–505. Transcripción para trazabilidad.

Se definen los siguientes rellenos en trasdós de muro:
- Relleno de trasdós de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos.

## Ejecución

Definir compatibilidad de filtro con el suelo, conexión con drenajes y necesidad de separación. Extender sin contaminar el árido ni dañar los elementos de drenaje y asegurar salida efectiva y mantenible del agua. Controlar espesor y compactación compatibles con el muro.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 570–576. Transcripción para trazabilidad.

Los materiales de relleno se extenderán en tongadas sucesivas de espesor uniforme y sensiblemente horizontales. El espesor de estas tongadas será lo suficientemente reducido para que, con los medios disponibles, se obtenga en toda ella el mismo grado de compactación exigido.
Los materiales de cada tongada serán de características uniformes o, si no lo fueran, se conseguirá esta uniformidad mezclándose convenientemente con los medios adecuados.
Una vez extendida la tongada, se procederá a su humectación, si es necesario. El contenido óptimo de humedad se determinará en obra, a la vista de la maquinaria disponible y de los resultados que se obtengan de los ensayos realizados.
En los casos especiales en que la humedad natural del material sea excesiva para conseguir la compactación prevista, se tomarán las medidas adecuadas, procediendo incluso a la desecación por oreo, o por adición y mezcla de materiales secos o sustancias apropiadas.
Conseguida la humectación más conveniente, se procederá a la compactación mecánica de la tongada. El grado de compactación a alcanzar en cada tongada en ningún caso será inferior al mayor del que posean los terrenos o materiales adyacentes, a su mismo nivel y siempre igual o superior al ochenta  y cinco por ciento (85 %) del Ensayo Próctor.
Las zonas que, por su forma, pudieran retener aguas en su superficie, se corregirán inmediatamente por el contratista.

## Medición y valoración

Por m³ según 3.26, con suministro, transporte y operaciones incluidas; drenajes o geotextiles sólo se separan si así lo prevé su partida.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 506–507. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
