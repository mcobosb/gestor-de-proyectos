"""
# Varios - Varios

**Clasificación BCCA:** `02WWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `02WWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02WWW00001 - TIERRAS ADQUIRIDAS EN PRÉSTAMO

**Unidad:** m3.

Tierras adquiridas en préstamo, comprendiendo excavación y canon de adquisición, pero sin incluir carga a camión y transporte desde la cantera al lugar de empleo. Medido el volumen en perfil natural.

### 02WWW01N - DEMOLICIÓN CUBRICIÓN FIBROCEMENTO/AMIANTO

**Unidad:** m².

Demolición de cubrición de placas onduladas de fibrocemento con presencia de amianto, incluidos caballetes, limas, canalones, remates laterales, encuentros con paramentos, etc., por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona limitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW02N - DESMONTAJE JARDINERAS DE FIBROCEMENTO/AMIANTO

**Unidad:** m.

Desmontaje de jardineras de fibrocemento con amianto, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW03N - DEMOLICIÓN CHIMENEAS EN CUBIERTA FIBROCEMENTO/AMIANTO

**Unidad:** m.

Demolición de chimeneas formadas por conductos de fibrocemento con amianto en su composición, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW04N - LEVANT. CANALONES Y BAJANTES FIBROCEMENTO/AMIANTO

**Unidad:** m.

Levantamiento de bajantes y canalones de fibrocemente con amianto en su composición, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento espedífico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW05N - DEM. SAN. ENT. T. FIBROCEMENTO A MANO

**Unidad:** m.

Demolición de colectores de saneamiento enterrados, de tubos de fibrocemento con amianto en su composición, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW06N - DEM. SAN. COLG. T. FIBROCEMENTO A MANO

**Unidad:** m.

Demolición de colectores de saneamiento colgados, de tubos de fibrocemento con amianto en su composición, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW07N - DEMOL. CUBIERTA FIBROCEMENTO/AMIANTO <4m

**Unidad:** m².

Demolición completa de cubierta formada de placas onduladas de fibrocemento con presencia de amianto y estructura de entramado de cerchas y correas metálicas situadas a menos de 4 metros de altura, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW08N - DEMOL. CUBIERTA FIBROCEMENTO/AMIANTO >4m

**Unidad:** m².

Demolición completa de cubierta formada de placas onduladas de fibrocemento con presencia de amianto y estructura de entramado de cerchas y correas metálicas situadas a más de 4 metros de altura, por medios manuales y sin aprovechamiento del material desmontado, incluso limpieza, plastificado, etiquetado y paletizado en zona delimitada y protegida a pie de carga, sin transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW09N - RETIRADA DE RESIDUOS CON AMIANTO

**Unidad:** kg.

Retirada de residuos de elementos de fibrocemento con amianto previamente plastificados y paletizados con transporte a centro de tratamiento específico (vertedero toxicológico), siendo retirado por empresa cualificada e inscrita en el Registro de Empresas con Riesgo al Amianto, utilizando los operarios todos los medios auxiliares necesarios en este tipo de trabajos, y con p.p. de medios auxiliares.

### 02WWW10N - ANÁLISIS AMBIENTAL AMIANTO

**Unidad:** u.

Análisis cuantitativo de muestras ambientales. Metodo del filtro de membrana/microscópia óptica de contraste de fases (método multifibra), incluido redacción de informe en cumplimiento del RD 396/2006.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### VARIOS - varios

**Clasificación:** 02WW. **Capítulo:** acondicionamiento de terrenos. **Familia:** varios.

"""
#### Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Estabilizar el sistema auxiliar y controlar sus efectos sobre el entorno, registrando movimientos y caudales durante su funcionamiento.

Para la variante «varios» se comprobarán expresamente sistema específico, cálculo provisional, agua y afecciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Excavaciones y rellenos: m³ entre perfiles aprobados, distinguiendo terreno en banco y relleno compactado. Refino o compactación superficial: m². Transportes y sostenimientos requieren partida y base propias, sin volver a abonar operaciones incluidas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
