"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Galerías

**Clasificación BCCA:** `02WGG`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Galerías**, dentro de **Galerías**.
Aplicable a las partidas cuyo código BCCA comienza por `02WGG`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02WGG00001 - EXC. GALERÍA. BAJO ELEM. CONSTRUC. DIVERSOS, TIERRAS C. DURA

**Unidad:** m3.

Excavación en galería por debajo de elementos constructivos diversos, en tierras de consistencia dura, realizada con medios manuales, incluso p.p. de limpieza y extracción de tierras a los bordes. Medido el volumen en perfil natural.

### 02WGG00002 - EXC. GALERÍA. BAJO ELEM. CONSTRUC. DIVERSOS, TIERRAS C. MEDIA

**Unidad:** m3.

Excavación en galería por debajo de elementos constructivos diversos, en tierras de consistencia media, realizada con medios manuales, incluso p.p. de limpieza y extracción de tierras a los bordes. Medido el volumen en perfil natural.

### 02WGG00003 - EXC. GALERÍA. BAJO ELEM. CONSTRUC. DIVERSOS, TIERRAS C. BLANDA

**Unidad:** m3.

Excavación en galería por debajo de elementos constructivos diversos, en tierras de consistencia blanda, realizada con medios manuales, incluso p.p. de limpieza y extracción de tierras a los bordes. Medido el volumen en perfil natural.

### 02WGG90001 - EXC. GALERÍA BAJO ELEMEN. CONSTR. DIVERSOS, TIERRA C. DURA

**Unidad:** m3.

Excavación en galería por debajo de elementos constructivos diversos, en tierras de consistencia dura, realizada con medios mecánicos, incluso p.p. de limpieza y extracción de tierras a los bordes. Medido el volumen en perfil natural.

### 02WGG90002 - EXC. GALERÍA BAJO ELEMEN. CONSTR. DIVERSOS, TIERRA C. MEDIA

**Unidad:** m3.

Excavación en galería por debajo de elementos constructivos diversos, en tierras de consistencia media, realizada con medios mecánicos, incluso p.p. de limpieza y extracción de tierras a los bordes. Medido el volumen en perfil natural.

### 02WGG90003 - EXC. GALERÍA BAJO ELEMEN. CONSTRUC. DIVERSOS, TIERRA C. BLANDA

**Unidad:** m3.

Excavación en galería por debajo de elementos constructivos diversos, en tierras de consistencia blanda, realizada con medios mecánicos, incluso p.p. de limpieza y extracción de tierras a los bordes. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Galerías

**Clasificación:** 02WG. **Capítulo:** acondicionamiento de terrenos. **Familia:** varios.

"""
#### Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

El objeto de esta ficha es «galerías», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Estabilizar el sistema auxiliar y controlar sus efectos sobre el entorno, registrando movimientos y caudales durante la excavación. Ejecutar los trabajos subterráneos con sostenimiento, ventilación, evacuación y control de atmósfera adecuados a las condiciones de la excavación.

Para la variante «galerías» se comprobarán expresamente sistema específico, cálculo provisional, agua y afecciones; sección, terreno, sostenimiento y emergencia. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Excavaciones y rellenos: m³ entre perfiles aprobados, distinguiendo terreno en banco y relleno compactado. Refino o compactación superficial: m². Transportes y sostenimientos requieren partida y base propias, sin volver a abonar operaciones incluidas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
