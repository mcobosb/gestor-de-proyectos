"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# A brazo

**Clasificación BCCA:** `02PBB`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **A brazo**, dentro de **A brazo**.
Aplicable a las partidas cuyo código BCCA comienza por `02PBB`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02PBB00001 - EXC. POZOS TIERRA C. DURA, M. MANUALES, PROF. MAX. 1,50 m

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia dura realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00002 - EXC. POZOS TIERRA C. MEDIA, M. MANUALES, PROF. MAX. 1,50 m

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia media, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00003 - EXC. POZOS TIERRA C. BLANDA, M. MANUALES, PROF. MAX. 1,50 m

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia blanda, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00004 - EXC. POZOS ROCA BLANDA M. MANUALES, PROF. MAX. 1,50 m

**Unidad:** m3.

Excavación, en pozos, de roca blanda, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02PBB00005 - EXC. POZOS TERR. DISGREGADO M. MANUALES PROF. MAX 1,50 m

**Unidad:** m3.

Excavación, en pozos, en terrenos disgregados, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00006 - EXC. POZOS ESCOMBROS MEDIOS MANUALES HASTA 1,50 m

**Unidad:** m3.

Excavación, en pozos, de escombros, realizada con medios manuales hasta una profundidad máxima a 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00007 - EXC. POZOS TERRENO FANGOSO M. MANUALES PROF. MAX 1,50 m

**Unidad:** m3.

Excavación, en pozos, de terreno fangoso, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes y p.p. de agotamiento de aguas. Medido el volumen en perfil natural.

### 02PBB00008 - EXC. POZOS ROCA DURA, M. MANUALES, PROF. MAX. 1,50 m

**Unidad:** m3.

Excavación, en pozos, de roca dura, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extraccción a los bordes, y perfilado de fondos, laterales y empleo de compresor. Medido el volumen en perfil natural.

### 02PBB00009 - EXC. POZOS ROCA DURA, M. MAN., PROF. MAX. 1,50 m EXPLOSIVOS

**Unidad:** m3.

Excavación, en pozos, de roca dura realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes, empleo de compresor y utilización de explosivos. Medido el volumen en perfil natural.

### 02PBB00011 - EXC. POZOS TIERRA C. DURA M. MANUALES PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en pozos, de tierra de consistencia dura, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00012 - EXC. POZOS TIERRA C. MEDIA M. MANUALES PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en pozos, de tierra de consistencia media, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00013 - EXC. POZOS TIERRA C. BLANDA M. MANUALES PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en pozos, de tierra de consistencia blanda realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00015 - EXC. POZOS TERR. DISGREGADO M. MANUALES PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en pozos, de terreno disgregado, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00016 - EXC. POZOS ROCA BLANDA M. MANUALES, PROF. ENTRE 1,50 Y 3 m

**Unidad:** m3.

Excavación, en pozos, de roca blanda, realizada con medios manuales a una profundidad comprendida entre 1,50 m y 3 m, incluso extracción a los bordes y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02PBB00017 - EXC. POZOS ROCA DURA, M. MANUAL, ENTRE 1,50 Y 3 m Y EXPLOSIVOS

**Unidad:** m3.

Excavación, en pozos, de roca dura, realizada con medios manuales a una profundidad comprendida entre 1,50 m y 3 m, incluso extracción a los bordes, empleo de compresor y utilización de explosivos. Medido el volumen en perfil natural.

### 02PBB00018 - EXC. POZOS ROCA DURA, M. MANUAL, PROF. ENTRE 1,50 Y 3 m

**Unidad:** m3.

Excavación, en pozos, de roca dura, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extraccción a los bordes, y perfilado de fondos, laterales y empleo de compresor. Medido el volumen en perfil natural.

### 02PBB00021 - EXC. POZOS TERRENO FANGOSO M. MANUALES PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en pozos, de terreno fangoso, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes y p.p. de agotamiento de aguas. Medido el volumen en perfil natural.

### 02PBB00022 - EXC. POZOS ESCOMBROS MEDIOS MANUALES PROF. ENTRE 1,50 Y 3 m

**Unidad:** m3.

Excavación, en pozos, de escombros, realizada con medios manuales a una profundidad comprendida entre 1,50 m y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00027 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES <,= 25%, P

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción no mayor del 25%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00028 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES 25% A 50%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción del 25% a 50%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00029 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES 50% A 75%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción del 50% a 75%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00030 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES >,= 75%, P

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción del 25% a 50%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00031 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES <,= 25%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción no mayor del 25%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00032 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES 25% A 50%

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda  y escombros, realizada con medios manuales, en una proporción del 25% a 50%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00033 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES 50% A 75%

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción del 50% a 75%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00034 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES >,= 75%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción mayor de 75%, hasta una profundidad máxima de 1,50, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00063 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES <,= 25%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción no mayor del 25%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00064 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES 25% A 50%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción del 25% a 50%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00065 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES 50% A 75%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción del 50% a 75%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil naturalMedido el volumen en perfil natural.

### 02PBB00066 - EXC. MIXTA TIERRAS C. MEDIA, Y ESCOMBROS, M. MANUALES >,= 75%, P

**Unidad:** m3.

Excavación mixta de tierras de consistencia media y escombros, realizada con medios manuales, en una proporción mayor de 75%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00067 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES <,= 25%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción no mayor del 25%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00068 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES 25% A 50%

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción del 25% a 50%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00069 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES 50% A 75%

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción del 50% a 75%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02PBB00070 - EXC. MIXTA TIERRAS C. BLANDA, Y ESCOMBROS, M. MANUALES >,= 75%,

**Unidad:** m3.

Excavación mixta de tierras de consistencia blanda y escombros, realizada con medios manuales, en una proporción mayor de 75%, hasta una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### A brazo

**Clasificación:** 02PB. **Capítulo:** acondicionamiento de terrenos. **Familia:** pozos.

"""
#### Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

El objeto de esta ficha es «a brazo», dentro de «pozos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Comprobar estabilidad del pozo y accesos; impedir entradas de agua y aplicar las medidas de recinto confinado cuando correspondan.

Para la variante «a brazo» se comprobarán expresamente profundidad, sección, sostenimiento y ventilación. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Excavaciones y rellenos: m³ entre perfiles aprobados, distinguiendo terreno en banco y relleno compactado. Refino o compactación superficial: m². Transportes y sostenimientos requieren partida y base propias, sin volver a abonar operaciones incluidas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
