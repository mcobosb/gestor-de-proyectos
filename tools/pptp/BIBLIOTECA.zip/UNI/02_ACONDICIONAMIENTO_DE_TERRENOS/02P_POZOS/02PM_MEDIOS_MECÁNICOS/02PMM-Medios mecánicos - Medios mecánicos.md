"""
# Medios mecánicos - Medios mecánicos

**Clasificación BCCA:** `02PMM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Medios mecánicos**, dentro de **Medios mecánicos**.
Aplicable a las partidas cuyo código BCCA comienza por `02PMM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02PMM00001 - EXC. POZOS TIERRA C. DURA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia dura, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00002 - EXC. POZOS TIERRA C. MEDIA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia media realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00003 - EXC. POZOS TIERRA C. BLANDA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia blanda, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00004 - EXC. POZOS ROCA BLANDA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, de roca blanda realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes, perfilado de fondos y laterales y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02PMM00005 - EXC. POZOS TERR. DISGREGADO, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, en terrenos disgregados, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00006 - EXC. POZOS ESCOMBROS, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, en escombros, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00010 - EXC. POZOS ROCA DURA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos, de roca dura, realizada con medios mecánicos hasta una profundidad máxima de4 m, incluso extraccción a los bordes, y perfilado de fondos, laterales y empleo de compresor. Medido el volumen en perfil natural.

### 02PMM00011 - EXC. POZOS ROCA DURA, M. MEC., PROF. MAX. 4 m EXPLOSIVOS

**Unidad:** m3.

Excavación, en pozos, de roca dura realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes, empleo de compresor y utilización de explosivos. Medido el volumen en perfil natural.

### 02PMM00050 - EXC. POZOS CILÍNDR. C. MEDIA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos cilíndricos, de tierras de consistencia media, realizada con medios mecánicos, hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00051 - EXC. POZOS CILÍNDR. C. BLANDA, M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos cilíndricos, de tierras de consistencia blanda, realizada con medios mecánicos, hasta una profundidad máxima de 4m., incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00052 - EXC. POZOS CILÍNDR. C. M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos cilíndricos, de tierras de consistencia dura, realizada con medios mecánicos, hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado en fondos y laterales. Medido el volumen en perfil natural.

### 02PMM00053 - EXC. POZOS CILÍNDR. TERR. DISGREG., M. MECÁNICOS, PROF. MAX. 4 m

**Unidad:** m3.

Excavación, en pozos cilíndricos, de terreno disgregado realizada con medios mecánicos, hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM90011 - EXC. POZOS TIERRA C. DURA, M. MEC. HASTA 40 cm ANCHO CUCHARA

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia dura, realizada con medios mecánicos hasta una profundidad máxima de 4 my cuchara de 40 cm ancho incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM90012 - EXC. POZOS TIERRA C. MEDIA, M. MEC. HASTA 40 cm ANCHO CUCHARA

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia media, realizada con medios mecánicos hasta una profundidad máxima de 4 m y cuchara de 40 cm ancho incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM90013 - EXC. POZOS TIERRA C. BLANDA, M. MEC. HASTA 40 cm ANCHO CUCHARA

**Unidad:** m3.

Excavación, en pozos, de tierras de consistencia blanda, realizada con medios mecánicos hasta una profundidad máxima de 4 m y cuchara de 40 cm ancho incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02PMM90014 - EXC. POZOS TERRENO DISGREGADO, M. MEC. HASTA 40 cm ANCHO CUCHARA

**Unidad:** m3.

Excavación, en pozos, en terreno disgregado, realizada con medios mecánicos hasta una profundidad máxima de 4 m y cuchara de 40 cm ancho incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Medios mecánicos

**Clasificación:** 02PM. **Capítulo:** acondicionamiento de terrenos. **Familia:** pozos.

"""
#### Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

El objeto de esta ficha es «medios mecánicos», dentro de «pozos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Comprobar estabilidad del pozo y accesos; impedir entradas de agua y aplicar las medidas de recinto confinado cuando correspondan.

Para la variante «medios mecánicos» se comprobarán expresamente profundidad, sección, sostenimiento y ventilación. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Excavaciones y rellenos: m³ entre perfiles aprobados, distinguiendo terreno en banco y relleno compactado. Refino o compactación superficial: m². Transportes y sostenimientos requieren partida y base propias, sin volver a abonar operaciones incluidas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
