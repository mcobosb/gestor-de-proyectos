"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# A brazo

**Clasificación BCCA:** `02ZBB`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **A brazo**, dentro de **A brazo**.
Aplicable a las partidas cuyo código BCCA comienza por `02ZBB`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02ZBB00001 - EXC. ZANJAS, TIERRA C. DURA, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia dura, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00002 - EXC. ZANJAS, TIERRA C. MEDIA, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia media, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00003 - EXC. ZANJAS, TIERRA C.LANDA, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia blanda, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00004 - EXC. ZANJAS, ROCA BLANDA, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, de roca blanda, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02ZBB00005 - EXC. ZANJAS, TERR. DISGREGADO, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, en terrenos disgregados, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extración a los bordes. Medido el volumen en perfil natural.

### 02ZBB00006 - EXC. ZANJAS, TERRENO FANGOSO, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, de terreno fangoso realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes y p.p. de agotamiento de aguas. Medido el volumen en perfil natural.

### 02ZBB00007 - EXC. ZANJAS, ROCA DURA, M. MANUALES, PROF. MÁX. 1,50 m

**Unidad:** m3.

Excavación, en zanjas, de roca dura, con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes, perfilado de fondos y laterales y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02ZBB00009 - EXC. ZANJAS, ROCA DURA, M. MANUAL. PROF. MÁX. 1,50 m EXPLOSIVOS

**Unidad:** m3.

Excavación, en zanjas, de roca dura, realizada con medios manuales hasta una profundidad máxima de 1,50 m, incluso extracción a los bordes, empleo de compresor y utilización de explosivos. Medido el volumen en perfil natural.

### 02ZBB00011 - EXC. ZANJAS, TIERRA C. DURA, M. MANUALES, PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia dura, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00012 - EXC. ZANJAS, TIERRA C. MEDIA, M. MANUALES, PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia media, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00013 - EXC. ZANJAS, TIERRA C. BLANDA, M. MANUALES, PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia blanda, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00015 - EXC. ZANJAS, TERR. DISGREGADO, M. MANUALES, PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en zanjas, de terreno disgregado, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes. Medido el volumen en perfil natural.

### 02ZBB00017 - EXC. ZANJAS, ROCA BLANDA, M. MAN., PROF. ENTRE 1,50 Y 3 m

**Unidad:** m3.

Excavación, en zanjas, de roca blanda, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes, perfilado de fondos y laterales y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02ZBB00018 - EXC. ZANJAS, ROCA DURA, M. MAN., PROF. ENTRE 1,50 Y 3 m

**Unidad:** m3.

Excavación, en zanjas, de roca dura, con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes, perfilado de fondos y laterales y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02ZBB00019 - EXC. ZANJAS, ROCA DURA, M. MAN., ENTRE 1,50 Y 3 m Y EXPLOSIVOS

**Unidad:** m3.

Excavación, en zanjas, de roca dura, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes, empleo de compresor y utilización de explosivos. Medido el volumen en perfil natural.

### 02ZBB00021 - EXC. ZANJAS, TERRENO FANGOSO, M. MANUALES, PROF. 1,50 A 3 m

**Unidad:** m3.

Excavación, en zanjas, de terreno fangoso, realizada con medios manuales a una profundidad comprendida entre 1,50 y 3 m, incluso extracción a los bordes y p.p. de agotamiento de aguas. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### A brazo

**Clasificación:** 02ZB. **Capítulo:** acondicionamiento de terrenos. **Familia:** zanjas.

"""
#### Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

El objeto de esta ficha es «a brazo», dentro de «zanjas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Localizar redes y comprobar sección, fondo y sostenimiento; no apoyar la conducción sobre terreno reblandecido o alterado.

Para la variante «a brazo» se comprobarán expresamente ancho, profundidad, cama y distancias a servicios. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Excavaciones y rellenos: m³ entre perfiles aprobados, distinguiendo terreno en banco y relleno compactado. Refino o compactación superficial: m². Transportes y sostenimientos requieren partida y base propias, sin volver a abonar operaciones incluidas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
