# Excavación en zanjas y pozos para tuberías - Común

**Clasificación:** 02ZM  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** Zanjas y canalizaciones  

## Descripción
Apertura de zanjas y pozos mediante medios mecánicos para la instalación de canalizaciones de servicios y saneamiento, incluyendo la protección de redes existentes, sostenimiento del terreno, agotamiento de aguas y el posterior relleno y compactación.

## Ejecución
1. **Previos:** Replantear alineaciones y cotas rojas. Localizar e identificar servicios urbanos existentes (procediendo a su apeo, calzado o colgado de seguridad). Evaluar la estabilidad de las paredes para determinar la entibación necesaria (según RD 1627/1997).
2. **Excavación y achique:** Apertura de la zanja respetando los anchos y profundidades teóricas de proyecto (garantizando recubrimientos mínimos de 1,00 m). Mantener el fondo de zanja seco y firme mediante bombeo o agotamiento de filtraciones sin arrastre de finos. Acopiar el material apto en el lateral separado del borde.
3. **Control, relleno y remate:** Inspección del fondo de zanja antes de colocar la cama. Relleno por tongadas no superiores a 20 cm con material sin gruesos (>2 cm en contacto con el tubo) y compactado al 98% del Próctor Modificado. 

## Medición
* **Unidad de medida:** Metro cúbico (m³) de zanja excavada y metro cúbico (m³) de relleno compactado.
* **Criterio:** Volumen neto medido sobre la sección tipo teórica del proyecto adaptada al replanteo aprobado. No se medirán sobreexcavaciones por conveniencia del contratista.

## Valoración
El precio unitario (€/m³) incluye:
* Mano de obra, herramientas, maquinaria de excavación, elevación, carga y compactación.
* Entibación, sostenimiento del terreno y agotamiento/bombeo de aguas pluviales o freáticas.
* Calzado, apeo y protección de servicios enterrados existentes.
* Carga, transporte y gestión de excedentes o no aptos a vertedero/gestor autorizado, así como la aportación de materiales de préstamo para relleno si fuera preciso.