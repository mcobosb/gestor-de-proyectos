"""
## Registro de cambios
- Versión: 4 | Autor: - | Fecha: 11/11/2026 | Cambio: Rev.01
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Medios mecánicos

**Clasificación BCCA:** `02ZMM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Medios mecánicos**, dentro de **Medios mecánicos**.
Aplicable a las partidas cuyo código BCCA comienza por `02ZMM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02ZMM00001 - EXC. ZANJAS, TIERRAS C. DURA, M. MECÁNICOS, PROF. MÁX. 4 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia dura, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02ZMM00002 - EXC. ZANJAS, TIERRAS C. MEDIA, M. MECÁNICOS, PROF. MÁX. 4 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia media, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02ZMM00003 - EXC. ZANJAS, TIERRAS C. BLANDA, M. MECÁNICOS, PROF. MÁX. 4 m

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia blanda, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02ZMM00004 - EXC. ZANJAS, ROCA BLANDA, M. MECÁNICOS, PROF. MÁX. 4 m

**Unidad:** m3.

Excavación, en zanjas, de roca blanda, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes, perfilado de fondos y laterales y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02ZMM00005 - EXC. ZANJAS, TERRENO DISGREGADO, M. MECÁNICOS, PROF. MÁX. 4 m

**Unidad:** m3.

Excavación, en zanjas, de terreno disgregado, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02ZMM00010 - EXC. ZANJAS, ROCA DURA, M. MECÁNICOS, PROF. MÁX. 4 m

**Unidad:** m3.

Excavación en zanjas, de roca dura con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes, perfilado de fondos y laterales y p.p. de empleo de compresor. Medido el volumen en perfil natural.

### 02ZMM00011 - EXC. ZANJAS, ROCA DURA, M. MEC. PROF. MÁX. 4 m EXPLOSIVOS

**Unidad:** m3.

Excavación, en zanjas, de roca dura, realizada con medios mecánicos hasta una profundidad máxima de 4 m, incluso extracción a los bordes, empleo de compresor y utilización de explosivos. Medido el volumen en perfil natural.

### 02ZMM90001 - EXC. ZANJA TIERRA C. DURA, PROF. MAX. 1,5 m M. MEC. CUCH. 40 cm

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia dura, realizada con medios mecánicos hasta una profundidad máxima de 1,5 m y cuchara de 40 cm ancho, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02ZMM90002 - EXC. ZANJA TIERRA C. MEDIA, PROF. MAX. 1,5 m M. MEC. CUCH. 40 cm

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia media, realizada con medios mecánicos hasta una profundidad máxima de 1,5 m y cuchara de 40 cm ancho, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02ZMM90003 - EXC. ZANJA TIERRA C. BLANDA, PROF. MAX. 1,5 m M. MEC. CUCH. 40cm

**Unidad:** m3.

Excavación, en zanjas, de tierras de consistencia blanda, realizada con medios mecánicos hasta una profundidad máxima de 1,5 m y cuchara de 40 cm ancho, incluso extracción a los bordes y perfilado de fondos y laterales. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Excavación en zanjas y pozos para tuberías

**Clasificación:** 02ZM  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** Zanjas y canalizaciones  

"""
#### Descripción
Apertura de zanjas y pozos mediante medios mecánicos en tierras de consistencia media, utilizando cuchara o cuchara de excavadora de 40 cm de ancho, hasta una profundidad máxima de 1,5 m, para la instalación de canalizaciones de servicios y saneamiento. Incluye el perfilado de fondos y laterales, la extracción del terreno a los bordes, la protección de redes existentes, el sostenimiento del terreno, el agotamiento de aguas y el posterior relleno y compactación.

#### Ejecución
	**1. Previos:** Replantear alineaciones, anchos y cotas rojas. Localizar e identificar servicios urbanos existentes (procediendo a su apeo, calzado o colgado de seguridad). Evaluar la estabilidad de las paredes para determinar la entibación necesaria (según RD 1627/1997).
	**2. Excavación y achique:** Apertura de la zanja mediante pala/cuchara de 40 cm de ancho en tierras de consistencia media hasta la profundidad máxima de 1,5 m, extrayendo el material sobrante a los bordes y ejecutando el perfilado manual o mecánico de los fondos y paramentos laterales. Mantener el fondo seco y firme mediante bombeo o agotamiento de filtraciones sin arrastre de finos.
	**3. Control, relleno y remate:** Inspección del fondo de zanja y perfilado antes de colocar la cama de asiento. Relleno por tongadas no superiores a 20 cm con material apto (sin gruesos >2 cm en contacto con la tubería) y compactado al 98% del Próctor Modificado.

#### Medición
	* **Unidad de medida:** Metro cúbico (m³) de zanja excavada en perfil natural y metro cúbico (m³) de relleno compactado.
	* **Criterio:** Volumen neto realmente ejecutado y medido en su perfil natural sobre las secciones teóricas de proyecto aprobadas en la comprobación del replanteo. No se medirán sobreexcavaciones no autorizadas ni excesos por conveniencia del contratista.

#### Valoración
El precio unitario (€/m³) incluye:
	* Mano de obra, herramientas manuales, maquinaria de excavación equipada con cuchara de 40 cm de ancho, elevación, carga y compactación.
	* Extracción de las tierras a los bordes de la zanja, así como el perfilado exacto de fondos y laterales.
	* Entibación, sostenimiento del terreno y agotamiento/bombeo de aguas pluviales o freáticas.
	* Calzado, apeo y protección de servicios enterrados existentes.
	* Carga, transporte y gestión de excedentes a vertedero o gestor autorizado, así como la aportación de materiales de préstamo para relleno si fuera preciso.