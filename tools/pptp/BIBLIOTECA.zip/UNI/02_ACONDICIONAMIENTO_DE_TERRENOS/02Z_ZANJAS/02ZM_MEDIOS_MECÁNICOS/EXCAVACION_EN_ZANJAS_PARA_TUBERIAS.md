# Excavación en zanjas y pozos para tuberías

**Clasificación:** 02ZM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Apertura de zanjas y excavaciones auxiliares para alojar conducciones, con sostenimiento, protección de servicios y agotamiento según las necesidades del terreno.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 116–118. Transcripción para trazabilidad.

Está unidad comprende todas las operaciones necesarias para abrir las zanjas para la ejecución de la red de alcantarillado, incluso su entibación y drenaje, así como el posterior relleno y compactación de los mismos.

## Ejecución

Localizar servicios, replantear, definir taludes o entibación según la evaluación del terreno y proteger bordes y accesos. Excavar con cotas y anchuras aprobadas, evitar sobreexcavaciones y mantener el fondo estable y sin agua perjudicial. No condicionar la protección frente al derrumbe únicamente a superar una profundidad fija: aplicar el anexo IV del RD 1627/1997.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 119–126. Transcripción para trazabilidad.

La excavación se realizará acopiando los materiales a un lado de la zanja, sin mezclar las diferentes partes del material que pueden componer la explanada, para facilitar un posterior relleno.
Si durante la ejecución de la excavación aparecen manantiales o filtraciones motivadas por cualquier causa se utilizarán los medios necesarios para agotar las mismas.
En zanjas con profundidades superiores a 2 m será obligatoria la entibación de la misma, aunque el Director de la Obra podrá autorizar la sobre excavación como método sustitutivo sin que dicha sobre excavación tenga derecho a abono.
Cuando en los trabajos de excavación aparezcan servicios existentes, los trabajos se ejecutarán con medios adecuados para no dañar la instalación completándose con el colgado o calzado de dichas instalaciones. Todo ello no dará lugar a compensación económica alguna.
El relleno se ejecutará de acuerdo a lo especificado en planos de proyecto, teniendo en cuenta que el material en contacto con la tubería no tendrá áridos con tamaño superior a 2 cm. Si en el presupuesto no se incluye partida especifica para cama o protección de arena, esta se considera incluida en los precios, si el Director de obra considera necesario su colocación.
La compactación de las zanjas se hará con el mismo grado que el exigido a los terraplenes, es decir al 98% del Proctor Modificado.
Previo al relleno de las zanjas será necesaria la aprobación expresa de la Dirección Facultativa. En caso contrario podrá exigirse el descubrimiento de la tubería con cargo al Contratista.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 560–564. Transcripción para trazabilidad.

Se efectuarán las zanjas con las alineaciones y desniveles previstos en los planos del proyecto, replanteos definitivos o con las modificaciones que en su caso estime la Dirección de la obra.

La apertura de la zanja se efectuará con medios mecánicos. En el caso de efectuarse manualmente por alguna causa justificada y admitida por la dirección de la obra, esta partida conllevará precio contradictorio y será a abonar al contratista como tal.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 947–953. Transcripción para trazabilidad.

En lo referente a excavación y relleno de la misma, es preceptivo lo indicado en el Pliego de Condiciones Generales para Obras de Carreteras y Puentes (PG 3).
El ancho de la zanja viene definido por la sección tipo indicada en los planos, que se considera suficiente para los trabajos de colocación, sin embargo si por cualquier consideración el Contratista modificase esta dimensión por propia conveniencia, no podrá exigir aumento alguno en los volúmenes de excavación y por lo tanto en los precios correspondientes. La profundidad de la zanja viene dada por la cota roja de los perfiles longitudinales del trazado, sin embargo deberá cuidarse, con pequeñas rectificaciones del mismo si fuesen necesarias, que en todo momento el recubrimiento de la tubería sobre la arista superior de la misma, sea de un ( 1 ) metro. Excepcionalmente en algún pequeño tramo podrá aceptarse un recubrimiento de sesenta (60) centímetros, siempre que exista garantía de que no haya circulación rodada superior. En caso contrario deberá disponerse una losa de reparto de hormigón armado, que será sometida a la aprobación del Director de las Obras.
Como norma general los tubos se bajarán al fondo de la zanja con los elementos adecuados, según el peso y la longitud del tubo y la posible entibación de la zanja. Se centrarán debidamente con los adyacentes, y a continuación se procederá a fijarlos.
Las tuberías y zanjas se mantendrán libres de agua mediante los correspondientes desagües en la excavación y si fuera preciso se agotará el agua con bomba.
Cuando las pendientes de las zanjas sean superiores al diez por ciento (10%), la tubería se colocará en sentido ascendente. Si a juicio del Director de las Obras, no es posible colocarla en sentido ascendente, se tomarán las precauciones debidas para evitar el deslizamiento de los tubos. Si se precisa reajustar algún tubo, deberá levantarse el relleno y prepararlo como para su primera colocación.
Cuando se interrumpa la colocación de la tubería se taponarán los extremos libres, para impedir la entrada de agua o cuerpos extraños, y al reanudar el trabajo se examinará con todo cuidado el interior de la tubería, por si pudiera haberse introducido algún cuerpo extraño en la misma.

## Medición y valoración

Medir en m³ sobre perfiles teóricos adaptados al replanteo aprobado. Conservar las inclusiones de entibación, agotamiento y protección de servicios del original; el uso excepcional de medios manuales requiere el procedimiento contractual que corresponda, no un precio creado por esta ficha.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 127–130. Transcripción para trazabilidad.

La excavación se abonará por metros cúbicos (m³) y la medición de la excavación se realizará sobre los perfiles teóricos de proyecto, no habiendo lugar al abono de la sobre excavación, quedando incluido dentro del precio el agotamiento y entibación de las mismas, así como el calzado de los servicios existentes.
El precio fijado en el proyecto será independiente de las características geotécnicas del terreno. La medición del relleno de las zanjas se hará de acuerdo a las secciones tipo teóricas definidas en proyecto y el abono se hará por metros cúbicos (m³).
En el precio del relleno se encuentran incluidos la aportación de materiales procedentes de prestamos, incluida su excavación y trasporte, la compactación por tongadas no superiores a 20 cms de espesor obteniendo una densidad superior al 95% de la máxima obtenida en el ensayo Proctor Modificado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1112–1114. Transcripción para trazabilidad.

El precio correspondiente a cualquier excavación comprende, salvo que expresamente no se indique otra cosa en el Cuadro de Precios o en este Pliego, todos los trabajos necesarios para realizarla y sacar los productos resultantes, o sea, la excavación, elevación y carga de los productos, transporte a vertedero o lugar de empleo, descarga y, en los casos en que fuese preciso, las entibaciones y agotamientos.
Para realizar los agotamientos el Contratista utilizará los medios e instalaciones adecuadas para agotar el agua y verterla en algún cauce o colector. Cuando estas operaciones den lugar a arrastres del terreno, se evitarán los agotamientos y se adoptarán las medidas que juzgue convenientes el Director de la obra. Serán de cuenta del Contratista incluso los agotamientos que sea preciso realizar durante el plazo de garantía de las obras.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1134–1136. Transcripción para trazabilidad.

La medición se efectuará adaptando los perfiles teóricos de zanjas de los planos a los datos del terreno resultantes de los replanteos definitivos.
El abono se efectuará por metro cúbico (mi) y de acuerdo con el precio correspondiente del presupuesto, en el que se hallan comprendidas todas las partidas necesarias para la completa terminación de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
