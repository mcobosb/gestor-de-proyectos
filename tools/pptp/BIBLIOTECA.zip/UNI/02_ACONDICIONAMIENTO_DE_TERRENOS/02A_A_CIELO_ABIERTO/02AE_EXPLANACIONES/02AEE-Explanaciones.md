"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Explanaciones

**Clasificación BCCA:** `02AEE`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Explanaciones**, dentro de **Explanaciones**.
Aplicable a las partidas cuyo código BCCA comienza por `02AEE`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02AEE00001 - EXPLANACIÓN DE 50 cm ESP., TIERRAS CONSIST. BLANDA

**Unidad:** m2.

Explanación de 50 cm de espesor medio, con tierras de consistencia blanda, comprendiendo:excavación con medios mecánicos, transporte a relleno, extendido en tongadas de 20 cm y compactado con medios mecánicos al 95% proctor normal. Medida la superficie en verdadera magnitud.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

"""
### Excavación para formación de explanada y cajeo
"""

**Clasificación:** 02AE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Excavación en desmonte o apertura de caja hasta la explanada y geometría definidas en planos, incluidos los ajustes de taludes y cunetas no revestidas previstos.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 31–36. Transcripción para trazabilidad.
"""

Comprende los trabajos necesarios para conseguir la explanada definitiva en zonas en desmonte o la formación de la caja necesaria.
Incluirá la amplificación, mejora o rectificación de los taludes así como su refino, y la ejecución de cunetas provisionales o definitivas, siempre que estas no sean revestidas.
Condición que han de cumplir los materiales La explanada deberá cumplir las condiciones exigidas a los suelos adecuado en el Pliego de Prescripciones Técnicas Generales para Obras de Carretera y Puentes.
En caso contrario se procederá a la sustitución de material al menos en sus 50 cm superiores hasta formar una explanada E2.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 554–555. Transcripción para trazabilidad.
"""

#### Ejecución

Aprobar perfiles previos y replanteo, excavar de forma estable, clasificar los productos aprovechables y mantener drenaje y accesos seguros. Revisar la capacidad del fondo con la dirección antes de cubrirlo y ejecutar el refino y la compactación aprobados. La obtención de una explanada E2 exige comprobar la sección y el comportamiento del conjunto, no sólo sustituir un espesor sin justificación.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 37–42. Transcripción para trazabilidad.
"""

Antes de comenzar la excavación de un tramo vial el contratista requerirá la autorización expresa de la Dirección Facultativa comprobándose la toma de perfiles trasversales.
En el caso de explanada mejorada ésta no se extenderá hasta tanto no haya sido aprobado por la Dirección Facultativa la nivelación y comprobación del terreno natural.
Cuando la excavación llegue a la rasante de la explanada se requerirá la aprobación de la misma a la Dirección Facultativa.
Si la explanación no cumple las condiciones de capacidad portante necesaria, el Director podrá ordenar su excavación con objeto de aportar posteriormente una explanada mejorada.
Posteriormente se ejecutará el refino de la explanada y taludes, así como la compactación de la explanada.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 556–559. Transcripción para trazabilidad.
"""

Una vez terminadas las operaciones de desbroce y demolición del terreno, se iniciarán las obras de excavación, ajustándose a las alineaciones, pendientes, dimensiones y demás información contenida en los planos, el presente pliego, replanteos definitivos, y a lo que sobre el particular ordene el Director de las Obras.
Se tomarán todas las precauciones necesarias para alterar lo menos posible la roca o el terreno, en las proximidades del perfil de excavación, tanto en soleras como en taludes.

Toda excavación realizada por conveniencia de la propiedad o del contratista, y tras la aprobación por parte de la Dirección de la Obra, en exceso sobre los perfiles prescritos, será a expensas de uno u otro respectivamente, con la condición de que si excede en taludes tendrá que seguir hasta la superficie del terreno con la pendiente prescrita para no dejar huecos en los mismos.

#### Medición y valoración

Medir en m³ mediante perfiles aprobados, sin abonar sobreexcavaciones no autorizadas. El alcance del transporte se debe fijar conforme al contrato.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 43–47. Transcripción para trazabilidad.
"""

Se medirá por metros cúbicos (m3) realmente excavados medidos por diferencia entre los perfiles tomados antes y después de los trabajos.
Si durante las excavaciones aparecen manantiales o filtraciones motivadas por cualquier causa, los trabajos específicos que sea preciso ejecutar para eliminarlas se considerarán incluidas en los precios de excavación.
En el precio de las excavaciones se encuentra incluido el transporte a cualquier distancia, tanto a terraplén como a vertedero. Para su vertido en terraplén será necesaria la aprobación previa y expresa de la Dirección Facultativa.
Se entiende que el precio de la excavación incluye todos los materiales y operaciones para ejecutar correctamente la unidad.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1112–1118. Transcripción para trazabilidad.
"""

El precio correspondiente a cualquier excavación comprende, salvo que expresamente no se indique otra cosa en el Cuadro de Precios o en este Pliego, todos los trabajos necesarios para realizarla y sacar los productos resultantes, o sea, la excavación, elevación y carga de los productos, transporte a vertedero o lugar de empleo, descarga y, en los casos en que fuese preciso, las entibaciones y agotamientos.
Para realizar los agotamientos el Contratista utilizará los medios e instalaciones adecuadas para agotar el agua y verterla en algún cauce o colector. Cuando estas operaciones den lugar a arrastres del terreno, se evitarán los agotamientos y se adoptarán las medidas que juzgue convenientes el Director de la obra. Serán de cuenta del Contratista incluso los agotamientos que sea preciso realizar durante el plazo de garantía de las obras.

Se medirán por los metros cúbicos (m³) resultantes de la diferencia entre el perfil natural del terreno y los correspondientes perfiles fijados en los Planos, midiéndose la longitud según el eje materializado en los Planos, incluyéndose en el mismos el volumen correspondiente a la tierra vegetal. El precio incluye las operaciones indicadas en el Artículo 4.7. excepto, transporte y descarga de productos, y además las correspondientes a la señalización, medidas de seguridad y cierre temporal de la zona de los trabajos, así como un acabado de los taludes suave, uniforme, ajustado a lo estipulado en Planos y totalmente acorde con la superficie del terreno natural colindante.
Los perfiles del Proyecto se aprobarán o modificarán al efectuarse la comprobación del replanteo de las obras, y al pie de las diversas hojas de Planos, figurará la conformidad del Director de la obra, del Contratista, o de las personas en quien éstos deleguen. Durante la ejecución de los trabajos se sacarán cuantos perfiles transversales se estimen necesarios, firmándose igualmente las hojas correspondientes por ambas partes. No se admitirá ninguna reclamación del Contratista sobre el volumen resultante que no esté basada en las hojas anteriormente citadas.
No será de abono el exceso de excavación producido sobre los perfiles señalados en los Planos, ni los rellenos que hubiese que efectuar para conseguir la geometría prevista.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Refino de la explanada
"""

**Clasificación:** 02AE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Operaciones de acabado geométrico de la explanada antes de ejecutar el firme.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 584–585. Transcripción para trazabilidad.
"""

Consiste en el conjunto de operaciones necesarias para conseguir el acabado geométrico de la explanada fijado en planos.

#### Ejecución

Replantear cotas y perfiles, corregir irregularidades mediante escarificado y recrecido compatible, compactar y comprobar rasante, regularidad y ausencia de zonas que retengan agua. No cubrir sin aceptación del soporte y de su capacidad.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 586–592. Transcripción para trazabilidad.
"""

Se ejecutará con posterioridad a la explanación y construcción de todos los servicios que discurran por ella, e inmediatamente antes de iniciarse la construcción del firme.
Si hubiese que proceder a un recrecido de espesor inferior a la mitad (1/2) de la tongada compactada, se procederá previamente a un escarificado de todo el espesor de la misma, con objeto de asegurar la trabazón entre el recrecido y su asiento.
No se extenderá la subbase del firme sin que, antes, se comprueben las condiciones de calidad y características geométricas de la explanada.
En la explanada se dispondrán estacas de refino a lo largo del eje y a ambos bordes de la misma, con una distancia entre perfiles transversales no superiores a veinte metros (20 m) y niveladas hasta milímetros (mm) con arreglo a los Planos. En los recuadros entre estacas, la superficie no rebasará la teórica definida por ellas, ni rebajará de ella más de tres centímetros (3 cm) en ningún punto.
La superficie acabada no deberá variar en más de quince milímetros (15 mm) cuando se compruebe con una regla de tres metros (3 m), aplicada tanto paralela como normalmente al eje de la carretera.
Tampoco podrá haber zonas capaces de retener agua.
Las irregularidades que excedan de dichas tolerancias se corregirán por el Contratista.

#### Medición y valoración

El original lo incluye en excavaciones y zahorra. No establecer abono separado sin partida específica; si la hubiera, su unidad y geometría de medición deben fijarse en ella.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 43–47. Transcripción para trazabilidad.
"""

Se medirá por metros cúbicos (m3) realmente excavados medidos por diferencia entre los perfiles tomados antes y después de los trabajos.
Si durante las excavaciones aparecen manantiales o filtraciones motivadas por cualquier causa, los trabajos específicos que sea preciso ejecutar para eliminarlas se considerarán incluidas en los precios de excavación.
En el precio de las excavaciones se encuentra incluido el transporte a cualquier distancia, tanto a terraplén como a vertedero. Para su vertido en terraplén será necesaria la aprobación previa y expresa de la Dirección Facultativa.
Se entiende que el precio de la excavación incluye todos los materiales y operaciones para ejecutar correctamente la unidad.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 78–80. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos medidos sobre perfil teórico de planos una vez compactado.
El precio incluye la adquisición, transporte, extendido, humectación y compactación de la zahorra artificial, el refino y compactación de la explanada, y todos aquellos materiales y maquinaria necesarios para dejar la obra correctamente terminada, incluso la utilización de medios de compactación especiales para zonas singulares o el extendido a mano.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
