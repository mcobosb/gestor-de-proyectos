"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Apertura de cajas - Varios

**Clasificación BCCA:** `02ACW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Apertura de cajas**.
Aplicable a las partidas cuyo código BCCA comienza por `02ACW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Apertura de cajas

**Clasificación:** 02AC  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** A cielo abierto  

"""
#### Descripción
Vaciado y excavación del terreno a cielo abierto hasta la cota de subrasante prevista para la implantación de la caja de firme, aceras o viales, incluyendo el refino y perfilado de la superficie resultante.

#### Ejecución
1. **Previos:** Replantear cotas, levantar perfiles topográficos previos, comprobar la ubicación de servicios urbanos/redes subterráneas y verificar el drenaje superficial de la zona de trabajo.
2. **Excavación y vaciado:** Extracción del terreno por medios mecánicos hasta la sección y pendiente autorizadas, clasificando los productos extraídos (aprovechables para relleno o a retirar a vertedero/gestor).
3. **Control y refinado:** Perfilado final de la caja, comprobación de la estabilidad de bordes/taludes, verificación de cotas y eliminación de materiales no aptos antes de la compactación de la subrasante.

#### Medición
* **Unidad de medida:** Metro cúbico (m³) de terreno excavado sobre perfil teórico en banco (o metro cuadrado, m², para refino superficial de caja según desglose del cuadro de precios).
* **Criterio:** Volumen neto realmente excavado entre perfiles topográficos iniciales y finales aceptados.

#### Valoración
El precio unitario (€/m³ o €/m²) incluye:
* Mano de obra, herramientas, maquinaria de excavación, refino y medios auxiliares.
* Excavación, perfilado de fondo y paredes de la caja, y acopio intermedio.
* Carga y transporte del material sobrante o no apto a vertedero o gestor autorizado.
