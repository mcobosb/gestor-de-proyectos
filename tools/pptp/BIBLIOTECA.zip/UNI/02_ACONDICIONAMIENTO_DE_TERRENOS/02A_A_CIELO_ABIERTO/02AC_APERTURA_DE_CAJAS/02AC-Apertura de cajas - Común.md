# Apertura de cajas - Común

**Clasificación:** 02AC  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** A cielo abierto  

## Descripción
Vaciado y excavación del terreno a cielo abierto hasta la cota de subrasante prevista para la implantación de la caja de firme, aceras o viales, incluyendo el refino y perfilado de la superficie resultante.

## Ejecución
1. **Previos:** Replantear cotas, levantar perfiles topográficos previos, comprobar la ubicación de servicios urbanos/redes subterráneas y verificar el drenaje superficial de la zona de trabajo.
2. **Excavación y vaciado:** Extracción del terreno por medios mecánicos hasta la sección y pendiente autorizadas, clasificando los productos extraídos (aprovechables para relleno o a retirar a vertedero/gestor).
3. **Control y refinado:** Perfilado final de la caja, comprobación de la estabilidad de bordes/taludes, verificación de cotas y eliminación de materiales no aptos antes de la compactación de la subrasante.

## Medición
* **Unidad de medida:** Metro cúbico (m³) de terreno excavado sobre perfil teórico en banco (o metro cuadrado, m², para refino superficial de caja según desglose del cuadro de precios).
* **Criterio:** Volumen neto realmente excavado entre perfiles topográficos iniciales y finales aceptados.

## Valoración
El precio unitario (€/m³ o €/m²) incluye:
* Mano de obra, herramientas, maquinaria de excavación, refino y medios auxiliares.
* Excavación, perfilado de fondo y paredes de la caja, y acopio intermedio.
* Carga y transporte del material sobrante o no apto a vertedero o gestor autorizado.