# Terraplenes - Común

**Clasificación:** 02AT. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Aportación, extendido, humectación y compactación de suelos procedentes de excavación o préstamos para formar el terraplén.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 48–53. Transcripción para trazabilidad.

Consiste en la aportación, extendido y compactación de materiales terrosos, procedentes de excavación o préstamos.
Condiciones que han de cumplir los materiales:
- Se utilizarán como núcleos de terraplén los terrenos clasificados en el PG 3 como adecuados.
- Tanto para núcleos de terraplén, como la coronación, así como la explanada en desmontes se exigirá una densidad igual al 98% de la máxima del ensayo Proctor Modificado.

## Ejecución

Aprobar la procedencia y clasificación de los suelos y preparar el cimiento, escalonando las laderas cuando corresponda. Extender tongadas uniformes compatibles con el equipo y comprobar humedad y densidad antes de colocar la siguiente. Mantener el drenaje y reparar zonas reblandecidas. El texto particular exige el 98 % del Proctor Modificado; no sustituirlo por porcentajes referidos a un ensayo distinto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 54–63. Transcripción para trazabilidad.

El cimiento del terraplén se preparará de forma adecuada para suprimir discontinuidades efectuando los correspondientes trabajos de refino y compactación.
En zonas con pendiente transversal se escalonará el contacto con el terreno con escalones de ancho superior a 2´5 m, y con pendientes transversales que impidan el deslizamiento del terraplén.
Antes de iniciar el terraplén se procederá a levantar los perfiles transversales, necesarios para la posterior medición.
En zonas con filtraciones se procederá a realizar el drenaje necesario, con el sistema que apruebe la Dirección Facultativa.
Las tongadas serán de espesor uniforme y lo suficientemente reducido en el fin de conseguir, con los medios de compactación disponible, el grado de compactación exigida. El espesor de la tongada habrá de estar comprendida entre 20 y 35 cm.
Durante el extendido se eliminarán las piedras de tamaño superior a la mitad del espesor de la tongada.
No se extenderá ninguna tongada mientras no se haya comprobado que la capa inferior cumple las condiciones exigidas.
En el caso de la capa inferior se haya reblandecido por inundación o por cualquier otra causa, el contratista procederá a escarificarla y dejarla airear, sin derecho a compensación económica alguna.
En caso de ser necesaria la utilización de préstamos será perceptiva la autorización expresa de la Dirección Facultativa, previa al acopio de material.

## Medición y valoración

Medir en m³ compactados entre perfiles aprobados, con materiales, agua, extendido, compactación y correcciones incluidos en el alcance descrito.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 64–67. Transcripción para trazabilidad.

Se medirán y abonarán por metros cúbicos (m3) realmente ejecutados y compactados a su nivel definitivo, medidas por diferencias entre perfiles tomados antes y después de los trabajos.
Se entenderá que el precio del terraplén comprende la aportación de material procedente de la traza o de préstamos, incluyendo en el precio el canon, las excavaciones y carga en préstamos, el transporte, extendido, humectación, compactación y nivelación del terraplén, la eliminación de filtraciones en la base del terraplén, incluso el refino de los taludes resultantes, y la aportación de tierra vegetal para permitir la plantación en los mismos.
El precio incluye la adquisición, transporte, extendido, humectación y compactación del material, el refino y compactación de la explanada, y todos aquellos materiales y maquinaria necesarios para dejar la obra correctamente terminada, incluso la utilización de medios de compactación especiales para zonas singulares o el extendido a mano.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1119–1123. Transcripción para trazabilidad.

Se medirán por los metros cúbicos (m³) resultantes de la diferencia entre el perfil natural del terreno, una vez ejecutada la preparación de la base del terraplén, y los correspondientes perfiles de los Planos, para lo que es de valor lo especificado en los Artículos 5.6., sobre comprobación de perfiles.
Los perfiles correspondientes comprenden el coste de todas las operaciones necesarias para formar el terraplén o relleno, cualquiera que sea la procedencia de las tierras.
Incluye la pequeña remoción de la base del terraplén para facilitar la trabazón del mismo con el terreno natural, el agua para humedecer las tierras, el extendido y compactación de las mismas por tongadas de espesor definido por el Director de la obra y todas las operaciones previas de clasificación y acopios de suelos para la formación de terraplenes, así como un acabado de los taludes suave, uniforme, ajustado o lo estipulado en Planos totalmente acorde con la superficie del terreno natural colindante.
Asimismo, el precio incluye los materiales y trabajos adicionales necesarios en la zona de trabajo y la corrección de las irregularidades superiores a las tolerables, así como de los daños ocasionados por bajas temperaturas, paso de tráfico indebido y secuelas de una mala ejecución.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
