"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Vaciados

**Clasificación BCCA:** `02AVV`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Vaciados**, dentro de **Vaciados**.
Aplicable a las partidas cuyo código BCCA comienza por `02AVV`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02AVV00001 - EXCAVACIÓN EN VACIADO, DE TIERRAS DE CONSIST. DURA

**Unidad:** m3.

Excavación, en vaciado, de tierras de consistencia dura, realizada con medios mecánicos, incluso p.p. de perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02AVV00002 - EXCAVACIÓN EN VACIADO, DE TIERRAS DE CONSIST. MEDIA

**Unidad:** m3.

Excavación, en vaciado, de tierras de consistencia media, realizada con medios mecánicos, incluso p.p. de perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02AVV00003 - EXCAVACIÓN EN VACIADO, DE TIERRAS DE CONSIST. BLANDA

**Unidad:** m3.

Excavación, en vaciado, de tierras de consistencia blanda, realizada con medios mecánicos, incluso p.p. de perfilado de fondos y laterales. Medido el volumen en perfil natural.

### 02AVV00004 - EXCAVACIÓN EN VACIADO, DE TERRENO DISGREGADO

**Unidad:** m3.

Excavación en vaciado de terreno disgregado, realizada con medios mecánicos, incluso p.p. de perfilado de fondo y laterales. Medido el volumen en perfil natural.

### 02AVV00009 - EXCAVACIÓN EN VACIADO, DE TERRENO FANGOSO

**Unidad:** m3.

Excavación en vaciado de terreno fangoso, realizada con medios mecánicos, incluso p.p. de agotamiento de aguas. Medido el volumen en perfil natural.

### 02AVV00010 - EXCAVACIÓN EN VACIADO, DE ROCA BLANDA

**Unidad:** m3.

Excavación, en vaciado, de roca blanda, realizada con medios mecánicos, incluso p.p. de perfilado de fondos, laterales y empleo de compresor. Medido el volumen en perfil natural.

### 02AVV00011 - EXCAVACIÓN EN VACIADO, DE ROCA DURA

**Unidad:** m3.

Excavación, en vaciado, de roca dura, realizada con medios mecánicos, incluso p.p. de perfilado de fondos, laterales y empleo de compresor. Medido el volumen en perfil natural.

### 02AVV00012 - EXCAVACIÓN EN VACIADO, ROCA DURA, CON USO DE EXPLOSIVOS

**Unidad:** m3.

Excavación en vaciado de roca dura, realizada con medios mecánicos y utilización de explosivos. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Excavación sin clasificar para cimientos y emplazamientos

**Clasificación:** 02AV. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Excavación hasta las cotas y el terreno de apoyo adecuados para las cimentaciones, sin clasificación económica por tipo de terreno según el original.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 418–422. Transcripción para trazabilidad.
"""

Las excavaciones serán no clasificadas. No se hormigonará ninguna zapata ni cimiento sin que el Ingeniero Director de las obras haya comprobado las características del terreno. Si éstas resultaran inferiores a las necesarias, el Contratista continuará la excavación hasta la profundidad adecuada.
Cuando aparezca agua en las excavaciones se utilizarán los medios necesarios para poder evacuarla e impedir su entrada.
Los correspondientes precios unitarios son aplicables a la excavación en todo tipo de terreno y para cualquier profundidad, incluyendo las entibaciones y agotamientos que fuesen necesarios.

#### Ejecución

Replantear y excavar con sostenimiento, drenaje y accesos seguros. Mantener el fondo sin alteración y obtener la aprobación del terreno por la dirección antes del hormigonado. Toda profundización necesaria debe documentarse y aprobarse; no decidir la cimentación sólo durante la excavación sin comprobar el cálculo.

#### Medición y valoración

Por m³ según planos y modificaciones aprobadas, con transporte e inclusiones previstas en 3.20 y en su partida. No abonar sobreexcavaciones no autorizadas.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 423–424. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) realmente excavados, deducidos de los planos de construcción, quedando incluido en el precio del transporte de los productos a vertedero a cualquier distancia.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1112–1114. Transcripción para trazabilidad.
"""

El precio correspondiente a cualquier excavación comprende, salvo que expresamente no se indique otra cosa en el Cuadro de Precios o en este Pliego, todos los trabajos necesarios para realizarla y sacar los productos resultantes, o sea, la excavación, elevación y carga de los productos, transporte a vertedero o lugar de empleo, descarga y, en los casos en que fuese preciso, las entibaciones y agotamientos.
Para realizar los agotamientos el Contratista utilizará los medios e instalaciones adecuadas para agotar el agua y verterla en algún cauce o colector. Cuando estas operaciones den lugar a arrastres del terreno, se evitarán los agotamientos y se adoptarán las medidas que juzgue convenientes el Director de la obra. Serán de cuenta del Contratista incluso los agotamientos que sea preciso realizar durante el plazo de garantía de las obras.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
