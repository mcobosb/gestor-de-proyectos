# Excavación sin clasificar para cimientos y emplazamientos

**Clasificación:** 02AV. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Excavación hasta las cotas y el terreno de apoyo adecuados para las cimentaciones, sin clasificación económica por tipo de terreno según el original.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 418–422. Transcripción para trazabilidad.

Las excavaciones serán no clasificadas. No se hormigonará ninguna zapata ni cimiento sin que el Ingeniero Director de las obras haya comprobado las características del terreno. Si éstas resultaran inferiores a las necesarias, el Contratista continuará la excavación hasta la profundidad adecuada.
Cuando aparezca agua en las excavaciones se utilizarán los medios necesarios para poder evacuarla e impedir su entrada.
Los correspondientes precios unitarios son aplicables a la excavación en todo tipo de terreno y para cualquier profundidad, incluyendo las entibaciones y agotamientos que fuesen necesarios.

## Ejecución

Replantear y excavar con sostenimiento, drenaje y accesos seguros. Mantener el fondo sin alteración y obtener la aprobación del terreno por la dirección antes del hormigonado. Toda profundización necesaria debe documentarse y aprobarse; no decidir la cimentación sólo durante la excavación sin comprobar el cálculo.

## Medición y valoración

Por m³ según planos y modificaciones aprobadas, con transporte e inclusiones previstas en 3.20 y en su partida. No abonar sobreexcavaciones no autorizadas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 423–424. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) realmente excavados, deducidos de los planos de construcción, quedando incluido en el precio del transporte de los productos a vertedero a cualquier distancia.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1112–1114. Transcripción para trazabilidad.

El precio correspondiente a cualquier excavación comprende, salvo que expresamente no se indique otra cosa en el Cuadro de Precios o en este Pliego, todos los trabajos necesarios para realizarla y sacar los productos resultantes, o sea, la excavación, elevación y carga de los productos, transporte a vertedero o lugar de empleo, descarga y, en los casos en que fuese preciso, las entibaciones y agotamientos.
Para realizar los agotamientos el Contratista utilizará los medios e instalaciones adecuadas para agotar el agua y verterla en algún cauce o colector. Cuando estas operaciones den lugar a arrastres del terreno, se evitarán los agotamientos y se adoptarán las medidas que juzgue convenientes el Director de la obra. Serán de cuenta del Contratista incluso los agotamientos que sea preciso realizar durante el plazo de garantía de las obras.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
