"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Desmontes

**Clasificación BCCA:** `02ADD`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Desmontes**, dentro de **Desmontes**.
Aplicable a las partidas cuyo código BCCA comienza por `02ADD`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02ADD00001 - EXC. DESMONTE TIERRAS CONSIST. DURA, TRANSP. A TERRAPLÉN

**Unidad:** m3.

Excavación, en desmonte, de tierras de consistencia dura, realizada con medios mecánicos, incluso transporte a terraplén. Medido el volumen en perfil natural.

### 02ADD00002 - EXC. DESMONTE TIERRAS CONSIST. MEDIA, TRANSP. A TERRAPLÉN

**Unidad:** m3.

Excavación, en desmonte, de tierras de consistencia media, realizada con medios mecánicos, incluso transporte a terraplén. Medido el volumen en perfil natural.

### 02ADD00003 - EXC. DESMONTE TIERRAS CONSIST. BLANDA,TRANSP. A TERRAPLÉN

**Unidad:** m3.

Excavación, en desmonte, de tierras de consistencia blanda, realizada con medios mecánicos, incluso transporte a terraplén. Medido el volumen en perfil natural.

### 02ADD00004 - EXC. DESMONTE ROCA BLANDA, TRANSP. A TERRAPLÉN

**Unidad:** m3.

Excavación, en desmonte, de roca blanda, realizada con medios mecánicos, incluso transporte a terraplén. Medido el volumen en perfil natural.

### 02ADD00005 - EXC. DESMONTE ROCA DURA,TRANSP. A TERRAPLÉN

**Unidad:** m3.

Excavación, en desmonte, de roca dura realizada con medios mecánicos, incluso carga y transporte a terraplén. Medido el volumen en perfil natural.

### 02ADD00006 - EXC. DESMONTE TIERRAS CONSISTENCIA DURA

**Unidad:** m3.

Excavación, en desmonte, de tierras de consistencia dura, realizada con medios mecánicos. Medido el volumen en perfil natural.

### 02ADD00007 - EXC. DESMONTE TIERRAS CONSISTENCIA MEDIA

**Unidad:** m3.

Excavación, en desmonte, de tierras de consistencia media, realizada con medios mecánicos. Medido el volumen en perfil natural.

### 02ADD00008 - EXC. DESMONTE TIERRAS CONSISTENCIA BLANDA

**Unidad:** m3.

Excavación, en desmonte, de tierras de consistencia blanda, realizada con medios mecánicos. Medido el volumen en perfil natural.

### 02ADD00009 - EXC. DESMONTE ROCA BLANDA

**Unidad:** m3.

Excavación, en desmonte, de roca blanda, realizada con medios mecánicos. Medido el volumen en perfil natural.

### 02ADD00010 - EXC. DESMONTE ROCA DURA

**Unidad:** m3.

Excavación, en desmonte, de roca dura realizada con medios mecánicos. Medido el volumen en perfil natural.

### 02ADD00100 - EXC. DESMONTE TERRENO DISGREGADO, TRANSP. A TERRAPLÉN

**Unidad:** m3.

Excavación, en desmonte, de terreno disgregado, realizada con medios mecánicos, incluso transporte a terraplén. Medido el volumen en perfil natural.

### 02ADD00106 - EXC. DESMONTE TERRENO DISGREGADO

**Unidad:** m3.

Excavación, en desmonte, de terreno disgregado, realizada con medios mecánicos. Medido el volumen en perfil natural.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Desmontes

**Clasificación:** 02AD. **Capítulo:** acondicionamiento de terrenos. **Familia:** a cielo abierto.

"""
#### Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

El objeto de esta ficha es «desmontes», dentro de «a cielo abierto». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Controlar perfiles, drenaje y estabilidad de taludes durante cada fase; separar suelos no aptos y sobreexcavaciones para su decisión técnica.

Para la variante «desmontes» se comprobarán expresamente perfil de terreno y proyecto, taludes y destino de los productos. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Excavaciones y rellenos: m³ entre perfiles aprobados, distinguiendo terreno en banco y relleno compactado. Refino o compactación superficial: m². Transportes y sostenimientos requieren partida y base propias, sin volver a abonar operaciones incluidas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
