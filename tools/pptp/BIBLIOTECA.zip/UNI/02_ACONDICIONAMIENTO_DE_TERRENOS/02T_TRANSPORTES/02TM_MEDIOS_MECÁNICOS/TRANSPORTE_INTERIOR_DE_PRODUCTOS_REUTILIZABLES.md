# Transporte interior de productos reutilizables

**Clasificación:** 02TM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Movimiento dentro de la actuación de productos de excavación o cajeado destinados a reutilización.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1124–1125. Transcripción para trazabilidad.

Se refiere al transporte de aquellos productos que, procedentes de las propias excavaciones o cajeos, sean susceptibles de ser nuevamente utilizados.

## Ejecución

Comprobar aptitud del material y destino aprobado, separar fracciones y organizar recorridos y acopios seguros evitando contaminación, polvo y vertidos. Mantener trazabilidad de volúmenes y origen para no mezclar material no apto.

## Medición y valoración

El apartado 5.7 declara que no es de abono independiente y lo incluye en excavación, colocación de tubería u otras unidades.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1126–1126. Transcripción para trazabilidad.

Este transporte no será de abono, y está incluido dentro de las unidades de excavación, colocación de tubería, etc.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
