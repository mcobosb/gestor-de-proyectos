"""
# Medios mecánicos - Medios mecánicos

**Clasificación BCCA:** `02TMM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Medios mecánicos**, dentro de **Medios mecánicos**.
Aplicable a las partidas cuyo código BCCA comienza por `02TMM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02TMM00001 - TRANSPORTE TIERRAS, DIST. MÁX. 5 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00002 - TRANSPORTE TIERRAS, DIST. MÁX. 5 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00003 - TRANSPORTE TIERRAS, DIST. MÁX. 1 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante, a una distancia máxima de 1 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00004 - TRANSPORTE TIERRAS, DIST. MÁX. 500 m CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00006 - TRANSPORTE TIERRAS, DIST. MÁX. 1 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante a una distancia máxima de 1 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00007 - TRANSPORTE TIERRAS, DIST. MÁX. 500 m CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00011 - TRANSPORTE FANGOS, DIST. MÁX. 5 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00012 - TRANSPORTE FANGOS, DIST. MÁX. 5 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00013 - TRANSPORTE FANGOS, DIST. MÁX. 1 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 1 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00014 - TRANSPORTE FANGOS, DIST. MÁX. 500 m CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00016 - TRANSPORTE FANGOS, DIST. MÁX. 1 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 1 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00017 - TRANSPORTE FANGOS, DIST. MÁX. 500 m CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00021 - TRANSPORTE TIERRAS, ENTRE 5 Y 10 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras realizado en camión basculante a una distancia comprendida entre 5 y 10 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00022 - TRANSPORTE TIERRAS, ENTRE 5 Y 10 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras realizado en camión basculante a una distancia comprendida entre 5 y 10 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00023 - TRANSPORTE FANGOS, ENTRE 5 Y 10 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos realizado en camión basculante, a una distancia comprendida entre 5 y 10 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00024 - TRANSPORTE FANGOS, ENTRE 5 Y 10 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos realizado en camión basculante, a una distancia comprendida entre 5 y 10 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM90007 - TRANSPORTE TIERRAS, DIST. MAX. 500 m CARGA M. MEC.

**Unidad:** m3.

De transporte de tierras, realizado en autovolquete a una distancia máxima de 500 M, ingluso carga con medios mecánicos. Medido en perfil esponjado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Transporte interior de productos reutilizables

**Clasificación:** 02TM  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** Movimiento de tierras y acopios  

"""
#### Descripción
Carga, traslado interno y descarga dentro de la propia traza de la obra de los productos procedentes de excavaciones, cajeados o demoliciones que resulten aptos para su posterior reutilización (rellenos, explanadas o capas base).

#### Ejecución
1. **Previos:** Comprobar la aptitud del material excavado, verificar el punto de acopio provisional o de vertido definitivo autorizado y planificar los recorridos internos de maquinaria evitando afectar a zonas terminadas o servicios.
2. **Traslado y acopio:** Carga y transporte con medios mecánicos adecuados, evitando el acopio de materiales sobre bordes inestables, la contaminación del suelo apto con vegetación o restos de demolición, y la emisión excesiva de polvo o vertidos en viales públicos.
3. **Control y trazabilidad:** Control de origen/destino de los volúmenes trasladados, garantizando que no se mezclen terrenos de distinta calidad geotécnica ni materiales no aptos.

#### Medición
* **Unidad de medida:** Sin abono independiente (o metro cúbico, m³, en caso excepcional de partida explícita aprobada en cuadro de precios).
* **Criterio:** Operación de carácter suplementario; no genera medición directa por estar integrada en el ciclo del movimiento de tierras.

#### Valoración
* **Abono:** Unidad sin abono directo. El coste de este transporte interno está repercutido e incluido proporcionalmente en los precios unitarios de las partidas origen/destino (excavación de zanjas/cajas, rellenos compactados o colocación de tuberías).
* **Incluye:** Carga, recorrido interno, descarga, extensión previa en acopio, medios de aspiración/humectación de polvo y conservación de los itinerarios de obra.
