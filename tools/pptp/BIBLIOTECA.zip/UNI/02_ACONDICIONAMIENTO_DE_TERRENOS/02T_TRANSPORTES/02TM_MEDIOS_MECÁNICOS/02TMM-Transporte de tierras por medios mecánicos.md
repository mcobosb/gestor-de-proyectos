"""
## Registro de cambios
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Medios mecánicos

**Clasificación BCCA:** `02TMM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Medios mecánicos**, dentro de **Medios mecánicos**.
Aplicable a las partidas cuyo código BCCA comienza por `02TMM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 02TMM00001 - TRANSPORTE TIERRAS, DIST. MÁX. 5 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00002 - TRANSPORTE TIERRAS, DIST. MÁX. 5 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00003 - TRANSPORTE TIERRAS, DIST. MÁX. 1 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante, a una distancia máxima de 1 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00004 - TRANSPORTE TIERRAS, DIST. MÁX. 500 m CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00006 - TRANSPORTE TIERRAS, DIST. MÁX. 1 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras, realizado en camión basculante a una distancia máxima de 1 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00007 - TRANSPORTE TIERRAS, DIST. MÁX. 500 m CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00011 - TRANSPORTE FANGOS, DIST. MÁX. 5 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00012 - TRANSPORTE FANGOS, DIST. MÁX. 5 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 5 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00013 - TRANSPORTE FANGOS, DIST. MÁX. 1 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 1 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00014 - TRANSPORTE FANGOS, DIST. MÁX. 500 m CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00016 - TRANSPORTE FANGOS, DIST. MÁX. 1 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos, realizado en camión basculante a una distancia máxima de 1 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00017 - TRANSPORTE FANGOS, DIST. MÁX. 500 m CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos, realizado en carretillas mecánicas basculantes, a una distancia máxima de 500 m, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00021 - TRANSPORTE TIERRAS, ENTRE 5 Y 10 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de tierras realizado en camión basculante a una distancia comprendida entre 5 y 10 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00022 - TRANSPORTE TIERRAS, ENTRE 5 Y 10 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de tierras realizado en camión basculante a una distancia comprendida entre 5 y 10 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM00023 - TRANSPORTE FANGOS, ENTRE 5 Y 10 km CARGA M. MANUALES

**Unidad:** m3.

Transporte de fangos realizado en camión basculante, a una distancia comprendida entre 5 y 10 km, incluso carga con medios manuales. Medido en perfil esponjado.

### 02TMM00024 - TRANSPORTE FANGOS, ENTRE 5 Y 10 km CARGA M. MECÁNICOS

**Unidad:** m3.

Transporte de fangos realizado en camión basculante, a una distancia comprendida entre 5 y 10 km, incluso carga con medios mecánicos. Medido en perfil esponjado.

### 02TMM90007 - TRANSPORTE TIERRAS, DIST. MAX. 500 m CARGA M. MEC.

**Unidad:** m3.

De transporte de tierras, realizado en autovolquete a una distancia máxima de 500 M, ingluso carga con medios mecánicos. Medido en perfil esponjado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Transporte interior de productos reutilizables

**Clasificación:** 02TM  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** Movimiento de tierras y acopios  

"""
#### Descripción
Carga y transporte por carretera o viales de obra de productos procedentes de la excavación o demolición (tierras y materiales no aptos o excedentes) mediante camión basculante, hasta un vertedero autorizado, centro de gestión de residuos o punto de acopio final situado a una distancia máxima de 5,00 km.

#### Ejecución
	**1. Previos:** Verificar la distancia real al vertedero o punto de vertido autorizado. Coordinar los medios mecánicos de carga (pala cargadora o excavadora) y comprobar la adecuación, estanqueidad de las cajas y estado de los camiones basculantes.
	**2. Carga y transporte:** Realizar la carga mecánica de los materiales sobre los camiones basculantes evitando el llenado por encima de los laterales de la caja. Realizar el transporte por el itinerario autorizado respetando las normas de circulación, disponiendo de lonas o humectación previa si fuera preciso para evitar la emisión de polvo o el vertido de finos en viales públicos.
	**3. Control y trazabilidad:** Controlar las carreras y volúmenes transportados, conservando los vales de báscula, tiques de vertido o albaranes que justifiquen la entrega del material en el destino final autorizado.

#### Medición
	* **Unidad de medida:** Metro cúbico (m³) de tierra o material transportado.
	* **Criterio:** Volumen medido en perfil esponjado realmente transportado y verificado en obra o mediante los correspondientes comprobantes de báscula/vertido aceptados por la Dirección de Obra.

#### Valoración
El precio unitario (€/m³) incluye:
	* Carga de las tierras con medios mecánicos sobre camión basculante.
	* Transporte en camión basculante a una distancia máxima de 5,00 km.
	* Tiempos de espera, maniobras de carga y descarga, y limpieza del área de carga y de las ruedas de los vehículos antes de su incorporación a viales públicos.
	* Gastos de personal, combustible, conservación y mantenimiento de la maquinaria y vehículos de transporte.
