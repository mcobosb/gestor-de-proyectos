# Transporte interior de productos reutilizables - Común

**Clasificación:** 02TM  
**Capítulo:** Acondicionamiento de terrenos  
**Familia:** Movimiento de tierras y acopios  

## Descripción
Carga, traslado interno y descarga dentro de la propia traza de la obra de los productos procedentes de excavaciones, cajeados o demoliciones que resulten aptos para su posterior reutilización (rellenos, explanadas o capas base).

## Ejecución
1. **Previos:** Comprobar la aptitud del material excavado, verificar el punto de acopio provisional o de vertido definitivo autorizado y planificar los recorridos internos de maquinaria evitando afectar a zonas terminadas o servicios.
2. **Traslado y acopio:** Carga y transporte con medios mecánicos adecuados, evitando el acopio de materiales sobre bordes inestables, la contaminación del suelo apto con vegetación o restos de demolición, y la emisión excesiva de polvo o vertidos en viales públicos.
3. **Control y trazabilidad:** Control de origen/destino de los volúmenes trasladados, garantizando que no se mezclen terrenos de distinta calidad geotécnica ni materiales no aptos.

## Medición
* **Unidad de medida:** Sin abono independiente (o metro cúbico, m³, en caso excepcional de partida explícita aprobada en cuadro de precios).
* **Criterio:** Operación de carácter suplementario; no genera medición directa por estar integrada en el ciclo del movimiento de tierras.

## Valoración
* **Abono:** Unidad sin abono directo. El coste de este transporte interno está repercutido e incluido proporcionalmente en los precios unitarios de las partidas origen/destino (excavación de zanjas/cajas, rellenos compactados o colocación de tuberías).
* **Incluye:** Carga, recorrido interno, descarga, extensión previa en acopio, medios de aspiración/humectación de polvo y conservación de los itinerarios de obra.