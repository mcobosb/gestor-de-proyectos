# A brazo - Común

**Clasificación:** 02TB. **Capítulo:** acondicionamiento de terrenos. **Familia:** transportes.

## Descripción

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

El objeto de esta ficha es «a brazo», dentro de «transportes». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

Distinguir producto reutilizable de residuo y registrar origen, destino y recorridos autorizados; acondicionar las rutas internas.

Para la variante «a brazo» se comprobarán expresamente naturaleza del producto, distancia y criterio de carga y descarga. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Según presupuesto, m³ de material de referencia transportado a distancia definida, t acreditadas o t·km con masa y recorrido comprobados. No mezclar volumen en banco y suelto; carga, descarga, tasas y tratamiento sólo se abonarán separadamente si no están incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
