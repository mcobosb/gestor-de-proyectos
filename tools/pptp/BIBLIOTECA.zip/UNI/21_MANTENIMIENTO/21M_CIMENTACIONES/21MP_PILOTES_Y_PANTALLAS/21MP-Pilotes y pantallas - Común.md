"""
# Pilotes y pantallas - Común

**Clasificación:** 21MP. **Capítulo:** mantenimiento. **Familia:** cimentaciones.

"""
## Descripción

Inspección, conservación, reparación o sustitución localizada de elementos existentes, con diagnóstico previo y alcance aprobado.

El objeto de esta ficha es «pilotes y pantallas», dentro de «cimentaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Documentar el estado inicial y determinar la causa del deterioro antes de reparar. Proteger usuarios y elementos sanos, aislar instalaciones afectadas y ejecutar una muestra o reparación compatible con el soporte. Comprobar la prestación recuperada y registrar la intervención para el mantenimiento.

La intervención sobre elementos de hormigón requiere diagnóstico de corrosión, fisuración y capacidad; los refuerzos necesitan cálculo.

Para la variante «pilotes y pantallas» se comprobarán expresamente causa del daño, evaluación resistente y sistema de reparación. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar compatibilidad, extensión real, causas corregidas y resultado funcional; no ocultar lesiones activas ni sustituir un refuerzo estructural por un tratamiento superficial.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de superficie reparada, m de tramo, ud de elemento o intervención definida según presupuesto. Medir sólo zonas autorizadas; desglosar sustituciones y operaciones adicionales aprobadas sin repetir la revisión o el desmontaje incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
