# Vidrios compuestos - Común

**Clasificación:** 12AC. **Capítulo:** vidriería y elaborados sintéticos. **Familia:** vidrios aislantes.

## Descripción

Acristalamientos y elaborados sintéticos seleccionados para la seguridad, exposición y prestaciones del hueco o cerramiento.

El objeto de esta ficha es «vidrios compuestos», dentro de «vidrios aislantes». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar composición y dimensiones, estado de cantos y compatibilidad de apoyos y sellantes. Manipular con medios adecuados, colocar calzos y holguras previstos y evitar contactos rígidos o daños en capas funcionales.

Comprobar cámaras y sellado perimetral en vidrios aislantes y composición real de los paños.

Para la variante «vidrios compuestos» se comprobarán expresamente composición, cámara, capa y prestaciones térmicas. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar marcado e identificación, apoyos, retención y sellado, ausencia de daños y correspondencia con las prestaciones de seguridad y de fuego cuando procedan.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de paño de composición definida o ud de pieza especial. Establecer si se mide dimensión nominal o vista y si calzos, juntas y sellados están incluidos; no duplicar vidrios ya incluidos en la carpintería.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
