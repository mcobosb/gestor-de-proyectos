# varios

**Clasificación:** 12NW. **Capítulo:** vidriería y elaborados sintéticos. **Familia:** vidrios sencillos.

## Descripción

Acristalamientos y elaborados sintéticos seleccionados para la seguridad, exposición y prestaciones del hueco o cerramiento.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar composición y dimensiones, estado de cantos y compatibilidad de apoyos y sellantes. Manipular con medios adecuados, colocar calzos y holguras previstos y evitar contactos rígidos o daños en capas funcionales.

No equiparar vidrio templado, armado o de protección al fuego: cada prestación requiere la clasificación y montaje del sistema concreto.

Para la variante «varios» se comprobarán expresamente tratamiento, clase de seguridad y condiciones de montaje. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar marcado e identificación, apoyos, retención y sellado, ausencia de daños y correspondencia con las prestaciones de seguridad y de fuego cuando procedan.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de paño de composición definida o ud de pieza especial. Establecer si se mide dimensión nominal o vista y si calzos, juntas y sellados están incluidos; no duplicar vidrios ya incluidos en la carpintería.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
