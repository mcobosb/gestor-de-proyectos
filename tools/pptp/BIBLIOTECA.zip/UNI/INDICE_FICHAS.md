# Índice de fichas de materiales y unidades de obra

Fuentes: [PPTP.md](../../PPTP.md) para las **104 fichas originales** y [catálogo UNI](../../00_capitulos_subcapitulos.xlsx) para las **580 fichas marco nuevas**. Total: **684 fichas**. Cobertura: **637 carpetas finales**, todas con al menos una ficha directa. Organización: carpetas existentes de archivos/UNI, sin añadir niveles. El PPTP se conserva sin modificaciones; las fichas mantienen su contenido técnico con la limpieza de metadatos y encabezados descrita a continuación.

## Catálogo para software y paquete ZIP

- [catalogo.json](catalogo.json) contiene el inventario de fichas, sus códigos y niveles UNI, títulos, rutas relativas, tipo, encabezados y huellas SHA-256. El contenido técnico se obtiene leyendo cada archivo Markdown.
- Las fichas de tipo `marco` se distinguen de las de tipo `pptp`. Los códigos con varias fichas incluyen sus identificadores relacionados; no se debe seleccionar una variante automáticamente sólo por compartir código.
- `seleccion.criterios: null` significa que no hay reglas específicas de material, operación o uso codificadas. La selección requiere confirmación frente a las partidas del proyecto, incluso para códigos con una sola ficha.
- El software debe deduplicar por `id` y asignar la numeración al ensamblar los encabezados en el documento del proyecto. El índice no se incorpora como contenido técnico.
- [BIBLIOTECA_UNI.zip](../BIBLIOTECA_UNI.zip) incluye las fichas, este índice y el catálogo dentro de `archivos/UNI`, además de los documentos fuente disponibles en la raíz del paquete. Se conserva esa estructura para mantener las rutas de los enlaces; extraer el ZIP completo.
- El catálogo registra en `referencias_locales_no_disponibles` los documentos enlazados que ya faltaban en la biblioteca de origen. El empaquetado no reconstruye esos documentos ni acredita la vigencia de las referencias externas.

## Alcance de la ampliación por catálogo

- Se han cubierto únicamente las carpetas finales sin ficha; los capítulos y subcapítulos intermedios siguen siendo agrupaciones, no partidas artificiales. Una clasificación puede contener varias unidades y las fichas originales no implican cobertura de todas sus variantes.
- Las fichas marco nuevas son redacción orientativa por familia y clasificación, no extractos del PPTP ni soluciones calculadas. Cada ficha contiene únicamente Descripción, Ejecución y Medición y valoración.
- Las categorías «varios» se limitan a los trabajos propios de la partida y a su alcance contractual; el título del catálogo no amplía por sí solo los trabajos incluidos.
- La legislación y normativa aplicables se recogen en [02_DisposicionesTecnicasLegalesAplicables.md](../../02_DisposicionesTecnicasLegalesAplicables.md); las fichas no incluyen apartados de legislación.
- La medición y valoración se rigen por la unidad, las inclusiones y los precios del cuadro de precios aprobado, sin duplicar operaciones o medios auxiliares.
- Los títulos y apartados de las fichas utilizan únicamente los niveles # y ##; los códigos UNI se conservan como metadatos de clasificación y en las tablas del índice.
- La tabla de fichas originales incorpora observaciones de lectura; la segunda recoge la clasificación de las fichas marco.

## Criterios de las fichas originales y precauciones comunes

- Se han reunido las prescripciones de definición, ejecución y valoración dispersas en los capítulos 3, 4 y 5. Las variantes expresamente descritas y los materiales con requisitos propios tienen ficha independiente.
- Los medios, herramientas y componentes sin prescripción propia (tornillos, maquinaria, agua de curado, etc.) se mantienen en la unidad que los utiliza; no se convierten artificialmente en partidas nuevas.
- Cada ficha contiene un título de nivel 1 y las secciones de nivel 2 Descripción, Ejecución y Medición y valoración. El contenido técnico se integra en esos tres apartados.
- Las transcripciones permiten localizar el texto original; no convalidan erratas, normas antiguas, tablas mal copiadas ni prescripciones incompatibles con disposiciones obligatorias. Las observaciones del índice no forman parte del contenido técnico de las fichas.
- Los complementos de ejecución son síntesis técnicas apoyadas en las fuentes oficiales enlazadas; no son cálculos de proyecto ni transcripciones de normas UNE. Se debe comprobar la edición aplicable de estas últimas y las condiciones del titular de cada red.
- El PG-3 se utiliza como referencia técnica por remisión del pliego. No se presume que toda disposición de carreteras sea automáticamente obligatoria en cualquier urbanización. El CTE y los reglamentos de instalaciones se aplican dentro de su ámbito.
- La medición y valoración se ajustan al cuadro de precios y a los documentos contractuales; no se crean precios ni se duplican unidades.
- Los criterios de las fichas no alteran las magnitudes, materiales ni precios establecidos en la documentación contractual.
- Consulta normativa realizada el 05/11/2026. Las referencias enlazadas no constituyen una certificación exhaustiva de vigencia de toda la normativa nacional, autonómica, local o de los operadores.

## Fichas originales procedentes del PPTP

| Código | Ficha | Revisión específica |
|---|---|---|
| 01UE | [Demolición de arquetas eléctricas - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UE_ELECTRICIDAD/01UE-Demolici%C3%B3n%20de%20arquetas%20el%C3%A9ctricas%20-%20Com%C3%BAn.md) | La ejecución requiere coordinación previa con el titular y medidas frente al riesgo eléctrico. |
| 01UE | [Reposición de líneas eléctricas - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UE_ELECTRICIDAD/01UE-Reposici%C3%B3n%20de%20l%C3%ADneas%20el%C3%A9ctricas%20-%20Com%C3%BAn.md) | El REBT sólo cubre baja tensión. Si la línea es de media o alta tensión deberá aplicarse su reglamentación específica; el original no identifica su tensión. |
| 01UT | [Reposición de servicios telefónicos - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UT_TEL%C3%89FONO/01UT-Reposici%C3%B3n%20de%20servicios%20telef%C3%B3nicos%20-%20Com%C3%BAn.md) | — |

## Fichas marco añadidas por clasificación

Fichas nuevas: **580**. Todas están **pendientes de particularización**. Los datos siguientes se desarrollan en cada ficha junto con su procedimiento, controles y propuesta de medición.

| Código | Ficha marco | Datos pendientes de proyecto |
|---|---|---|
| 01UC | [Indicadores de circulación - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UC_INDICADORES_DE_CIRCULACI%C3%93N/01UC-Indicadores%20de%20circulaci%C3%B3n%20-%20Com%C3%BAn.md) | titular, permisos, desvíos y servicio provisional. |
| 01UG | [Gases y licuados - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UG_GASES_Y_LICUADOS/01UG-Gases%20y%20licuados%20-%20Com%C3%BAn.md) | titular, permisos, desvíos y servicio provisional. |
| 01UJ | [Jardinería - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UJ_JARDINER%C3%8DA/01UJ-Jardiner%C3%ADa%20-%20Com%C3%BAn.md) | titular, permisos, desvíos y servicio provisional. |
| 01UM | [Movimiento de tierras - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UM_MOVIMIENTO_DE_TIERRAS/01UM-Movimiento%20de%20tierras%20-%20Com%C3%BAn.md) | titular, permisos, desvíos y servicio provisional. |
| 01US | [Suministro de agua - Común](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01US_SUMINISTRO_DE_AGUA/01US-Suministro%20de%20agua%20-%20Com%C3%BAn.md) | titular, permisos, desvíos y servicio provisional. |
| 02ZW | [ZANJAS - varios - Común](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZW_VARIOS/02ZW-ZANJAS%20-%20varios%20-%20Com%C3%BAn.md) | ancho, profundidad, cama y distancias a servicios. |
| 08NU | [Calentadores por aerotermia - Común](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NU_CALENTADORES_POR_AEROTERMIA/08NU-Calentadores%20por%20aerotermia%20-%20Com%C3%BAn.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad; refrigerante, potencia, emplazamiento y requisitos ambientales. |
| 08OW | [ENERGÍA FOTOVOLTAICA - varios - Común](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OW_VARIOS/08OW-ENERG%C3%8DA%20FOTOVOLTAICA%20-%20varios%20-%20Com%C3%BAn.md) | potencia, cargas de viento, esquema eléctrico y condiciones de conexión. |
| 12WE | [Emplomados - Común](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WE_EMPLOMADOS/12WE-Emplomados%20-%20Com%C3%BAn.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 17RB | [Residuos bituminosos - Común](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RB_RESIDUOS_BITUMINOSOS/17RB-Residuos%20bituminosos%20-%20Com%C3%BAn.md) | composición de la mezcla y operaciones de separación. |
| 18BP | [Paredes y fachadas - Común](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BP_PAREDES_Y_FACHADAS/18BP-Paredes%20y%20fachadas%20-%20Com%C3%BAn.md) | material, lote, resistencia y prestación superficial. |
| 18CW | [CIMENTACIÓN - varios - Común](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CW_VARIOS/18CW-CIMENTACI%C3%93N%20-%20varios%20-%20Com%C3%BAn.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18ID | [Electricidad baja tensión bt - Común](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18ID_ELECTRICIDAD_BAJA_TENSI%C3%93N_BT/18ID-Electricidad%20baja%20tensi%C3%B3n%20bt%20-%20Com%C3%BAn.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IF | [Energía solar térmica - Común](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IF_ENERG%C3%8DA_SOLAR_T%C3%89RMICA/18IF-Energ%C3%ADa%20solar%20t%C3%A9rmica%20-%20Com%C3%BAn.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IG | [Climatización y calefacción - Común](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IG_CLIMATIZACI%C3%93N_Y_CALEFACCI%C3%93N/18IG-Climatizaci%C3%B3n%20y%20calefacci%C3%B3n%20-%20Com%C3%BAn.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IS | [Elevación - Común](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IS_ELEVACI%C3%93N/18IS-Elevaci%C3%B3n%20-%20Com%C3%BAn.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 21IW | [INSTALACIONES - varios - Común](21_MANTENIMIENTO/21I_INSTALACIONES/21IW_VARIOS/21IW-INSTALACIONES%20-%20varios%20-%20Com%C3%BAn.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21KW | [CARPINTERÍA, SEGURIDAD Y PROTECCIÓN - varios - Común](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KW_VARIOS/21KW-CARPINTER%C3%8DA%2C%20SEGURIDAD%20Y%20PROTECCI%C3%93N%20-%20varios%20-%20Com%C3%BAn.md) | material, lesión y prestaciones originales. |
| 21ML | [Losas - Común](21_MANTENIMIENTO/21M_CIMENTACIONES/21ML_LOSAS/21ML-Losas%20-%20Com%C3%BAn.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MP | [Pilotes y pantallas - Común](21_MANTENIMIENTO/21M_CIMENTACIONES/21MP_PILOTES_Y_PANTALLAS/21MP-Pilotes%20y%20pantallas%20-%20Com%C3%BAn.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MV | [Vigas y zunchos - Común](21_MANTENIMIENTO/21M_CIMENTACIONES/21MV_VIGAS_Y_ZUNCHOS/21MV-Vigas%20y%20zunchos%20-%20Com%C3%BAn.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MW | [CIMENTACIONES - varios - Común](21_MANTENIMIENTO/21M_CIMENTACIONES/21MW_VARIOS/21MW-CIMENTACIONES%20-%20varios%20-%20Com%C3%BAn.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MX | [Auxiliares - Común](21_MANTENIMIENTO/21M_CIMENTACIONES/21MX_AUXILIARES/21MX-Auxiliares%20-%20Com%C3%BAn.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MZ | [Zapatas - Común](21_MANTENIMIENTO/21M_CIMENTACIONES/21MZ_ZAPATAS/21MZ-Zapatas%20-%20Com%C3%BAn.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21QW | [CUBIERTAS - varios - Común](21_MANTENIMIENTO/21Q_CUBIERTAS/21QW_VARIOS/21QW-CUBIERTAS%20-%20varios%20-%20Com%C3%BAn.md) | composición existente, lesión y prueba de estanqueidad. |
| 21RW | [REVESTIMIENTOS - varios - Común](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RW_VARIOS/21RW-REVESTIMIENTOS%20-%20varios%20-%20Com%C3%BAn.md) | daño, soporte, alcance y acabado de reposición. |
| 21VS | [Elaborados sintéticos - Común](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VS_ELABORADOS_SINT%C3%89TICOS/21VS-Elaborados%20sint%C3%A9ticos%20-%20Com%C3%BAn.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21W | [MANTENIMIENTO - varios - Común](21_MANTENIMIENTO/21W_VARIOS/21W-MANTENIMIENTO%20-%20varios%20-%20Com%C3%BAn.md) | elemento, avería, operación y criterio de recepción. |
| 21XA | [ESTRUCTURAS - acero - Común](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XA_ACERO/21XA-ESTRUCTURAS%20-%20acero%20-%20Com%C3%BAn.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XF | [Forjados - Común](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XF_FORJADOS/21XF-Forjados%20-%20Com%C3%BAn.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XH | [ESTRUCTURAS - hormigón - Común](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XH_HORMIG%C3%93N/21XH-ESTRUCTURAS%20-%20hormig%C3%B3n%20-%20Com%C3%BAn.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XM | [Madera - Común](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XM_MADERA/21XM-Madera%20-%20Com%C3%BAn.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 01AAA | [Retirada de arcos y bóvedas de ladrillo - arcos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/01AAA-Retirada%20de%20arcos%20y%20b%C3%B3vedas%20de%20ladrillo%20-%20arcos.md) | Revisar aplicación. |
| 01AAB | [Retirada de arcos y bóvedas de ladrillo - bóvedas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/01AAB-Retirada%20de%20arcos%20y%20b%C3%B3vedas%20de%20ladrillo%20-%20b%C3%B3vedas.md) | Revisar aplicación. |
| 01AAW | [Retirada de arcos y bóvedas de ladrillo - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/01AAW-Retirada%20de%20arcos%20y%20b%C3%B3vedas%20de%20ladrillo%20-%20varios.md) | Revisar aplicación. |
| 01ABH | [Retirada de fábricas de bloque - huecos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AB_F%C3%81BRICAS_DE_BLOQUE/01ABH-Retirada%20de%20f%C3%A1bricas%20de%20bloque%20-%20huecos.md) | Revisar aplicación. |
| 01ABM | [Retirada de fábricas de bloque - macizos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AB_F%C3%81BRICAS_DE_BLOQUE/01ABM-Retirada%20de%20f%C3%A1bricas%20de%20bloque%20-%20macizos.md) | Revisar aplicación. |
| 01ABW | [Retirada de fábricas de bloque - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AB_F%C3%81BRICAS_DE_BLOQUE/01ABW-Retirada%20de%20f%C3%A1bricas%20de%20bloque%20-%20varios.md) | Revisar aplicación. |
| 01ACA | [Retirada de cantería - arcos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/01ACA-Retirada%20de%20canter%C3%ADa%20-%20arcos.md) | Revisar aplicación. |
| 01ACB | [Retirada de cantería - bóvedas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/01ACB-Retirada%20de%20canter%C3%ADa%20-%20b%C3%B3vedas.md) | Revisar aplicación. |
| 01ACM | [Retirada de cantería - mampostería](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/01ACM-Retirada%20de%20canter%C3%ADa%20-%20mamposter%C3%ADa.md) | Revisar aplicación. |
| 01ACS | [Retirada de cantería - sillerías](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/01ACS-Retirada%20de%20canter%C3%ADa%20-%20siller%C3%ADas.md) | Revisar aplicación. |
| 01ACW | [Retirada de cantería - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/01ACW-Retirada%20de%20canter%C3%ADa%20-%20varios.md) | Revisar aplicación. |
| 01ACX | [Retirada de cantería - mixtas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/01ACX-Retirada%20de%20canter%C3%ADa%20-%20mixtas.md) | Revisar aplicación. |
| 01ADS | [Retirada de distribuciones de ladrillo - tabiques sencillos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AD_DISTRIBUCIONES_DE_LADRILLO/01ADS-Retirada%20de%20distribuciones%20de%20ladrillo%20-%20tabiques%20sencillos.md) | Revisar aplicación. |
| 01ADT | [Retirada de distribuciones de ladrillo - tabicones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AD_DISTRIBUCIONES_DE_LADRILLO/01ADT-Retirada%20de%20distribuciones%20de%20ladrillo%20-%20tabicones.md) | Revisar aplicación. |
| 01ADW | [Retirada de distribuciones de ladrillo - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AD_DISTRIBUCIONES_DE_LADRILLO/01ADW-Retirada%20de%20distribuciones%20de%20ladrillo%20-%20varios.md) | Revisar aplicación. |
| 01ALE | [Retirada de paredes de ladrillo - especiales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/01ALE-Retirada%20de%20paredes%20de%20ladrillo%20-%20especiales.md) | Revisar aplicación. |
| 01ALH | [Retirada de paredes de ladrillo - huecos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/01ALH-Retirada%20de%20paredes%20de%20ladrillo%20-%20huecos.md) | Revisar aplicación. |
| 01ALM | [Retirada de paredes de ladrillo - macizos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/01ALM-Retirada%20de%20paredes%20de%20ladrillo%20-%20macizos.md) | Revisar aplicación. |
| 01ALP | [Retirada de paredes de ladrillo - perforados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/01ALP-Retirada%20de%20paredes%20de%20ladrillo%20-%20perforados.md) | Revisar aplicación. |
| 01ALW | [Retirada de paredes de ladrillo - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/01ALW-Retirada%20de%20paredes%20de%20ladrillo%20-%20varios.md) | Revisar aplicación. |
| 01ALX | [Retirada de paredes de ladrillo - mixtas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/01ALX-Retirada%20de%20paredes%20de%20ladrillo%20-%20mixtas.md) | Revisar aplicación. |
| 01APE | [Retirada de prefabricados - exteriores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AP_PREFABRICADOS/01APE-Retirada%20de%20prefabricados%20-%20exteriores.md) | Revisar aplicación. |
| 01API | [Retirada de prefabricados - interiores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AP_PREFABRICADOS/01API-Retirada%20de%20prefabricados%20-%20interiores.md) | Revisar aplicación. |
| 01APW | [Retirada de prefabricados - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AP_PREFABRICADOS/01APW-Retirada%20de%20prefabricados%20-%20varios.md) | Revisar aplicación. |
| 01AWD | [Retirada de varios - dinteles](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AW_VARIOS/01AWD-Retirada%20de%20varios%20-%20dinteles.md) | Revisar aplicación. |
| 01AWF | [Retirada de varios - formaciones de pendientes](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AW_VARIOS/01AWF-Retirada%20de%20varios%20-%20formaciones%20de%20pendientes.md) | Revisar aplicación. |
| 01AWM | [Retirada de varios - mochetas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AW_VARIOS/01AWM-Retirada%20de%20varios%20-%20mochetas.md) | Revisar aplicación. |
| 01AWP | [Retirada de varios - peldaños](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AW_VARIOS/01AWP-Retirada%20de%20varios%20-%20pelda%C3%B1os.md) | Revisar aplicación. |
| 01AWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AW_VARIOS/01AWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01CAA | [Retirada de hormigón armado - hormigón armado](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CA_HORMIG%C3%93N_ARMADO/01CAA-Retirada%20de%20hormig%C3%B3n%20armado%20-%20hormig%C3%B3n%20armado.md) | Revisar aplicación. |
| 01CAW | [Retirada de hormigón armado - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CA_HORMIG%C3%93N_ARMADO/01CAW-Retirada%20de%20hormig%C3%B3n%20armado%20-%20varios.md) | Revisar aplicación. |
| 01CMM | [Retirada de hormigón en masa - hormigón en masa](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CM_HORMIG%C3%93N_EN_MASA/01CMM-Retirada%20de%20hormig%C3%B3n%20en%20masa%20-%20hormig%C3%B3n%20en%20masa.md) | Revisar aplicación. |
| 01CMW | [Retirada de hormigón en masa - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CM_HORMIG%C3%93N_EN_MASA/01CMW-Retirada%20de%20hormig%C3%B3n%20en%20masa%20-%20varios.md) | Revisar aplicación. |
| 01CWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CW_VARIOS/01CWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01EBB | [Retirada de a brazo - a brazo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EB_A_BRAZO/01EBB-Retirada%20de%20a%20brazo%20-%20a%20brazo.md) | Revisar aplicación. |
| 01EBW | [Retirada de a brazo - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EB_A_BRAZO/01EBW-Retirada%20de%20a%20brazo%20-%20varios.md) | Revisar aplicación. |
| 01EEE | [Retirada de explosivos - explosivos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EE_EXPLOSIVOS/01EEE-Retirada%20de%20explosivos%20-%20explosivos.md) | Revisar aplicación. |
| 01EEW | [Retirada de explosivos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EE_EXPLOSIVOS/01EEW-Retirada%20de%20explosivos%20-%20varios.md) | Revisar aplicación. |
| 01EMM | [Retirada de mecánicos - mecánicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EM_MEC%C3%81NICOS/01EMM-Retirada%20de%20mec%C3%A1nicos%20-%20mec%C3%A1nicos.md) | Revisar aplicación. |
| 01EMW | [Retirada de mecánicos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EM_MEC%C3%81NICOS/01EMW-Retirada%20de%20mec%C3%A1nicos%20-%20varios.md) | Revisar aplicación. |
| 01EWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EW_VARIOS/01EWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01ICA | [Retirada de climatización - aire acondicionado](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IC_CLIMATIZACI%C3%93N/01ICA-Retirada%20de%20climatizaci%C3%B3n%20-%20aire%20acondicionado.md) | Revisar aplicación. |
| 01ICC | [Retirada de climatización - calefacción](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IC_CLIMATIZACI%C3%93N/01ICC-Retirada%20de%20climatizaci%C3%B3n%20-%20calefacci%C3%B3n.md) | Revisar aplicación. |
| 01ICV | [Retirada de climatización - ventilación](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IC_CLIMATIZACI%C3%93N/01ICV-Retirada%20de%20climatizaci%C3%B3n%20-%20ventilaci%C3%B3n.md) | Revisar aplicación. |
| 01ICW | [Retirada de climatización - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IC_CLIMATIZACI%C3%93N/01ICW-Retirada%20de%20climatizaci%C3%B3n%20-%20varios.md) | Revisar aplicación. |
| 01IEA | [Retirada de eléctricas - acometidas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEA-Retirada%20de%20el%C3%A9ctricas%20-%20acometidas.md) | Revisar aplicación. |
| 01IEC | [Retirada de eléctricas - circuitos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEC-Retirada%20de%20el%C3%A9ctricas%20-%20circuitos.md) | Revisar aplicación. |
| 01IED | [Retirada de eléctricas - derivaciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IED-Retirada%20de%20el%C3%A9ctricas%20-%20derivaciones.md) | Revisar aplicación. |
| 01IEE | [Retirada de eléctricas - enchufes](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEE-Retirada%20de%20el%C3%A9ctricas%20-%20enchufes.md) | Revisar aplicación. |
| 01IEI | [Retirada de eléctricas - interruptores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEI-Retirada%20de%20el%C3%A9ctricas%20-%20interruptores.md) | Revisar aplicación. |
| 01IEK | [Retirada de eléctricas - contadores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEK-Retirada%20de%20el%C3%A9ctricas%20-%20contadores.md) | Revisar aplicación. |
| 01IEL | [Retirada de eléctricas - puntos de luz](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEL-Retirada%20de%20el%C3%A9ctricas%20-%20puntos%20de%20luz.md) | Revisar aplicación. |
| 01IER | [Retirada de eléctricas - líneas generales de alimentación](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IER-Retirada%20de%20el%C3%A9ctricas%20-%20l%C3%ADneas%20generales%20de%20alimentaci%C3%B3n.md) | Revisar aplicación. |
| 01IET | [Retirada de eléctricas - puestas a tierra](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IET-Retirada%20de%20el%C3%A9ctricas%20-%20puestas%20a%20tierra.md) | Revisar aplicación. |
| 01IEW | [Retirada de eléctricas - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/01IEW-Retirada%20de%20el%C3%A9ctricas%20-%20varios.md) | Revisar aplicación. |
| 01IFA | [Retirada de fontanería - acometidas y contadores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFA-Retirada%20de%20fontaner%C3%ADa%20-%20acometidas%20y%20contadores.md) | Revisar aplicación. |
| 01IFC | [Retirada de fontanería - canalizaciones de agua caliente](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFC-Retirada%20de%20fontaner%C3%ADa%20-%20canalizaciones%20de%20agua%20caliente.md) | Revisar aplicación. |
| 01IFD | [Retirada de fontanería - desagües](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFD-Retirada%20de%20fontaner%C3%ADa%20-%20desag%C3%BCes.md) | Revisar aplicación. |
| 01IFF | [Retirada de fontanería - canalizaciones de agua fría](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFF-Retirada%20de%20fontaner%C3%ADa%20-%20canalizaciones%20de%20agua%20fr%C3%ADa.md) | Revisar aplicación. |
| 01IFG | [Retirada de fontanería - griferías](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFG-Retirada%20de%20fontaner%C3%ADa%20-%20grifer%C3%ADas.md) | Revisar aplicación. |
| 01IFS | [Retirada de fontanería - aparatos sanitarios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFS-Retirada%20de%20fontaner%C3%ADa%20-%20aparatos%20sanitarios.md) | Revisar aplicación. |
| 01IFT | [Retirada de fontanería - termos y calentadores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFT-Retirada%20de%20fontaner%C3%ADa%20-%20termos%20y%20calentadores.md) | Revisar aplicación. |
| 01IFV | [Retirada de fontanería - valvulería](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFV-Retirada%20de%20fontaner%C3%ADa%20-%20valvuler%C3%ADa.md) | Revisar aplicación. |
| 01IFW | [Retirada de fontanería - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/01IFW-Retirada%20de%20fontaner%C3%ADa%20-%20varios.md) | Revisar aplicación. |
| 01ILB | [Retirada de gases y licuados - butano](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/01ILB-Retirada%20de%20gases%20y%20licuados%20-%20butano.md) | Revisar aplicación. |
| 01ILC | [Retirada de gases y licuados - gas ciudad](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/01ILC-Retirada%20de%20gases%20y%20licuados%20-%20gas%20ciudad.md) | Revisar aplicación. |
| 01ILF | [Retirada de gases y licuados - fuel-oil](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/01ILF-Retirada%20de%20gases%20y%20licuados%20-%20fuel-oil.md) | Revisar aplicación. |
| 01ILG | [Retirada de gases y licuados - gasóleo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/01ILG-Retirada%20de%20gases%20y%20licuados%20-%20gas%C3%B3leo.md) | Revisar aplicación. |
| 01ILP | [Retirada de gases y licuados - propano](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/01ILP-Retirada%20de%20gases%20y%20licuados%20-%20propano.md) | Revisar aplicación. |
| 01ILW | [Retirada de gases y licuados - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/01ILW-Retirada%20de%20gases%20y%20licuados%20-%20varios.md) | Revisar aplicación. |
| 01IMA | [Retirada de electro-mecánicas - ascensores y montacargas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IM_ELECTRO_MEC%C3%81NICAS/01IMA-Retirada%20de%20electro-mec%C3%A1nicas%20-%20ascensores%20y%20montacargas.md) | Revisar aplicación. |
| 01IMB | [Retirada de electro-mecánicas - equipos de bombeo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IM_ELECTRO_MEC%C3%81NICAS/01IMB-Retirada%20de%20electro-mec%C3%A1nicas%20-%20equipos%20de%20bombeo.md) | Revisar aplicación. |
| 01IME | [Retirada de electro-mecánicas - escaleras mecánicas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IM_ELECTRO_MEC%C3%81NICAS/01IME-Retirada%20de%20electro-mec%C3%A1nicas%20-%20escaleras%20mec%C3%A1nicas.md) | Revisar aplicación. |
| 01IMW | [Retirada de electro-mecánicas - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IM_ELECTRO_MEC%C3%81NICAS/01IMW-Retirada%20de%20electro-mec%C3%A1nicas%20-%20varios.md) | Revisar aplicación. |
| 01IPI | [Retirada de protecciones - contra incendios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IP_PROTECCIONES/01IPI-Retirada%20de%20protecciones%20-%20contra%20incendios.md) | Revisar aplicación. |
| 01IPP | [Retirada de protecciones - pararrayos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IP_PROTECCIONES/01IPP-Retirada%20de%20protecciones%20-%20pararrayos.md) | Revisar aplicación. |
| 01IPR | [Retirada de protecciones - antirrobo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IP_PROTECCIONES/01IPR-Retirada%20de%20protecciones%20-%20antirrobo.md) | Revisar aplicación. |
| 01IPW | [Retirada de protecciones - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IP_PROTECCIONES/01IPW-Retirada%20de%20protecciones%20-%20varios.md) | Revisar aplicación. |
| 01ISB | [Retirada de salubridad - basuras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IS_SALUBRIDAD/01ISB-Retirada%20de%20salubridad%20-%20basuras.md) | Revisar aplicación. |
| 01ISH | [Retirada de salubridad - humos y gases](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IS_SALUBRIDAD/01ISH-Retirada%20de%20salubridad%20-%20humos%20y%20gases.md) | Revisar aplicación. |
| 01ISW | [Retirada de salubridad - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IS_SALUBRIDAD/01ISW-Retirada%20de%20salubridad%20-%20varios.md) | Revisar aplicación. |
| 01IVA | [Retirada de audiovisuales - antenas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IV_AUDIOVISUALES/01IVA-Retirada%20de%20audiovisuales%20-%20antenas.md) | Revisar aplicación. |
| 01IVM | [Retirada de audiovisuales - megafonía](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IV_AUDIOVISUALES/01IVM-Retirada%20de%20audiovisuales%20-%20megafon%C3%ADa.md) | Revisar aplicación. |
| 01IVT | [Retirada de audiovisuales - telefonía](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IV_AUDIOVISUALES/01IVT-Retirada%20de%20audiovisuales%20-%20telefon%C3%ADa.md) | Revisar aplicación. |
| 01IVV | [Retirada de audiovisuales - vídeo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IV_AUDIOVISUALES/01IVV-Retirada%20de%20audiovisuales%20-%20v%C3%ADdeo.md) | Revisar aplicación. |
| 01IVW | [Retirada de audiovisuales - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IV_AUDIOVISUALES/01IVW-Retirada%20de%20audiovisuales%20-%20varios.md) | Revisar aplicación. |
| 01IWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IW_VARIOS/01IWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01KAM | [Retirada de acero - mamparas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KA_ACERO/01KAM-Retirada%20de%20acero%20-%20mamparas.md) | Revisar aplicación. |
| 01KAP | [Retirada de acero - puertas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KA_ACERO/01KAP-Retirada%20de%20acero%20-%20puertas.md) | Revisar aplicación. |
| 01KAV | [Retirada de acero - ventanas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KA_ACERO/01KAV-Retirada%20de%20acero%20-%20ventanas.md) | Revisar aplicación. |
| 01KAW | [Retirada de acero - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KA_ACERO/01KAW-Retirada%20de%20acero%20-%20varios.md) | Revisar aplicación. |
| 01KLM | [Retirada de aleaciones ligeras - mamparas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KL_ALEACIONES_LIGERAS/01KLM-Retirada%20de%20aleaciones%20ligeras%20-%20mamparas.md) | Revisar aplicación. |
| 01KLP | [Retirada de aleaciones ligeras - puertas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KL_ALEACIONES_LIGERAS/01KLP-Retirada%20de%20aleaciones%20ligeras%20-%20puertas.md) | Revisar aplicación. |
| 01KLV | [Retirada de aleaciones ligeras - ventanas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KL_ALEACIONES_LIGERAS/01KLV-Retirada%20de%20aleaciones%20ligeras%20-%20ventanas.md) | Revisar aplicación. |
| 01KLW | [Retirada de aleaciones ligeras - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KL_ALEACIONES_LIGERAS/01KLW-Retirada%20de%20aleaciones%20ligeras%20-%20varios.md) | Revisar aplicación. |
| 01KMA | [Retirada de madera - armarios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KM_MADERA/01KMA-Retirada%20de%20madera%20-%20armarios.md) | Revisar aplicación. |
| 01KMM | [Retirada de madera - mamparas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KM_MADERA/01KMM-Retirada%20de%20madera%20-%20mamparas.md) | Revisar aplicación. |
| 01KMP | [Retirada de madera - puertas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KM_MADERA/01KMP-Retirada%20de%20madera%20-%20puertas.md) | Revisar aplicación. |
| 01KMV | [Retirada de madera - ventanas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KM_MADERA/01KMV-Retirada%20de%20madera%20-%20ventanas.md) | Revisar aplicación. |
| 01KMW | [Retirada de madera - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KM_MADERA/01KMW-Retirada%20de%20madera%20-%20varios.md) | Revisar aplicación. |
| 01KSB | [Retirada de seguridad y protección - barandillas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KS_SEGURIDAD_Y_PROTECCI%C3%93N/01KSB-Retirada%20de%20seguridad%20y%20protecci%C3%B3n%20-%20barandillas.md) | Revisar aplicación. |
| 01KSC | [Retirada de seguridad y protección - celosías](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KS_SEGURIDAD_Y_PROTECCI%C3%93N/01KSC-Retirada%20de%20seguridad%20y%20protecci%C3%B3n%20-%20celos%C3%ADas.md) | Revisar aplicación. |
| 01KSP | [Retirada de seguridad y protección - persianas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KS_SEGURIDAD_Y_PROTECCI%C3%93N/01KSP-Retirada%20de%20seguridad%20y%20protecci%C3%B3n%20-%20persianas.md) | Revisar aplicación. |
| 01KSR | [Retirada de seguridad y protección - rejas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KS_SEGURIDAD_Y_PROTECCI%C3%93N/01KSR-Retirada%20de%20seguridad%20y%20protecci%C3%B3n%20-%20rejas.md) | Revisar aplicación. |
| 01KSW | [Retirada de seguridad y protección - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KS_SEGURIDAD_Y_PROTECCI%C3%93N/01KSW-Retirada%20de%20seguridad%20y%20protecci%C3%B3n%20-%20varios.md) | Revisar aplicación. |
| 01KWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KW_VARIOS/01KWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01QHA | [Retirada de horizontales - ajardinadas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QH_HORIZONTALES/01QHA-Retirada%20de%20horizontales%20-%20ajardinadas.md) | Revisar aplicación. |
| 01QHN | [Retirada de horizontales - no transitables](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QH_HORIZONTALES/01QHN-Retirada%20de%20horizontales%20-%20no%20transitables.md) | Revisar aplicación. |
| 01QHT | [Retirada de horizontales - transitables](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QH_HORIZONTALES/01QHT-Retirada%20de%20horizontales%20-%20transitables.md) | Revisar aplicación. |
| 01QHW | [Retirada de horizontales - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QH_HORIZONTALES/01QHW-Retirada%20de%20horizontales%20-%20varios.md) | Revisar aplicación. |
| 01QIF | [Retirada de inclinadas - fibrocemento](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIF-Retirada%20de%20inclinadas%20-%20fibrocemento.md) | Revisar aplicación. |
| 01QIG | [Retirada de inclinadas - galvanizadas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIG-Retirada%20de%20inclinadas%20-%20galvanizadas.md) | Revisar aplicación. |
| 01QIL | [Retirada de inclinadas - aleaciones ligeras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIL-Retirada%20de%20inclinadas%20-%20aleaciones%20ligeras.md) | Revisar aplicación. |
| 01QIP | [Retirada de inclinadas - pizarra](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIP-Retirada%20de%20inclinadas%20-%20pizarra.md) | Revisar aplicación. |
| 01QIS | [Retirada de inclinadas - sintéticas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIS-Retirada%20de%20inclinadas%20-%20sint%C3%A9ticas.md) | Revisar aplicación. |
| 01QIT | [Retirada de inclinadas - tejas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIT-Retirada%20de%20inclinadas%20-%20tejas.md) | Revisar aplicación. |
| 01QIW | [Retirada de inclinadas - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/01QIW-Retirada%20de%20inclinadas%20-%20varios.md) | Revisar aplicación. |
| 01QWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QW_VARIOS/01QWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01RAA | [Retirada de aplacados - alicatados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RA_APLACADOS/01RAA-Retirada%20de%20aplacados%20-%20alicatados.md) | Revisar aplicación. |
| 01RAC | [Retirada de aplacados - chapados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RA_APLACADOS/01RAC-Retirada%20de%20aplacados%20-%20chapados.md) | Revisar aplicación. |
| 01RAW | [Retirada de aplacados - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RA_APLACADOS/01RAW-Retirada%20de%20aplacados%20-%20varios.md) | Revisar aplicación. |
| 01RCE | [Retirada de continuos - enfoscados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RC_CONTINUOS/01RCE-Retirada%20de%20continuos%20-%20enfoscados.md) | Revisar aplicación. |
| 01RCG | [Retirada de continuos - guarnecidos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RC_CONTINUOS/01RCG-Retirada%20de%20continuos%20-%20guarnecidos.md) | Revisar aplicación. |
| 01RCL | [Retirada de continuos - enlucidos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RC_CONTINUOS/01RCL-Retirada%20de%20continuos%20-%20enlucidos.md) | Revisar aplicación. |
| 01RCT | [Retirada de continuos - tendidos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RC_CONTINUOS/01RCT-Retirada%20de%20continuos%20-%20tendidos.md) | Revisar aplicación. |
| 01RCW | [Retirada de continuos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RC_CONTINUOS/01RCW-Retirada%20de%20continuos%20-%20varios.md) | Revisar aplicación. |
| 01RLC | [Retirada de ligeros - corcho](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RL_LIGEROS/01RLC-Retirada%20de%20ligeros%20-%20corcho.md) | Revisar aplicación. |
| 01RLL | [Retirada de ligeros - aleaciones ligeras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RL_LIGEROS/01RLL-Retirada%20de%20ligeros%20-%20aleaciones%20ligeras.md) | Revisar aplicación. |
| 01RLM | [Retirada de ligeros - madera](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RL_LIGEROS/01RLM-Retirada%20de%20ligeros%20-%20madera.md) | Revisar aplicación. |
| 01RLW | [Retirada de ligeros - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RL_LIGEROS/01RLW-Retirada%20de%20ligeros%20-%20varios.md) | Revisar aplicación. |
| 01RPA | [Retirada de peldaños - piedras artificiales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/01RPA-Retirada%20de%20pelda%C3%B1os%20-%20piedras%20artificiales.md) | Revisar aplicación. |
| 01RPC | [Retirada de peldaños - cerámicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/01RPC-Retirada%20de%20pelda%C3%B1os%20-%20cer%C3%A1micos.md) | Revisar aplicación. |
| 01RPL | [Retirada de peldaños - ligeros](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/01RPL-Retirada%20de%20pelda%C3%B1os%20-%20ligeros.md) | Revisar aplicación. |
| 01RPM | [Retirada de peldaños - maderas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/01RPM-Retirada%20de%20pelda%C3%B1os%20-%20maderas.md) | Revisar aplicación. |
| 01RPN | [Retirada de peldaños - piedras naturales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/01RPN-Retirada%20de%20pelda%C3%B1os%20-%20piedras%20naturales.md) | Revisar aplicación. |
| 01RPW | [Retirada de peldaños - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/01RPW-Retirada%20de%20pelda%C3%B1os%20-%20varios.md) | Revisar aplicación. |
| 01RSC | [Retirada de suelos - cerámicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSC-Retirada%20de%20suelos%20-%20cer%C3%A1micos.md) | Revisar aplicación. |
| 01RSE | [Retirada de suelos - especiales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSE-Retirada%20de%20suelos%20-%20especiales.md) | Revisar aplicación. |
| 01RSH | [Retirada de suelos - hidráulicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSH-Retirada%20de%20suelos%20-%20hidr%C3%A1ulicos.md) | Revisar aplicación. |
| 01RSL | [Retirada de suelos - ligeros](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSL-Retirada%20de%20suelos%20-%20ligeros.md) | Revisar aplicación. |
| 01RSM | [Retirada de suelos - maderas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSM-Retirada%20de%20suelos%20-%20maderas.md) | Revisar aplicación. |
| 01RSN | [Retirada de suelos - piedras naturales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSN-Retirada%20de%20suelos%20-%20piedras%20naturales.md) | Revisar aplicación. |
| 01RSS | [Retirada de suelos - soleras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSS-Retirada%20de%20suelos%20-%20soleras.md) | Revisar aplicación. |
| 01RST | [Retirada de suelos - terrazos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RST-Retirada%20de%20suelos%20-%20terrazos.md) | Revisar aplicación. |
| 01RSW | [Retirada de suelos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/01RSW-Retirada%20de%20suelos%20-%20varios.md) | Revisar aplicación. |
| 01RTE | [Retirada de techos - escayola](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/01RTE-Retirada%20de%20techos%20-%20escayola.md) | Revisar aplicación. |
| 01RTF | [Retirada de techos - fibras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/01RTF-Retirada%20de%20techos%20-%20fibras.md) | Revisar aplicación. |
| 01RTL | [Retirada de techos - aleaciones ligeras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/01RTL-Retirada%20de%20techos%20-%20aleaciones%20ligeras.md) | Revisar aplicación. |
| 01RTM | [Retirada de techos - madera](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/01RTM-Retirada%20de%20techos%20-%20madera.md) | Revisar aplicación. |
| 01RTS | [Retirada de techos - sintéticos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/01RTS-Retirada%20de%20techos%20-%20sint%C3%A9ticos.md) | Revisar aplicación. |
| 01RTW | [Retirada de techos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/01RTW-Retirada%20de%20techos%20-%20varios.md) | Revisar aplicación. |
| 01RWA | [Retirada de varios - alféizares](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RW_VARIOS/01RWA-Retirada%20de%20varios%20-%20alf%C3%A9izares.md) | Revisar aplicación. |
| 01RWR | [Retirada de varios - remates](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RW_VARIOS/01RWR-Retirada%20de%20varios%20-%20remates.md) | Revisar aplicación. |
| 01RWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RW_VARIOS/01RWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01SCA | [Retirada de redes colgadas - arquetas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SC_REDES_COLGADAS/01SCA-Retirada%20de%20redes%20colgadas%20-%20arquetas.md) | Revisar aplicación. |
| 01SCC | [Retirada de redes colgadas - colectores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SC_REDES_COLGADAS/01SCC-Retirada%20de%20redes%20colgadas%20-%20colectores.md) | Revisar aplicación. |
| 01SCE | [Retirada de redes colgadas - elementos complementarios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SC_REDES_COLGADAS/01SCE-Retirada%20de%20redes%20colgadas%20-%20elementos%20complementarios.md) | Revisar aplicación. |
| 01SCW | [Retirada de redes colgadas - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SC_REDES_COLGADAS/01SCW-Retirada%20de%20redes%20colgadas%20-%20varios.md) | Revisar aplicación. |
| 01SEA | [Retirada de redes enterradas - arquetas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SE_REDES_ENTERRADAS/01SEA-Retirada%20de%20redes%20enterradas%20-%20arquetas.md) | Revisar aplicación. |
| 01SEC | [Retirada de redes enterradas - colectores](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SE_REDES_ENTERRADAS/01SEC-Retirada%20de%20redes%20enterradas%20-%20colectores.md) | Revisar aplicación. |
| 01SEE | [Retirada de redes enterradas - elementos complementarios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SE_REDES_ENTERRADAS/01SEE-Retirada%20de%20redes%20enterradas%20-%20elementos%20complementarios.md) | Revisar aplicación. |
| 01SEP | [Retirada de redes enterradas - pozos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SE_REDES_ENTERRADAS/01SEP-Retirada%20de%20redes%20enterradas%20-%20pozos.md) | Revisar aplicación. |
| 01SEW | [Retirada de redes enterradas - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SE_REDES_ENTERRADAS/01SEW-Retirada%20de%20redes%20enterradas%20-%20varios.md) | Revisar aplicación. |
| 01SVB | [Retirada de redes verticales - bajantes](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SV_REDES_VERTICALES/01SVB-Retirada%20de%20redes%20verticales%20-%20bajantes.md) | Revisar aplicación. |
| 01SVC | [Retirada de redes verticales - cazoletas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SV_REDES_VERTICALES/01SVC-Retirada%20de%20redes%20verticales%20-%20cazoletas.md) | Revisar aplicación. |
| 01SVE | [Retirada de redes verticales - elementos complementaris](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SV_REDES_VERTICALES/01SVE-Retirada%20de%20redes%20verticales%20-%20elementos%20complementaris.md) | Revisar aplicación. |
| 01SVW | [Retirada de redes verticales - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SV_REDES_VERTICALES/01SVW-Retirada%20de%20redes%20verticales%20-%20varios.md) | Revisar aplicación. |
| 01SWA | [Retirada de varios - acometidas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SW_VARIOS/01SWA-Retirada%20de%20varios%20-%20acometidas.md) | Revisar aplicación. |
| 01SWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SW_VARIOS/01SWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01TAA | [Retirada de apeos y apuntalamientos - abovedados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TA_APEOS_Y_APUNTALAMIENTOS/01TAA-Retirada%20de%20apeos%20y%20apuntalamientos%20-%20abovedados.md) | Revisar aplicación. |
| 01TAH | [Retirada de apeos y apuntalamientos - horizontales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TA_APEOS_Y_APUNTALAMIENTOS/01TAH-Retirada%20de%20apeos%20y%20apuntalamientos%20-%20horizontales.md) | Revisar aplicación. |
| 01TAI | [Retirada de apeos y apuntalamientos - inclinados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TA_APEOS_Y_APUNTALAMIENTOS/01TAI-Retirada%20de%20apeos%20y%20apuntalamientos%20-%20inclinados.md) | Revisar aplicación. |
| 01TAV | [Retirada de apeos y apuntalamientos - verticales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TA_APEOS_Y_APUNTALAMIENTOS/01TAV-Retirada%20de%20apeos%20y%20apuntalamientos%20-%20verticales.md) | Revisar aplicación. |
| 01TAW | [Retirada de apeos y apuntalamientos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TA_APEOS_Y_APUNTALAMIENTOS/01TAW-Retirada%20de%20apeos%20y%20apuntalamientos%20-%20varios.md) | Revisar aplicación. |
| 01TCE | [Retirada de accesibilidad - exterior](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TC_ACCESIBILIDAD/01TCE-Retirada%20de%20accesibilidad%20-%20exterior.md) | Revisar aplicación. |
| 01TCI | [Retirada de accesibilidad - interior](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TC_ACCESIBILIDAD/01TCI-Retirada%20de%20accesibilidad%20-%20interior.md) | Revisar aplicación. |
| 01TCW | [Retirada de accesibilidad - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TC_ACCESIBILIDAD/01TCW-Retirada%20de%20accesibilidad%20-%20varios.md) | Revisar aplicación. |
| 01TLD | [Retirada de limpiezas y retiradas - desinfecciones y desratizaciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/01TLD-Retirada%20de%20limpiezas%20y%20retiradas%20-%20desinfecciones%20y%20desratizaciones.md) | Revisar aplicación. |
| 01TLE | [Retirada de limpiezas y retiradas - escombros](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/01TLE-Retirada%20de%20limpiezas%20y%20retiradas%20-%20escombros.md) | Revisar aplicación. |
| 01TLL | [Retirada de limpiezas y retiradas - limpieza](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/01TLL-Retirada%20de%20limpiezas%20y%20retiradas%20-%20limpieza.md) | Revisar aplicación. |
| 01TLM | [Retirada de limpiezas y retiradas - muebles](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/01TLM-Retirada%20de%20limpiezas%20y%20retiradas%20-%20muebles.md) | Revisar aplicación. |
| 01TLR | [Retirada de limpiezas y retiradas - rescates de objetos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/01TLR-Retirada%20de%20limpiezas%20y%20retiradas%20-%20rescates%20de%20objetos.md) | Revisar aplicación. |
| 01TLW | [Retirada de limpiezas y retiradas - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/01TLW-Retirada%20de%20limpiezas%20y%20retiradas%20-%20varios.md) | Revisar aplicación. |
| 01TMA | [Retirada de medidas especiales - agotamientos y desecaciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TM_MEDIDAS_ESPECIALES/01TMA-Retirada%20de%20medidas%20especiales%20-%20agotamientos%20y%20desecaciones.md) | Revisar aplicación. |
| 01TMT | [Retirada de medidas especiales - tratamientos del terreno](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TM_MEDIDAS_ESPECIALES/01TMT-Retirada%20de%20medidas%20especiales%20-%20tratamientos%20del%20terreno.md) | Revisar aplicación. |
| 01TMW | [Retirada de medidas especiales - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TM_MEDIDAS_ESPECIALES/01TMW-Retirada%20de%20medidas%20especiales%20-%20varios.md) | Revisar aplicación. |
| 01TRA | [Retirada de actuación sobre redes - agua](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRA-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20agua.md) | Revisar aplicación. |
| 01TRC | [Retirada de actuación sobre redes - climatización](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRC-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20climatizaci%C3%B3n.md) | Revisar aplicación. |
| 01TRE | [Retirada de actuación sobre redes - eléctricas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRE-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20el%C3%A9ctricas.md) | Revisar aplicación. |
| 01TRG | [Retirada de actuación sobre redes - gases y licuados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRG-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20gases%20y%20licuados.md) | Revisar aplicación. |
| 01TRS | [Retirada de actuación sobre redes - saneamiento](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRS-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20saneamiento.md) | Revisar aplicación. |
| 01TRT | [Retirada de actuación sobre redes - telefónicas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRT-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20telef%C3%B3nicas.md) | Revisar aplicación. |
| 01TRV | [Retirada de actuación sobre redes - audiovisuales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRV-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20audiovisuales.md) | Revisar aplicación. |
| 01TRW | [Retirada de actuación sobre redes - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/01TRW-Retirada%20de%20actuaci%C3%B3n%20sobre%20redes%20-%20varios.md) | Revisar aplicación. |
| 01TSP | [Retirada de señalizaciones, prevenciones y protecciones - prevenciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TS_SE%C3%91ALIZACIONES_PREVENCIONES_Y_PROTECCIONES/01TSP-Retirada%20de%20se%C3%B1alizaciones%2C%20prevenciones%20y%20protecciones%20-%20prevenciones.md) | Revisar aplicación. |
| 01TSS | [Retirada de señalizaciones, prevenciones y protecciones - señalizaciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TS_SE%C3%91ALIZACIONES_PREVENCIONES_Y_PROTECCIONES/01TSS-Retirada%20de%20se%C3%B1alizaciones%2C%20prevenciones%20y%20protecciones%20-%20se%C3%B1alizaciones.md) | Revisar aplicación. |
| 01TST | [Retirada de señalizaciones, prevenciones y protecciones - protecciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TS_SE%C3%91ALIZACIONES_PREVENCIONES_Y_PROTECCIONES/01TST-Retirada%20de%20se%C3%B1alizaciones%2C%20prevenciones%20y%20protecciones%20-%20protecciones.md) | Revisar aplicación. |
| 01TSW | [Retirada de señalizaciones, prevenciones y protecciones - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TS_SE%C3%91ALIZACIONES_PREVENCIONES_Y_PROTECCIONES/01TSW-Retirada%20de%20se%C3%B1alizaciones%2C%20prevenciones%20y%20protecciones%20-%20varios.md) | Revisar aplicación. |
| 01TVA | [Retirada de vegetación - arranques, destoconados y talados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TV_VEGETACI%C3%93N/01TVA-Retirada%20de%20vegetaci%C3%B3n%20-%20arranques%2C%20destoconados%20y%20talados.md) | Revisar aplicación. |
| 01TVD | [Retirada de vegetación - desbroces](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TV_VEGETACI%C3%93N/01TVD-Retirada%20de%20vegetaci%C3%B3n%20-%20desbroces.md) | Revisar aplicación. |
| 01TVP | [Retirada de vegetación - podas y tratamientos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TV_VEGETACI%C3%93N/01TVP-Retirada%20de%20vegetaci%C3%B3n%20-%20podas%20y%20tratamientos.md) | Revisar aplicación. |
| 01TVW | [Retirada de vegetación - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TV_VEGETACI%C3%93N/01TVW-Retirada%20de%20vegetaci%C3%B3n%20-%20varios.md) | Revisar aplicación. |
| 01TWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TW_VARIOS/01TWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01UAA | [Retirada de alcantarillado - acometidas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/01UAA-Retirada%20de%20alcantarillado%20-%20acometidas.md) | Revisar aplicación. |
| 01UAC | [Retirada de alcantarillado - canalizaciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/01UAC-Retirada%20de%20alcantarillado%20-%20canalizaciones.md) | Revisar aplicación. |
| 01UAD | [Retirada de alcantarillado - depuración y vertido](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/01UAD-Retirada%20de%20alcantarillado%20-%20depuraci%C3%B3n%20y%20vertido.md) | Revisar aplicación. |
| 01UAP | [Retirada de alcantarillado - pozos y arquetas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/01UAP-Retirada%20de%20alcantarillado%20-%20pozos%20y%20arquetas.md) | Revisar aplicación. |
| 01UAS | [Retirada de alcantarillado - sumideros](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/01UAS-Retirada%20de%20alcantarillado%20-%20sumideros.md) | Revisar aplicación. |
| 01UAW | [Retirada de alcantarillado - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/01UAW-Retirada%20de%20alcantarillado%20-%20varios.md) | Revisar aplicación. |
| 01UPB | [Retirada de pavimentaciones - bordillos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPB-Retirada%20de%20pavimentaciones%20-%20bordillos.md) | Revisar aplicación. |
| 01UPC | [Retirada de pavimentaciones - calzadas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPC-Retirada%20de%20pavimentaciones%20-%20calzadas.md) | Revisar aplicación. |
| 01UPE | [Retirada de pavimentaciones - encintados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPE-Retirada%20de%20pavimentaciones%20-%20encintados.md) | Revisar aplicación. |
| 01UPF | [Retirada de pavimentaciones - firmes](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPF-Retirada%20de%20pavimentaciones%20-%20firmes.md) | Revisar aplicación. |
| 01UPP | [Retirada de pavimentaciones - pavimentos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPP-Retirada%20de%20pavimentaciones%20-%20pavimentos.md) | Revisar aplicación. |
| 01UPS | [Retirada de pavimentaciones - soleras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPS-Retirada%20de%20pavimentaciones%20-%20soleras.md) | Revisar aplicación. |
| 01UPV | [Retirada de pavimentaciones - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPV-Retirada%20de%20pavimentaciones%20-%20varios.md) | Revisar aplicación. |
| 01UUB | [Retirada de amueblamiento urbano - bancos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/01UUB-Retirada%20de%20amueblamiento%20urbano%20-%20bancos.md) | Revisar aplicación. |
| 01UUF | [Retirada de amueblamiento urbano - fuentes](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/01UUF-Retirada%20de%20amueblamiento%20urbano%20-%20fuentes.md) | Revisar aplicación. |
| 01UUJ | [Retirada de amueblamiento urbano - juegos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/01UUJ-Retirada%20de%20amueblamiento%20urbano%20-%20juegos.md) | Revisar aplicación. |
| 01UUP | [Retirada de amueblamiento urbano - papeleras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/01UUP-Retirada%20de%20amueblamiento%20urbano%20-%20papeleras.md) | Revisar aplicación. |
| 01UUS | [Retirada de amueblamiento urbano - equipamiento deportivo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/01UUS-Retirada%20de%20amueblamiento%20urbano%20-%20equipamiento%20deportivo.md) | Revisar aplicación. |
| 01UUW | [Retirada de amueblamiento urbano - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/01UUW-Retirada%20de%20amueblamiento%20urbano%20-%20varios.md) | Revisar aplicación. |
| 01UWC | [Retirada de varios - cerramientos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UW_VARIOS/01UWC-Retirada%20de%20varios%20-%20cerramientos.md) | Revisar aplicación. |
| 01WAA | [Retirada de aislamientos - acústicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WA_AISLAMIENTOS/01WAA-Retirada%20de%20aislamientos%20-%20ac%C3%BAsticos.md) | Revisar aplicación. |
| 01WAI | [Retirada de aislamientos - impermeabilizaciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WA_AISLAMIENTOS/01WAI-Retirada%20de%20aislamientos%20-%20impermeabilizaciones.md) | Revisar aplicación. |
| 01WAT | [Retirada de aislamientos - térmicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WA_AISLAMIENTOS/01WAT-Retirada%20de%20aislamientos%20-%20t%C3%A9rmicos.md) | Revisar aplicación. |
| 01WAW | [Retirada de aislamientos - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WA_AISLAMIENTOS/01WAW-Retirada%20de%20aislamientos%20-%20varios.md) | Revisar aplicación. |
| 01WDM | [Retirada de decoración - mobiliario](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WD_DECORACI%C3%93N/01WDM-Retirada%20de%20decoraci%C3%B3n%20-%20mobiliario.md) | Revisar aplicación. |
| 01WDW | [Retirada de decoración - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WD_DECORACI%C3%93N/01WDW-Retirada%20de%20decoraci%C3%B3n%20-%20varios.md) | Revisar aplicación. |
| 01WVL | [Retirada de vidrios - lunas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WV_VIDRIOS/01WVL-Retirada%20de%20vidrios%20-%20lunas.md) | Revisar aplicación. |
| 01WVV | [Retirada de vidrios - vidrios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WV_VIDRIOS/01WVV-Retirada%20de%20vidrios%20-%20vidrios.md) | Revisar aplicación. |
| 01WVW | [Retirada de vidrios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WV_VIDRIOS/01WVW-Retirada%20de%20vidrios%20-%20varios.md) | Revisar aplicación. |
| 01WWN | [Retirada de varios - amianto](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WW_VARIOS/01WWN-Retirada%20de%20varios%20-%20amianto.md) | Revisar aplicación. |
| 01WWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WW_VARIOS/01WWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 01XAC | [Retirada de acero - laminados en caliente](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XA_ACERO/01XAC-Retirada%20de%20acero%20-%20laminados%20en%20caliente.md) | Revisar aplicación. |
| 01XAF | [Retirada de acero - laminados en frio](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XA_ACERO/01XAF-Retirada%20de%20acero%20-%20laminados%20en%20frio.md) | Revisar aplicación. |
| 01XAW | [Retirada de acero - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XA_ACERO/01XAW-Retirada%20de%20acero%20-%20varios.md) | Revisar aplicación. |
| 01XFB | [Retirada de forjados - bidireccionales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XF_FORJADOS/01XFB-Retirada%20de%20forjados%20-%20bidireccionales.md) | Revisar aplicación. |
| 01XFU | [Retirada de forjados - unidireccionales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XF_FORJADOS/01XFU-Retirada%20de%20forjados%20-%20unidireccionales.md) | Revisar aplicación. |
| 01XFW | [Retirada de forjados - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XF_FORJADOS/01XFW-Retirada%20de%20forjados%20-%20varios.md) | Revisar aplicación. |
| 01XHJ | [Retirada de hormigón armado - vigas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XH_HORMIG%C3%93N_ARMADO/01XHJ-Retirada%20de%20hormig%C3%B3n%20armado%20-%20vigas.md) | Revisar aplicación. |
| 01XHL | [Retirada de hormigón armado - losas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XH_HORMIG%C3%93N_ARMADO/01XHL-Retirada%20de%20hormig%C3%B3n%20armado%20-%20losas.md) | Revisar aplicación. |
| 01XHP | [Retirada de hormigón armado - pilares](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XH_HORMIG%C3%93N_ARMADO/01XHP-Retirada%20de%20hormig%C3%B3n%20armado%20-%20pilares.md) | Revisar aplicación. |
| 01XHW | [Retirada de hormigón armado - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XH_HORMIG%C3%93N_ARMADO/01XHW-Retirada%20de%20hormig%C3%B3n%20armado%20-%20varios.md) | Revisar aplicación. |
| 01XML | [Retirada de madera - laminadas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XM_MADERA/01XML-Retirada%20de%20madera%20-%20laminadas.md) | Revisar aplicación. |
| 01XMT | [Retirada de madera - tradicionales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XM_MADERA/01XMT-Retirada%20de%20madera%20-%20tradicionales.md) | Revisar aplicación. |
| 01XMW | [Retirada de madera - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XM_MADERA/01XMW-Retirada%20de%20madera%20-%20varios.md) | Revisar aplicación. |
| 01XWE | [Retirada de varios - estructuras especiales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XW_VARIOS/01XWE-Retirada%20de%20varios%20-%20estructuras%20especiales.md) | Revisar aplicación. |
| 01XWW | [Retirada de varios - varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XW_VARIOS/01XWW-Retirada%20de%20varios%20-%20varios.md) | Revisar aplicación. |
| 02ACC | [Apertura de cajas - Apertura de cajas](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AC_APERTURA_DE_CAJAS/02ACC-Apertura%20de%20cajas%20-%20Apertura%20de%20cajas.md) | Revisar aplicación. |
| 02ACW | [Apertura de cajas - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AC_APERTURA_DE_CAJAS/02ACW-Apertura%20de%20cajas%20-%20Varios.md) | Revisar aplicación. |
| 02ADD | [Desmontes - Desmontes](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AD_DESMONTES/02ADD-Desmontes%20-%20Desmontes.md) | Revisar aplicación. |
| 02ADW | [Desmontes - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AD_DESMONTES/02ADW-Desmontes%20-%20Varios.md) | Revisar aplicación. |
| 02AEE | [Explanaciones - Explanaciones](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AE_EXPLANACIONES/02AEE-Explanaciones%20-%20Explanaciones.md) | Revisar aplicación. |
| 02AEW | [Explanaciones - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AE_EXPLANACIONES/02AEW-Explanaciones%20-%20Varios.md) | Revisar aplicación. |
| 02ATT | [Terraplenes - Terraplenes](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AT_TERRAPLENES/02ATT-Terraplenes%20-%20Terraplenes.md) | Revisar aplicación. |
| 02ATW | [Terraplenes - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AT_TERRAPLENES/02ATW-Terraplenes%20-%20Varios.md) | Revisar aplicación. |
| 02AVV | [Vaciados - Vaciados](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AV_VACIADOS/02AVV-Vaciados%20-%20Vaciados.md) | Revisar aplicación. |
| 02AVW | [Vaciados - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AV_VACIADOS/02AVW-Vaciados%20-%20Varios.md) | Revisar aplicación. |
| 02AWW | [Varios - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AW_VARIOS/02AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 02PBB | [A brazo - A brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PB_A_BRAZO/02PBB-A%20brazo%20-%20A%20brazo.md) | Revisar aplicación. |
| 02PBW | [A brazo - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PB_A_BRAZO/02PBW-A%20brazo%20-%20Varios.md) | Revisar aplicación. |
| 02PMM | [Medios mecánicos - Medios mecánicos](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PM_MEDIOS_MEC%C3%81NICOS/02PMM-Medios%20mec%C3%A1nicos%20-%20Medios%20mec%C3%A1nicos.md) | Revisar aplicación. |
| 02PMW | [Medios mecánicos - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PM_MEDIOS_MEC%C3%81NICOS/02PMW-Medios%20mec%C3%A1nicos%20-%20Varios.md) | Revisar aplicación. |
| 02PWW | [Varios - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PW_VARIOS/02PWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 02RCB | [Compactaciones - A brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RC_COMPACTACIONES/02RCB-Compactaciones%20-%20A%20brazo.md) | Revisar aplicación. |
| 02RCM | [Compactaciones - Medios mecánicos](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RC_COMPACTACIONES/02RCM-Compactaciones%20-%20Medios%20mec%C3%A1nicos.md) | Revisar aplicación. |
| 02RCW | [Compactaciones - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RC_COMPACTACIONES/02RCW-Compactaciones%20-%20Varios.md) | Revisar aplicación. |
| 02RRB | [Rellenos - A brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/02RRB-Rellenos%20-%20A%20brazo.md) | Revisar aplicación. |
| 02RRM | [Rellenos - Medios mecánicos](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/02RRM-Rellenos%20-%20Medios%20mec%C3%A1nicos.md) | Revisar aplicación. |
| 02RRW | [Rellenos - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/02RRW-Rellenos%20-%20Varios.md) | Revisar aplicación. |
| 02RWW | [Varios - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RW_VARIOS/02RWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 02TBB | [A brazo - A brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TB_A_BRAZO/02TBB-A%20brazo%20-%20A%20brazo.md) | Revisar aplicación. |
| 02TBW | [A brazo - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TB_A_BRAZO/02TBW-A%20brazo%20-%20Varios.md) | Revisar aplicación. |
| 02TMM | [Medios mecánicos - Medios mecánicos](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TM_MEDIOS_MEC%C3%81NICOS/02TMM-Medios%20mec%C3%A1nicos%20-%20Medios%20mec%C3%A1nicos.md) | Revisar aplicación. |
| 02TMW | [Medios mecánicos - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TM_MEDIOS_MEC%C3%81NICOS/02TMW-Medios%20mec%C3%A1nicos%20-%20Varios.md) | Revisar aplicación. |
| 02TWW | [Varios - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TW_VARIOS/02TWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 02WAA | [Agotamientos - Agotamientos](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WA_AGOTAMIENTOS/02WAA-Agotamientos%20-%20Agotamientos.md) | Revisar aplicación. |
| 02WAW | [Agotamientos - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WA_AGOTAMIENTOS/02WAW-Agotamientos%20-%20Varios.md) | Revisar aplicación. |
| 02WEE | [Entibaciones - Entibaciones](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WE_ENTIBACIONES/02WEE-Entibaciones%20-%20Entibaciones.md) | Revisar aplicación. |
| 02WEW | [Entibaciones - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WE_ENTIBACIONES/02WEW-Entibaciones%20-%20Varios.md) | Revisar aplicación. |
| 02WGG | [Galerías - Galerías](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WG_GALER%C3%8DAS/02WGG-Galer%C3%ADas%20-%20Galer%C3%ADas.md) | Revisar aplicación. |
| 02WGW | [Galerías - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WG_GALER%C3%8DAS/02WGW-Galer%C3%ADas%20-%20Varios.md) | Revisar aplicación. |
| 02WSS | [Sistemas especiales - Sistemas especiales](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WS_SISTEMAS_ESPECIALES/02WSS-Sistemas%20especiales%20-%20Sistemas%20especiales.md) | Revisar aplicación. |
| 02WSW | [Sistemas especiales - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WS_SISTEMAS_ESPECIALES/02WSW-Sistemas%20especiales%20-%20Varios.md) | Revisar aplicación. |
| 02WWW | [Varios - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WW_VARIOS/02WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 02WXW | [Mixtas - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WX_MIXTAS/02WXW-Mixtas%20-%20Varios.md) | Revisar aplicación. |
| 02WXX | [Mixtas - Sistemas especiales](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WX_MIXTAS/02WXX-Mixtas%20-%20Sistemas%20especiales.md) | Revisar aplicación. |
| 02ZBB | [A brazo - A brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZB_A_BRAZO/02ZBB-A%20brazo%20-%20A%20brazo.md) | Revisar aplicación. |
| 02ZBW | [A brazo - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZB_A_BRAZO/02ZBW-A%20brazo%20-%20Varios.md) | Revisar aplicación. |
| 02ZMM | [Medios mecánicos - Medios mecánicos](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZM_MEDIOS_MEC%C3%81NICOS/02ZMM-Medios%20mec%C3%A1nicos%20-%20Medios%20mec%C3%A1nicos.md) | Revisar aplicación. |
| 02ZMW | [Medios mecánicos - Varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZM_MEDIOS_MEC%C3%81NICOS/02ZMW-Medios%20mec%C3%A1nicos%20-%20Varios.md) | Revisar aplicación. |
| 03ACC | [Barras corrugadas - Barras corrugadas](03_CIMENTACIONES/03A_ARMADURAS/03AC_BARRAS_CORRUGADAS/03ACC-Barras%20corrugadas%20-%20Barras%20corrugadas.md) | Revisar aplicación. |
| 03ACW | [Barras corrugadas - Varios](03_CIMENTACIONES/03A_ARMADURAS/03AC_BARRAS_CORRUGADAS/03ACW-Barras%20corrugadas%20-%20Varios.md) | Revisar aplicación. |
| 03ALL | [Barras lisas - Barras lisas](03_CIMENTACIONES/03A_ARMADURAS/03AL_BARRAS_LISAS/03ALL-Barras%20lisas%20-%20Barras%20lisas.md) | Revisar aplicación. |
| 03ALW | [Barras lisas - Varios](03_CIMENTACIONES/03A_ARMADURAS/03AL_BARRAS_LISAS/03ALW-Barras%20lisas%20-%20Varios.md) | Revisar aplicación. |
| 03AMM | [Mallas electrosoldadas - Mallas electrosoldadas](03_CIMENTACIONES/03A_ARMADURAS/03AM_MALLAS_ELECTROSOLDADAS/03AMM-Mallas%20electrosoldadas%20-%20Mallas%20electrosoldadas.md) | Revisar aplicación. |
| 03AMW | [Mallas electrosoldadas - Varios](03_CIMENTACIONES/03A_ARMADURAS/03AM_MALLAS_ELECTROSOLDADAS/03AMW-Mallas%20electrosoldadas%20-%20Varios.md) | Revisar aplicación. |
| 03AWW | [Varios - Varios](03_CIMENTACIONES/03A_ARMADURAS/03AW_VARIOS/03AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 03CCI | [Consolidaciones - Inyecciones](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CC_CONSOLIDACIONES/03CCI-Consolidaciones%20-%20Inyecciones.md) | Revisar aplicación. |
| 03CCJ | [Consolidaciones - Jet-grouting](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CC_CONSOLIDACIONES/03CCJ-Consolidaciones%20-%20Jet-grouting.md) | Revisar aplicación. |
| 03CCV | [Consolidaciones - Vibroflotación](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CC_CONSOLIDACIONES/03CCV-Consolidaciones%20-%20Vibroflotaci%C3%B3n.md) | Revisar aplicación. |
| 03CCW | [Consolidaciones - Varios](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CC_CONSOLIDACIONES/03CCW-Consolidaciones%20-%20Varios.md) | Revisar aplicación. |
| 03CMM | [Muros pantalla - Muros pantalla](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CM_MUROS_PANTALLA/03CMM-Muros%20pantalla%20-%20Muros%20pantalla.md) | Revisar aplicación. |
| 03CMW | [Muros pantalla - Varios](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CM_MUROS_PANTALLA/03CMW-Muros%20pantalla%20-%20Varios.md) | Revisar aplicación. |
| 03CPP | [Pilotes - Prefabricados](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CP_PILOTES/03CPP-Pilotes%20-%20Prefabricados.md) | Revisar aplicación. |
| 03CPS | [Pilotes - In situ](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CP_PILOTES/03CPS-Pilotes%20-%20In%20situ.md) | Revisar aplicación. |
| 03CPW | [Pilotes - Varios](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CP_PILOTES/03CPW-Pilotes%20-%20Varios.md) | Revisar aplicación. |
| 03CTI | [Micropilotes - In situ](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CT_MICROPILOTES/03CTI-Micropilotes%20-%20In%20situ.md) | Revisar aplicación. |
| 03CTW | [Micropilotes - Varios](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CT_MICROPILOTES/03CTW-Micropilotes%20-%20Varios.md) | Revisar aplicación. |
| 03CWW | [Varios - Varios](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CW_VARIOS/03CWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 03EPF | [Perdidos - Fábricas](03_CIMENTACIONES/03E_ENCOFRADOS/03EP_PERDIDOS/03EPF-Perdidos%20-%20F%C3%A1bricas.md) | Revisar aplicación. |
| 03EPW | [Perdidos - Varios](03_CIMENTACIONES/03E_ENCOFRADOS/03EP_PERDIDOS/03EPW-Perdidos%20-%20Varios.md) | Revisar aplicación. |
| 03ERM | [Recuperables - Madera](03_CIMENTACIONES/03E_ENCOFRADOS/03ER_RECUPERABLES/03ERM-Recuperables%20-%20Madera.md) | Revisar aplicación. |
| 03ERT | [Recuperables - Metálicos](03_CIMENTACIONES/03E_ENCOFRADOS/03ER_RECUPERABLES/03ERT-Recuperables%20-%20Met%C3%A1licos.md) | Revisar aplicación. |
| 03ERW | [Recuperables - Varios](03_CIMENTACIONES/03E_ENCOFRADOS/03ER_RECUPERABLES/03ERW-Recuperables%20-%20Varios.md) | Revisar aplicación. |
| 03EWW | [Varios - Varios](03_CIMENTACIONES/03E_ENCOFRADOS/03EW_VARIOS/03EWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 03HAA | [Para armar - Arriostramientos](03_CIMENTACIONES/03H_HORMIGONES/03HA_PARA_ARMAR/03HAA-Para%20armar%20-%20Arriostramientos.md) | Revisar aplicación. |
| 03HAL | [Para armar - Losas](03_CIMENTACIONES/03H_HORMIGONES/03HA_PARA_ARMAR/03HAL-Para%20armar%20-%20Losas.md) | Revisar aplicación. |
| 03HAM | [Para armar - Muros](03_CIMENTACIONES/03H_HORMIGONES/03HA_PARA_ARMAR/03HAM-Para%20armar%20-%20Muros.md) | Revisar aplicación. |
| 03HAW | [Para armar - Varios](03_CIMENTACIONES/03H_HORMIGONES/03HA_PARA_ARMAR/03HAW-Para%20armar%20-%20Varios.md) | Revisar aplicación. |
| 03HAZ | [Para armar - Zapatas](03_CIMENTACIONES/03H_HORMIGONES/03HA_PARA_ARMAR/03HAZ-Para%20armar%20-%20Zapatas.md) | Revisar aplicación. |
| 03HMM | [En masa - En masa](03_CIMENTACIONES/03H_HORMIGONES/03HM_EN_MASA/03HMM-En%20masa%20-%20En%20masa.md) | Revisar aplicación. |
| 03HMW | [En masa - Varios](03_CIMENTACIONES/03H_HORMIGONES/03HM_EN_MASA/03HMW-En%20masa%20-%20Varios.md) | Revisar aplicación. |
| 03HRA | [Armados - Arriostramientos](03_CIMENTACIONES/03H_HORMIGONES/03HR_ARMADOS/03HRA-Armados%20-%20Arriostramientos.md) | Revisar aplicación. |
| 03HRL | [Armados - Losas](03_CIMENTACIONES/03H_HORMIGONES/03HR_ARMADOS/03HRL-Armados%20-%20Losas.md) | Revisar aplicación. |
| 03HRM | [Armados - Muros](03_CIMENTACIONES/03H_HORMIGONES/03HR_ARMADOS/03HRM-Armados%20-%20Muros.md) | Revisar aplicación. |
| 03HRW | [Armados - Varios](03_CIMENTACIONES/03H_HORMIGONES/03HR_ARMADOS/03HRW-Armados%20-%20Varios.md) | Revisar aplicación. |
| 03HRZ | [Armados - Zapatas](03_CIMENTACIONES/03H_HORMIGONES/03HR_ARMADOS/03HRZ-Armados%20-%20Zapatas.md) | Revisar aplicación. |
| 03HWW | [Varios - Varios](03_CIMENTACIONES/03H_HORMIGONES/03HW_VARIOS/03HWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 03WSS | [Sub-bases - Sub-bases](03_CIMENTACIONES/03W_VARIOS/03WS_SUB_BASES/03WSS-Sub-bases%20-%20Sub-bases.md) | Revisar aplicación. |
| 03WSW | [Sub-bases - Varios](03_CIMENTACIONES/03W_VARIOS/03WS_SUB_BASES/03WSW-Sub-bases%20-%20Varios.md) | Revisar aplicación. |
| 03WWW | [Varios - Varios](03_CIMENTACIONES/03W_VARIOS/03WW_VARIOS/03WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 04CAB | [Arquetas - A pie de bajante](04_SANEAMIENTO/04C_REDES_COLGADAS/04CA_ARQUETAS/04CAB-Arquetas%20-%20A%20pie%20de%20bajante.md) | Revisar aplicación. |
| 04CAP | [Arquetas - De paso](04_SANEAMIENTO/04C_REDES_COLGADAS/04CA_ARQUETAS/04CAP-Arquetas%20-%20De%20paso.md) | Revisar aplicación. |
| 04CAS | [Arquetas - Sifónicas](04_SANEAMIENTO/04C_REDES_COLGADAS/04CA_ARQUETAS/04CAS-Arquetas%20-%20Sif%C3%B3nicas.md) | Revisar aplicación. |
| 04CAW | [Arquetas - Varios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CA_ARQUETAS/04CAW-Arquetas%20-%20Varios.md) | Revisar aplicación. |
| 04CCP | [Colectores - P.V.C](04_SANEAMIENTO/04C_REDES_COLGADAS/04CC_COLECTORES/04CCP-Colectores%20-%20P.V.C.md) | Revisar aplicación. |
| 04CCW | [Colectores - Varios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CC_COLECTORES/04CCW-Colectores%20-%20Varios.md) | Revisar aplicación. |
| 04CEE | [Elementos complementarios - Elementos complementarios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CE_ELEMENTOS_COMPLEMENTARIOS/04CEE-Elementos%20complementarios%20-%20Elementos%20complementarios.md) | Revisar aplicación. |
| 04CEW | [Elementos complementarios - Varios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CE_ELEMENTOS_COMPLEMENTARIOS/04CEW-Elementos%20complementarios%20-%20Varios.md) | Revisar aplicación. |
| 04CWW | [Varios - Varios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CW_VARIOS/04CWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 04EAB | [Arquetas - A pie de bajante](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EA_ARQUETAS/04EAB-Arquetas%20-%20A%20pie%20de%20bajante.md) | Revisar aplicación. |
| 04EAP | [Arquetas - De paso](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EA_ARQUETAS/04EAP-Arquetas%20-%20De%20paso.md) | Revisar aplicación. |
| 04EAS | [Arquetas - Sifónicas](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EA_ARQUETAS/04EAS-Arquetas%20-%20Sif%C3%B3nicas.md) | Revisar aplicación. |
| 04EAW | [Arquetas - Varios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EA_ARQUETAS/04EAW-Arquetas%20-%20Varios.md) | Revisar aplicación. |
| 04ECH | [Colectores - Hormigón](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EC_COLECTORES/04ECH-Colectores%20-%20Hormig%C3%B3n.md) | Revisar aplicación. |
| 04ECP | [Colectores - P.V.C](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EC_COLECTORES/04ECP-Colectores%20-%20P.V.C.md) | Revisar aplicación. |
| 04ECW | [Colectores - Varios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EC_COLECTORES/04ECW-Colectores%20-%20Varios.md) | Revisar aplicación. |
| 04EEE | [Elementos complementarios - Elementos complementarios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EE_ELEMENTOS_COMPLEMENTARIOS/04EEE-Elementos%20complementarios%20-%20Elementos%20complementarios.md) | Revisar aplicación. |
| 04EEW | [Elementos complementarios - Varios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EE_ELEMENTOS_COMPLEMENTARIOS/04EEW-Elementos%20complementarios%20-%20Varios.md) | Revisar aplicación. |
| 04EPP | [Pozos - Pozos](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EP_POZOS/04EPP-Pozos%20-%20Pozos.md) | Revisar aplicación. |
| 04EPW | [Pozos - Varios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EP_POZOS/04EPW-Pozos%20-%20Varios.md) | Revisar aplicación. |
| 04EWW | [Varios - Varios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EW_VARIOS/04EWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 04VBF | [Bajantes - Fibrocemento](04_SANEAMIENTO/04V_REDES_VERTICALES/04VB_BAJANTES/04VBF-Bajantes%20-%20Fibrocemento.md) | Revisar aplicación. |
| 04VBM | [Bajantes - Metálicas](04_SANEAMIENTO/04V_REDES_VERTICALES/04VB_BAJANTES/04VBM-Bajantes%20-%20Met%C3%A1licas.md) | Revisar aplicación. |
| 04VBP | [Bajantes - P.V.C](04_SANEAMIENTO/04V_REDES_VERTICALES/04VB_BAJANTES/04VBP-Bajantes%20-%20P.V.C.md) | Revisar aplicación. |
| 04VBW | [Bajantes - Varios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VB_BAJANTES/04VBW-Bajantes%20-%20Varios.md) | Revisar aplicación. |
| 04VCC | [Cazoletas - Cazoletas](04_SANEAMIENTO/04V_REDES_VERTICALES/04VC_CAZOLETAS/04VCC-Cazoletas%20-%20Cazoletas.md) | Revisar aplicación. |
| 04VCW | [Cazoletas - Varios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VC_CAZOLETAS/04VCW-Cazoletas%20-%20Varios.md) | Revisar aplicación. |
| 04VEE | [Elementos complementarios - Elementos complementarios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VE_ELEMENTOS_COMPLEMENTARIOS/04VEE-Elementos%20complementarios%20-%20Elementos%20complementarios.md) | Revisar aplicación. |
| 04VEW | [Elementos complementarios - Varios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VE_ELEMENTOS_COMPLEMENTARIOS/04VEW-Elementos%20complementarios%20-%20Varios.md) | Revisar aplicación. |
| 04VWW | [Varios - Varios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VW_VARIOS/04VWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 04WAA | [Acometidas - Acometidas](04_SANEAMIENTO/04W_VARIOS/04WA_ACOMETIDAS/04WAA-Acometidas%20-%20Acometidas.md) | Revisar aplicación. |
| 04WAW | [Acometidas - Varios](04_SANEAMIENTO/04W_VARIOS/04WA_ACOMETIDAS/04WAW-Acometidas%20-%20Varios.md) | Revisar aplicación. |
| 04WWW | [Varios - Varios](04_SANEAMIENTO/04W_VARIOS/04WW_VARIOS/04WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 05ACJ | [Laminados en caliente - Vigas](05_ESTRUCTURAS/05A_ACERO/05AC_LAMINADOS_EN_CALIENTE/05ACJ-Laminados%20en%20caliente%20-%20Vigas.md) | Revisar aplicación. |
| 05ACS | [Laminados en caliente - Soportes](05_ESTRUCTURAS/05A_ACERO/05AC_LAMINADOS_EN_CALIENTE/05ACS-Laminados%20en%20caliente%20-%20Soportes.md) | Revisar aplicación. |
| 05ACT | [Laminados en caliente - Trianguladas](05_ESTRUCTURAS/05A_ACERO/05AC_LAMINADOS_EN_CALIENTE/05ACT-Laminados%20en%20caliente%20-%20Trianguladas.md) | Revisar aplicación. |
| 05ACV | [Laminados en caliente - Viguetas](05_ESTRUCTURAS/05A_ACERO/05AC_LAMINADOS_EN_CALIENTE/05ACV-Laminados%20en%20caliente%20-%20Viguetas.md) | Revisar aplicación. |
| 05ACW | [Laminados en caliente - Varios](05_ESTRUCTURAS/05A_ACERO/05AC_LAMINADOS_EN_CALIENTE/05ACW-Laminados%20en%20caliente%20-%20Varios.md) | Revisar aplicación. |
| 05AFF | [Laminados en frío - Laminados en frio](05_ESTRUCTURAS/05A_ACERO/05AF_LAMINADOS_EN_FR%C3%8DO/05AFF-Laminados%20en%20fr%C3%ADo%20-%20Laminados%20en%20frio.md) | Revisar aplicación. |
| 05AFW | [Laminados en frío - Varios](05_ESTRUCTURAS/05A_ACERO/05AF_LAMINADOS_EN_FR%C3%8DO/05AFW-Laminados%20en%20fr%C3%ADo%20-%20Varios.md) | Revisar aplicación. |
| 05AWW | [Varios - Varios](05_ESTRUCTURAS/05A_ACERO/05AW_VARIOS/05AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 05FBB | [Bidireccionales - Bidireccionales](05_ESTRUCTURAS/05F_FORJADOS/05FB_BIDIRECCIONALES/05FBB-Bidireccionales%20-%20Bidireccionales.md) | Revisar aplicación. |
| 05FBW | [Bidireccionales - Varios](05_ESTRUCTURAS/05F_FORJADOS/05FB_BIDIRECCIONALES/05FBW-Bidireccionales%20-%20Varios.md) | Revisar aplicación. |
| 05FMM | [Madera - Madera](05_ESTRUCTURAS/05F_FORJADOS/05FM_MADERA/05FMM-Madera%20-%20Madera.md) | Revisar aplicación. |
| 05FMW | [Madera - Varios](05_ESTRUCTURAS/05F_FORJADOS/05FM_MADERA/05FMW-Madera%20-%20Varios.md) | Revisar aplicación. |
| 05FUA | [Unidireccionales - Autorresistentes](05_ESTRUCTURAS/05F_FORJADOS/05FU_UNIDIRECCIONALES/05FUA-Unidireccionales%20-%20Autorresistentes.md) | Revisar aplicación. |
| 05FUS | [Unidireccionales - Semirresistentes](05_ESTRUCTURAS/05F_FORJADOS/05FU_UNIDIRECCIONALES/05FUS-Unidireccionales%20-%20Semirresistentes.md) | Revisar aplicación. |
| 05FUW | [Unidireccionales - Varios](05_ESTRUCTURAS/05F_FORJADOS/05FU_UNIDIRECCIONALES/05FUW-Unidireccionales%20-%20Varios.md) | Revisar aplicación. |
| 05FWW | [Varios - Varios](05_ESTRUCTURAS/05F_FORJADOS/05FW_VARIOS/05FWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 05HAC | [Armaduras - Corrugadas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HA_ARMADURAS/05HAC-Armaduras%20-%20Corrugadas.md) | Revisar aplicación. |
| 05HAL | [Armaduras - Lisas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HA_ARMADURAS/05HAL-Armaduras%20-%20Lisas.md) | Revisar aplicación. |
| 05HAM | [Armaduras - Mallas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HA_ARMADURAS/05HAM-Armaduras%20-%20Mallas.md) | Revisar aplicación. |
| 05HAW | [Armaduras - Varios](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HA_ARMADURAS/05HAW-Armaduras%20-%20Varios.md) | Revisar aplicación. |
| 05HED | [Encofrados - Desencofrados](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/05HED-Encofrados%20-%20Desencofrados.md) | Revisar aplicación. |
| 05HEF | [Encofrados - Fibrocemento](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/05HEF-Encofrados%20-%20Fibrocemento.md) | Revisar aplicación. |
| 05HEM | [Encofrados - Maderas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/05HEM-Encofrados%20-%20Maderas.md) | Revisar aplicación. |
| 05HET | [Encofrados - Metálicos](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/05HET-Encofrados%20-%20Met%C3%A1licos.md) | Revisar aplicación. |
| 05HEW | [Encofrados - Varios](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/05HEW-Encofrados%20-%20Varios.md) | Revisar aplicación. |
| 05HHJ | [Para armar - Vigas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/05HHJ-Para%20armar%20-%20Vigas.md) | Revisar aplicación. |
| 05HHL | [Para armar - Losas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/05HHL-Para%20armar%20-%20Losas.md) | Revisar aplicación. |
| 05HHM | [Para armar - Muros](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/05HHM-Para%20armar%20-%20Muros.md) | Revisar aplicación. |
| 05HHP | [Para armar - Pilares](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/05HHP-Para%20armar%20-%20Pilares.md) | Revisar aplicación. |
| 05HHW | [Para armar - Varios](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/05HHW-Para%20armar%20-%20Varios.md) | Revisar aplicación. |
| 05HRJ | [Armados - Vigas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HR_ARMADOS/05HRJ-Armados%20-%20Vigas.md) | Revisar aplicación. |
| 05HRL | [Armados - Losas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HR_ARMADOS/05HRL-Armados%20-%20Losas.md) | Revisar aplicación. |
| 05HRM | [Armados - Muros](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HR_ARMADOS/05HRM-Armados%20-%20Muros.md) | Revisar aplicación. |
| 05HRP | [Armados - Pilares](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HR_ARMADOS/05HRP-Armados%20-%20Pilares.md) | Revisar aplicación. |
| 05HRW | [Armados - Varios](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HR_ARMADOS/05HRW-Armados%20-%20Varios.md) | Revisar aplicación. |
| 05HWW | [Varios - Varios](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HW_VARIOS/05HWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 05MLA | [Laminadas - Arcos y bóvedas](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLA-Laminadas%20-%20Arcos%20y%20b%C3%B3vedas.md) | Revisar aplicación. |
| 05MLE | [Laminadas - Entabacados y tableros](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLE-Laminadas%20-%20Entabacados%20y%20tableros.md) | Revisar aplicación. |
| 05MLM | [Laminadas - Muros](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLM-Laminadas%20-%20Muros.md) | Revisar aplicación. |
| 05MLP | [Laminadas - Pórticos](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLP-Laminadas%20-%20P%C3%B3rticos.md) | Revisar aplicación. |
| 05MLS | [Laminadas - Soportes](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLS-Laminadas%20-%20Soportes.md) | Revisar aplicación. |
| 05MLT | [Laminadas - Trianguladas](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLT-Laminadas%20-%20Trianguladas.md) | Revisar aplicación. |
| 05MLV | [Laminadas - Vigas](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLV-Laminadas%20-%20Vigas.md) | Revisar aplicación. |
| 05MLW | [Laminadas - Varios](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/05MLW-Laminadas%20-%20Varios.md) | Revisar aplicación. |
| 05MTT | [Tradicionales - Tradicionales](05_ESTRUCTURAS/05M_MADERA/05MT_TRADICIONALES/05MTT-Tradicionales%20-%20Tradicionales.md) | Revisar aplicación. |
| 05MTW | [Tradicionales - Varios](05_ESTRUCTURAS/05M_MADERA/05MT_TRADICIONALES/05MTW-Tradicionales%20-%20Varios.md) | Revisar aplicación. |
| 05MWW | [Varios - Varios](05_ESTRUCTURAS/05M_MADERA/05MW_VARIOS/05MWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 05WCH | [Estructuras completas - Hormigón](05_ESTRUCTURAS/05W_VARIOS/05WC_ESTRUCTURAS_COMPLETAS/05WCH-Estructuras%20completas%20-%20Hormig%C3%B3n.md) | Revisar aplicación. |
| 05WCW | [Estructuras completas - Varios](05_ESTRUCTURAS/05W_VARIOS/05WC_ESTRUCTURAS_COMPLETAS/05WCW-Estructuras%20completas%20-%20Varios.md) | Revisar aplicación. |
| 05WCX | [Estructuras completas - Mixtas](05_ESTRUCTURAS/05W_VARIOS/05WC_ESTRUCTURAS_COMPLETAS/05WCX-Estructuras%20completas%20-%20Mixtas.md) | Revisar aplicación. |
| 05WEE | [Estructuras especiales - Estructuras especiales](05_ESTRUCTURAS/05W_VARIOS/05WE_ESTRUCTURAS_ESPECIALES/05WEE-Estructuras%20especiales%20-%20Estructuras%20especiales.md) | Revisar aplicación. |
| 05WEW | [Estructuras especiales - Varios](05_ESTRUCTURAS/05W_VARIOS/05WE_ESTRUCTURAS_ESPECIALES/05WEW-Estructuras%20especiales%20-%20Varios.md) | Revisar aplicación. |
| 05WTS | [Tratamientos - Superficiales](05_ESTRUCTURAS/05W_VARIOS/05WT_TRATAMIENTOS/05WTS-Tratamientos%20-%20Superficiales.md) | Revisar aplicación. |
| 05WTW | [Tratamientos - Varios](05_ESTRUCTURAS/05W_VARIOS/05WT_TRATAMIENTOS/05WTW-Tratamientos%20-%20Varios.md) | Revisar aplicación. |
| 05WWW | [Varios - Varios](05_ESTRUCTURAS/05W_VARIOS/05WW_VARIOS/05WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06AEE | [Especiales - Especiales](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AE_ESPECIALES/06AEE-Especiales%20-%20Especiales.md) | Revisar aplicación. |
| 06AEW | [Especiales - Varios](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AE_ESPECIALES/06AEW-Especiales%20-%20Varios.md) | Revisar aplicación. |
| 06AHH | [Huecos - Huecos](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AH_HUECOS/06AHH-Huecos%20-%20Huecos.md) | Revisar aplicación. |
| 06AHW | [Huecos - Varios](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AH_HUECOS/06AHW-Huecos%20-%20Varios.md) | Revisar aplicación. |
| 06AMM | [Macizos - Macizos](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AM_MACIZOS/06AMM-Macizos%20-%20Macizos.md) | Revisar aplicación. |
| 06AMW | [Macizos - Varios](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AM_MACIZOS/06AMW-Macizos%20-%20Varios.md) | Revisar aplicación. |
| 06APP | [Perforados - Perforados](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AP_PERFORADOS/06APP-Perforados%20-%20Perforados.md) | Revisar aplicación. |
| 06APW | [Perforados - Varios](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AP_PERFORADOS/06APW-Perforados%20-%20Varios.md) | Revisar aplicación. |
| 06AWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AW_VARIOS/06AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06BHA | [Huecos - Arcilla aligerada](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BH_HUECOS/06BHA-Huecos%20-%20Arcilla%20aligerada.md) | Revisar aplicación. |
| 06BHC | [Huecos - Cerámica](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BH_HUECOS/06BHC-Huecos%20-%20Cer%C3%A1mica.md) | Revisar aplicación. |
| 06BHH | [Huecos - Hormigón](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BH_HUECOS/06BHH-Huecos%20-%20Hormig%C3%B3n.md) | Revisar aplicación. |
| 06BHL | [Huecos - Hormigón ligero](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BH_HUECOS/06BHL-Huecos%20-%20Hormig%C3%B3n%20ligero.md) | Revisar aplicación. |
| 06BHW | [Huecos - Varios](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BH_HUECOS/06BHW-Huecos%20-%20Varios.md) | Revisar aplicación. |
| 06BMM | [Macizos - Macizos](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BM_MACIZOS/06BMM-Macizos%20-%20Macizos.md) | Revisar aplicación. |
| 06BMW | [Macizos - Varios](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BM_MACIZOS/06BMW-Macizos%20-%20Varios.md) | Revisar aplicación. |
| 06BWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BW_VARIOS/06BWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06CAA | [Arcos y bóvedas - Arcos](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CA_ARCOS_Y_B%C3%93VEDAS/06CAA-Arcos%20y%20b%C3%B3vedas%20-%20Arcos.md) | Revisar aplicación. |
| 06CAB | [Arcos y bóvedas - Bóvedas](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CA_ARCOS_Y_B%C3%93VEDAS/06CAB-Arcos%20y%20b%C3%B3vedas%20-%20B%C3%B3vedas.md) | Revisar aplicación. |
| 06CAW | [Arcos y bóvedas - Varios](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CA_ARCOS_Y_B%C3%93VEDAS/06CAW-Arcos%20y%20b%C3%B3vedas%20-%20Varios.md) | Revisar aplicación. |
| 06CMC | [Mampostería - Concertada](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CM_MAMPOSTER%C3%8DA/06CMC-Mamposter%C3%ADa%20-%20Concertada.md) | Revisar aplicación. |
| 06CMK | [Mampostería - Careada](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CM_MAMPOSTER%C3%8DA/06CMK-Mamposter%C3%ADa%20-%20Careada.md) | Revisar aplicación. |
| 06CMO | [Mampostería - Ordinaria](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CM_MAMPOSTER%C3%8DA/06CMO-Mamposter%C3%ADa%20-%20Ordinaria.md) | Revisar aplicación. |
| 06CMW | [Mampostería - Varios](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CM_MAMPOSTER%C3%8DA/06CMW-Mamposter%C3%ADa%20-%20Varios.md) | Revisar aplicación. |
| 06CSJ | [Sillería - Sillarejos](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CS_SILLER%C3%8DA/06CSJ-Siller%C3%ADa%20-%20Sillarejos.md) | Revisar aplicación. |
| 06CSS | [Sillería - Sillares](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CS_SILLER%C3%8DA/06CSS-Siller%C3%ADa%20-%20Sillares.md) | Revisar aplicación. |
| 06CSW | [Sillería - Varios](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CS_SILLER%C3%8DA/06CSW-Siller%C3%ADa%20-%20Varios.md) | Revisar aplicación. |
| 06CWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CW_VARIOS/06CWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06CXW | [Mixtas - Varios](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CX_MIXTAS/06CXW-Mixtas%20-%20Varios.md) | Revisar aplicación. |
| 06CXX | [Mixtas - Mixtas](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CX_MIXTAS/06CXX-Mixtas%20-%20Mixtas.md) | Revisar aplicación. |
| 06DPC | [Tabiquería prefabricada - Placas de yeso laminado](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DP_TABIQUER%C3%8DA_PREFABRICADA/06DPC-Tabiquer%C3%ADa%20prefabricada%20-%20Placas%20de%20yeso%20laminado.md) | Revisar aplicación. |
| 06DPW | [Tabiquería prefabricada - Varios](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DP_TABIQUER%C3%8DA_PREFABRICADA/06DPW-Tabiquer%C3%ADa%20prefabricada%20-%20Varios.md) | Revisar aplicación. |
| 06DPY | [Tabiquería prefabricada - Paneles de yeso](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DP_TABIQUER%C3%8DA_PREFABRICADA/06DPY-Tabiquer%C3%ADa%20prefabricada%20-%20Paneles%20de%20yeso.md) | Revisar aplicación. |
| 06DSS | [Tabiques sencillos - Tabiques sencillos](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DS_TABIQUES_SENCILLOS/06DSS-Tabiques%20sencillos%20-%20Tabiques%20sencillos.md) | Revisar aplicación. |
| 06DSW | [Tabiques sencillos - Varios](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DS_TABIQUES_SENCILLOS/06DSW-Tabiques%20sencillos%20-%20Varios.md) | Revisar aplicación. |
| 06DTD | [Tabicones - Hueco doble](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DT_TABICONES/06DTD-Tabicones%20-%20Hueco%20doble.md) | Revisar aplicación. |
| 06DTG | [Tabicones - Gafa](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DT_TABICONES/06DTG-Tabicones%20-%20Gafa.md) | Revisar aplicación. |
| 06DTW | [Tabicones - Varios](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DT_TABICONES/06DTW-Tabicones%20-%20Varios.md) | Revisar aplicación. |
| 06DWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DW_VARIOS/06DWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06EBT | [Muros bioclimáticos - Muros trombe](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EB_MUROS_BIOCLIM%C3%81TICOS/06EBT-Muros%20bioclim%C3%A1ticos%20-%20Muros%20trombe.md) | Revisar aplicación. |
| 06EBW | [Muros bioclimáticos - Varios](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EB_MUROS_BIOCLIM%C3%81TICOS/06EBW-Muros%20bioclim%C3%A1ticos%20-%20Varios.md) | Revisar aplicación. |
| 06EVC | [Fachadas ventiladas - Cerámicas](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EV_FACHADAS_VENTILADAS/06EVC-Fachadas%20ventiladas%20-%20Cer%C3%A1micas.md) | Revisar aplicación. |
| 06EVP | [Fachadas ventiladas - Piedra natural](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EV_FACHADAS_VENTILADAS/06EVP-Fachadas%20ventiladas%20-%20Piedra%20natural.md) | Revisar aplicación. |
| 06EVR | [Fachadas ventiladas - Resinas termoendurecibles](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EV_FACHADAS_VENTILADAS/06EVR-Fachadas%20ventiladas%20-%20Resinas%20termoendurecibles.md) | Revisar aplicación. |
| 06EVW | [Fachadas ventiladas - Varios](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EV_FACHADAS_VENTILADAS/06EVW-Fachadas%20ventiladas%20-%20Varios.md) | Revisar aplicación. |
| 06EWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EW_VARIOS/06EWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06LEC | [Especiales - Citaras](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LE_ESPECIALES/06LEC-Especiales%20-%20Citaras.md) | Revisar aplicación. |
| 06LEM | [Especiales - Muros](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LE_ESPECIALES/06LEM-Especiales%20-%20Muros.md) | Revisar aplicación. |
| 06LEW | [Especiales - Varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LE_ESPECIALES/06LEW-Especiales%20-%20Varios.md) | Revisar aplicación. |
| 06LHC | [Huecos - Citaras](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LH_HUECOS/06LHC-Huecos%20-%20Citaras.md) | Revisar aplicación. |
| 06LHM | [Huecos - Muros](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LH_HUECOS/06LHM-Huecos%20-%20Muros.md) | Revisar aplicación. |
| 06LHW | [Huecos - Varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LH_HUECOS/06LHW-Huecos%20-%20Varios.md) | Revisar aplicación. |
| 06LMC | [Macizos - Citaras](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LM_MACIZOS/06LMC-Macizos%20-%20Citaras.md) | Revisar aplicación. |
| 06LMM | [Macizos - Muros](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LM_MACIZOS/06LMM-Macizos%20-%20Muros.md) | Revisar aplicación. |
| 06LMW | [Macizos - Varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LM_MACIZOS/06LMW-Macizos%20-%20Varios.md) | Revisar aplicación. |
| 06LPC | [Perforados - Citaras](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LP_PERFORADOS/06LPC-Perforados%20-%20Citaras.md) | Revisar aplicación. |
| 06LPM | [Perforados - Muros](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LP_PERFORADOS/06LPM-Perforados%20-%20Muros.md) | Revisar aplicación. |
| 06LPW | [Perforados - Varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LP_PERFORADOS/06LPW-Perforados%20-%20Varios.md) | Revisar aplicación. |
| 06LWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LW_VARIOS/06LWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06LXC | [Mixtas - Citaras](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LX_MIXTAS/06LXC-Mixtas%20-%20Citaras.md) | Revisar aplicación. |
| 06LXM | [Mixtas - Muros](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LX_MIXTAS/06LXM-Mixtas%20-%20Muros.md) | Revisar aplicación. |
| 06LXW | [Mixtas - Varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LX_MIXTAS/06LXW-Mixtas%20-%20Varios.md) | Revisar aplicación. |
| 06PCC | [Cerámicos - Celosías](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PC_CER%C3%81MICOS/06PCC-Cer%C3%A1micos%20-%20Celos%C3%ADas.md) | Revisar aplicación. |
| 06PCW | [Cerámicos - Varios](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PC_CER%C3%81MICOS/06PCW-Cer%C3%A1micos%20-%20Varios.md) | Revisar aplicación. |
| 06PHB | [Hormigón - Balaustradas](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PH_HORMIG%C3%93N/06PHB-Hormig%C3%B3n%20-%20Balaustradas.md) | Revisar aplicación. |
| 06PHC | [Hormigón - Celosías](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PH_HORMIG%C3%93N/06PHC-Hormig%C3%B3n%20-%20Celos%C3%ADas.md) | Revisar aplicación. |
| 06PHW | [Hormigón - Varios](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PH_HORMIG%C3%93N/06PHW-Hormig%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 06PMA | [Metálicos - Acero](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PM_MET%C3%81LICOS/06PMA-Met%C3%A1licos%20-%20Acero.md) | Revisar aplicación. |
| 06PML | [Metálicos - Aluminio](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PM_MET%C3%81LICOS/06PML-Met%C3%A1licos%20-%20Aluminio.md) | Revisar aplicación. |
| 06PMW | [Metálicos - Varios](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PM_MET%C3%81LICOS/06PMW-Met%C3%A1licos%20-%20Varios.md) | Revisar aplicación. |
| 06PSW | [Sintéticos - Varios](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PS_SINT%C3%89TICOS/06PSW-Sint%C3%A9ticos%20-%20Varios.md) | Revisar aplicación. |
| 06PWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PW_VARIOS/06PWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 06WDD | [Dinteles - Dinteles](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WD_DINTELES/06WDD-Dinteles%20-%20Dinteles.md) | Revisar aplicación. |
| 06WDW | [Dinteles - Varios](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WD_DINTELES/06WDW-Dinteles%20-%20Varios.md) | Revisar aplicación. |
| 06WFF | [Formación de pendientes - Formación de pendientes](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WF_FORMACI%C3%93N_DE_PENDIENTES/06WFF-Formaci%C3%B3n%20de%20pendientes%20-%20Formaci%C3%B3n%20de%20pendientes.md) | Revisar aplicación. |
| 06WFW | [Formación de pendientes - Varios](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WF_FORMACI%C3%93N_DE_PENDIENTES/06WFW-Formaci%C3%B3n%20de%20pendientes%20-%20Varios.md) | Revisar aplicación. |
| 06WMM | [Mochetas - Mochetas](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WM_MOCHETAS/06WMM-Mochetas%20-%20Mochetas.md) | Revisar aplicación. |
| 06WMW | [Mochetas - Varios](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WM_MOCHETAS/06WMW-Mochetas%20-%20Varios.md) | Revisar aplicación. |
| 06WPP | [Peldañeados - Peldaños](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WP_PELDA%C3%91EADOS/06WPP-Pelda%C3%B1eados%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 06WPW | [Peldañeados - Varios](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WP_PELDA%C3%91EADOS/06WPW-Pelda%C3%B1eados%20-%20Varios.md) | Revisar aplicación. |
| 06WRF | [Rampas - Fábrica](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WR_RAMPAS/06WRF-Rampas%20-%20F%C3%A1brica.md) | Revisar aplicación. |
| 06WRM | [Rampas - Metálicas](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WR_RAMPAS/06WRM-Rampas%20-%20Met%C3%A1licas.md) | Revisar aplicación. |
| 06WRW | [Rampas - Varios](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WR_RAMPAS/06WRW-Rampas%20-%20Varios.md) | Revisar aplicación. |
| 06WWR | [Varios - Recibidos](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WW_VARIOS/06WWR-Varios%20-%20Recibidos.md) | Revisar aplicación. |
| 06WWT | [Varios - Tableros](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WW_VARIOS/06WWT-Varios%20-%20Tableros.md) | Revisar aplicación. |
| 06WWW | [Varios - Varios](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WW_VARIOS/06WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 07HAE | [Ajardinadas - Encuentros](07_CUBIERTAS/07H_HORIZONTALES/07HA_AJARDINADAS/07HAE-Ajardinadas%20-%20Encuentros.md) | Revisar aplicación. |
| 07HAF | [Ajardinadas - Faldones](07_CUBIERTAS/07H_HORIZONTALES/07HA_AJARDINADAS/07HAF-Ajardinadas%20-%20Faldones.md) | Revisar aplicación. |
| 07HAW | [Ajardinadas - Varios](07_CUBIERTAS/07H_HORIZONTALES/07HA_AJARDINADAS/07HAW-Ajardinadas%20-%20Varios.md) | Revisar aplicación. |
| 07HNE | [No transitables - Encuentros](07_CUBIERTAS/07H_HORIZONTALES/07HN_NO_TRANSITABLES/07HNE-No%20transitables%20-%20Encuentros.md) | Revisar aplicación. |
| 07HNF | [No transitables - Faldones](07_CUBIERTAS/07H_HORIZONTALES/07HN_NO_TRANSITABLES/07HNF-No%20transitables%20-%20Faldones.md) | Revisar aplicación. |
| 07HNW | [No transitables - Varios](07_CUBIERTAS/07H_HORIZONTALES/07HN_NO_TRANSITABLES/07HNW-No%20transitables%20-%20Varios.md) | Revisar aplicación. |
| 07HTE | [Transitables - Encuentros](07_CUBIERTAS/07H_HORIZONTALES/07HT_TRANSITABLES/07HTE-Transitables%20-%20Encuentros.md) | Revisar aplicación. |
| 07HTF | [Transitables - Faldones](07_CUBIERTAS/07H_HORIZONTALES/07HT_TRANSITABLES/07HTF-Transitables%20-%20Faldones.md) | Revisar aplicación. |
| 07HTW | [Transitables - Varios](07_CUBIERTAS/07H_HORIZONTALES/07HT_TRANSITABLES/07HTW-Transitables%20-%20Varios.md) | Revisar aplicación. |
| 07HWW | [Varios - Varios](07_CUBIERTAS/07H_HORIZONTALES/07HW_VARIOS/07HWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 07IFE | [Fibrocemento - Encuentros](07_CUBIERTAS/07I_INCLINADAS/07IF_FIBROCEMENTO/07IFE-Fibrocemento%20-%20Encuentros.md) | Revisar aplicación. |
| 07IFF | [Fibrocemento - Faldones](07_CUBIERTAS/07I_INCLINADAS/07IF_FIBROCEMENTO/07IFF-Fibrocemento%20-%20Faldones.md) | Revisar aplicación. |
| 07IFL | [Fibrocemento - Limas](07_CUBIERTAS/07I_INCLINADAS/07IF_FIBROCEMENTO/07IFL-Fibrocemento%20-%20Limas.md) | Revisar aplicación. |
| 07IFW | [Fibrocemento - Varios](07_CUBIERTAS/07I_INCLINADAS/07IF_FIBROCEMENTO/07IFW-Fibrocemento%20-%20Varios.md) | Revisar aplicación. |
| 07IGE | [Galvanizados - Encuentros](07_CUBIERTAS/07I_INCLINADAS/07IG_GALVANIZADOS/07IGE-Galvanizados%20-%20Encuentros.md) | Revisar aplicación. |
| 07IGF | [Galvanizados - Faldones](07_CUBIERTAS/07I_INCLINADAS/07IG_GALVANIZADOS/07IGF-Galvanizados%20-%20Faldones.md) | Revisar aplicación. |
| 07IGL | [Galvanizados - Limas](07_CUBIERTAS/07I_INCLINADAS/07IG_GALVANIZADOS/07IGL-Galvanizados%20-%20Limas.md) | Revisar aplicación. |
| 07IGW | [Galvanizados - Varios](07_CUBIERTAS/07I_INCLINADAS/07IG_GALVANIZADOS/07IGW-Galvanizados%20-%20Varios.md) | Revisar aplicación. |
| 07ILE | [Aleaciones ligeras - Encuentros](07_CUBIERTAS/07I_INCLINADAS/07IL_ALEACIONES_LIGERAS/07ILE-Aleaciones%20ligeras%20-%20Encuentros.md) | Revisar aplicación. |
| 07ILF | [Aleaciones ligeras - Faldones](07_CUBIERTAS/07I_INCLINADAS/07IL_ALEACIONES_LIGERAS/07ILF-Aleaciones%20ligeras%20-%20Faldones.md) | Revisar aplicación. |
| 07ILL | [Aleaciones ligeras - Limas](07_CUBIERTAS/07I_INCLINADAS/07IL_ALEACIONES_LIGERAS/07ILL-Aleaciones%20ligeras%20-%20Limas.md) | Revisar aplicación. |
| 07ILW | [Aleaciones ligeras - Varios](07_CUBIERTAS/07I_INCLINADAS/07IL_ALEACIONES_LIGERAS/07ILW-Aleaciones%20ligeras%20-%20Varios.md) | Revisar aplicación. |
| 07IPE | [Pizarra - Encuentros](07_CUBIERTAS/07I_INCLINADAS/07IP_PIZARRA/07IPE-Pizarra%20-%20Encuentros.md) | Revisar aplicación. |
| 07IPF | [Pizarra - Faldones](07_CUBIERTAS/07I_INCLINADAS/07IP_PIZARRA/07IPF-Pizarra%20-%20Faldones.md) | Revisar aplicación. |
| 07IPL | [Pizarra - Limas](07_CUBIERTAS/07I_INCLINADAS/07IP_PIZARRA/07IPL-Pizarra%20-%20Limas.md) | Revisar aplicación. |
| 07IPW | [Pizarra - Varios](07_CUBIERTAS/07I_INCLINADAS/07IP_PIZARRA/07IPW-Pizarra%20-%20Varios.md) | Revisar aplicación. |
| 07ISE | [Sintéticas - Encuentros](07_CUBIERTAS/07I_INCLINADAS/07IS_SINT%C3%89TICAS/07ISE-Sint%C3%A9ticas%20-%20Encuentros.md) | Revisar aplicación. |
| 07ISF | [Sintéticas - Faldones](07_CUBIERTAS/07I_INCLINADAS/07IS_SINT%C3%89TICAS/07ISF-Sint%C3%A9ticas%20-%20Faldones.md) | Revisar aplicación. |
| 07ISL | [Sintéticas - Limas](07_CUBIERTAS/07I_INCLINADAS/07IS_SINT%C3%89TICAS/07ISL-Sint%C3%A9ticas%20-%20Limas.md) | Revisar aplicación. |
| 07ISW | [Sintéticas - Varios](07_CUBIERTAS/07I_INCLINADAS/07IS_SINT%C3%89TICAS/07ISW-Sint%C3%A9ticas%20-%20Varios.md) | Revisar aplicación. |
| 07ITE | [Tejas - Encuentros](07_CUBIERTAS/07I_INCLINADAS/07IT_TEJAS/07ITE-Tejas%20-%20Encuentros.md) | Revisar aplicación. |
| 07ITF | [Tejas - Faldones](07_CUBIERTAS/07I_INCLINADAS/07IT_TEJAS/07ITF-Tejas%20-%20Faldones.md) | Revisar aplicación. |
| 07ITL | [Tejas - Limas](07_CUBIERTAS/07I_INCLINADAS/07IT_TEJAS/07ITL-Tejas%20-%20Limas.md) | Revisar aplicación. |
| 07ITW | [Tejas - Varios](07_CUBIERTAS/07I_INCLINADAS/07IT_TEJAS/07ITW-Tejas%20-%20Varios.md) | Revisar aplicación. |
| 07IWW | [Varios - Varios](07_CUBIERTAS/07I_INCLINADAS/07IW_VARIOS/07IWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 07WLC | [Lucernarios y claraboyas - Claraboyas](07_CUBIERTAS/07W_VARIOS/07WL_LUCERNARIOS_Y_CLARABOYAS/07WLC-Lucernarios%20y%20claraboyas%20-%20Claraboyas.md) | Revisar aplicación. |
| 07WLL | [Lucernarios y claraboyas - Lucernarios](07_CUBIERTAS/07W_VARIOS/07WL_LUCERNARIOS_Y_CLARABOYAS/07WLL-Lucernarios%20y%20claraboyas%20-%20Lucernarios.md) | Revisar aplicación. |
| 07WLW | [Lucernarios y claraboyas - Varios](07_CUBIERTAS/07W_VARIOS/07WL_LUCERNARIOS_Y_CLARABOYAS/07WLW-Lucernarios%20y%20claraboyas%20-%20Varios.md) | Revisar aplicación. |
| 07WWW | [Varios - Varios](07_CUBIERTAS/07W_VARIOS/07WW_VARIOS/07WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08CAA | [Aire acondicionado - Equipos y elementos auxiliares](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAA-Aire%20acondicionado%20-%20Equipos%20y%20elementos%20auxiliares.md) | Revisar aplicación. |
| 08CAB | [Aire acondicionado - Baterías de calentamiento](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAB-Aire%20acondicionado%20-%20Bater%C3%ADas%20de%20calentamiento.md) | Revisar aplicación. |
| 08CAD | [Aire acondicionado - Distribución](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAD-Aire%20acondicionado%20-%20Distribuci%C3%B3n.md) | Revisar aplicación. |
| 08CAE | [Aire acondicionado - Torres de enfriamiento](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAE-Aire%20acondicionado%20-%20Torres%20de%20enfriamiento.md) | Revisar aplicación. |
| 08CAF | [Aire acondicionado - Equipos de producción de frio y calor](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAF-Aire%20acondicionado%20-%20Equipos%20de%20producci%C3%B3n%20de%20frio%20y%20calor.md) | Revisar aplicación. |
| 08CAR | [Aire acondicionado - Regulación y control](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAR-Aire%20acondicionado%20-%20Regulaci%C3%B3n%20y%20control.md) | Revisar aplicación. |
| 08CAT | [Aire acondicionado - Centrales de tratamiento](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAT-Aire%20acondicionado%20-%20Centrales%20de%20tratamiento.md) | Revisar aplicación. |
| 08CAU | [Aire acondicionado - Unidades terminales](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAU-Aire%20acondicionado%20-%20Unidades%20terminales.md) | Revisar aplicación. |
| 08CAV | [Aire acondicionado - Valvulería y canalizaciones](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAV-Aire%20acondicionado%20-%20Valvuler%C3%ADa%20y%20canalizaciones.md) | Revisar aplicación. |
| 08CAW | [Aire acondicionado - Varios](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/08CAW-Aire%20acondicionado%20-%20Varios.md) | Revisar aplicación. |
| 08CCA | [Calefacción - Equipos auxiliares](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/08CCA-Calefacci%C3%B3n%20-%20Equipos%20auxiliares.md) | Revisar aplicación. |
| 08CCC | [Calefacción - Calderas](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/08CCC-Calefacci%C3%B3n%20-%20Calderas.md) | Revisar aplicación. |
| 08CCE | [Calefacción - Emisores](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/08CCE-Calefacci%C3%B3n%20-%20Emisores.md) | Revisar aplicación. |
| 08CCR | [Calefacción - Regulación y control](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/08CCR-Calefacci%C3%B3n%20-%20Regulaci%C3%B3n%20y%20control.md) | Revisar aplicación. |
| 08CCV | [Calefacción - Valvulería y canalizaciones](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/08CCV-Calefacci%C3%B3n%20-%20Valvuler%C3%ADa%20y%20canalizaciones.md) | Revisar aplicación. |
| 08CCW | [Calefacción - Varios](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/08CCW-Calefacci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08CVC | [Ventilación - Conductos](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/08CVC-Ventilaci%C3%B3n%20-%20Conductos.md) | Revisar aplicación. |
| 08CVD | [Ventilación - Detección y alarma](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/08CVD-Ventilaci%C3%B3n%20-%20Detecci%C3%B3n%20y%20alarma.md) | Revisar aplicación. |
| 08CVE | [Ventilación - Extractores](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/08CVE-Ventilaci%C3%B3n%20-%20Extractores.md) | Revisar aplicación. |
| 08CVR | [Ventilación - Rejillas y difusores](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/08CVR-Ventilaci%C3%B3n%20-%20Rejillas%20y%20difusores.md) | Revisar aplicación. |
| 08CVV | [Ventilación - Ventiladores](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/08CVV-Ventilaci%C3%B3n%20-%20Ventiladores.md) | Revisar aplicación. |
| 08CVW | [Ventilación - Varios](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/08CVW-Ventilaci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08CWW | [Varios - Varios](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CW_VARIOS/08CWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08EAA | [Acometidas - Acometidas](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EA_ACOMETIDAS/08EAA-Acometidas%20-%20Acometidas.md) | Revisar aplicación. |
| 08EAW | [Acometidas - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EA_ACOMETIDAS/08EAW-Acometidas%20-%20Varios.md) | Revisar aplicación. |
| 08ECC | [Circuitos - Circuitos](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EC_CIRCUITOS/08ECC-Circuitos%20-%20Circuitos.md) | Revisar aplicación. |
| 08ECK | [Circuitos - Conductores](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EC_CIRCUITOS/08ECK-Circuitos%20-%20Conductores.md) | Revisar aplicación. |
| 08ECW | [Circuitos - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EC_CIRCUITOS/08ECW-Circuitos%20-%20Varios.md) | Revisar aplicación. |
| 08EDD | [Derivaciones - Derivaciones](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ED_DERIVACIONES/08EDD-Derivaciones%20-%20Derivaciones.md) | Revisar aplicación. |
| 08EDW | [Derivaciones - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ED_DERIVACIONES/08EDW-Derivaciones%20-%20Varios.md) | Revisar aplicación. |
| 08EID | [Interruptores - Diferenciales](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EI_INTERRUPTORES/08EID-Interruptores%20-%20Diferenciales.md) | Revisar aplicación. |
| 08EIM | [Interruptores - Magnetotérmicos](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EI_INTERRUPTORES/08EIM-Interruptores%20-%20Magnetot%C3%A9rmicos.md) | Revisar aplicación. |
| 08EIW | [Interruptores - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EI_INTERRUPTORES/08EIW-Interruptores%20-%20Varios.md) | Revisar aplicación. |
| 08EKK | [Contadores - Contadores](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EK_CONTADORES/08EKK-Contadores%20-%20Contadores.md) | Revisar aplicación. |
| 08EKW | [Contadores - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EK_CONTADORES/08EKW-Contadores%20-%20Varios.md) | Revisar aplicación. |
| 08ELL | [Puntos de luz - Puntos de luz](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EL_PUNTOS_DE_LUZ/08ELL-Puntos%20de%20luz%20-%20Puntos%20de%20luz.md) | Revisar aplicación. |
| 08ELW | [Puntos de luz - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EL_PUNTOS_DE_LUZ/08ELW-Puntos%20de%20luz%20-%20Varios.md) | Revisar aplicación. |
| 08EPP | [Puestas a tierra - Puestas a tierra](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EP_PUESTAS_A_TIERRA/08EPP-Puestas%20a%20tierra%20-%20Puestas%20a%20tierra.md) | Revisar aplicación. |
| 08EPW | [Puestas a tierra - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EP_PUESTAS_A_TIERRA/08EPW-Puestas%20a%20tierra%20-%20Varios.md) | Revisar aplicación. |
| 08ERR | [Líneas generales de alimentación - Líneas generales de alimentación](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ER_L%C3%8DNEAS_GENERALES_DE_ALIMENTACI%C3%93N/08ERR-L%C3%ADneas%20generales%20de%20alimentaci%C3%B3n%20-%20L%C3%ADneas%20generales%20de%20alimentaci%C3%B3n.md) | Revisar aplicación. |
| 08ERW | [Líneas generales de alimentación - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ER_L%C3%8DNEAS_GENERALES_DE_ALIMENTACI%C3%93N/08ERW-L%C3%ADneas%20generales%20de%20alimentaci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08ETP | [Tomas de corriente - Puestos de trabajo](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ET_TOMAS_DE_CORRIENTE/08ETP-Tomas%20de%20corriente%20-%20Puestos%20de%20trabajo.md) | Revisar aplicación. |
| 08ETT | [Tomas de corriente - Tomas de corriente](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ET_TOMAS_DE_CORRIENTE/08ETT-Tomas%20de%20corriente%20-%20Tomas%20de%20corriente.md) | Revisar aplicación. |
| 08ETW | [Tomas de corriente - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ET_TOMAS_DE_CORRIENTE/08ETW-Tomas%20de%20corriente%20-%20Varios.md) | Revisar aplicación. |
| 08EWW | [Varios - Varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EW_VARIOS/08EWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08FAA | [Acometidas y contadores - Acometidas](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FA_ACOMETIDAS_Y_CONTADORES/08FAA-Acometidas%20y%20contadores%20-%20Acometidas.md) | Revisar aplicación. |
| 08FAC | [Acometidas y contadores - Contadores](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FA_ACOMETIDAS_Y_CONTADORES/08FAC-Acometidas%20y%20contadores%20-%20Contadores.md) | Revisar aplicación. |
| 08FAW | [Acometidas y contadores - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FA_ACOMETIDAS_Y_CONTADORES/08FAW-Acometidas%20y%20contadores%20-%20Varios.md) | Revisar aplicación. |
| 08FCC | [Canalizaciones agua caliente - Cobre](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FC_CANALIZACIONES_AGUA_CALIENTE/08FCC-Canalizaciones%20agua%20caliente%20-%20Cobre.md) | Revisar aplicación. |
| 08FCG | [Canalizaciones agua caliente - Galvanizado](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FC_CANALIZACIONES_AGUA_CALIENTE/08FCG-Canalizaciones%20agua%20caliente%20-%20Galvanizado.md) | Revisar aplicación. |
| 08FCP | [Canalizaciones agua caliente - Piezas especiales](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FC_CANALIZACIONES_AGUA_CALIENTE/08FCP-Canalizaciones%20agua%20caliente%20-%20Piezas%20especiales.md) | Revisar aplicación. |
| 08FCW | [Canalizaciones agua caliente - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FC_CANALIZACIONES_AGUA_CALIENTE/08FCW-Canalizaciones%20agua%20caliente%20-%20Varios.md) | Revisar aplicación. |
| 08FDE | [Desagües - Piezas especiales](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FD_DESAG%C3%9CES/08FDE-Desag%C3%BCes%20-%20Piezas%20especiales.md) | Revisar aplicación. |
| 08FDF | [Desagües - Fibrocemento](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FD_DESAG%C3%9CES/08FDF-Desag%C3%BCes%20-%20Fibrocemento.md) | Revisar aplicación. |
| 08FDP | [Desagües - Plásticos](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FD_DESAG%C3%9CES/08FDP-Desag%C3%BCes%20-%20Pl%C3%A1sticos.md) | Revisar aplicación. |
| 08FDW | [Desagües - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FD_DESAG%C3%9CES/08FDW-Desag%C3%BCes%20-%20Varios.md) | Revisar aplicación. |
| 08FFC | [Canalizaciones agua fría - Cobre](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FF_CANALIZACIONES_AGUA_FR%C3%8DA/08FFC-Canalizaciones%20agua%20fr%C3%ADa%20-%20Cobre.md) | Revisar aplicación. |
| 08FFE | [Canalizaciones agua fría - Piezas especiales](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FF_CANALIZACIONES_AGUA_FR%C3%8DA/08FFE-Canalizaciones%20agua%20fr%C3%ADa%20-%20Piezas%20especiales.md) | Revisar aplicación. |
| 08FFG | [Canalizaciones agua fría - Galvanizado](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FF_CANALIZACIONES_AGUA_FR%C3%8DA/08FFG-Canalizaciones%20agua%20fr%C3%ADa%20-%20Galvanizado.md) | Revisar aplicación. |
| 08FFP | [Canalizaciones agua fría - Plástico](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FF_CANALIZACIONES_AGUA_FR%C3%8DA/08FFP-Canalizaciones%20agua%20fr%C3%ADa%20-%20Pl%C3%A1stico.md) | Revisar aplicación. |
| 08FFW | [Canalizaciones agua fría - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FF_CANALIZACIONES_AGUA_FR%C3%8DA/08FFW-Canalizaciones%20agua%20fr%C3%ADa%20-%20Varios.md) | Revisar aplicación. |
| 08FGB | [Griferías - Bidé](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/08FGB-Grifer%C3%ADas%20-%20Bid%C3%A9.md) | Revisar aplicación. |
| 08FGD | [Griferías - Ducha](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/08FGD-Grifer%C3%ADas%20-%20Ducha.md) | Revisar aplicación. |
| 08FGF | [Griferías - Fregadero](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/08FGF-Grifer%C3%ADas%20-%20Fregadero.md) | Revisar aplicación. |
| 08FGL | [Griferías - Lavabo](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/08FGL-Grifer%C3%ADas%20-%20Lavabo.md) | Revisar aplicación. |
| 08FGN | [Griferías - Bañera](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/08FGN-Grifer%C3%ADas%20-%20Ba%C3%B1era.md) | Revisar aplicación. |
| 08FGW | [Griferías - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/08FGW-Grifer%C3%ADas%20-%20Varios.md) | Revisar aplicación. |
| 08FSB | [Aparatos sanitarios - Bidé](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSB-Aparatos%20sanitarios%20-%20Bid%C3%A9.md) | Revisar aplicación. |
| 08FSD | [Aparatos sanitarios - Ducha](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSD-Aparatos%20sanitarios%20-%20Ducha.md) | Revisar aplicación. |
| 08FSF | [Aparatos sanitarios - Fregadero](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSF-Aparatos%20sanitarios%20-%20Fregadero.md) | Revisar aplicación. |
| 08FSI | [Aparatos sanitarios - Inodoro](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSI-Aparatos%20sanitarios%20-%20Inodoro.md) | Revisar aplicación. |
| 08FSL | [Aparatos sanitarios - Lavabo](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSL-Aparatos%20sanitarios%20-%20Lavabo.md) | Revisar aplicación. |
| 08FSN | [Aparatos sanitarios - Bañera](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSN-Aparatos%20sanitarios%20-%20Ba%C3%B1era.md) | Revisar aplicación. |
| 08FSW | [Aparatos sanitarios - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/08FSW-Aparatos%20sanitarios%20-%20Varios.md) | Revisar aplicación. |
| 08FTC | [Termos y calentadores - Calentadores](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FT_TERMOS_Y_CALENTADORES/08FTC-Termos%20y%20calentadores%20-%20Calentadores.md) | Revisar aplicación. |
| 08FTT | [Termos y calentadores - Termos](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FT_TERMOS_Y_CALENTADORES/08FTT-Termos%20y%20calentadores%20-%20Termos.md) | Revisar aplicación. |
| 08FTW | [Termos y calentadores - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FT_TERMOS_Y_CALENTADORES/08FTW-Termos%20y%20calentadores%20-%20Varios.md) | Revisar aplicación. |
| 08FVB | [Valvulería - Bola](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FV_VALVULER%C3%8DA/08FVB-Valvuler%C3%ADa%20-%20Bola.md) | Revisar aplicación. |
| 08FVC | [Valvulería - Compuerta](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FV_VALVULER%C3%8DA/08FVC-Valvuler%C3%ADa%20-%20Compuerta.md) | Revisar aplicación. |
| 08FVL | [Valvulería - Llaves de paso](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FV_VALVULER%C3%8DA/08FVL-Valvuler%C3%ADa%20-%20Llaves%20de%20paso.md) | Revisar aplicación. |
| 08FVR | [Valvulería - Retención](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FV_VALVULER%C3%8DA/08FVR-Valvuler%C3%ADa%20-%20Retenci%C3%B3n.md) | Revisar aplicación. |
| 08FVW | [Valvulería - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FV_VALVULER%C3%8DA/08FVW-Valvuler%C3%ADa%20-%20Varios.md) | Revisar aplicación. |
| 08FWW | [Varios - Varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FW_VARIOS/08FWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08KDA | [Datos - Acometidas](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KD_DATOS/08KDA-Datos%20-%20Acometidas.md) | Revisar aplicación. |
| 08KDC | [Datos - Canalizaciones](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KD_DATOS/08KDC-Datos%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08KDE | [Datos - Equipos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KD_DATOS/08KDE-Datos%20-%20Equipos.md) | Revisar aplicación. |
| 08KDP | [Datos - Aparatos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KD_DATOS/08KDP-Datos%20-%20Aparatos.md) | Revisar aplicación. |
| 08KDW | [Datos - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KD_DATOS/08KDW-Datos%20-%20Varios.md) | Revisar aplicación. |
| 08KEA | [Electroacústicas - Aparatos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KE_ELECTROAC%C3%9ASTICAS/08KEA-Electroac%C3%BAsticas%20-%20Aparatos.md) | Revisar aplicación. |
| 08KEC | [Electroacústicas - Canalizaciones](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KE_ELECTROAC%C3%9ASTICAS/08KEC-Electroac%C3%BAsticas%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08KEW | [Electroacústicas - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KE_ELECTROAC%C3%9ASTICAS/08KEW-Electroac%C3%BAsticas%20-%20Varios.md) | Revisar aplicación. |
| 08KFA | [Infraestructuras - Acometidas](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KF_INFRAESTRUCTURAS/08KFA-Infraestructuras%20-%20Acometidas.md) | Revisar aplicación. |
| 08KFC | [Infraestructuras - Conductos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KF_INFRAESTRUCTURAS/08KFC-Infraestructuras%20-%20Conductos.md) | Revisar aplicación. |
| 08KFR | [Infraestructuras - Registros](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KF_INFRAESTRUCTURAS/08KFR-Infraestructuras%20-%20Registros.md) | Revisar aplicación. |
| 08KFW | [Infraestructuras - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KF_INFRAESTRUCTURAS/08KFW-Infraestructuras%20-%20Varios.md) | Revisar aplicación. |
| 08KIA | [Intercomunicación - Aparatos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KI_INTERCOMUNICACI%C3%93N/08KIA-Intercomunicaci%C3%B3n%20-%20Aparatos.md) | Revisar aplicación. |
| 08KIC | [Intercomunicación - Canalizaciones](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KI_INTERCOMUNICACI%C3%93N/08KIC-Intercomunicaci%C3%B3n%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08KIW | [Intercomunicación - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KI_INTERCOMUNICACI%C3%93N/08KIW-Intercomunicaci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08KRA | [Radio - Aparatos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KR_RADIO/08KRA-Radio%20-%20Aparatos.md) | Revisar aplicación. |
| 08KRC | [Radio - Canalizaciones](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KR_RADIO/08KRC-Radio%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08KRW | [Radio - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KR_RADIO/08KRW-Radio%20-%20Varios.md) | Revisar aplicación. |
| 08KTA | [Telefonía - Aparatos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KT_TELEFON%C3%8DA/08KTA-Telefon%C3%ADa%20-%20Aparatos.md) | Revisar aplicación. |
| 08KTC | [Telefonía - Canalizaciones](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KT_TELEFON%C3%8DA/08KTC-Telefon%C3%ADa%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08KTW | [Telefonía - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KT_TELEFON%C3%8DA/08KTW-Telefon%C3%ADa%20-%20Varios.md) | Revisar aplicación. |
| 08KVA | [Televisión - Aparatos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KV_TELEVISI%C3%93N/08KVA-Televisi%C3%B3n%20-%20Aparatos.md) | Revisar aplicación. |
| 08KVC | [Televisión - Canalizaciones](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KV_TELEVISI%C3%93N/08KVC-Televisi%C3%B3n%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08KVW | [Televisión - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KV_TELEVISI%C3%93N/08KVW-Televisi%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08KWW | [Varios - Varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KW_VARIOS/08KWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08LBB | [Butano - Butano](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LB_BUTANO/08LBB-Butano%20-%20Butano.md) | Revisar aplicación. |
| 08LBW | [Butano - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LB_BUTANO/08LBW-Butano%20-%20Varios.md) | Revisar aplicación. |
| 08LCC | [Gas ciudad - Gas ciudad](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LC_GAS_CIUDAD/08LCC-Gas%20ciudad%20-%20Gas%20ciudad.md) | Revisar aplicación. |
| 08LCW | [Gas ciudad - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LC_GAS_CIUDAD/08LCW-Gas%20ciudad%20-%20Varios.md) | Revisar aplicación. |
| 08LFF | [Fuel-oil - Fué-oil](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LF_FUEL_OIL/08LFF-Fuel-oil%20-%20Fu%C3%A9-oil.md) | Revisar aplicación. |
| 08LFW | [Fuel-oil - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LF_FUEL_OIL/08LFW-Fuel-oil%20-%20Varios.md) | Revisar aplicación. |
| 08LGG | [Gasóleo - Gasóleo](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LG_GAS%C3%93LEO/08LGG-Gas%C3%B3leo%20-%20Gas%C3%B3leo.md) | Revisar aplicación. |
| 08LGW | [Gasóleo - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LG_GAS%C3%93LEO/08LGW-Gas%C3%B3leo%20-%20Varios.md) | Revisar aplicación. |
| 08LMM | [Gases medicinales - Gases medicinales](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LM_GASES_MEDICINALES/08LMM-Gases%20medicinales%20-%20Gases%20medicinales.md) | Revisar aplicación. |
| 08LNA | [Gas Natural - Acometida](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LN_GAS_NATURAL/08LNA-Gas%20Natural%20-%20Acometida.md) | Revisar aplicación. |
| 08LNC | [Gas Natural - Canalizaciones](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LN_GAS_NATURAL/08LNC-Gas%20Natural%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08LNE | [Gas Natural - Equipos](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LN_GAS_NATURAL/08LNE-Gas%20Natural%20-%20Equipos.md) | Revisar aplicación. |
| 08LNV | [Gas Natural - Valvuleria](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LN_GAS_NATURAL/08LNV-Gas%20Natural%20-%20Valvuleria.md) | Revisar aplicación. |
| 08LNW | [Gas Natural - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LN_GAS_NATURAL/08LNW-Gas%20Natural%20-%20Varios.md) | Revisar aplicación. |
| 08LPP | [Propano - Propano](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LP_PROPANO/08LPP-Propano%20-%20Propano.md) | Revisar aplicación. |
| 08LPW | [Propano - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LP_PROPANO/08LPW-Propano%20-%20Varios.md) | Revisar aplicación. |
| 08LWW | [Varios - Varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LW_VARIOS/08LWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08MAA | [Ascensores y montacargas - Ascensores](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MA_ASCENSORES_Y_MONTACARGAS/08MAA-Ascensores%20y%20montacargas%20-%20Ascensores.md) | Revisar aplicación. |
| 08MAM | [Ascensores y montacargas - Montacargas](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MA_ASCENSORES_Y_MONTACARGAS/08MAM-Ascensores%20y%20montacargas%20-%20Montacargas.md) | Revisar aplicación. |
| 08MAW | [Ascensores y montacargas - Varios](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MA_ASCENSORES_Y_MONTACARGAS/08MAW-Ascensores%20y%20montacargas%20-%20Varios.md) | Revisar aplicación. |
| 08MBA | [Equipos de bombeo - Agua](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MB_EQUIPOS_DE_BOMBEO/08MBA-Equipos%20de%20bombeo%20-%20Agua.md) | Revisar aplicación. |
| 08MBE | [Equipos de bombeo - Equipos de presión](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MB_EQUIPOS_DE_BOMBEO/08MBE-Equipos%20de%20bombeo%20-%20Equipos%20de%20presi%C3%B3n.md) | Revisar aplicación. |
| 08MBL | [Equipos de bombeo - Lodos](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MB_EQUIPOS_DE_BOMBEO/08MBL-Equipos%20de%20bombeo%20-%20Lodos.md) | Revisar aplicación. |
| 08MBW | [Equipos de bombeo - Varios](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MB_EQUIPOS_DE_BOMBEO/08MBW-Equipos%20de%20bombeo%20-%20Varios.md) | Revisar aplicación. |
| 08MEE | [Escaleras, rampas y tapices - Escaleras](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08ME_ESCALERAS_RAMPAS_Y_TAPICES/08MEE-Escaleras%2C%20rampas%20y%20tapices%20-%20Escaleras.md) | Revisar aplicación. |
| 08MER | [Escaleras, rampas y tapices - Rampas](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08ME_ESCALERAS_RAMPAS_Y_TAPICES/08MER-Escaleras%2C%20rampas%20y%20tapices%20-%20Rampas.md) | Revisar aplicación. |
| 08MET | [Escaleras, rampas y tapices - Tapices](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08ME_ESCALERAS_RAMPAS_Y_TAPICES/08MET-Escaleras%2C%20rampas%20y%20tapices%20-%20Tapices.md) | Revisar aplicación. |
| 08MEW | [Escaleras, rampas y tapices - Varios](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08ME_ESCALERAS_RAMPAS_Y_TAPICES/08MEW-Escaleras%2C%20rampas%20y%20tapices%20-%20Varios.md) | Revisar aplicación. |
| 08MWW | [Varios - Varios](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MW_VARIOS/08MWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08NAA | [Acumuladores - Acumuladores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NA_ACUMULADORES/08NAA-Acumuladores%20-%20Acumuladores.md) | Revisar aplicación. |
| 08NAW | [Acumuladores - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NA_ACUMULADORES/08NAW-Acumuladores%20-%20Varios.md) | Revisar aplicación. |
| 08NBB | [Bancadas - Bancadas](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NB_BANCADAS/08NBB-Bancadas%20-%20Bancadas.md) | Revisar aplicación. |
| 08NBW | [Bancadas - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NB_BANCADAS/08NBW-Bancadas%20-%20Varios.md) | Revisar aplicación. |
| 08NCC | [Contadores - Contadores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NC_CONTADORES/08NCC-Contadores%20-%20Contadores.md) | Revisar aplicación. |
| 08NCW | [Contadores - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NC_CONTADORES/08NCW-Contadores%20-%20Varios.md) | Revisar aplicación. |
| 08NDD | [Sistemas de distribución - Sistemas de distribución](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08ND_SISTEMAS_DE_DISTRIBUCI%C3%93N/08NDD-Sistemas%20de%20distribuci%C3%B3n%20-%20Sistemas%20de%20distribuci%C3%B3n.md) | Revisar aplicación. |
| 08NDW | [Sistemas de distribución - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08ND_SISTEMAS_DE_DISTRIBUCI%C3%93N/08NDW-Sistemas%20de%20distribuci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08NEE | [Estructuras portantes - Estructuras portantes](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NE_ESTRUCTURAS_PORTANTES/08NEE-Estructuras%20portantes%20-%20Estructuras%20portantes.md) | Revisar aplicación. |
| 08NEW | [Estructuras portantes - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NE_ESTRUCTURAS_PORTANTES/08NEW-Estructuras%20portantes%20-%20Varios.md) | Revisar aplicación. |
| 08NII | [Intercambiadores - Intercambiadores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NI_INTERCAMBIADORES/08NII-Intercambiadores%20-%20Intercambiadores.md) | Revisar aplicación. |
| 08NIW | [Intercambiadores - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NI_INTERCAMBIADORES/08NIW-Intercambiadores%20-%20Varios.md) | Revisar aplicación. |
| 08NLL | [Sistemas de llenado-vaciado - Sistema de llenado-vaciado](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NL_SISTEMAS_DE_LLENADO_VACIADO/08NLL-Sistemas%20de%20llenado-vaciado%20-%20Sistema%20de%20llenado-vaciado.md) | Revisar aplicación. |
| 08NLW | [Sistemas de llenado-vaciado - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NL_SISTEMAS_DE_LLENADO_VACIADO/08NLW-Sistemas%20de%20llenado-vaciado%20-%20Varios.md) | Revisar aplicación. |
| 08NOC | [Captadores - Captadores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NO_CAPTADORES/08NOC-Captadores%20-%20Captadores.md) | Revisar aplicación. |
| 08NOW | [Captadores - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NO_CAPTADORES/08NOW-Captadores%20-%20Varios.md) | Revisar aplicación. |
| 08NPP | [Circuito primario - Circuito primario](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NP_CIRCUITO_PRIMARIO/08NPP-Circuito%20primario%20-%20Circuito%20primario.md) | Revisar aplicación. |
| 08NPW | [Circuito primario - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NP_CIRCUITO_PRIMARIO/08NPW-Circuito%20primario%20-%20Varios.md) | Revisar aplicación. |
| 08NRR | [Sistema de regulación y control - Sistemas de regulación y control](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NR_SISTEMA_DE_REGULACI%C3%93N_Y_CONTROL/08NRR-Sistema%20de%20regulaci%C3%B3n%20y%20control%20-%20Sistemas%20de%20regulaci%C3%B3n%20y%20control.md) | Revisar aplicación. |
| 08NRW | [Sistema de regulación y control - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NR_SISTEMA_DE_REGULACI%C3%93N_Y_CONTROL/08NRW-Sistema%20de%20regulaci%C3%B3n%20y%20control%20-%20Varios.md) | Revisar aplicación. |
| 08NSS | [Prevención de sobrecalentamiento - Prevención de sobrecalentamiento](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NS_PREVENCI%C3%93N_DE_SOBRECALENTAMIENTO/08NSS-Prevenci%C3%B3n%20de%20sobrecalentamiento%20-%20Prevenci%C3%B3n%20de%20sobrecalentamiento.md) | Revisar aplicación. |
| 08NSW | [Prevención de sobrecalentamiento - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NS_PREVENCI%C3%93N_DE_SOBRECALENTAMIENTO/08NSW-Prevenci%C3%B3n%20de%20sobrecalentamiento%20-%20Varios.md) | Revisar aplicación. |
| 08NTT | [Equipos de termosifón - Equipos de termosifón](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NT_EQUIPOS_DE_TERMOSIF%C3%93N/08NTT-Equipos%20de%20termosif%C3%B3n%20-%20Equipos%20de%20termosif%C3%B3n.md) | Revisar aplicación. |
| 08NTW | [Equipos de termosifón - Varios](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NT_EQUIPOS_DE_TERMOSIF%C3%93N/08NTW-Equipos%20de%20termosif%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08OEE | [Estructuras portantes - Estructuras portantes](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OE_ESTRUCTURAS_PORTANTES/08OEE-Estructuras%20portantes%20-%20Estructuras%20portantes.md) | Revisar aplicación. |
| 08OOC | [Captadores - Captadores](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OO_CAPTADORES/08OOC-Captadores%20-%20Captadores.md) | Revisar aplicación. |
| 08ORR | [Sistema de regulación y control - Sistemas de regulación y control](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OR_SISTEMA_DE_REGULACI%C3%93N_Y_CONTROL/08ORR-Sistema%20de%20regulaci%C3%B3n%20y%20control%20-%20Sistemas%20de%20regulaci%C3%B3n%20y%20control.md) | Revisar aplicación. |
| 08ORW | [Sistema de regulación y control - Varios](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OR_SISTEMA_DE_REGULACI%C3%93N_Y_CONTROL/08ORW-Sistema%20de%20regulaci%C3%B3n%20y%20control%20-%20Varios.md) | Revisar aplicación. |
| 08OUU | [Monitorización y control - Sistemas](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OU_MONITORIZACI%C3%93N_Y_CONTROL/08OUU-Monitorizaci%C3%B3n%20y%20control%20-%20Sistemas.md) | Revisar aplicación. |
| 08PIA | [Contra incendios - Protecciones](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIA-Contra%20incendios%20-%20Protecciones.md) | Revisar aplicación. |
| 08PIC | [Contra incendios - Canalizaciones](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIC-Contra%20incendios%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08PID | [Contra incendios - Detección y alarma](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PID-Contra%20incendios%20-%20Detecci%C3%B3n%20y%20alarma.md) | Revisar aplicación. |
| 08PIE | [Contra incendios - Extintores móviles](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIE-Contra%20incendios%20-%20Extintores%20m%C3%B3viles.md) | Revisar aplicación. |
| 08PIF | [Contra incendios - Equipos fijos](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIF-Contra%20incendios%20-%20Equipos%20fijos.md) | Revisar aplicación. |
| 08PIM | [Contra incendios - Equipos con manguera](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIM-Contra%20incendios%20-%20Equipos%20con%20manguera.md) | Revisar aplicación. |
| 08PIS | [Contra incendios - Señalización y emergencia](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIS-Contra%20incendios%20-%20Se%C3%B1alizaci%C3%B3n%20y%20emergencia.md) | Revisar aplicación. |
| 08PIV | [Contra incendios - Válvulas](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIV-Contra%20incendios%20-%20V%C3%A1lvulas.md) | Revisar aplicación. |
| 08PIW | [Contra incendios - Varios](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/08PIW-Contra%20incendios%20-%20Varios.md) | Revisar aplicación. |
| 08PPA | [Pararrayos - Aparatos](08_INSTALACIONES/08P_PROTECCIONES/08PP_PARARRAYOS/08PPA-Pararrayos%20-%20Aparatos.md) | Revisar aplicación. |
| 08PPC | [Pararrayos - Canalizaciones](08_INSTALACIONES/08P_PROTECCIONES/08PP_PARARRAYOS/08PPC-Pararrayos%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08PPW | [Pararrayos - Varios](08_INSTALACIONES/08P_PROTECCIONES/08PP_PARARRAYOS/08PPW-Pararrayos%20-%20Varios.md) | Revisar aplicación. |
| 08PRR | [Antirrobo - Antirrobo](08_INSTALACIONES/08P_PROTECCIONES/08PR_ANTIRROBO/08PRR-Antirrobo%20-%20Antirrobo.md) | Revisar aplicación. |
| 08PRW | [Antirrobo - Varios](08_INSTALACIONES/08P_PROTECCIONES/08PR_ANTIRROBO/08PRW-Antirrobo%20-%20Varios.md) | Revisar aplicación. |
| 08PWW | [Varios - Varios](08_INSTALACIONES/08P_PROTECCIONES/08PW_VARIOS/08PWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08SBB | [Basuras - Basuras](08_INSTALACIONES/08S_SALUBRIDAD/08SB_BASURAS/08SBB-Basuras%20-%20Basuras.md) | Revisar aplicación. |
| 08SBW | [Basuras - Varios](08_INSTALACIONES/08S_SALUBRIDAD/08SB_BASURAS/08SBW-Basuras%20-%20Varios.md) | Revisar aplicación. |
| 08SHC | [Humos y gases - Canalizaciones](08_INSTALACIONES/08S_SALUBRIDAD/08SH_HUMOS_Y_GASES/08SHC-Humos%20y%20gases%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08SHE | [Humos y gases - Extractores](08_INSTALACIONES/08S_SALUBRIDAD/08SH_HUMOS_Y_GASES/08SHE-Humos%20y%20gases%20-%20Extractores.md) | Revisar aplicación. |
| 08SHW | [Humos y gases - Varios](08_INSTALACIONES/08S_SALUBRIDAD/08SH_HUMOS_Y_GASES/08SHW-Humos%20y%20gases%20-%20Varios.md) | Revisar aplicación. |
| 08SWW | [Varios - Varios](08_INSTALACIONES/08S_SALUBRIDAD/08SW_VARIOS/08SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 08TCA | [Control Remoto - Aparatos](08_INSTALACIONES/08T_CONTROL_REMOTO/08TC_CONTROL_REMOTO/08TCA-Control%20Remoto%20-%20Aparatos.md) | Revisar aplicación. |
| 08TCC | [Control Remoto - Canalizaciones](08_INSTALACIONES/08T_CONTROL_REMOTO/08TC_CONTROL_REMOTO/08TCC-Control%20Remoto%20-%20Canalizaciones.md) | Revisar aplicación. |
| 08WII | [Iluminación - Iluminación](08_INSTALACIONES/08W_VARIOS/08WI_ILUMINACI%C3%93N/08WII-Iluminaci%C3%B3n%20-%20Iluminaci%C3%B3n.md) | Revisar aplicación. |
| 08WIW | [Iluminación - Varios](08_INSTALACIONES/08W_VARIOS/08WI_ILUMINACI%C3%93N/08WIW-Iluminaci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 08WPP | [Puestos de Trabajo Mixtos - Puestos de Trabajo Mixtos](08_INSTALACIONES/08W_VARIOS/08WP_PUESTOS_DE_TRABAJO_MIXTOS/08WPP-Puestos%20de%20Trabajo%20Mixtos%20-%20Puestos%20de%20Trabajo%20Mixtos.md) | Revisar aplicación. |
| 08WPW | [Puestos de Trabajo Mixtos - Varios](08_INSTALACIONES/08W_VARIOS/08WP_PUESTOS_DE_TRABAJO_MIXTOS/08WPW-Puestos%20de%20Trabajo%20Mixtos%20-%20Varios.md) | Revisar aplicación. |
| 08WWW | [Varios - Varios](08_INSTALACIONES/08W_VARIOS/08WW_VARIOS/08WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 09APP | [Paredes - Paredes](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AP_PAREDES/09APP-Paredes%20-%20Paredes.md) | Revisar aplicación. |
| 09APW | [Paredes - Varios](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AP_PAREDES/09APW-Paredes%20-%20Varios.md) | Revisar aplicación. |
| 09ASS | [Suelos - Suelos](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AS_SUELOS/09ASS-Suelos%20-%20Suelos.md) | Revisar aplicación. |
| 09ASW | [Suelos - Varios](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AS_SUELOS/09ASW-Suelos%20-%20Varios.md) | Revisar aplicación. |
| 09ATT | [Techos - Techos](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AT_TECHOS/09ATT-Techos%20-%20Techos.md) | Revisar aplicación. |
| 09ATW | [Techos - Varios](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AT_TECHOS/09ATW-Techos%20-%20Varios.md) | Revisar aplicación. |
| 09AWW | [Varios - Varios](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AW_VARIOS/09AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 09IJJ | [Juntas - Juntas](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IJ_JUNTAS/09IJJ-Juntas%20-%20Juntas.md) | Revisar aplicación. |
| 09IJW | [Juntas - Varios](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IJ_JUNTAS/09IJW-Juntas%20-%20Varios.md) | Revisar aplicación. |
| 09IMM | [Muros - Muros](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IM_MUROS/09IMM-Muros%20-%20Muros.md) | Revisar aplicación. |
| 09IMW | [Muros - Varios](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IM_MUROS/09IMW-Muros%20-%20Varios.md) | Revisar aplicación. |
| 09IPP | [Paredes - Paredes](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IP_PAREDES/09IPP-Paredes%20-%20Paredes.md) | Revisar aplicación. |
| 09IPW | [Paredes - Varios](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IP_PAREDES/09IPW-Paredes%20-%20Varios.md) | Revisar aplicación. |
| 09ISS | [Suelos - Suelos](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IS_SUELOS/09ISS-Suelos%20-%20Suelos.md) | Revisar aplicación. |
| 09ISW | [Suelos - Varios](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IS_SUELOS/09ISW-Suelos%20-%20Varios.md) | Revisar aplicación. |
| 09IWW | [Varios - Varios](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IW_VARIOS/09IWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 09TCC | [Canalizaciones - Canalizaciones](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TC_CANALIZACIONES/09TCC-Canalizaciones%20-%20Canalizaciones.md) | Revisar aplicación. |
| 09TCW | [Canalizaciones - Varios](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TC_CANALIZACIONES/09TCW-Canalizaciones%20-%20Varios.md) | Revisar aplicación. |
| 09TPP | [Paredes - Paredes](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TP_PAREDES/09TPP-Paredes%20-%20Paredes.md) | Revisar aplicación. |
| 09TPW | [Paredes - Varios](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TP_PAREDES/09TPW-Paredes%20-%20Varios.md) | Revisar aplicación. |
| 09TSS | [Suelos - Suelos](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TS_SUELOS/09TSS-Suelos%20-%20Suelos.md) | Revisar aplicación. |
| 09TSW | [Suelos - Varios](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TS_SUELOS/09TSW-Suelos%20-%20Varios.md) | Revisar aplicación. |
| 09TTT | [Techos - Techos](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TT_TECHOS/09TTT-Techos%20-%20Techos.md) | Revisar aplicación. |
| 09TTW | [Techos - Varios](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TT_TECHOS/09TTW-Techos%20-%20Varios.md) | Revisar aplicación. |
| 09TWW | [Varios - Varios](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TW_VARIOS/09TWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 09WWW | [Varios - Varios](09_AISLAMIENTOS/09W_VARIOS/09WW_VARIOS/09WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10AAD | [Alicatados - Decorados](10_REVESTIMIENTOS/10A_APLACADOS/10AA_ALICATADOS/10AAD-Alicatados%20-%20Decorados.md) | Revisar aplicación. |
| 10AAE | [Alicatados - Especiales](10_REVESTIMIENTOS/10A_APLACADOS/10AA_ALICATADOS/10AAE-Alicatados%20-%20Especiales.md) | Revisar aplicación. |
| 10AAL | [Alicatados - Lisos](10_REVESTIMIENTOS/10A_APLACADOS/10AA_ALICATADOS/10AAL-Alicatados%20-%20Lisos.md) | Revisar aplicación. |
| 10AAW | [Alicatados - Varios](10_REVESTIMIENTOS/10A_APLACADOS/10AA_ALICATADOS/10AAW-Alicatados%20-%20Varios.md) | Revisar aplicación. |
| 10ACA | [Chapados - Piedras artificiales](10_REVESTIMIENTOS/10A_APLACADOS/10AC_CHAPADOS/10ACA-Chapados%20-%20Piedras%20artificiales.md) | Revisar aplicación. |
| 10ACN | [Chapados - Piedras naturales](10_REVESTIMIENTOS/10A_APLACADOS/10AC_CHAPADOS/10ACN-Chapados%20-%20Piedras%20naturales.md) | Revisar aplicación. |
| 10ACW | [Chapados - Varios](10_REVESTIMIENTOS/10A_APLACADOS/10AC_CHAPADOS/10ACW-Chapados%20-%20Varios.md) | Revisar aplicación. |
| 10AWW | [Varios - Varios](10_REVESTIMIENTOS/10A_APLACADOS/10AW_VARIOS/10AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10CEE | [Enfoscados - Enfoscados](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CE_ENFOSCADOS/10CEE-Enfoscados%20-%20Enfoscados.md) | Revisar aplicación. |
| 10CEW | [Enfoscados - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CE_ENFOSCADOS/10CEW-Enfoscados%20-%20Varios.md) | Revisar aplicación. |
| 10CGG | [Guarnecidos - Guarnecidos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CG_GUARNECIDOS/10CGG-Guarnecidos%20-%20Guarnecidos.md) | Revisar aplicación. |
| 10CGW | [Guarnecidos - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CG_GUARNECIDOS/10CGW-Guarnecidos%20-%20Varios.md) | Revisar aplicación. |
| 10CLL | [Enlucidos - Enlucidos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CL_ENLUCIDOS/10CLL-Enlucidos%20-%20Enlucidos.md) | Revisar aplicación. |
| 10CLW | [Enlucidos - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CL_ENLUCIDOS/10CLW-Enlucidos%20-%20Varios.md) | Revisar aplicación. |
| 10CPE | [Poliméricos - Enlucidos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CP_POLIM%C3%89RICOS/10CPE-Polim%C3%A9ricos%20-%20Enlucidos.md) | Revisar aplicación. |
| 10CPM | [Poliméricos - Monocapas](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CP_POLIM%C3%89RICOS/10CPM-Polim%C3%A9ricos%20-%20Monocapas.md) | Revisar aplicación. |
| 10CPW | [Poliméricos - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CP_POLIM%C3%89RICOS/10CPW-Polim%C3%A9ricos%20-%20Varios.md) | Revisar aplicación. |
| 10CRR | [Revocos - Revocos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CR_REVOCOS/10CRR-Revocos%20-%20Revocos.md) | Revisar aplicación. |
| 10CRW | [Revocos - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CR_REVOCOS/10CRW-Revocos%20-%20Varios.md) | Revisar aplicación. |
| 10CTT | [Tendidos - Tendidos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CT_TENDIDOS/10CTT-Tendidos%20-%20Tendidos.md) | Revisar aplicación. |
| 10CTW | [Tendidos - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CT_TENDIDOS/10CTW-Tendidos%20-%20Varios.md) | Revisar aplicación. |
| 10CWE | [Varios - Estucos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CW_VARIOS/10CWE-Varios%20-%20Estucos.md) | Revisar aplicación. |
| 10CWW | [Varios - Varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CW_VARIOS/10CWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10LAM | [Aleaciones ligeras - Metales](10_REVESTIMIENTOS/10L_LIGEROS/10LA_ALEACIONES_LIGERAS/10LAM-Aleaciones%20ligeras%20-%20Metales.md) | Revisar aplicación. |
| 10LAP | [Aleaciones ligeras - Plásticos](10_REVESTIMIENTOS/10L_LIGEROS/10LA_ALEACIONES_LIGERAS/10LAP-Aleaciones%20ligeras%20-%20Pl%C3%A1sticos.md) | Revisar aplicación. |
| 10LAW | [Aleaciones ligeras - Varios](10_REVESTIMIENTOS/10L_LIGEROS/10LA_ALEACIONES_LIGERAS/10LAW-Aleaciones%20ligeras%20-%20Varios.md) | Revisar aplicación. |
| 10LCC | [Corcho - Corcho](10_REVESTIMIENTOS/10L_LIGEROS/10LC_CORCHO/10LCC-Corcho%20-%20Corcho.md) | Revisar aplicación. |
| 10LCW | [Corcho - Varios](10_REVESTIMIENTOS/10L_LIGEROS/10LC_CORCHO/10LCW-Corcho%20-%20Varios.md) | Revisar aplicación. |
| 10LMM | [Madera - Madera](10_REVESTIMIENTOS/10L_LIGEROS/10LM_MADERA/10LMM-Madera%20-%20Madera.md) | Revisar aplicación. |
| 10LMW | [Madera - Varios](10_REVESTIMIENTOS/10L_LIGEROS/10LM_MADERA/10LMW-Madera%20-%20Varios.md) | Revisar aplicación. |
| 10LWW | [Varios - Varios](10_REVESTIMIENTOS/10L_LIGEROS/10LW_VARIOS/10LWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10PAP | [Piedras artificiales - Peldaños](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PA_PIEDRAS_ARTIFICIALES/10PAP-Piedras%20artificiales%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 10PAW | [Piedras artificiales - Varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PA_PIEDRAS_ARTIFICIALES/10PAW-Piedras%20artificiales%20-%20Varios.md) | Revisar aplicación. |
| 10PAZ | [Piedras artificiales - Zanquines](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PA_PIEDRAS_ARTIFICIALES/10PAZ-Piedras%20artificiales%20-%20Zanquines.md) | Revisar aplicación. |
| 10PCP | [Cerámicos - Peldaños](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PC_CER%C3%81MICOS/10PCP-Cer%C3%A1micos%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 10PCW | [Cerámicos - Varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PC_CER%C3%81MICOS/10PCW-Cer%C3%A1micos%20-%20Varios.md) | Revisar aplicación. |
| 10PCZ | [Cerámicos - Zanquines](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PC_CER%C3%81MICOS/10PCZ-Cer%C3%A1micos%20-%20Zanquines.md) | Revisar aplicación. |
| 10PLP | [Ligeros - Peldaños](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PL_LIGEROS/10PLP-Ligeros%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 10PLW | [Ligeros - Varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PL_LIGEROS/10PLW-Ligeros%20-%20Varios.md) | Revisar aplicación. |
| 10PLZ | [Ligeros - Zanquines](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PL_LIGEROS/10PLZ-Ligeros%20-%20Zanquines.md) | Revisar aplicación. |
| 10PMP | [Maderas - Peldaños](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PM_MADERAS/10PMP-Maderas%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 10PMW | [Maderas - Varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PM_MADERAS/10PMW-Maderas%20-%20Varios.md) | Revisar aplicación. |
| 10PMZ | [Maderas - Zanquines](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PM_MADERAS/10PMZ-Maderas%20-%20Zanquines.md) | Revisar aplicación. |
| 10PNP | [Piedras naturales - Peldaños](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PN_PIEDRAS_NATURALES/10PNP-Piedras%20naturales%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 10PNW | [Piedras naturales - Varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PN_PIEDRAS_NATURALES/10PNW-Piedras%20naturales%20-%20Varios.md) | Revisar aplicación. |
| 10PNZ | [Piedras naturales - Zanquines](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PN_PIEDRAS_NATURALES/10PNZ-Piedras%20naturales%20-%20Zanquines.md) | Revisar aplicación. |
| 10PWW | [Varios - Varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PW_VARIOS/10PWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10SCR | [Cerámicos - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SC_CER%C3%81MICOS/10SCR-Cer%C3%A1micos%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SCS | [Cerámicos - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10SC_CER%C3%81MICOS/10SCS-Cer%C3%A1micos%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10SCW | [Cerámicos - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SC_CER%C3%81MICOS/10SCW-Cer%C3%A1micos%20-%20Varios.md) | Revisar aplicación. |
| 10SER | [Especiales - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SE_ESPECIALES/10SER-Especiales%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SES | [Especiales - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10SE_ESPECIALES/10SES-Especiales%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10SEW | [Especiales - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SE_ESPECIALES/10SEW-Especiales%20-%20Varios.md) | Revisar aplicación. |
| 10SHR | [Hidráulicos - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SH_HIDR%C3%81ULICOS/10SHR-Hidr%C3%A1ulicos%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SHS | [Hidráulicos - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10SH_HIDR%C3%81ULICOS/10SHS-Hidr%C3%A1ulicos%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10SHW | [Hidráulicos - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SH_HIDR%C3%81ULICOS/10SHW-Hidr%C3%A1ulicos%20-%20Varios.md) | Revisar aplicación. |
| 10SLR | [Ligeros - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SL_LIGEROS/10SLR-Ligeros%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SLS | [Ligeros - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10SL_LIGEROS/10SLS-Ligeros%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10SLW | [Ligeros - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SL_LIGEROS/10SLW-Ligeros%20-%20Varios.md) | Revisar aplicación. |
| 10SMR | [Maderas - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SM_MADERAS/10SMR-Maderas%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SMS | [Maderas - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10SM_MADERAS/10SMS-Maderas%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10SMW | [Maderas - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SM_MADERAS/10SMW-Maderas%20-%20Varios.md) | Revisar aplicación. |
| 10SNR | [Piedras naturales - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SN_PIEDRAS_NATURALES/10SNR-Piedras%20naturales%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SNS | [Piedras naturales - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10SN_PIEDRAS_NATURALES/10SNS-Piedras%20naturales%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10SNW | [Piedras naturales - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SN_PIEDRAS_NATURALES/10SNW-Piedras%20naturales%20-%20Varios.md) | Revisar aplicación. |
| 10SSR | [Soleras - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10SS_SOLERAS/10SSR-Soleras%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10SSS | [Soleras - Soleras](10_REVESTIMIENTOS/10S_SUELOS/10SS_SOLERAS/10SSS-Soleras%20-%20Soleras.md) | Revisar aplicación. |
| 10SSW | [Soleras - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SS_SOLERAS/10SSW-Soleras%20-%20Varios.md) | Revisar aplicación. |
| 10STR | [Terrazos - Rodapiés](10_REVESTIMIENTOS/10S_SUELOS/10ST_TERRAZOS/10STR-Terrazos%20-%20Rodapi%C3%A9s.md) | Revisar aplicación. |
| 10STS | [Terrazos - Solerías](10_REVESTIMIENTOS/10S_SUELOS/10ST_TERRAZOS/10STS-Terrazos%20-%20Soler%C3%ADas.md) | Revisar aplicación. |
| 10STW | [Terrazos - Varios](10_REVESTIMIENTOS/10S_SUELOS/10ST_TERRAZOS/10STW-Terrazos%20-%20Varios.md) | Revisar aplicación. |
| 10SWW | [Varios - Varios](10_REVESTIMIENTOS/10S_SUELOS/10SW_VARIOS/10SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10TER | [Escayolas - Remates](10_REVESTIMIENTOS/10T_TECHOS/10TE_ESCAYOLAS/10TER-Escayolas%20-%20Remates.md) | Revisar aplicación. |
| 10TET | [Escayolas - Techos](10_REVESTIMIENTOS/10T_TECHOS/10TE_ESCAYOLAS/10TET-Escayolas%20-%20Techos.md) | Revisar aplicación. |
| 10TEW | [Escayolas - Varios](10_REVESTIMIENTOS/10T_TECHOS/10TE_ESCAYOLAS/10TEW-Escayolas%20-%20Varios.md) | Revisar aplicación. |
| 10TFR | [Fibras - Remates](10_REVESTIMIENTOS/10T_TECHOS/10TF_FIBRAS/10TFR-Fibras%20-%20Remates.md) | Revisar aplicación. |
| 10TFT | [Fibras - Techos](10_REVESTIMIENTOS/10T_TECHOS/10TF_FIBRAS/10TFT-Fibras%20-%20Techos.md) | Revisar aplicación. |
| 10TFW | [Fibras - Varios](10_REVESTIMIENTOS/10T_TECHOS/10TF_FIBRAS/10TFW-Fibras%20-%20Varios.md) | Revisar aplicación. |
| 10TLR | [Aleaciones ligeras - Remates](10_REVESTIMIENTOS/10T_TECHOS/10TL_ALEACIONES_LIGERAS/10TLR-Aleaciones%20ligeras%20-%20Remates.md) | Revisar aplicación. |
| 10TLT | [Aleaciones ligeras - Techos](10_REVESTIMIENTOS/10T_TECHOS/10TL_ALEACIONES_LIGERAS/10TLT-Aleaciones%20ligeras%20-%20Techos.md) | Revisar aplicación. |
| 10TLW | [Aleaciones ligeras - Varios](10_REVESTIMIENTOS/10T_TECHOS/10TL_ALEACIONES_LIGERAS/10TLW-Aleaciones%20ligeras%20-%20Varios.md) | Revisar aplicación. |
| 10TMR | [Maderas - Remates](10_REVESTIMIENTOS/10T_TECHOS/10TM_MADERAS/10TMR-Maderas%20-%20Remates.md) | Revisar aplicación. |
| 10TMT | [Maderas - Techos](10_REVESTIMIENTOS/10T_TECHOS/10TM_MADERAS/10TMT-Maderas%20-%20Techos.md) | Revisar aplicación. |
| 10TMW | [Maderas - Varios](10_REVESTIMIENTOS/10T_TECHOS/10TM_MADERAS/10TMW-Maderas%20-%20Varios.md) | Revisar aplicación. |
| 10TSR | [Sintéticos - Remates](10_REVESTIMIENTOS/10T_TECHOS/10TS_SINT%C3%89TICOS/10TSR-Sint%C3%A9ticos%20-%20Remates.md) | Revisar aplicación. |
| 10TST | [Sintéticos - Techos](10_REVESTIMIENTOS/10T_TECHOS/10TS_SINT%C3%89TICOS/10TST-Sint%C3%A9ticos%20-%20Techos.md) | Revisar aplicación. |
| 10TSW | [Sintéticos - Varios](10_REVESTIMIENTOS/10T_TECHOS/10TS_SINT%C3%89TICOS/10TSW-Sint%C3%A9ticos%20-%20Varios.md) | Revisar aplicación. |
| 10TWW | [Varios - Varios](10_REVESTIMIENTOS/10T_TECHOS/10TW_VARIOS/10TWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 10WAA | [Alféizares - Piedras artificiales](10_REVESTIMIENTOS/10W_VARIOS/10WA_ALF%C3%89IZARES/10WAA-Alf%C3%A9izares%20-%20Piedras%20artificiales.md) | Revisar aplicación. |
| 10WAC | [Alféizares - Cerámicos](10_REVESTIMIENTOS/10W_VARIOS/10WA_ALF%C3%89IZARES/10WAC-Alf%C3%A9izares%20-%20Cer%C3%A1micos.md) | Revisar aplicación. |
| 10WAN | [Alféizares - Piedras naturales](10_REVESTIMIENTOS/10W_VARIOS/10WA_ALF%C3%89IZARES/10WAN-Alf%C3%A9izares%20-%20Piedras%20naturales.md) | Revisar aplicación. |
| 10WAW | [Alféizares - Varios](10_REVESTIMIENTOS/10W_VARIOS/10WA_ALF%C3%89IZARES/10WAW-Alf%C3%A9izares%20-%20Varios.md) | Revisar aplicación. |
| 10WRA | [Remates - Piedras artificiales](10_REVESTIMIENTOS/10W_VARIOS/10WR_REMATES/10WRA-Remates%20-%20Piedras%20artificiales.md) | Revisar aplicación. |
| 10WRC | [Remates - Cerámicos](10_REVESTIMIENTOS/10W_VARIOS/10WR_REMATES/10WRC-Remates%20-%20Cer%C3%A1micos.md) | Revisar aplicación. |
| 10WRN | [Remates - Piedras naturales](10_REVESTIMIENTOS/10W_VARIOS/10WR_REMATES/10WRN-Remates%20-%20Piedras%20naturales.md) | Revisar aplicación. |
| 10WRW | [Remates - Varios](10_REVESTIMIENTOS/10W_VARIOS/10WR_REMATES/10WRW-Remates%20-%20Varios.md) | Revisar aplicación. |
| 10WWW | [Varios - Varios](10_REVESTIMIENTOS/10W_VARIOS/10WW_VARIOS/10WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 11AMA | [Mamparas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AM_MAMPARAS/11AMA-Mamparas%20-%20Abatibles.md) | Revisar aplicación. |
| 11AMC | [Mamparas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AM_MAMPARAS/11AMC-Mamparas%20-%20Correderas.md) | Revisar aplicación. |
| 11AMF | [Mamparas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AM_MAMPARAS/11AMF-Mamparas%20-%20Fijas.md) | Revisar aplicación. |
| 11AMP | [Mamparas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AM_MAMPARAS/11AMP-Mamparas%20-%20Plegables.md) | Revisar aplicación. |
| 11AMW | [Mamparas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AM_MAMPARAS/11AMW-Mamparas%20-%20Varios.md) | Revisar aplicación. |
| 11APA | [Puertas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AP_PUERTAS/11APA-Puertas%20-%20Abatibles.md) | Revisar aplicación. |
| 11APC | [Puertas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AP_PUERTAS/11APC-Puertas%20-%20Correderas.md) | Revisar aplicación. |
| 11APP | [Puertas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AP_PUERTAS/11APP-Puertas%20-%20Plegables.md) | Revisar aplicación. |
| 11APR | [Puertas - Arrollables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AP_PUERTAS/11APR-Puertas%20-%20Arrollables.md) | Revisar aplicación. |
| 11APW | [Puertas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AP_PUERTAS/11APW-Puertas%20-%20Varios.md) | Revisar aplicación. |
| 11AVA | [Ventanas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AV_VENTANAS/11AVA-Ventanas%20-%20Abatibles.md) | Revisar aplicación. |
| 11AVC | [Ventanas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AV_VENTANAS/11AVC-Ventanas%20-%20Correderas.md) | Revisar aplicación. |
| 11AVF | [Ventanas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AV_VENTANAS/11AVF-Ventanas%20-%20Fijas.md) | Revisar aplicación. |
| 11AVW | [Ventanas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AV_VENTANAS/11AVW-Ventanas%20-%20Varios.md) | Revisar aplicación. |
| 11AWW | [Varios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AW_VARIOS/11AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 11LAA | [Armarios - Corredera](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LA_ARMARIOS/11LAA-Armarios%20-%20Corredera.md) | Revisar aplicación. |
| 11LAV | [Armarios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LA_ARMARIOS/11LAV-Armarios%20-%20Varios.md) | Revisar aplicación. |
| 11LMA | [Mamparas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LM_MAMPARAS/11LMA-Mamparas%20-%20Abatibles.md) | Revisar aplicación. |
| 11LMC | [Mamparas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LM_MAMPARAS/11LMC-Mamparas%20-%20Correderas.md) | Revisar aplicación. |
| 11LMF | [Mamparas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LM_MAMPARAS/11LMF-Mamparas%20-%20Fijas.md) | Revisar aplicación. |
| 11LMP | [Mamparas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LM_MAMPARAS/11LMP-Mamparas%20-%20Plegables.md) | Revisar aplicación. |
| 11LMW | [Mamparas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LM_MAMPARAS/11LMW-Mamparas%20-%20Varios.md) | Revisar aplicación. |
| 11LPA | [Puertas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LP_PUERTAS/11LPA-Puertas%20-%20Abatibles.md) | Revisar aplicación. |
| 11LPC | [Puertas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LP_PUERTAS/11LPC-Puertas%20-%20Correderas.md) | Revisar aplicación. |
| 11LPP | [Puertas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LP_PUERTAS/11LPP-Puertas%20-%20Plegables.md) | Revisar aplicación. |
| 11LPW | [Puertas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LP_PUERTAS/11LPW-Puertas%20-%20Varios.md) | Revisar aplicación. |
| 11LVA | [Ventanas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LV_VENTANAS/11LVA-Ventanas%20-%20Abatibles.md) | Revisar aplicación. |
| 11LVC | [Ventanas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LV_VENTANAS/11LVC-Ventanas%20-%20Correderas.md) | Revisar aplicación. |
| 11LVF | [Ventanas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LV_VENTANAS/11LVF-Ventanas%20-%20Fijas.md) | Revisar aplicación. |
| 11LVW | [Ventanas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LV_VENTANAS/11LVW-Ventanas%20-%20Varios.md) | Revisar aplicación. |
| 11LWW | [Varios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LW_VARIOS/11LWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 11MAB | [Armarios - Barnizar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MA_ARMARIOS/11MAB-Armarios%20-%20Barnizar.md) | Revisar aplicación. |
| 11MAP | [Armarios - Pintar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MA_ARMARIOS/11MAP-Armarios%20-%20Pintar.md) | Revisar aplicación. |
| 11MAW | [Armarios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MA_ARMARIOS/11MAW-Armarios%20-%20Varios.md) | Revisar aplicación. |
| 11MMB | [Mamparas - Barnizar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MM_MAMPARAS/11MMB-Mamparas%20-%20Barnizar.md) | Revisar aplicación. |
| 11MMP | [Mamparas - Pintar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MM_MAMPARAS/11MMP-Mamparas%20-%20Pintar.md) | Revisar aplicación. |
| 11MMW | [Mamparas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MM_MAMPARAS/11MMW-Mamparas%20-%20Varios.md) | Revisar aplicación. |
| 11MPB | [Puertas - Barnizar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MP_PUERTAS/11MPB-Puertas%20-%20Barnizar.md) | Revisar aplicación. |
| 11MPP | [Puertas - Pintar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MP_PUERTAS/11MPP-Puertas%20-%20Pintar.md) | Revisar aplicación. |
| 11MPW | [Puertas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MP_PUERTAS/11MPW-Puertas%20-%20Varios.md) | Revisar aplicación. |
| 11MVB | [Ventanas - Barnizar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MV_VENTANAS/11MVB-Ventanas%20-%20Barnizar.md) | Revisar aplicación. |
| 11MVP | [Ventanas - Pintar](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MV_VENTANAS/11MVP-Ventanas%20-%20Pintar.md) | Revisar aplicación. |
| 11MVW | [Ventanas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MV_VENTANAS/11MVW-Ventanas%20-%20Varios.md) | Revisar aplicación. |
| 11MWW | [Varios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MW_VARIOS/11MWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 11PMA | [Mamparas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PM_MAMPARAS/11PMA-Mamparas%20-%20Abatibles.md) | Revisar aplicación. |
| 11PMC | [Mamparas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PM_MAMPARAS/11PMC-Mamparas%20-%20Correderas.md) | Revisar aplicación. |
| 11PMF | [Mamparas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PM_MAMPARAS/11PMF-Mamparas%20-%20Fijas.md) | Revisar aplicación. |
| 11PMP | [Mamparas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PM_MAMPARAS/11PMP-Mamparas%20-%20Plegables.md) | Revisar aplicación. |
| 11PMW | [Mamparas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PM_MAMPARAS/11PMW-Mamparas%20-%20Varios.md) | Revisar aplicación. |
| 11PPA | [Puertas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PP_PUERTAS/11PPA-Puertas%20-%20Abatibles.md) | Revisar aplicación. |
| 11PPC | [Puertas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PP_PUERTAS/11PPC-Puertas%20-%20Correderas.md) | Revisar aplicación. |
| 11PPF | [Puertas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PP_PUERTAS/11PPF-Puertas%20-%20Fijas.md) | Revisar aplicación. |
| 11PPP | [Puertas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PP_PUERTAS/11PPP-Puertas%20-%20Plegables.md) | Revisar aplicación. |
| 11PPW | [Puertas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PP_PUERTAS/11PPW-Puertas%20-%20Varios.md) | Revisar aplicación. |
| 11PVA | [Ventanas - Abatibles](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PV_VENTANAS/11PVA-Ventanas%20-%20Abatibles.md) | Revisar aplicación. |
| 11PVC | [Ventanas - Correderas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PV_VENTANAS/11PVC-Ventanas%20-%20Correderas.md) | Revisar aplicación. |
| 11PVF | [Ventanas - Fijas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PV_VENTANAS/11PVF-Ventanas%20-%20Fijas.md) | Revisar aplicación. |
| 11PVP | [Ventanas - Plegables](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PV_VENTANAS/11PVP-Ventanas%20-%20Plegables.md) | Revisar aplicación. |
| 11PVW | [Ventanas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PV_VENTANAS/11PVW-Ventanas%20-%20Varios.md) | Revisar aplicación. |
| 11PWW | [Varios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PW_VARIOS/11PWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 11SBA | [Barandillas - Acero](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SB_BARANDILLAS/11SBA-Barandillas%20-%20Acero.md) | Revisar aplicación. |
| 11SBL | [Barandillas - Aluminio](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SB_BARANDILLAS/11SBL-Barandillas%20-%20Aluminio.md) | Revisar aplicación. |
| 11SBW | [Barandillas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SB_BARANDILLAS/11SBW-Barandillas%20-%20Varios.md) | Revisar aplicación. |
| 11SCA | [Celosías - Acero](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SC_CELOS%C3%8DAS/11SCA-Celos%C3%ADas%20-%20Acero.md) | Revisar aplicación. |
| 11SCL | [Celosías - Aluminio](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SC_CELOS%C3%8DAS/11SCL-Celos%C3%ADas%20-%20Aluminio.md) | Revisar aplicación. |
| 11SCM | [Celosías - Madera](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SC_CELOS%C3%8DAS/11SCM-Celos%C3%ADas%20-%20Madera.md) | Revisar aplicación. |
| 11SCP | [Celosías - P.V.C](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SC_CELOS%C3%8DAS/11SCP-Celos%C3%ADas%20-%20P.V.C.md) | Revisar aplicación. |
| 11SCW | [Celosías - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SC_CELOS%C3%8DAS/11SCW-Celos%C3%ADas%20-%20Varios.md) | Revisar aplicación. |
| 11SEA | [Escaleras - Acero](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SE_ESCALERAS/11SEA-Escaleras%20-%20Acero.md) | Revisar aplicación. |
| 11SEV | [Escaleras - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SE_ESCALERAS/11SEV-Escaleras%20-%20Varios.md) | Revisar aplicación. |
| 11SGG | [Cerramiento acero galvanizado - Cerramiento acero galvanizado](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SG_CERRAMIENTO_ACERO_GALVANIZADO/11SGG-Cerramiento%20acero%20galvanizado%20-%20Cerramiento%20acero%20galvanizado.md) | Revisar aplicación. |
| 11SPA | [Persianas - Acero](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SP_PERSIANAS/11SPA-Persianas%20-%20Acero.md) | Revisar aplicación. |
| 11SPL | [Persianas - Aluminio](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SP_PERSIANAS/11SPL-Persianas%20-%20Aluminio.md) | Revisar aplicación. |
| 11SPM | [Persianas - Madera](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SP_PERSIANAS/11SPM-Persianas%20-%20Madera.md) | Revisar aplicación. |
| 11SPP | [Persianas - P.V.C](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SP_PERSIANAS/11SPP-Persianas%20-%20P.V.C.md) | Revisar aplicación. |
| 11SPW | [Persianas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SP_PERSIANAS/11SPW-Persianas%20-%20Varios.md) | Revisar aplicación. |
| 11SRH | [Rejas - Perfiles huecos](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SR_REJAS/11SRH-Rejas%20-%20Perfiles%20huecos.md) | Revisar aplicación. |
| 11SRM | [Rejas - Perfiles macizos](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SR_REJAS/11SRM-Rejas%20-%20Perfiles%20macizos.md) | Revisar aplicación. |
| 11SRW | [Rejas - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SR_REJAS/11SRW-Rejas%20-%20Varios.md) | Revisar aplicación. |
| 11SWW | [Varios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SW_VARIOS/11SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 11WWW | [Varios - Varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11W_VARIOS/11WW_VARIOS/11WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 12ACA | [Vidrios compuestos - Acústicos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACA-Vidrios%20compuestos%20-%20Ac%C3%BAsticos.md) | Revisar aplicación. |
| 12ACB | [Vidrios compuestos - Baja emisividad](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACB-Vidrios%20compuestos%20-%20Baja%20emisividad.md) | Revisar aplicación. |
| 12ACC | [Vidrios compuestos - Control Solar](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACC-Vidrios%20compuestos%20-%20Control%20Solar.md) | Revisar aplicación. |
| 12ACK | [Vidrios compuestos - Acústicos y eficiencia energética](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACK-Vidrios%20compuestos%20-%20Ac%C3%BAsticos%20y%20eficiencia%20energ%C3%A9tica.md) | Revisar aplicación. |
| 12ACN | [Vidrios compuestos - Normales](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACN-Vidrios%20compuestos%20-%20Normales.md) | Revisar aplicación. |
| 12ACP | [Vidrios compuestos - Impresos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACP-Vidrios%20compuestos%20-%20Impresos.md) | Revisar aplicación. |
| 12ACT | [Vidrios compuestos - Térmicos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACT-Vidrios%20compuestos%20-%20T%C3%A9rmicos.md) | Revisar aplicación. |
| 12ACW | [Vidrios compuestos - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/12ACW-Vidrios%20compuestos%20-%20Varios.md) | Revisar aplicación. |
| 12ASB | [Vidrios simples - Baja emisividad](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12ASB-Vidrios%20simples%20-%20Baja%20emisividad.md) | Revisar aplicación. |
| 12ASC | [Vidrios simples - Control solar](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12ASC-Vidrios%20simples%20-%20Control%20solar.md) | Revisar aplicación. |
| 12ASD | [Vidrios simples - Control solar y baja emisividad](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12ASD-Vidrios%20simples%20-%20Control%20solar%20y%20baja%20emisividad.md) | Revisar aplicación. |
| 12ASN | [Vidrios simples - Normales](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12ASN-Vidrios%20simples%20-%20Normales.md) | Revisar aplicación. |
| 12ASP | [Vidrios simples - Impresos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12ASP-Vidrios%20simples%20-%20Impresos.md) | Revisar aplicación. |
| 12AST | [Vidrios simples - Templados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12AST-Vidrios%20simples%20-%20Templados.md) | Revisar aplicación. |
| 12ASW | [Vidrios simples - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/12ASW-Vidrios%20simples%20-%20Varios.md) | Revisar aplicación. |
| 12AWW | [Varios - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AW_VARIOS/12AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 12LAC | [Acústicos y Térmicos - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LA_AC%C3%9ASTICOS_Y_T%C3%89RMICOS/12LAC-Ac%C3%BAsticos%20y%20T%C3%A9rmicos%20-%20Coloreados.md) | Revisar aplicación. |
| 12LAI | [Acústicos y Térmicos - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LA_AC%C3%9ASTICOS_Y_T%C3%89RMICOS/12LAI-Ac%C3%BAsticos%20y%20T%C3%A9rmicos%20-%20Incoloros.md) | Revisar aplicación. |
| 12LAW | [Acústicos y Térmicos - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LA_AC%C3%9ASTICOS_Y_T%C3%89RMICOS/12LAW-Ac%C3%BAsticos%20y%20T%C3%A9rmicos%20-%20Varios.md) | Revisar aplicación. |
| 12LSB | [Seguridad - Antibala](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LS_SEGURIDAD/12LSB-Seguridad%20-%20Antibala.md) | Revisar aplicación. |
| 12LSM | [Seguridad - Antimotín](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LS_SEGURIDAD/12LSM-Seguridad%20-%20Antimot%C3%ADn.md) | Revisar aplicación. |
| 12LSR | [Seguridad - Antirobo](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LS_SEGURIDAD/12LSR-Seguridad%20-%20Antirobo.md) | Revisar aplicación. |
| 12LSS | [Seguridad - Simple](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LS_SEGURIDAD/12LSS-Seguridad%20-%20Simple.md) | Revisar aplicación. |
| 12LSW | [Seguridad - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LS_SEGURIDAD/12LSW-Seguridad%20-%20Varios.md) | Revisar aplicación. |
| 12LWW | [Varios - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LW_VARIOS/12LWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 12NAC | [Armados - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NA_ARMADOS/12NAC-Armados%20-%20Coloreados.md) | Revisar aplicación. |
| 12NAI | [Armados - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NA_ARMADOS/12NAI-Armados%20-%20Incoloros.md) | Revisar aplicación. |
| 12NAW | [Armados - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NA_ARMADOS/12NAW-Armados%20-%20Varios.md) | Revisar aplicación. |
| 12NFC | [Protección al fuego - Cortafuegos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NF_PROTECCI%C3%93N_AL_FUEGO/12NFC-Protecci%C3%B3n%20al%20fuego%20-%20Cortafuegos.md) | Revisar aplicación. |
| 12NFD | [Protección al fuego - Parallamas](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NF_PROTECCI%C3%93N_AL_FUEGO/12NFD-Protecci%C3%B3n%20al%20fuego%20-%20Parallamas.md) | Revisar aplicación. |
| 12NFW | [Protección al fuego - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NF_PROTECCI%C3%93N_AL_FUEGO/12NFW-Protecci%C3%B3n%20al%20fuego%20-%20Varios.md) | Revisar aplicación. |
| 12NMA | [Mateados - Al ácido](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NM_MATEADOS/12NMA-Mateados%20-%20Al%20%C3%A1cido.md) | Revisar aplicación. |
| 12NMW | [Mateados - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NM_MATEADOS/12NMW-Mateados%20-%20Varios.md) | Revisar aplicación. |
| 12NNC | [Normales - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NN_NORMALES/12NNC-Normales%20-%20Coloreados.md) | Revisar aplicación. |
| 12NNI | [Normales - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NN_NORMALES/12NNI-Normales%20-%20Incoloros.md) | Revisar aplicación. |
| 12NNW | [Normales - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NN_NORMALES/12NNW-Normales%20-%20Varios.md) | Revisar aplicación. |
| 12NPC | [Impresos - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NP_IMPRESOS/12NPC-Impresos%20-%20Coloreados.md) | Revisar aplicación. |
| 12NPI | [Impresos - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NP_IMPRESOS/12NPI-Impresos%20-%20Incoloros.md) | Revisar aplicación. |
| 12NPW | [Impresos - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NP_IMPRESOS/12NPW-Impresos%20-%20Varios.md) | Revisar aplicación. |
| 12NRC | [Reflectantes - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NR_REFLECTANTES/12NRC-Reflectantes%20-%20Coloreados.md) | Revisar aplicación. |
| 12NRI | [Reflectantes - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NR_REFLECTANTES/12NRI-Reflectantes%20-%20Incoloros.md) | Revisar aplicación. |
| 12NRW | [Reflectantes - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NR_REFLECTANTES/12NRW-Reflectantes%20-%20Varios.md) | Revisar aplicación. |
| 12NTC | [Templados - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NT_TEMPLADOS/12NTC-Templados%20-%20Coloreados.md) | Revisar aplicación. |
| 12NTI | [Templados - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NT_TEMPLADOS/12NTI-Templados%20-%20Incoloros.md) | Revisar aplicación. |
| 12NTW | [Templados - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NT_TEMPLADOS/12NTW-Templados%20-%20Varios.md) | Revisar aplicación. |
| 12NWW | [Varios - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NW_VARIOS/12NWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 12SMC | [Metacrilatos - Celulares](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SM_METACRILATOS/12SMC-Metacrilatos%20-%20Celulares.md) | Revisar aplicación. |
| 12SMT | [Metacrilatos - Compactos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SM_METACRILATOS/12SMT-Metacrilatos%20-%20Compactos.md) | Revisar aplicación. |
| 12SMW | [Metacrilatos - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SM_METACRILATOS/12SMW-Metacrilatos%20-%20Varios.md) | Revisar aplicación. |
| 12SPC | [Policarbonatos - Celulares](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SP_POLICARBONATOS/12SPC-Policarbonatos%20-%20Celulares.md) | Revisar aplicación. |
| 12SPT | [Policarbonatos - Compactos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SP_POLICARBONATOS/12SPT-Policarbonatos%20-%20Compactos.md) | Revisar aplicación. |
| 12SPW | [Policarbonatos - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SP_POLICARBONATOS/12SPW-Policarbonatos%20-%20Varios.md) | Revisar aplicación. |
| 12SWW | [Varios - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SW_VARIOS/12SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 12WAA | [Autolimpiantes - Vidrio aislante](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WA_AUTOLIMPIANTES/12WAA-Autolimpiantes%20-%20Vidrio%20aislante.md) | Revisar aplicación. |
| 12WAE | [Autolimpiantes - Eficiencia energética](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WA_AUTOLIMPIANTES/12WAE-Autolimpiantes%20-%20Eficiencia%20energ%C3%A9tica.md) | Revisar aplicación. |
| 12WAS | [Autolimpiantes - Seguiridad](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WA_AUTOLIMPIANTES/12WAS-Autolimpiantes%20-%20Seguiridad.md) | Revisar aplicación. |
| 12WAT | [Autolimpiantes - Templados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WA_AUTOLIMPIANTES/12WAT-Autolimpiantes%20-%20Templados.md) | Revisar aplicación. |
| 12WAW | [Autolimpiantes - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WA_AUTOLIMPIANTES/12WAW-Autolimpiantes%20-%20Varios.md) | Revisar aplicación. |
| 12WCA | [Conformados - Angulados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WC_CONFORMADOS/12WCA-Conformados%20-%20Angulados.md) | Revisar aplicación. |
| 12WCC | [Conformados - Curvados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WC_CONFORMADOS/12WCC-Conformados%20-%20Curvados.md) | Revisar aplicación. |
| 12WCW | [Conformados - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WC_CONFORMADOS/12WCW-Conformados%20-%20Varios.md) | Revisar aplicación. |
| 12WKK | [Muros cortina - Muros cortina](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WK_MUROS_CORTINA/12WKK-Muros%20cortina%20-%20Muros%20cortina.md) | Revisar aplicación. |
| 12WKW | [Muros cortina - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WK_MUROS_CORTINA/12WKW-Muros%20cortina%20-%20Varios.md) | Revisar aplicación. |
| 12WMC | [Moldeados - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WM_MOLDEADOS/12WMC-Moldeados%20-%20Coloreados.md) | Revisar aplicación. |
| 12WMI | [Moldeados - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WM_MOLDEADOS/12WMI-Moldeados%20-%20Incoloros.md) | Revisar aplicación. |
| 12WMW | [Moldeados - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WM_MOLDEADOS/12WMW-Moldeados%20-%20Varios.md) | Revisar aplicación. |
| 12WSC | [Espejos - Coloreados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WS_ESPEJOS/12WSC-Espejos%20-%20Coloreados.md) | Revisar aplicación. |
| 12WSI | [Espejos - Incoloros](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WS_ESPEJOS/12WSI-Espejos%20-%20Incoloros.md) | Revisar aplicación. |
| 12WSW | [Espejos - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WS_ESPEJOS/12WSW-Espejos%20-%20Varios.md) | Revisar aplicación. |
| 12WWW | [Varios - Varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WW_VARIOS/12WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 13EAA | [Acrílicas - Acrílicas](13_PINTURAS/13E_EXTERIORES/13EA_ACR%C3%8DLICAS/13EAA-Acr%C3%ADlicas%20-%20Acr%C3%ADlicas.md) | Revisar aplicación. |
| 13EAW | [Acrílicas - Varios](13_PINTURAS/13E_EXTERIORES/13EA_ACR%C3%8DLICAS/13EAW-Acr%C3%ADlicas%20-%20Varios.md) | Revisar aplicación. |
| 13EBB | [Barniz - Barníz](13_PINTURAS/13E_EXTERIORES/13EB_BARNIZ/13EBB-Barniz%20-%20Barn%C3%ADz.md) | Revisar aplicación. |
| 13EBW | [Barniz - Varios](13_PINTURAS/13E_EXTERIORES/13EB_BARNIZ/13EBW-Barniz%20-%20Varios.md) | Revisar aplicación. |
| 13ECC | [Cal - Cal](13_PINTURAS/13E_EXTERIORES/13EC_CAL/13ECC-Cal%20-%20Cal.md) | Revisar aplicación. |
| 13ECW | [Cal - Varios](13_PINTURAS/13E_EXTERIORES/13EC_CAL/13ECW-Cal%20-%20Varios.md) | Revisar aplicación. |
| 13EEE | [Esmalte - Esmalte](13_PINTURAS/13E_EXTERIORES/13EE_ESMALTE/13EEE-Esmalte%20-%20Esmalte.md) | Revisar aplicación. |
| 13EEW | [Esmalte - Varios](13_PINTURAS/13E_EXTERIORES/13EE_ESMALTE/13EEW-Esmalte%20-%20Varios.md) | Revisar aplicación. |
| 13EOO | [Óleo - Óleo](13_PINTURAS/13E_EXTERIORES/13EO_%C3%93LEO/13EOO-%C3%93leo%20-%20%C3%93leo.md) | Revisar aplicación. |
| 13EOW | [Óleo - Varios](13_PINTURAS/13E_EXTERIORES/13EO_%C3%93LEO/13EOW-%C3%93leo%20-%20Varios.md) | Revisar aplicación. |
| 13EPP | [Pétreas - Pétreas](13_PINTURAS/13E_EXTERIORES/13EP_P%C3%89TREAS/13EPP-P%C3%A9treas%20-%20P%C3%A9treas.md) | Revisar aplicación. |
| 13EPW | [Pétreas - Varios](13_PINTURAS/13E_EXTERIORES/13EP_P%C3%89TREAS/13EPW-P%C3%A9treas%20-%20Varios.md) | Revisar aplicación. |
| 13ESS | [Silicato - Silicato](13_PINTURAS/13E_EXTERIORES/13ES_SILICATO/13ESS-Silicato%20-%20Silicato.md) | Revisar aplicación. |
| 13ESW | [Silicato - Varios](13_PINTURAS/13E_EXTERIORES/13ES_SILICATO/13ESW-Silicato%20-%20Varios.md) | Revisar aplicación. |
| 13EWW | [Varios - Varios](13_PINTURAS/13E_EXTERIORES/13EW_VARIOS/13EWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 13IBB | [Barniz - Barniz](13_PINTURAS/13I_INTERIORES/13IB_BARNIZ/13IBB-Barniz%20-%20Barniz.md) | Revisar aplicación. |
| 13IBW | [Barniz - Varios](13_PINTURAS/13I_INTERIORES/13IB_BARNIZ/13IBW-Barniz%20-%20Varios.md) | Revisar aplicación. |
| 13IEE | [Esmalte - Esmalte](13_PINTURAS/13I_INTERIORES/13IE_ESMALTE/13IEE-Esmalte%20-%20Esmalte.md) | Revisar aplicación. |
| 13IEW | [Esmalte - Varios](13_PINTURAS/13I_INTERIORES/13IE_ESMALTE/13IEW-Esmalte%20-%20Varios.md) | Revisar aplicación. |
| 13ILL | [Lacas - Lacas](13_PINTURAS/13I_INTERIORES/13IL_LACAS/13ILL-Lacas%20-%20Lacas.md) | Revisar aplicación. |
| 13ILW | [Lacas - Varios](13_PINTURAS/13I_INTERIORES/13IL_LACAS/13ILW-Lacas%20-%20Varios.md) | Revisar aplicación. |
| 13IOO | [Óleo - Óleo](13_PINTURAS/13I_INTERIORES/13IO_%C3%93LEO/13IOO-%C3%93leo%20-%20%C3%93leo.md) | Revisar aplicación. |
| 13IOW | [Óleo - Varios](13_PINTURAS/13I_INTERIORES/13IO_%C3%93LEO/13IOW-%C3%93leo%20-%20Varios.md) | Revisar aplicación. |
| 13IPP | [Plásticos - Plásticos](13_PINTURAS/13I_INTERIORES/13IP_PL%C3%81STICOS/13IPP-Pl%C3%A1sticos%20-%20Pl%C3%A1sticos.md) | Revisar aplicación. |
| 13IPW | [Plásticos - Varios](13_PINTURAS/13I_INTERIORES/13IP_PL%C3%81STICOS/13IPW-Pl%C3%A1sticos%20-%20Varios.md) | Revisar aplicación. |
| 13ITT | [Temple - Temple](13_PINTURAS/13I_INTERIORES/13IT_TEMPLE/13ITT-Temple%20-%20Temple.md) | Revisar aplicación. |
| 13ITW | [Temple - Varios](13_PINTURAS/13I_INTERIORES/13IT_TEMPLE/13ITW-Temple%20-%20Varios.md) | Revisar aplicación. |
| 13IWW | [Varios - Varios](13_PINTURAS/13I_INTERIORES/13IW_VARIOS/13IWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 13SAA | [Anticalóricas - Anticalóricas](13_PINTURAS/13S_ESPECIALES/13SA_ANTICAL%C3%93RICAS/13SAA-Antical%C3%B3ricas%20-%20Antical%C3%B3ricas.md) | Revisar aplicación. |
| 13SAW | [Anticalóricas - Varios](13_PINTURAS/13S_ESPECIALES/13SA_ANTICAL%C3%93RICAS/13SAW-Antical%C3%B3ricas%20-%20Varios.md) | Revisar aplicación. |
| 13SCC | [Clorocaucho - Clorocaucho](13_PINTURAS/13S_ESPECIALES/13SC_CLOROCAUCHO/13SCC-Clorocaucho%20-%20Clorocaucho.md) | Revisar aplicación. |
| 13SCW | [Clorocaucho - Varios](13_PINTURAS/13S_ESPECIALES/13SC_CLOROCAUCHO/13SCW-Clorocaucho%20-%20Varios.md) | Revisar aplicación. |
| 13SII | [Ignífugas - Ignífugas](13_PINTURAS/13S_ESPECIALES/13SI_IGN%C3%8DFUGAS/13SII-Ign%C3%ADfugas%20-%20Ign%C3%ADfugas.md) | Revisar aplicación. |
| 13SIW | [Ignífugas - Varios](13_PINTURAS/13S_ESPECIALES/13SI_IGN%C3%8DFUGAS/13SIW-Ign%C3%ADfugas%20-%20Varios.md) | Revisar aplicación. |
| 13SWW | [Varios - Varios](13_PINTURAS/13S_ESPECIALES/13SW_VARIOS/13SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 13WWW | [Varios - Varios](13_PINTURAS/13W_VARIOS/13WW_VARIOS/13WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 14MAA | [Aseos y baños - Aseos](14_EQUIPAMIENTO/14M_MOBILIARIO/14MA_ASEOS_Y_BA%C3%91OS/14MAA-Aseos%20y%20ba%C3%B1os%20-%20Aseos.md) | Revisar aplicación. |
| 14MAB | [Aseos y baños - Baños](14_EQUIPAMIENTO/14M_MOBILIARIO/14MA_ASEOS_Y_BA%C3%91OS/14MAB-Aseos%20y%20ba%C3%B1os%20-%20Ba%C3%B1os.md) | Revisar aplicación. |
| 14MAW | [Aseos y baños - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MA_ASEOS_Y_BA%C3%91OS/14MAW-Aseos%20y%20ba%C3%B1os%20-%20Varios.md) | Revisar aplicación. |
| 14MCC | [Cocinas - Cocinas](14_EQUIPAMIENTO/14M_MOBILIARIO/14MC_COCINAS/14MCC-Cocinas%20-%20Cocinas.md) | Revisar aplicación. |
| 14MCW | [Cocinas - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MC_COCINAS/14MCW-Cocinas%20-%20Varios.md) | Revisar aplicación. |
| 14MDD | [Dormitorios - Dormitorios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MD_DORMITORIOS/14MDD-Dormitorios%20-%20Dormitorios.md) | Revisar aplicación. |
| 14MDW | [Dormitorios - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MD_DORMITORIOS/14MDW-Dormitorios%20-%20Varios.md) | Revisar aplicación. |
| 14MEE | [Estanterías - Estanterías](14_EQUIPAMIENTO/14M_MOBILIARIO/14ME_ESTANTER%C3%8DAS/14MEE-Estanter%C3%ADas%20-%20Estanter%C3%ADas.md) | Revisar aplicación. |
| 14MEW | [Estanterías - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14ME_ESTANTER%C3%8DAS/14MEW-Estanter%C3%ADas%20-%20Varios.md) | Revisar aplicación. |
| 14MLL | [Lámparas - Lámparas](14_EQUIPAMIENTO/14M_MOBILIARIO/14ML_L%C3%81MPARAS/14MLL-L%C3%A1mparas%20-%20L%C3%A1mparas.md) | Revisar aplicación. |
| 14MLW | [Lámparas - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14ML_L%C3%81MPARAS/14MLW-L%C3%A1mparas%20-%20Varios.md) | Revisar aplicación. |
| 14MMM | [Mesas - Mesas](14_EQUIPAMIENTO/14M_MOBILIARIO/14MM_MESAS/14MMM-Mesas%20-%20Mesas.md) | Revisar aplicación. |
| 14MMW | [Mesas - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MM_MESAS/14MMW-Mesas%20-%20Varios.md) | Revisar aplicación. |
| 14MSS | [Sillas y sillones - Sillas y sillones](14_EQUIPAMIENTO/14M_MOBILIARIO/14MS_SILLAS_Y_SILLONES/14MSS-Sillas%20y%20sillones%20-%20Sillas%20y%20sillones.md) | Revisar aplicación. |
| 14MSW | [Sillas y sillones - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MS_SILLAS_Y_SILLONES/14MSW-Sillas%20y%20sillones%20-%20Varios.md) | Revisar aplicación. |
| 14MVV | [Vestuarios - Vestuarios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MV_VESTUARIOS/14MVV-Vestuarios%20-%20Vestuarios.md) | Revisar aplicación. |
| 14MVW | [Vestuarios - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MV_VESTUARIOS/14MVW-Vestuarios%20-%20Varios.md) | Revisar aplicación. |
| 14MWW | [Varios - Varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MW_VARIOS/14MWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 14WAA | [Elementos artísticos - Elementos artísticos](14_EQUIPAMIENTO/14W_VARIOS/14WA_ELEMENTOS_ART%C3%8DSTICOS/14WAA-Elementos%20art%C3%ADsticos%20-%20Elementos%20art%C3%ADsticos.md) | Revisar aplicación. |
| 14WAW | [Elementos artísticos - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WA_ELEMENTOS_ART%C3%8DSTICOS/14WAW-Elementos%20art%C3%ADsticos%20-%20Varios.md) | Revisar aplicación. |
| 14WBB | [Buzones - Buzones](14_EQUIPAMIENTO/14W_VARIOS/14WB_BUZONES/14WBB-Buzones%20-%20Buzones.md) | Revisar aplicación. |
| 14WBW | [Buzones - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WB_BUZONES/14WBW-Buzones%20-%20Varios.md) | Revisar aplicación. |
| 14WCC | [Cortinas - Cortinas](14_EQUIPAMIENTO/14W_VARIOS/14WC_CORTINAS/14WCC-Cortinas%20-%20Cortinas.md) | Revisar aplicación. |
| 14WCW | [Cortinas - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WC_CORTINAS/14WCW-Cortinas%20-%20Varios.md) | Revisar aplicación. |
| 14WEE | [Entelados y empapelados - Empapelados](14_EQUIPAMIENTO/14W_VARIOS/14WE_ENTELADOS_Y_EMPAPELADOS/14WEE-Entelados%20y%20empapelados%20-%20Empapelados.md) | Revisar aplicación. |
| 14WET | [Entelados y empapelados - Entelados](14_EQUIPAMIENTO/14W_VARIOS/14WE_ENTELADOS_Y_EMPAPELADOS/14WET-Entelados%20y%20empapelados%20-%20Entelados.md) | Revisar aplicación. |
| 14WEW | [Entelados y empapelados - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WE_ENTELADOS_Y_EMPAPELADOS/14WEW-Entelados%20y%20empapelados%20-%20Varios.md) | Revisar aplicación. |
| 14WJJ | [Jardineras - Jardineras](14_EQUIPAMIENTO/14W_VARIOS/14WJ_JARDINERAS/14WJJ-Jardineras%20-%20Jardineras.md) | Revisar aplicación. |
| 14WJW | [Jardineras - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WJ_JARDINERAS/14WJW-Jardineras%20-%20Varios.md) | Revisar aplicación. |
| 14WSS | [Señalizaciones - Señalizaciones](14_EQUIPAMIENTO/14W_VARIOS/14WS_SE%C3%91ALIZACIONES/14WSS-Se%C3%B1alizaciones%20-%20Se%C3%B1alizaciones.md) | Revisar aplicación. |
| 14WSW | [Señalizaciones - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WS_SE%C3%91ALIZACIONES/14WSW-Se%C3%B1alizaciones%20-%20Varios.md) | Revisar aplicación. |
| 14WWW | [Varios - Varios](14_EQUIPAMIENTO/14W_VARIOS/14WW_VARIOS/14WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15AAA | [Acometidas - Acometidas](15_URBANIZACIONES/15A_ALCANTARILLADO/15AA_ACOMETIDAS/15AAA-Acometidas%20-%20Acometidas.md) | Revisar aplicación. |
| 15AAW | [Acometidas - Varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AA_ACOMETIDAS/15AAW-Acometidas%20-%20Varios.md) | Revisar aplicación. |
| 15ACF | [Canalizaciones - Fibrocemento](15_URBANIZACIONES/15A_ALCANTARILLADO/15AC_CANALIZACIONES/15ACF-Canalizaciones%20-%20Fibrocemento.md) | Revisar aplicación. |
| 15ACH | [Canalizaciones - Hormigón](15_URBANIZACIONES/15A_ALCANTARILLADO/15AC_CANALIZACIONES/15ACH-Canalizaciones%20-%20Hormig%C3%B3n.md) | Revisar aplicación. |
| 15ACP | [Canalizaciones - P.V.C](15_URBANIZACIONES/15A_ALCANTARILLADO/15AC_CANALIZACIONES/15ACP-Canalizaciones%20-%20P.V.C.md) | Revisar aplicación. |
| 15ACW | [Canalizaciones - Varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AC_CANALIZACIONES/15ACW-Canalizaciones%20-%20Varios.md) | Revisar aplicación. |
| 15ADD | [Depuración y vertido - Depuración y vertido](15_URBANIZACIONES/15A_ALCANTARILLADO/15AD_DEPURACI%C3%93N_Y_VERTIDO/15ADD-Depuraci%C3%B3n%20y%20vertido%20-%20Depuraci%C3%B3n%20y%20vertido.md) | Revisar aplicación. |
| 15ADW | [Depuración y vertido - Varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AD_DEPURACI%C3%93N_Y_VERTIDO/15ADW-Depuraci%C3%B3n%20y%20vertido%20-%20Varios.md) | Revisar aplicación. |
| 15APA | [Pozos y arquetas - Arquetas](15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/15APA-Pozos%20y%20arquetas%20-%20Arquetas.md) | Revisar aplicación. |
| 15APP | [Pozos y arquetas - Pozos](15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/15APP-Pozos%20y%20arquetas%20-%20Pozos.md) | Revisar aplicación. |
| 15APW | [Pozos y arquetas - Varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/15APW-Pozos%20y%20arquetas%20-%20Varios.md) | Revisar aplicación. |
| 15ASS | [Sumideros - Sumideros](15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/15ASS-Sumideros%20-%20Sumideros.md) | Revisar aplicación. |
| 15ASW | [Sumideros - Varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/15ASW-Sumideros%20-%20Varios.md) | Revisar aplicación. |
| 15AWW | [Varios - Varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AW_VARIOS/15AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15CPP | [Pinturas - Pinturas](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CP_PINTURAS/15CPP-Pinturas%20-%20Pinturas.md) | Revisar aplicación. |
| 15CPW | [Pinturas - Varios](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CP_PINTURAS/15CPW-Pinturas%20-%20Varios.md) | Revisar aplicación. |
| 15CRP | [Rótulos y placas - Placas](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CR_R%C3%93TULOS_Y_PLACAS/15CRP-R%C3%B3tulos%20y%20placas%20-%20Placas.md) | Revisar aplicación. |
| 15CRR | [Rótulos y placas - Rótulos](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CR_R%C3%93TULOS_Y_PLACAS/15CRR-R%C3%B3tulos%20y%20placas%20-%20R%C3%B3tulos.md) | Revisar aplicación. |
| 15CRW | [Rótulos y placas - VArios](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CR_R%C3%93TULOS_Y_PLACAS/15CRW-R%C3%B3tulos%20y%20placas%20-%20VArios.md) | Revisar aplicación. |
| 15CSS | [Semáforos - Semáforos](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CS_SEM%C3%81FOROS/15CSS-Sem%C3%A1foros%20-%20Sem%C3%A1foros.md) | Revisar aplicación. |
| 15CSW | [Semáforos - Varios](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CS_SEM%C3%81FOROS/15CSW-Sem%C3%A1foros%20-%20Varios.md) | Revisar aplicación. |
| 15CWW | [Varios - Varios](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CW_VARIOS/15CWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15EAA | [Acometidas - Acometidas](15_URBANIZACIONES/15E_ELECTRICIDAD/15EA_ACOMETIDAS/15EAA-Acometidas%20-%20Acometidas.md) | Revisar aplicación. |
| 15EAW | [Acometidas - Varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15EA_ACOMETIDAS/15EAW-Acometidas%20-%20Varios.md) | Revisar aplicación. |
| 15EEE | [Redes enterradas - Redes enterradas](15_URBANIZACIONES/15E_ELECTRICIDAD/15EE_REDES_ENTERRADAS/15EEE-Redes%20enterradas%20-%20Redes%20enterradas.md) | Revisar aplicación. |
| 15EEW | [Redes enterradas - Varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15EE_REDES_ENTERRADAS/15EEW-Redes%20enterradas%20-%20Varios.md) | Revisar aplicación. |
| 15EPP | [Alumbrado público - Alumbrado público](15_URBANIZACIONES/15E_ELECTRICIDAD/15EP_ALUMBRADO_P%C3%9ABLICO/15EPP-Alumbrado%20p%C3%BAblico%20-%20Alumbrado%20p%C3%BAblico.md) | Revisar aplicación. |
| 15EPW | [Alumbrado público - Varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15EP_ALUMBRADO_P%C3%9ABLICO/15EPW-Alumbrado%20p%C3%BAblico%20-%20Varios.md) | Revisar aplicación. |
| 15ERR | [Redes aéreas - Redes aéreas](15_URBANIZACIONES/15E_ELECTRICIDAD/15ER_REDES_A%C3%89REAS/15ERR-Redes%20a%C3%A9reas%20-%20Redes%20a%C3%A9reas.md) | Revisar aplicación. |
| 15ERW | [Redes aéreas - Varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15ER_REDES_A%C3%89REAS/15ERW-Redes%20a%C3%A9reas%20-%20Varios.md) | Revisar aplicación. |
| 15ETT | [Transformadores - Transformadores](15_URBANIZACIONES/15E_ELECTRICIDAD/15ET_TRANSFORMADORES/15ETT-Transformadores%20-%20Transformadores.md) | Revisar aplicación. |
| 15ETW | [Transformadores - Varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15ET_TRANSFORMADORES/15ETW-Transformadores%20-%20Varios.md) | Revisar aplicación. |
| 15EWW | [Varios - Varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15EW_VARIOS/15EWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15GCC | [Gas ciudad - Gas natural](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GC_GAS_CIUDAD/15GCC-Gas%20ciudad%20-%20Gas%20natural.md) | Revisar aplicación. |
| 15GCW | [Gas ciudad - Varios](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GC_GAS_CIUDAD/15GCW-Gas%20ciudad%20-%20Varios.md) | Revisar aplicación. |
| 15GFF | [Fuel-oil - Fuel-oil](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GF_FUEL_OIL/15GFF-Fuel-oil%20-%20Fuel-oil.md) | Revisar aplicación. |
| 15GFW | [Fuel-oil - Varios](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GF_FUEL_OIL/15GFW-Fuel-oil%20-%20Varios.md) | Revisar aplicación. |
| 15GGG | [Gasóleo - Gasóleo](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GG_GAS%C3%93LEO/15GGG-Gas%C3%B3leo%20-%20Gas%C3%B3leo.md) | Revisar aplicación. |
| 15GGW | [Gasóleo - Varios](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GG_GAS%C3%93LEO/15GGW-Gas%C3%B3leo%20-%20Varios.md) | Revisar aplicación. |
| 15GPP | [Propano - Propano](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GP_PROPANO/15GPP-Propano%20-%20Propano.md) | Revisar aplicación. |
| 15GPW | [Propano - Varios](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GP_PROPANO/15GPW-Propano%20-%20Varios.md) | Revisar aplicación. |
| 15GWW | [Varios - Varios](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GW_VARIOS/15GWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15JAA | [Arboles - Arboles](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JA_ARBOLES/15JAA-Arboles%20-%20Arboles.md) | Revisar aplicación. |
| 15JAW | [Arboles - Varios](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JA_ARBOLES/15JAW-Arboles%20-%20Varios.md) | Revisar aplicación. |
| 15JPP | [Plantas de jardín - Plantas de jardín](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JP_PLANTAS_DE_JARD%C3%8DN/15JPP-Plantas%20de%20jard%C3%ADn%20-%20Plantas%20de%20jard%C3%ADn.md) | Revisar aplicación. |
| 15JPW | [Plantas de jardín - Varios](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JP_PLANTAS_DE_JARD%C3%8DN/15JPW-Plantas%20de%20jard%C3%ADn%20-%20Varios.md) | Revisar aplicación. |
| 15JSS | [Setos - Setos](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JS_SETOS/15JSS-Setos%20-%20Setos.md) | Revisar aplicación. |
| 15JSW | [Setos - Varios](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JS_SETOS/15JSW-Setos%20-%20Varios.md) | Revisar aplicación. |
| 15JTT | [Tapizantes - Tapizantes](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JT_TAPIZANTES/15JTT-Tapizantes%20-%20Tapizantes.md) | Revisar aplicación. |
| 15JTW | [Tapizantes - Varios](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JT_TAPIZANTES/15JTW-Tapizantes%20-%20Varios.md) | Revisar aplicación. |
| 15JWW | [Varios - Varios](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JW_VARIOS/15JWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15MAA | [Apertura de cajas - Apertura de cajas](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MA_APERTURA_DE_CAJAS/15MAA-Apertura%20de%20cajas%20-%20Apertura%20de%20cajas.md) | Revisar aplicación. |
| 15MAW | [Apertura de cajas - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MA_APERTURA_DE_CAJAS/15MAW-Apertura%20de%20cajas%20-%20Varios.md) | Revisar aplicación. |
| 15MCC | [Compactaciones - Compactaciones](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MC_COMPACTACIONES/15MCC-Compactaciones%20-%20Compactaciones.md) | Revisar aplicación. |
| 15MCW | [Compactaciones - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MC_COMPACTACIONES/15MCW-Compactaciones%20-%20Varios.md) | Revisar aplicación. |
| 15MDD | [Desmontes - Desmontes](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MD_DESMONTES/15MDD-Desmontes%20-%20Desmontes.md) | Revisar aplicación. |
| 15MDW | [Desmontes - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MD_DESMONTES/15MDW-Desmontes%20-%20Varios.md) | Revisar aplicación. |
| 15MEE | [Explanaciones - Explanaciones](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15ME_EXPLANACIONES/15MEE-Explanaciones%20-%20Explanaciones.md) | Revisar aplicación. |
| 15MEW | [Explanaciones - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15ME_EXPLANACIONES/15MEW-Explanaciones%20-%20Varios.md) | Revisar aplicación. |
| 15MPP | [Pozos - Pozos](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MP_POZOS/15MPP-Pozos%20-%20Pozos.md) | Revisar aplicación. |
| 15MPW | [Pozos - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MP_POZOS/15MPW-Pozos%20-%20Varios.md) | Revisar aplicación. |
| 15MRR | [Rellenos - Rellenos](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MR_RELLENOS/15MRR-Rellenos%20-%20Rellenos.md) | Revisar aplicación. |
| 15MRW | [Rellenos - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MR_RELLENOS/15MRW-Rellenos%20-%20Varios.md) | Revisar aplicación. |
| 15MTT | [Transportes - Transportes](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MT_TRANSPORTES/15MTT-Transportes%20-%20Transportes.md) | Revisar aplicación. |
| 15MTW | [Transportes - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MT_TRANSPORTES/15MTW-Transportes%20-%20Varios.md) | Revisar aplicación. |
| 15MWW | [Varios - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MW_VARIOS/15MWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15MZW | [Zanjas - Varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MZ_ZANJAS/15MZW-Zanjas%20-%20Varios.md) | Revisar aplicación. |
| 15MZZ | [Zanjas - Zanjas](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MZ_ZANJAS/15MZZ-Zanjas%20-%20Zanjas.md) | Revisar aplicación. |
| 15PBB | [Bordillos - Bordillos](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PB_BORDILLOS/15PBB-Bordillos%20-%20Bordillos.md) | Revisar aplicación. |
| 15PBW | [Bordillos - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PB_BORDILLOS/15PBW-Bordillos%20-%20Varios.md) | Revisar aplicación. |
| 15PCC | [Calzadas - Calzadas](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/15PCC-Calzadas%20-%20Calzadas.md) | Revisar aplicación. |
| 15PCW | [Calzadas - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/15PCW-Calzadas%20-%20Varios.md) | Revisar aplicación. |
| 15PEE | [Encintados - Encintados](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PE_ENCINTADOS/15PEE-Encintados%20-%20Encintados.md) | Revisar aplicación. |
| 15PEW | [Encintados - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PE_ENCINTADOS/15PEW-Encintados%20-%20Varios.md) | Revisar aplicación. |
| 15PFF | [Firmes - Firmes](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/15PFF-Firmes%20-%20Firmes.md) | Revisar aplicación. |
| 15PFW | [Firmes - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/15PFW-Firmes%20-%20Varios.md) | Revisar aplicación. |
| 15PPE | [Pavimentos - Escalones](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PP_PAVIMENTOS/15PPE-Pavimentos%20-%20Escalones.md) | Revisar aplicación. |
| 15PPP | [Pavimentos - Pavimentos](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PP_PAVIMENTOS/15PPP-Pavimentos%20-%20Pavimentos.md) | Revisar aplicación. |
| 15PPW | [Pavimentos - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PP_PAVIMENTOS/15PPW-Pavimentos%20-%20Varios.md) | Revisar aplicación. |
| 15PSS | [Soleras - Soleras](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PS_SOLERAS/15PSS-Soleras%20-%20Soleras.md) | Revisar aplicación. |
| 15PSW | [Soleras - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PS_SOLERAS/15PSW-Soleras%20-%20Varios.md) | Revisar aplicación. |
| 15PWW | [Varios - Varios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PW_VARIOS/15PWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15SAA | [Acometidas - Acometidas](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SA_ACOMETIDAS/15SAA-Acometidas%20-%20Acometidas.md) | Revisar aplicación. |
| 15SAW | [Acometidas - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SA_ACOMETIDAS/15SAW-Acometidas%20-%20Varios.md) | Revisar aplicación. |
| 15SBD | [Bocas de riego - Para fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SB_BOCAS_DE_RIEGO/15SBD-Bocas%20de%20riego%20-%20Para%20fundici%C3%B3n.md) | Revisar aplicación. |
| 15SBE | [Bocas de riego - Para polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SB_BOCAS_DE_RIEGO/15SBE-Bocas%20de%20riego%20-%20Para%20polietileno.md) | Revisar aplicación. |
| 15SBF | [Bocas de riego - Para fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SB_BOCAS_DE_RIEGO/15SBF-Bocas%20de%20riego%20-%20Para%20fibrocemento.md) | Revisar aplicación. |
| 15SBP | [Bocas de riego - Para P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SB_BOCAS_DE_RIEGO/15SBP-Bocas%20de%20riego%20-%20Para%20P.V.C.md) | Revisar aplicación. |
| 15SBW | [Bocas de riego - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SB_BOCAS_DE_RIEGO/15SBW-Bocas%20de%20riego%20-%20Varios.md) | Revisar aplicación. |
| 15SCD | [Conducciones - Fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/15SCD-Conducciones%20-%20Fundici%C3%B3n.md) | Revisar aplicación. |
| 15SCE | [Conducciones - Polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/15SCE-Conducciones%20-%20Polietileno.md) | Revisar aplicación. |
| 15SCF | [Conducciones - Fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/15SCF-Conducciones%20-%20Fibrocemento.md) | Revisar aplicación. |
| 15SCG | [Conducciones - Galvanizado](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/15SCG-Conducciones%20-%20Galvanizado.md) | Revisar aplicación. |
| 15SCP | [Conducciones - P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/15SCP-Conducciones%20-%20P.V.C.md) | Revisar aplicación. |
| 15SCW | [Conducciones - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/15SCW-Conducciones%20-%20Varios.md) | Revisar aplicación. |
| 15SDD | [Desagües - Para fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SD_DESAG%C3%9CES/15SDD-Desag%C3%BCes%20-%20Para%20fundici%C3%B3n.md) | Revisar aplicación. |
| 15SDE | [Desagües - Para polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SD_DESAG%C3%9CES/15SDE-Desag%C3%BCes%20-%20Para%20polietileno.md) | Revisar aplicación. |
| 15SDF | [Desagües - Para fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SD_DESAG%C3%9CES/15SDF-Desag%C3%BCes%20-%20Para%20fibrocemento.md) | Revisar aplicación. |
| 15SDP | [Desagües - Para P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SD_DESAG%C3%9CES/15SDP-Desag%C3%BCes%20-%20Para%20P.V.C.md) | Revisar aplicación. |
| 15SDW | [Desagües - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SD_DESAG%C3%9CES/15SDW-Desag%C3%BCes%20-%20Varios.md) | Revisar aplicación. |
| 15SHD | [Hidrantes - Para fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SH_HIDRANTES/15SHD-Hidrantes%20-%20Para%20fundici%C3%B3n.md) | Revisar aplicación. |
| 15SHE | [Hidrantes - Para polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SH_HIDRANTES/15SHE-Hidrantes%20-%20Para%20polietileno.md) | Revisar aplicación. |
| 15SHF | [Hidrantes - Para fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SH_HIDRANTES/15SHF-Hidrantes%20-%20Para%20fibrocemento.md) | Revisar aplicación. |
| 15SHP | [Hidrantes - Para P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SH_HIDRANTES/15SHP-Hidrantes%20-%20Para%20P.V.C.md) | Revisar aplicación. |
| 15SHW | [Hidrantes - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SH_HIDRANTES/15SHW-Hidrantes%20-%20Varios.md) | Revisar aplicación. |
| 15SPD | [Piezas especiales - Para fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/15SPD-Piezas%20especiales%20-%20Para%20fundici%C3%B3n.md) | Revisar aplicación. |
| 15SPE | [Piezas especiales - Para polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/15SPE-Piezas%20especiales%20-%20Para%20polietileno.md) | Revisar aplicación. |
| 15SPF | [Piezas especiales - Para fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/15SPF-Piezas%20especiales%20-%20Para%20fibrocemento.md) | Revisar aplicación. |
| 15SPP | [Piezas especiales - Para P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/15SPP-Piezas%20especiales%20-%20Para%20P.V.C.md) | Revisar aplicación. |
| 15SPW | [Piezas especiales - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/15SPW-Piezas%20especiales%20-%20Varios.md) | Revisar aplicación. |
| 15SVD | [Válvulas - Para fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/15SVD-V%C3%A1lvulas%20-%20Para%20fundici%C3%B3n.md) | Revisar aplicación. |
| 15SVE | [Válvulas - Para polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/15SVE-V%C3%A1lvulas%20-%20Para%20polietileno.md) | Revisar aplicación. |
| 15SVF | [Válvulas - Para fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/15SVF-V%C3%A1lvulas%20-%20Para%20fibrocemento.md) | Revisar aplicación. |
| 15SVP | [Válvulas - Para P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/15SVP-V%C3%A1lvulas%20-%20Para%20P.V.C.md) | Revisar aplicación. |
| 15SVW | [Válvulas - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/15SVW-V%C3%A1lvulas%20-%20Varios.md) | Revisar aplicación. |
| 15SWA | [Varios - Arquetas](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SW_VARIOS/15SWA-Varios%20-%20Arquetas.md) | Revisar aplicación. |
| 15SWC | [Varios - Contadores](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SW_VARIOS/15SWC-Varios%20-%20Contadores.md) | Revisar aplicación. |
| 15SWP | [Varios - Pozos](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SW_VARIOS/15SWP-Varios%20-%20Pozos.md) | Revisar aplicación. |
| 15SWW | [Varios - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SW_VARIOS/15SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15SYD | [Ventosas - Para fundición](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SY_VENTOSAS/15SYD-Ventosas%20-%20Para%20fundici%C3%B3n.md) | Revisar aplicación. |
| 15SYE | [Ventosas - Para polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SY_VENTOSAS/15SYE-Ventosas%20-%20Para%20polietileno.md) | Revisar aplicación. |
| 15SYF | [Ventosas - Para fibrocemento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SY_VENTOSAS/15SYF-Ventosas%20-%20Para%20fibrocemento.md) | Revisar aplicación. |
| 15SYP | [Ventosas - Para P.V.C](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SY_VENTOSAS/15SYP-Ventosas%20-%20Para%20P.V.C.md) | Revisar aplicación. |
| 15SYW | [Ventosas - Varios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SY_VENTOSAS/15SYW-Ventosas%20-%20Varios.md) | Revisar aplicación. |
| 15TCC | [Canalizaciones - Canalizaciones](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TC_CANALIZACIONES/15TCC-Canalizaciones%20-%20Canalizaciones.md) | Revisar aplicación. |
| 15TCW | [Canalizaciones - Varios](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TC_CANALIZACIONES/15TCW-Canalizaciones%20-%20Varios.md) | Revisar aplicación. |
| 15TRR | [Registros - Registros](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TR_REGISTROS/15TRR-Registros%20-%20Registros.md) | Revisar aplicación. |
| 15TRW | [Registros - Varios](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TR_REGISTROS/15TRW-Registros%20-%20Varios.md) | Revisar aplicación. |
| 15TWW | [Varios - Varios](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TW_VARIOS/15TWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15UBB | [Bancos - Banco](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UB_BANCOS/15UBB-Bancos%20-%20Banco.md) | Revisar aplicación. |
| 15UBW | [Bancos - Varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UB_BANCOS/15UBW-Bancos%20-%20Varios.md) | Revisar aplicación. |
| 15UFF | [Fuentes - Fuente](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UF_FUENTES/15UFF-Fuentes%20-%20Fuente.md) | Revisar aplicación. |
| 15UFW | [Fuentes - Varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UF_FUENTES/15UFW-Fuentes%20-%20Varios.md) | Revisar aplicación. |
| 15UJJ | [Juegos - Juegos](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UJ_JUEGOS/15UJJ-Juegos%20-%20Juegos.md) | Revisar aplicación. |
| 15UJW | [Juegos - Varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UJ_JUEGOS/15UJW-Juegos%20-%20Varios.md) | Revisar aplicación. |
| 15UPP | [Papeleras - Papelera](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UP_PAPELERAS/15UPP-Papeleras%20-%20Papelera.md) | Revisar aplicación. |
| 15UPW | [Papeleras - Varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UP_PAPELERAS/15UPW-Papeleras%20-%20Varios.md) | Revisar aplicación. |
| 15USA | [Equipamiento deportivo - Accesorios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15US_EQUIPAMIENTO_DEPORTIVO/15USA-Equipamiento%20deportivo%20-%20Accesorios.md) | Revisar aplicación. |
| 15USC | [Equipamiento deportivo - Parque canino](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15US_EQUIPAMIENTO_DEPORTIVO/15USC-Equipamiento%20deportivo%20-%20Parque%20canino.md) | Revisar aplicación. |
| 15USK | [Equipamiento deportivo - Parque calistenia](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15US_EQUIPAMIENTO_DEPORTIVO/15USK-Equipamiento%20deportivo%20-%20Parque%20calistenia.md) | Revisar aplicación. |
| 15USM | [Equipamiento deportivo - Aparatos biosaludables](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15US_EQUIPAMIENTO_DEPORTIVO/15USM-Equipamiento%20deportivo%20-%20Aparatos%20biosaludables.md) | Revisar aplicación. |
| 15USW | [Equipamiento deportivo - Varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15US_EQUIPAMIENTO_DEPORTIVO/15USW-Equipamiento%20deportivo%20-%20Varios.md) | Revisar aplicación. |
| 15UWP | [Varios - Equipamiento para playas](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UW_VARIOS/15UWP-Varios%20-%20Equipamiento%20para%20playas.md) | Revisar aplicación. |
| 15UWW | [Varios - Varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UW_VARIOS/15UWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 15WCC | [Cerramientos - Cerramientos](15_URBANIZACIONES/15W_VARIOS/15WC_CERRAMIENTOS/15WCC-Cerramientos%20-%20Cerramientos.md) | Revisar aplicación. |
| 15WCW | [Cerramientos - Varios](15_URBANIZACIONES/15W_VARIOS/15WC_CERRAMIENTOS/15WCW-Cerramientos%20-%20Varios.md) | Revisar aplicación. |
| 15WMH | [Muros de contención - Hormigón](15_URBANIZACIONES/15W_VARIOS/15WM_MUROS_DE_CONTENCI%C3%93N/15WMH-Muros%20de%20contenci%C3%B3n%20-%20Hormig%C3%B3n.md) | Revisar aplicación. |
| 15WML | [Muros de contención - Ladrillo](15_URBANIZACIONES/15W_VARIOS/15WM_MUROS_DE_CONTENCI%C3%93N/15WML-Muros%20de%20contenci%C3%B3n%20-%20Ladrillo.md) | Revisar aplicación. |
| 15WMW | [Muros de contención - Varios](15_URBANIZACIONES/15W_VARIOS/15WM_MUROS_DE_CONTENCI%C3%93N/15WMW-Muros%20de%20contenci%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 15WWT | [Varios - Trabajos previos](15_URBANIZACIONES/15W_VARIOS/15WW_VARIOS/15WWT-Varios%20-%20Trabajos%20previos.md) | Revisar aplicación. |
| 15WWW | [Varios - Varios](15_URBANIZACIONES/15W_VARIOS/15WW_VARIOS/15WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17AAA | [Aluminio - Aluminio](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AA_ALUMINIO/17AAA-Aluminio%20-%20Aluminio.md) | Revisar aplicación. |
| 17AAW | [Aluminio - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AA_ALUMINIO/17AAW-Aluminio%20-%20Varios.md) | Revisar aplicación. |
| 17ABB | [Bronce, Cobre y Latón - Bronce](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AB_BRONCE_COBRE_Y_LAT%C3%93N/17ABB-Bronce%2C%20Cobre%20y%20Lat%C3%B3n%20-%20Bronce.md) | Revisar aplicación. |
| 17ABC | [Bronce, Cobre y Latón - Cobre](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AB_BRONCE_COBRE_Y_LAT%C3%93N/17ABC-Bronce%2C%20Cobre%20y%20Lat%C3%B3n%20-%20Cobre.md) | Revisar aplicación. |
| 17ABL | [Bronce, Cobre y Latón - Latón](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AB_BRONCE_COBRE_Y_LAT%C3%93N/17ABL-Bronce%2C%20Cobre%20y%20Lat%C3%B3n%20-%20Lat%C3%B3n.md) | Revisar aplicación. |
| 17ABW | [Bronce, Cobre y Latón - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AB_BRONCE_COBRE_Y_LAT%C3%93N/17ABW-Bronce%2C%20Cobre%20y%20Lat%C3%B3n%20-%20Varios.md) | Revisar aplicación. |
| 17ACC | [Cables - Cables](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AC_CABLES/17ACC-Cables%20-%20Cables.md) | Revisar aplicación. |
| 17ACW | [Cables - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AC_CABLES/17ACW-Cables%20-%20Varios.md) | Revisar aplicación. |
| 17AEE | [Estaño - Estaño](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AE_ESTA%C3%91O/17AEE-Esta%C3%B1o%20-%20Esta%C3%B1o.md) | Revisar aplicación. |
| 17AEW | [Estaño - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AE_ESTA%C3%91O/17AEW-Esta%C3%B1o%20-%20Varios.md) | Revisar aplicación. |
| 17AHA | [Hierro y acero - Acero](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AH_HIERRO_Y_ACERO/17AHA-Hierro%20y%20acero%20-%20Acero.md) | Revisar aplicación. |
| 17AHH | [Hierro y acero - Hierro](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AH_HIERRO_Y_ACERO/17AHH-Hierro%20y%20acero%20-%20Hierro.md) | Revisar aplicación. |
| 17AHW | [Hierro y acero - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AH_HIERRO_Y_ACERO/17AHW-Hierro%20y%20acero%20-%20Varios.md) | Revisar aplicación. |
| 17AMM | [Metales mezclados - Metales mezclados](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AM_METALES_MEZCLADOS/17AMM-Metales%20mezclados%20-%20Metales%20mezclados.md) | Revisar aplicación. |
| 17AMW | [Metales mezclados - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AM_METALES_MEZCLADOS/17AMW-Metales%20mezclados%20-%20Varios.md) | Revisar aplicación. |
| 17APA | [Plomo - Plomo](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AP_PLOMO/17APA-Plomo%20-%20Plomo.md) | Revisar aplicación. |
| 17APW | [Plomo - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AP_PLOMO/17APW-Plomo%20-%20Varios.md) | Revisar aplicación. |
| 17AWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AW_VARIOS/17AWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17AZW | [Zinc - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AZ_ZINC/17AZW-Zinc%20-%20Varios.md) | Revisar aplicación. |
| 17AZZ | [Zinc - Zinc](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AZ_ZINC/17AZZ-Zinc%20-%20Zinc.md) | Revisar aplicación. |
| 17FAA | [Asfalto con alquitrán - Asfalto con alquitrán](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FA_ASFALTO_CON_ALQUITR%C3%81N/17FAA-Asfalto%20con%20alquitr%C3%A1n%20-%20Asfalto%20con%20alquitr%C3%A1n.md) | Revisar aplicación. |
| 17FAW | [Asfalto con alquitrán - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FA_ASFALTO_CON_ALQUITR%C3%81N/17FAW-Asfalto%20con%20alquitr%C3%A1n%20-%20Varios.md) | Revisar aplicación. |
| 17FSS | [Asfalto sin alquitrán - Asfalto sin alquitrán](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FS_ASFALTO_SIN_ALQUITR%C3%81N/17FSS-Asfalto%20sin%20alquitr%C3%A1n%20-%20Asfalto%20sin%20alquitr%C3%A1n.md) | Revisar aplicación. |
| 17FSW | [Asfalto sin alquitrán - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FS_ASFALTO_SIN_ALQUITR%C3%81N/17FSW-Asfalto%20sin%20alquitr%C3%A1n%20-%20Varios.md) | Revisar aplicación. |
| 17FTT | [Alquitrán y productos alquitranados - Alquitrán y productos alquitranados](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FT_ALQUITR%C3%81N_Y_PRODUCTOS_ALQUITRANADOS/17FTT-Alquitr%C3%A1n%20y%20productos%20alquitranados%20-%20Alquitr%C3%A1n%20y%20productos%20alquitranados.md) | Revisar aplicación. |
| 17FTW | [Alquitrán y productos alquitranados - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FT_ALQUITR%C3%81N_Y_PRODUCTOS_ALQUITRANADOS/17FTW-Alquitr%C3%A1n%20y%20productos%20alquitranados%20-%20Varios.md) | Revisar aplicación. |
| 17FWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FW_VARIOS/17FWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17HAA | [Áridos y piedras naturales - Áridos](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HA_%C3%81RIDOS_Y_PIEDRAS_NATURALES/17HAA-%C3%81ridos%20y%20piedras%20naturales%20-%20%C3%81ridos.md) | Revisar aplicación. |
| 17HAP | [Áridos y piedras naturales - Piedras naturales](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HA_%C3%81RIDOS_Y_PIEDRAS_NATURALES/17HAP-%C3%81ridos%20y%20piedras%20naturales%20-%20Piedras%20naturales.md) | Revisar aplicación. |
| 17HAW | [Áridos y piedras naturales - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HA_%C3%81RIDOS_Y_PIEDRAS_NATURALES/17HAW-%C3%81ridos%20y%20piedras%20naturales%20-%20Varios.md) | Revisar aplicación. |
| 17HCB | [Materiales cerámicos - Baldosas](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HC_MATERIALES_CER%C3%81MICOS/17HCB-Materiales%20cer%C3%A1micos%20-%20Baldosas.md) | Revisar aplicación. |
| 17HCL | [Materiales cerámicos - Ladrillos](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HC_MATERIALES_CER%C3%81MICOS/17HCL-Materiales%20cer%C3%A1micos%20-%20Ladrillos.md) | Revisar aplicación. |
| 17HCT | [Materiales cerámicos - Tejas](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HC_MATERIALES_CER%C3%81MICOS/17HCT-Materiales%20cer%C3%A1micos%20-%20Tejas.md) | Revisar aplicación. |
| 17HCW | [Materiales cerámicos - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HC_MATERIALES_CER%C3%81MICOS/17HCW-Materiales%20cer%C3%A1micos%20-%20Varios.md) | Revisar aplicación. |
| 17HHC | [Hormigones, terrazos, cementos y cales - Cementos](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HH_HORMIGONES_TERRAZOS_CEMENTOS_Y_CALES/17HHC-Hormigones%2C%20terrazos%2C%20cementos%20y%20cales%20-%20Cementos.md) | Revisar aplicación. |
| 17HHH | [Hormigones, terrazos, cementos y cales - Hormigones](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HH_HORMIGONES_TERRAZOS_CEMENTOS_Y_CALES/17HHH-Hormigones%2C%20terrazos%2C%20cementos%20y%20cales%20-%20Hormigones.md) | Revisar aplicación. |
| 17HHK | [Hormigones, terrazos, cementos y cales - Cales](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HH_HORMIGONES_TERRAZOS_CEMENTOS_Y_CALES/17HHK-Hormigones%2C%20terrazos%2C%20cementos%20y%20cales%20-%20Cales.md) | Revisar aplicación. |
| 17HHT | [Hormigones, terrazos, cementos y cales - Terrazos y piedras artificiales](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HH_HORMIGONES_TERRAZOS_CEMENTOS_Y_CALES/17HHT-Hormigones%2C%20terrazos%2C%20cementos%20y%20cales%20-%20Terrazos%20y%20piedras%20artificiales.md) | Revisar aplicación. |
| 17HHW | [Hormigones, terrazos, cementos y cales - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HH_HORMIGONES_TERRAZOS_CEMENTOS_Y_CALES/17HHW-Hormigones%2C%20terrazos%2C%20cementos%20y%20cales%20-%20Varios.md) | Revisar aplicación. |
| 17HMM | [Morteros - Morteros](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HM_MORTEROS/17HMM-Morteros%20-%20Morteros.md) | Revisar aplicación. |
| 17HMW | [Morteros - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HM_MORTEROS/17HMW-Morteros%20-%20Varios.md) | Revisar aplicación. |
| 17HWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HW_VARIOS/17HWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17HYE | [Materiales de construcción derivados del yeso - Escayolas](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HY_MATERIALES_DE_CONSTRUCCI%C3%93N_DERIVADOS_DEL_YESO/17HYE-Materiales%20de%20construcci%C3%B3n%20derivados%20del%20yeso%20-%20Escayolas.md) | Revisar aplicación. |
| 17HYW | [Materiales de construcción derivados del yeso - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HY_MATERIALES_DE_CONSTRUCCI%C3%93N_DERIVADOS_DEL_YESO/17HYW-Materiales%20de%20construcci%C3%B3n%20derivados%20del%20yeso%20-%20Varios.md) | Revisar aplicación. |
| 17HYY | [Materiales de construcción derivados del yeso - Yeso](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HY_MATERIALES_DE_CONSTRUCCI%C3%93N_DERIVADOS_DEL_YESO/17HYY-Materiales%20de%20construcci%C3%B3n%20derivados%20del%20yeso%20-%20Yeso.md) | Revisar aplicación. |
| 17IAA | [Materiales derivados del yeso con amianto - Materiales de aislamiento con amianto](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IA_MATERIALES_DERIVADOS_DEL_YESO_CON_AMIANTO/17IAA-Materiales%20derivados%20del%20yeso%20con%20amianto%20-%20Materiales%20de%20aislamiento%20con%20amianto.md) | Revisar aplicación. |
| 17IAW | [Materiales derivados del yeso con amianto - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IA_MATERIALES_DERIVADOS_DEL_YESO_CON_AMIANTO/17IAW-Materiales%20derivados%20del%20yeso%20con%20amianto%20-%20Varios.md) | Revisar aplicación. |
| 17IOO | [Otros materiales de aislamiento - Otros materiales de aislamiento](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IO_OTROS_MATERIALES_DE_AISLAMIENTO/17IOO-Otros%20materiales%20de%20aislamiento%20-%20Otros%20materiales%20de%20aislamiento.md) | Revisar aplicación. |
| 17IOW | [Otros materiales de aislamiento - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IO_OTROS_MATERIALES_DE_AISLAMIENTO/17IOW-Otros%20materiales%20de%20aislamiento%20-%20Varios.md) | Revisar aplicación. |
| 17IWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IW_VARIOS/17IWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17MMM | [Maderas, papeles, plásticos y sintéticos - Madera, papeles y cartones](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MM_MADERAS_PAPELES_PL%C3%81STICOS_Y_SINT%C3%89TICOS/17MMM-Maderas%2C%20papeles%2C%20pl%C3%A1sticos%20y%20sint%C3%A9ticos%20-%20Madera%2C%20papeles%20y%20cartones.md) | Revisar aplicación. |
| 17MMP | [Maderas, papeles, plásticos y sintéticos - Plásticos y sintéticos](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MM_MADERAS_PAPELES_PL%C3%81STICOS_Y_SINT%C3%89TICOS/17MMP-Maderas%2C%20papeles%2C%20pl%C3%A1sticos%20y%20sint%C3%A9ticos%20-%20Pl%C3%A1sticos%20y%20sint%C3%A9ticos.md) | Revisar aplicación. |
| 17MMW | [Maderas, papeles, plásticos y sintéticos - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MM_MADERAS_PAPELES_PL%C3%81STICOS_Y_SINT%C3%89TICOS/17MMW-Maderas%2C%20papeles%2C%20pl%C3%A1sticos%20y%20sint%C3%A9ticos%20-%20Varios.md) | Revisar aplicación. |
| 17MVV | [Vidrios - Vidrios](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MV_VIDRIOS/17MVV-Vidrios%20-%20Vidrios.md) | Revisar aplicación. |
| 17MVW | [Vidrios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MV_VIDRIOS/17MVW-Vidrios%20-%20Varios.md) | Revisar aplicación. |
| 17MWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MW_VARIOS/17MWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17RRR | [Residuos mezclados - Residuos mezclados](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RR_RESIDUOS_MEZCLADOS/17RRR-Residuos%20mezclados%20-%20Residuos%20mezclados.md) | Revisar aplicación. |
| 17RRW | [Residuos mezclados - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RR_RESIDUOS_MEZCLADOS/17RRW-Residuos%20mezclados%20-%20Varios.md) | Revisar aplicación. |
| 17RWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RW_VARIOS/17RWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17TLL | [Lodos de renaje - Lodos de drenaje](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TL_LODOS_DE_RENAJE/17TLL-Lodos%20de%20renaje%20-%20Lodos%20de%20drenaje.md) | Revisar aplicación. |
| 17TLW | [Lodos de renaje - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TL_LODOS_DE_RENAJE/17TLW-Lodos%20de%20renaje%20-%20Varios.md) | Revisar aplicación. |
| 17TTP | [Terrenos - Piedras](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TT_TERRENOS/17TTP-Terrenos%20-%20Piedras.md) | Revisar aplicación. |
| 17TTT | [Terrenos - Terrenos](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TT_TERRENOS/17TTT-Terrenos%20-%20Terrenos.md) | Revisar aplicación. |
| 17TTW | [Terrenos - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TT_TERRENOS/17TTW-Terrenos%20-%20Varios.md) | Revisar aplicación. |
| 17TWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TW_VARIOS/17TWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 17WWW | [Varios - Varios](17_GESTI%C3%93N_DE_RESIDUOS/17W_VARIOS/17WW_VARIOS/17WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 18ALF | [Laboratorio - Ensayos físicos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18A_%C3%81RIDOS_Y_SUELOS/18AL_LABORATORIO/18ALF-Laboratorio%20-%20Ensayos%20f%C3%ADsicos.md) | Revisar aplicación. |
| 18ALQ | [Laboratorio - Ensayos químicos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18A_%C3%81RIDOS_Y_SUELOS/18AL_LABORATORIO/18ALQ-Laboratorio%20-%20Ensayos%20qu%C3%ADmicos.md) | Revisar aplicación. |
| 18ASS | [In situ - In situ](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18A_%C3%81RIDOS_Y_SUELOS/18AS_IN_SITU/18ASS-In%20situ%20-%20In%20situ.md) | Revisar aplicación. |
| 18BBC | [Baldosas - Baldosa cerámica](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/18BBC-Baldosas%20-%20Baldosa%20cer%C3%A1mica.md) | Revisar aplicación. |
| 18BBE | [Baldosas - Baldosa de piedra natural exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/18BBE-Baldosas%20-%20Baldosa%20de%20piedra%20natural%20exterior.md) | Revisar aplicación. |
| 18BBH | [Baldosas - Baldosa de hormigón](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/18BBH-Baldosas%20-%20Baldosa%20de%20hormig%C3%B3n.md) | Revisar aplicación. |
| 18BBI | [Baldosas - Baldosa de piedra natural interior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/18BBI-Baldosas%20-%20Baldosa%20de%20piedra%20natural%20interior.md) | Revisar aplicación. |
| 18BBR | [Baldosas - Baldosas de terrazo exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/18BBR-Baldosas%20-%20Baldosas%20de%20terrazo%20exterior.md) | Revisar aplicación. |
| 18BBT | [Baldosas - Baldosas de terrazo interior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/18BBT-Baldosas%20-%20Baldosas%20de%20terrazo%20interior.md) | Revisar aplicación. |
| 18BSH | [Suelo - Pavimento de hormigón continuo](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BS_SUELO/18BSH-Suelo%20-%20Pavimento%20de%20hormig%C3%B3n%20continuo.md) | Revisar aplicación. |
| 18BSM | [Suelo - Pavimento de madera](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BS_SUELO/18BSM-Suelo%20-%20Pavimento%20de%20madera.md) | Revisar aplicación. |
| 18BSV | [Suelo - Pavimento vinílico](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BS_SUELO/18BSV-Suelo%20-%20Pavimento%20vin%C3%ADlico.md) | Revisar aplicación. |
| 18BTA | [Techos - Perfilería de acero galvanizado en techos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BT_TECHOS/18BTA-Techos%20-%20Perfiler%C3%ADa%20de%20acero%20galvanizado%20en%20techos.md) | Revisar aplicación. |
| 18BTY | [Techos - Placa de yeso laminado o escayola](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BT_TECHOS/18BTY-Techos%20-%20Placa%20de%20yeso%20laminado%20o%20escayola.md) | Revisar aplicación. |
| 18CAA | [Pantallas - Pantallas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CA_PANTALLAS/18CAA-Pantallas%20-%20Pantallas.md) | Revisar aplicación. |
| 18CEE | [Escolleras - Escolleras](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CE_ESCOLLERAS/18CEE-Escolleras%20-%20Escolleras.md) | Revisar aplicación. |
| 18CLL | [Lodos bentolíticos o suspensiones poliméricas - Lodos bentolíticos o suspensiones poliméricas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CL_LODOS_BENTOL%C3%8DTICOS_O_SUSPENSIONES_POLIM%C3%89RICAS/18CLL-Lodos%20bentol%C3%ADticos%20o%20suspensiones%20polim%C3%A9ricas%20-%20Lodos%20bentol%C3%ADticos%20o%20suspensiones%20polim%C3%A9ricas.md) | Revisar aplicación. |
| 18CMM | [Micropilotes - Micropilotes](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CM_MICROPILOTES/18CMM-Micropilotes%20-%20Micropilotes.md) | Revisar aplicación. |
| 18CPI | [Pilotes - In situ](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CP_PILOTES/18CPI-Pilotes%20-%20In%20situ.md) | Revisar aplicación. |
| 18CPP | [Pilotes - Pilotes prefabricados](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CP_PILOTES/18CPP-Pilotes%20-%20Pilotes%20prefabricados.md) | Revisar aplicación. |
| 18EEF | [Estructura de fábrica - Fábrica de ladrillo](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18E_ESTRUCTURAS_DE_F%C3%81BRICA/18EE_ESTRUCTURA_DE_F%C3%81BRICA/18EEF-Estructura%20de%20f%C3%A1brica%20-%20F%C3%A1brica%20de%20ladrillo.md) | Revisar aplicación. |
| 18HHI | [Hormigón - Insitu](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18H_ESTRUCTURAS_DE_HORMIG%C3%93N/18HH_HORMIG%C3%93N/18HHI-Hormig%C3%B3n%20-%20Insitu.md) | Revisar aplicación. |
| 18HHL | [Hormigón - Laboratorio](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18H_ESTRUCTURAS_DE_HORMIG%C3%93N/18HH_HORMIG%C3%93N/18HHL-Hormig%C3%B3n%20-%20Laboratorio.md) | Revisar aplicación. |
| 18HWW | [Varios - Varios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18H_ESTRUCTURAS_DE_HORMIG%C3%93N/18HW_VARIOS/18HWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 18IAA | [SANEAMIENTO - Pruebas de funcionamiento. Saneamiento exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IA_SANEAMIENTO/18IAA-SANEAMIENTO%20-%20Pruebas%20de%20funcionamiento.%20Saneamiento%20exterior.md) | Revisar aplicación. |
| 18IAB | [SANEAMIENTO - Pruebas de funcionamiento. Saneamiento interior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IA_SANEAMIENTO/18IAB-SANEAMIENTO%20-%20Pruebas%20de%20funcionamiento.%20Saneamiento%20interior.md) | Revisar aplicación. |
| 18IAC | [SANEAMIENTO - Tubos de saneamiento PVC](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IA_SANEAMIENTO/18IAC-SANEAMIENTO%20-%20Tubos%20de%20saneamiento%20PVC.md) | Revisar aplicación. |
| 18IBA | [ABASTECIMIENTO EN REDES EXTERIORES DE AGUA - Pruebas de funcionamiento en redes exteriores de agua](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IB_ABASTECIMIENTO_EN_REDES_EXTERIORES_DE_AGUA/18IBA-ABASTECIMIENTO%20EN%20REDES%20EXTERIORES%20DE%20AGUA%20-%20Pruebas%20de%20funcionamiento%20en%20redes%20exteriores%20de%20agua.md) | Revisar aplicación. |
| 18IBB | [ABASTECIMIENTO EN REDES EXTERIORES DE AGUA - Tubos de abastecimiento](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IB_ABASTECIMIENTO_EN_REDES_EXTERIORES_DE_AGUA/18IBB-ABASTECIMIENTO%20EN%20REDES%20EXTERIORES%20DE%20AGUA%20-%20Tubos%20de%20abastecimiento.md) | Revisar aplicación. |
| 18ICA | [FONTANERIA Y REDES INTERIORES DE SUMINISTRO DE AGUA - Pruebas de funcionamiento](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IC_FONTANERIA_Y_REDES_INTERIORES_DE_SUMINISTRO_DE_AGUA/18ICA-FONTANERIA%20Y%20REDES%20INTERIORES%20DE%20SUMINISTRO%20DE%20AGUA%20-%20Pruebas%20de%20funcionamiento.md) | Revisar aplicación. |
| 18ICB | [FONTANERIA Y REDES INTERIORES DE SUMINISTRO DE AGUA - Tubos de Fontanería (Polietileno)](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IC_FONTANERIA_Y_REDES_INTERIORES_DE_SUMINISTRO_DE_AGUA/18ICB-FONTANERIA%20Y%20REDES%20INTERIORES%20DE%20SUMINISTRO%20DE%20AGUA%20-%20Tubos%20de%20Fontaner%C3%ADa%20%28Polietileno%29.md) | Revisar aplicación. |
| 18ICC | [FONTANERIA Y REDES INTERIORES DE SUMINISTRO DE AGUA - Tubos de Fontanería (Cobre)](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IC_FONTANERIA_Y_REDES_INTERIORES_DE_SUMINISTRO_DE_AGUA/18ICC-FONTANERIA%20Y%20REDES%20INTERIORES%20DE%20SUMINISTRO%20DE%20AGUA%20-%20Tubos%20de%20Fontaner%C3%ADa%20%28Cobre%29.md) | Revisar aplicación. |
| 18IEE | [ELECTRICIDAD MEDIA TENSIÓN (MT) - Electricidad media tensión (MT)](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IE_ELECTRICIDAD_MEDIA_TENSI%C3%93N_MT/18IEE-ELECTRICIDAD%20MEDIA%20TENSI%C3%93N%20%28MT%29%20-%20Electricidad%20media%20tensi%C3%B3n%20%28MT%29.md) | Revisar aplicación. |
| 18IHP | [VENTILACIÓN - Ventilación](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IH_VENTILACI%C3%93N/18IHP-VENTILACI%C3%93N%20-%20Ventilaci%C3%B3n.md) | Revisar aplicación. |
| 18III | [EXTRACCIÓN - Extracción](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18II_EXTRACCI%C3%93N/18III-EXTRACCI%C3%93N%20-%20Extracci%C3%B3n.md) | Revisar aplicación. |
| 18IJJ | [INSTALACIÓN CONTRA INCENDIOS - Instalación contra incendios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IJ_INSTALACI%C3%93N_CONTRA_INCENDIOS/18IJJ-INSTALACI%C3%93N%20CONTRA%20INCENDIOS%20-%20Instalaci%C3%B3n%20contra%20incendios.md) | Revisar aplicación. |
| 18ILL | [RIEGO - Riego](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IL_RIEGO/18ILL-RIEGO%20-%20Riego.md) | Revisar aplicación. |
| 18IMM | [PISCINAS - Piscinas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IM_PISCINAS/18IMM-PISCINAS%20-%20Piscinas.md) | Revisar aplicación. |
| 18INN | [DETECCIÓN DE MONÓXIDO DE CARBONO - Detección de monóxido de carbono](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IN_DETECCI%C3%93N_DE_MON%C3%93XIDO_DE_CARBONO/18INN-DETECCI%C3%93N%20DE%20MON%C3%93XIDO%20DE%20CARBONO%20-%20Detecci%C3%B3n%20de%20mon%C3%B3xido%20de%20carbono.md) | Revisar aplicación. |
| 18IOO | [ALUMBRADO EXTERIOR - Alumbrado exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IO_ALUMBRADO_EXTERIOR/18IOO-ALUMBRADO%20EXTERIOR%20-%20Alumbrado%20exterior.md) | Revisar aplicación. |
| 18IPP | [PARARRAYOS - Pararrayos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IP_PARARRAYOS/18IPP-PARARRAYOS%20-%20Pararrayos.md) | Revisar aplicación. |
| 18IQQ | [TELECOMUNICACIONES - Telecomunicaciones](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IQ_TELECOMUNICACIONES/18IQQ-TELECOMUNICACIONES%20-%20Telecomunicaciones.md) | Revisar aplicación. |
| 18IRR | [GAS NATURAL - Gas natural](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IR_GAS_NATURAL/18IRR-GAS%20NATURAL%20-%20Gas%20natural.md) | Revisar aplicación. |
| 18ITT | [GASES MEDICINALES - Gases medicinales](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IT_GASES_MEDICINALES/18ITT-GASES%20MEDICINALES%20-%20Gases%20medicinales.md) | Revisar aplicación. |
| 18IUU | [INSTALACIONES ESPECIALES - Instalaciones especiales](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IU_INSTALACIONES_ESPECIALES/18IUU-INSTALACIONES%20ESPECIALES%20-%20Instalaciones%20especiales.md) | Revisar aplicación. |
| 18KAA | [Carpintería exterior - Carpintería exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18K_CARPINTER%C3%8DA_Y_VIDRIOS/18KA_CARPINTER%C3%8DA_EXTERIOR/18KAA-Carpinter%C3%ADa%20exterior%20-%20Carpinter%C3%ADa%20exterior.md) | Revisar aplicación. |
| 18KBA | [Carpintería interior - Puertas de madera](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18K_CARPINTER%C3%8DA_Y_VIDRIOS/18KB_CARPINTER%C3%8DA_INTERIOR/18KBA-Carpinter%C3%ADa%20interior%20-%20Puertas%20de%20madera.md) | Revisar aplicación. |
| 18KCC | [Vidrios - Vidrios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18K_CARPINTER%C3%8DA_Y_VIDRIOS/18KC_VIDRIOS/18KCC-Vidrios%20-%20Vidrios.md) | Revisar aplicación. |
| 18MAA | [Madera aserrada - Madera aserrada](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18MA_MADERA_ASERRADA/18MAA-Madera%20aserrada%20-%20Madera%20aserrada.md) | Revisar aplicación. |
| 18MAW | [Madera aserrada - Varios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18MA_MADERA_ASERRADA/18MAW-Madera%20aserrada%20-%20Varios.md) | Revisar aplicación. |
| 18MLL | [Madera laminada encolada - Madera laminada encolada](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18ML_MADERA_LAMINADA_ENCOLADA/18MLL-Madera%20laminada%20encolada%20-%20Madera%20laminada%20encolada.md) | Revisar aplicación. |
| 18MLW | [Madera laminada encolada - Varios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18ML_MADERA_LAMINADA_ENCOLADA/18MLW-Madera%20laminada%20encolada%20-%20Varios.md) | Revisar aplicación. |
| 18MTT | [Tableros - Tableros](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18MT_TABLEROS/18MTT-Tableros%20-%20Tableros.md) | Revisar aplicación. |
| 18MTW | [Tableros - Varios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18MT_TABLEROS/18MTW-Tableros%20-%20Varios.md) | Revisar aplicación. |
| 18OGG | [Guarnecido y enlucido de yeso - Guarnecido y enlucido de yeso](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18O_MORTEROS_YESOS_CALES_ESCAYOLAS_Y_CEMENTOS/18OG_GUARNECIDO_Y_ENLUCIDO_DE_YESO/18OGG-Guarnecido%20y%20enlucido%20de%20yeso%20-%20Guarnecido%20y%20enlucido%20de%20yeso.md) | Revisar aplicación. |
| 18OMM | [Mortero cola - Mortero cola](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18O_MORTEROS_YESOS_CALES_ESCAYOLAS_Y_CEMENTOS/18OM_MORTERO_COLA/18OMM-Mortero%20cola%20-%20Mortero%20cola.md) | Revisar aplicación. |
| 18ORR | [Revoco y enlucido con mortero de cemento - Revocos y enlucidos con mortero de cemento](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18O_MORTEROS_YESOS_CALES_ESCAYOLAS_Y_CEMENTOS/18OR_REVOCO_Y_ENLUCIDO_CON_MORTERO_DE_CEMENTO/18ORR-Revoco%20y%20enlucido%20con%20mortero%20de%20cemento%20-%20Revocos%20y%20enlucidos%20con%20mortero%20de%20cemento.md) | Revisar aplicación. |
| 18PAP | [Pintura paramentos - Pinturas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18P_PINTURAS/18PA_PINTURA_PARAMENTOS/18PAP-Pintura%20paramentos%20-%20Pinturas.md) | Revisar aplicación. |
| 18PMC | [Pintura estructura metálica - Protección anticorrosiva](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18P_PINTURAS/18PM_PINTURA_ESTRUCTURA_MET%C3%81LICA/18PMC-Pintura%20estructura%20met%C3%A1lica%20-%20Protecci%C3%B3n%20anticorrosiva.md) | Revisar aplicación. |
| 18RBB | [Bovedillas - Bovedillas cerámicas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RB_BOVEDILLAS/18RBB-Bovedillas%20-%20Bovedillas%20cer%C3%A1micas.md) | Revisar aplicación. |
| 18RBH | [Bovedillas - Bovedillas de hormigón](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RB_BOVEDILLAS/18RBH-Bovedillas%20-%20Bovedillas%20de%20hormig%C3%B3n.md) | Revisar aplicación. |
| 18RHH | [Bloques de hormigón - Bloques de hormigón](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RH_BLOQUES_DE_HORMIG%C3%93N/18RHH-Bloques%20de%20hormig%C3%B3n%20-%20Bloques%20de%20hormig%C3%B3n.md) | Revisar aplicación. |
| 18RPA | [Alicatados y aplacados](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RP_AGRUPACION_POR_CODIGO/18RPA-Alicatados%20y%20aplacados.md) | Revisar aplicación. |
| 18RPB | [Paneles de yeso laminado](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RP_AGRUPACION_POR_CODIGO/18RPB-Paneles%20de%20yeso%20laminado.md) | Revisar aplicación. |
| 18RPC | [Perfilería de acero galvanizado en tabiquería](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RP_AGRUPACION_POR_CODIGO/18RPC-Perfiler%C3%ADa%20de%20acero%20galvanizado%20en%20tabiquer%C3%ADa.md) | Revisar aplicación. |
| 18RRR | [Ladrillos y bloques cerámicos - Ladrillos y bloques cerámicos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RR_LADRILLOS_Y_BLOQUES_CER%C3%81MICOS/18RRR-Ladrillos%20y%20bloques%20cer%C3%A1micos%20-%20Ladrillos%20y%20bloques%20cer%C3%A1micos.md) | Revisar aplicación. |
| 18RTC | [Tejas - Tejas cerámicas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RT_TEJAS/18RTC-Tejas%20-%20Tejas%20cer%C3%A1micas.md) | Revisar aplicación. |
| 18RTH | [Tejas - Teja de hormigón](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RT_TEJAS/18RTH-Tejas%20-%20Teja%20de%20hormig%C3%B3n.md) | Revisar aplicación. |
| 18SCA | [Protección anticorrosiva - Protección anticorrosiva](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SC_PROTECCI%C3%93N_ANTICORROSIVA/18SCA-Protecci%C3%B3n%20anticorrosiva%20-%20Protecci%C3%B3n%20anticorrosiva.md) | Revisar aplicación. |
| 18SCF | [Protección anticorrosiva - Protección contra el fuego](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SC_PROTECCI%C3%93N_ANTICORROSIVA/18SCF-Protecci%C3%B3n%20anticorrosiva%20-%20Protecci%C3%B3n%20contra%20el%20fuego.md) | Revisar aplicación. |
| 18SCG | [Protección anticorrosiva - Estructuras galvanizadas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SC_PROTECCI%C3%93N_ANTICORROSIVA/18SCG-Protecci%C3%B3n%20anticorrosiva%20-%20Estructuras%20galvanizadas.md) | Revisar aplicación. |
| 18SCS | [Protección anticorrosiva - Preparación superficial](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SC_PROTECCI%C3%93N_ANTICORROSIVA/18SCS-Protecci%C3%B3n%20anticorrosiva%20-%20Preparaci%C3%B3n%20superficial.md) | Revisar aplicación. |
| 18SEE | [Elementos metálicos - Elementos metálicos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SE_ELEMENTOS_MET%C3%81LICOS/18SEE-Elementos%20met%C3%A1licos%20-%20Elementos%20met%C3%A1licos.md) | Revisar aplicación. |
| 18SPP | [Perfiles - Perfiles](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SP_PERFILES/18SPP-Perfiles%20-%20Perfiles.md) | Revisar aplicación. |
| 18SSA | [Soldaduras - Soldaduras en ángulo](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SS_SOLDADURAS/18SSA-Soldaduras%20-%20Soldaduras%20en%20%C3%A1ngulo.md) | Revisar aplicación. |
| 18SSC | [Soldaduras - Conectores soldados](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SS_SOLDADURAS/18SSC-Soldaduras%20-%20Conectores%20soldados.md) | Revisar aplicación. |
| 18SST | [Soldaduras - Soldaduras a tope](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SS_SOLDADURAS/18SST-Soldaduras%20-%20Soldaduras%20a%20tope.md) | Revisar aplicación. |
| 18TAA | [Aislamientos - Aislamiento rígido](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18T_AISLAMIENTOS_E_IMPERMEABILIZACIONES/18TA_AISLAMIENTOS/18TAA-Aislamientos%20-%20Aislamiento%20r%C3%ADgido.md) | Revisar aplicación. |
| 18TAE | [Aislamientos - Aislamiento expandido](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18T_AISLAMIENTOS_E_IMPERMEABILIZACIONES/18TA_AISLAMIENTOS/18TAE-Aislamientos%20-%20Aislamiento%20expandido.md) | Revisar aplicación. |
| 18TGB | [Geosintéticos - Láminas bituminosas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18T_AISLAMIENTOS_E_IMPERMEABILIZACIONES/18TG_GEOSINT%C3%89TICOS/18TGB-Geosint%C3%A9ticos%20-%20L%C3%A1minas%20bituminosas.md) | Revisar aplicación. |
| 18TGP | [Geosintéticos - Láminas plásticas o de caucho](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18T_AISLAMIENTOS_E_IMPERMEABILIZACIONES/18TG_GEOSINT%C3%89TICOS/18TGP-Geosint%C3%A9ticos%20-%20L%C3%A1minas%20pl%C3%A1sticas%20o%20de%20caucho.md) | Revisar aplicación. |
| 18UAA | [PRUEBAS DE ACÚSTICA - Pruebas de acústica](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UA_PRUEBAS_DE_AC%C3%9ASTICA/18UAA-PRUEBAS%20DE%20AC%C3%9ASTICA%20-%20Pruebas%20de%20ac%C3%BAstica.md) | Revisar aplicación. |
| 18UBB | [PRUEBAS DE ESTANQUEIDAD EN CUBIERTAS Y FACHADAS - Pruebas de estanqueidad en cubiertas y fachadas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UB_PRUEBAS_DE_ESTANQUEIDAD_EN_CUBIERTAS_Y_FACHADAS/18UBB-PRUEBAS%20DE%20ESTANQUEIDAD%20EN%20CUBIERTAS%20Y%20FACHADAS%20-%20Pruebas%20de%20estanqueidad%20en%20cubiertas%20y%20fachadas.md) | Revisar aplicación. |
| 18UCA | [PRUEBAS SOBRE BARANDILLAS - Barandillas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UC_PRUEBAS_SOBRE_BARANDILLAS/18UCA-PRUEBAS%20SOBRE%20BARANDILLAS%20-%20Barandillas.md) | Revisar aplicación. |
| 18UDA | [PRUEBAS DE EFICIENCIA ENERGÉTICA - Pruebas de eficiencia energética](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UD_PRUEBAS_DE_EFICIENCIA_ENERG%C3%89TICA/18UDA-PRUEBAS%20DE%20EFICIENCIA%20ENERG%C3%89TICA%20-%20Pruebas%20de%20eficiencia%20energ%C3%A9tica.md) | Revisar aplicación. |
| 19LAA | [Adaptaciones - Aseos](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LA_ADAPTACIONES/19LAA-Adaptaciones%20-%20Aseos.md) | Revisar aplicación. |
| 19LAC | [Adaptaciones - Comedores](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LA_ADAPTACIONES/19LAC-Adaptaciones%20-%20Comedores.md) | Revisar aplicación. |
| 19LAS | [Adaptaciones - Salas primeros auxilios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LA_ADAPTACIONES/19LAS-Adaptaciones%20-%20Salas%20primeros%20auxilios.md) | Revisar aplicación. |
| 19LAV | [Adaptaciones - Vestuarios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LA_ADAPTACIONES/19LAV-Adaptaciones%20-%20Vestuarios.md) | Revisar aplicación. |
| 19LAW | [Adaptaciones - Varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LA_ADAPTACIONES/19LAW-Adaptaciones%20-%20Varios.md) | Revisar aplicación. |
| 19LIA | [Instalaciones - Aseos](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LI_INSTALACIONES/19LIA-Instalaciones%20-%20Aseos.md) | Revisar aplicación. |
| 19LIC | [Instalaciones - Comedores](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LI_INSTALACIONES/19LIC-Instalaciones%20-%20Comedores.md) | Revisar aplicación. |
| 19LIS | [Instalaciones - Salas primeros auxilios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LI_INSTALACIONES/19LIS-Instalaciones%20-%20Salas%20primeros%20auxilios.md) | Revisar aplicación. |
| 19LIV | [Instalaciones - Vestuarios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LI_INSTALACIONES/19LIV-Instalaciones%20-%20Vestuarios.md) | Revisar aplicación. |
| 19LIW | [Instalaciones - Varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LI_INSTALACIONES/19LIW-Instalaciones%20-%20Varios.md) | Revisar aplicación. |
| 19LLA | [Locales - Aseos](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LL_LOCALES/19LLA-Locales%20-%20Aseos.md) | Revisar aplicación. |
| 19LLC | [Locales - Comedores](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LL_LOCALES/19LLC-Locales%20-%20Comedores.md) | Revisar aplicación. |
| 19LLS | [Locales - Salas primeros auxilios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LL_LOCALES/19LLS-Locales%20-%20Salas%20primeros%20auxilios.md) | Revisar aplicación. |
| 19LLV | [Locales - Vestuarios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LL_LOCALES/19LLV-Locales%20-%20Vestuarios.md) | Revisar aplicación. |
| 19LLW | [Locales - Varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LL_LOCALES/19LLW-Locales%20-%20Varios.md) | Revisar aplicación. |
| 19LMA | [Amueblamiento - Aseos](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LM_AMUEBLAMIENTO/19LMA-Amueblamiento%20-%20Aseos.md) | Revisar aplicación. |
| 19LMC | [Amueblamiento - Comedores](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LM_AMUEBLAMIENTO/19LMC-Amueblamiento%20-%20Comedores.md) | Revisar aplicación. |
| 19LMS | [Amueblamiento - Salas primeros auxilios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LM_AMUEBLAMIENTO/19LMS-Amueblamiento%20-%20Salas%20primeros%20auxilios.md) | Revisar aplicación. |
| 19LMV | [Amueblamiento - Vestuarios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LM_AMUEBLAMIENTO/19LMV-Amueblamiento%20-%20Vestuarios.md) | Revisar aplicación. |
| 19LMW | [Amueblamiento - Varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LM_AMUEBLAMIENTO/19LMW-Amueblamiento%20-%20Varios.md) | Revisar aplicación. |
| 19LPA | [Prefabricados - Aseos](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LP_PREFABRICADOS/19LPA-Prefabricados%20-%20Aseos.md) | Revisar aplicación. |
| 19LPC | [Prefabricados - Comedores](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LP_PREFABRICADOS/19LPC-Prefabricados%20-%20Comedores.md) | Revisar aplicación. |
| 19LPS | [Prefabricados - Salas primeros auxilios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LP_PREFABRICADOS/19LPS-Prefabricados%20-%20Salas%20primeros%20auxilios.md) | Revisar aplicación. |
| 19LPV | [Prefabricados - Vestuarios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LP_PREFABRICADOS/19LPV-Prefabricados%20-%20Vestuarios.md) | Revisar aplicación. |
| 19LPW | [Prefabricados - Varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LP_PREFABRICADOS/19LPW-Prefabricados%20-%20Varios.md) | Revisar aplicación. |
| 19LWW | [Varios - Varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LW_VARIOS/19LWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 19SCB | [Colectiva - Barandillas](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCB-Colectiva%20-%20Barandillas.md) | Revisar aplicación. |
| 19SCH | [Colectiva - Protección de huecos](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCH-Colectiva%20-%20Protecci%C3%B3n%20de%20huecos.md) | Revisar aplicación. |
| 19SCI | [Colectiva - Protección contra incendios](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCI-Colectiva%20-%20Protecci%C3%B3n%20contra%20incendios.md) | Revisar aplicación. |
| 19SCP | [Colectiva - Pasos cubiertos](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCP-Colectiva%20-%20Pasos%20cubiertos.md) | Revisar aplicación. |
| 19SCR | [Colectiva - Redes](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCR-Colectiva%20-%20Redes.md) | Revisar aplicación. |
| 19SCT | [Colectiva - Toldos](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCT-Colectiva%20-%20Toldos.md) | Revisar aplicación. |
| 19SCV | [Colectiva - Ventilaciones](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCV-Colectiva%20-%20Ventilaciones.md) | Revisar aplicación. |
| 19SCW | [Colectiva - Varios](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/19SCW-Colectiva%20-%20Varios.md) | Revisar aplicación. |
| 19SIC | [Individual - Cabeza](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SI_INDIVIDUAL/19SIC-Individual%20-%20Cabeza.md) | Revisar aplicación. |
| 19SIM | [Individual - Manos](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SI_INDIVIDUAL/19SIM-Individual%20-%20Manos.md) | Revisar aplicación. |
| 19SIP | [Individual - Pies](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SI_INDIVIDUAL/19SIP-Individual%20-%20Pies.md) | Revisar aplicación. |
| 19SIT | [Individual - Tronco, piernas y brazos](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SI_INDIVIDUAL/19SIT-Individual%20-%20Tronco%2C%20piernas%20y%20brazos.md) | Revisar aplicación. |
| 19SIW | [Individual - Varios](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SI_INDIVIDUAL/19SIW-Individual%20-%20Varios.md) | Revisar aplicación. |
| 19SSA | [Señalizaciones y acotamientos - Acotamiento](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SS_SE%C3%91ALIZACIONES_Y_ACOTAMIENTOS/19SSA-Se%C3%B1alizaciones%20y%20acotamientos%20-%20Acotamiento.md) | Revisar aplicación. |
| 19SSS | [Señalizaciones y acotamientos - Señalización](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SS_SE%C3%91ALIZACIONES_Y_ACOTAMIENTOS/19SSS-Se%C3%B1alizaciones%20y%20acotamientos%20-%20Se%C3%B1alizaci%C3%B3n.md) | Revisar aplicación. |
| 19SSW | [Señalizaciones y acotamientos - Varios](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SS_SE%C3%91ALIZACIONES_Y_ACOTAMIENTOS/19SSW-Se%C3%B1alizaciones%20y%20acotamientos%20-%20Varios.md) | Revisar aplicación. |
| 19SWW | [Varios - Varios](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SW_VARIOS/19SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 19WFF | [Formación específica - Formación específica](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WF_FORMACI%C3%93N_ESPEC%C3%8DFICA/19WFF-Formaci%C3%B3n%20espec%C3%ADfica%20-%20Formaci%C3%B3n%20espec%C3%ADfica.md) | Revisar aplicación. |
| 19WFW | [Formación específica - Varios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WF_FORMACI%C3%93N_ESPEC%C3%8DFICA/19WFW-Formaci%C3%B3n%20espec%C3%ADfica%20-%20Varios.md) | Revisar aplicación. |
| 19WMM | [Medicina preventiva - Medicina preventiva](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WM_MEDICINA_PREVENTIVA/19WMM-Medicina%20preventiva%20-%20Medicina%20preventiva.md) | Revisar aplicación. |
| 19WMW | [Medicina preventiva - Varios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WM_MEDICINA_PREVENTIVA/19WMW-Medicina%20preventiva%20-%20Varios.md) | Revisar aplicación. |
| 19WPP | [Primeros auxilios - Primeros auxilios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WP_PRIMEROS_AUXILIOS/19WPP-Primeros%20auxilios%20-%20Primeros%20auxilios.md) | Revisar aplicación. |
| 19WPW | [Primeros auxilios - Varios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WP_PRIMEROS_AUXILIOS/19WPW-Primeros%20auxilios%20-%20Varios.md) | Revisar aplicación. |
| 19WSS | [Seguimiento y control interno - Seguimiento y control](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WS_SEGUIMIENTO_Y_CONTROL_INTERNO/19WSS-Seguimiento%20y%20control%20interno%20-%20Seguimiento%20y%20control.md) | Revisar aplicación. |
| 19WSW | [Seguimiento y control interno - Varios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WS_SEGUIMIENTO_Y_CONTROL_INTERNO/19WSW-Seguimiento%20y%20control%20interno%20-%20Varios.md) | Revisar aplicación. |
| 19WWW | [Varios - Varios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WW_VARIOS/19WWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 21AAL | [ARCOS Y BÓVEDAS DE LADRILLO - Limpieza y tratamientos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/21AAL-ARCOS%20Y%20B%C3%93VEDAS%20DE%20LADRILLO%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21AAR | [ARCOS Y BÓVEDAS DE LADRILLO - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/21AAR-ARCOS%20Y%20B%C3%93VEDAS%20DE%20LADRILLO%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21AAS | [ARCOS Y BÓVEDAS DE LADRILLO - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/21AAS-ARCOS%20Y%20B%C3%93VEDAS%20DE%20LADRILLO%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21AAW | [ARCOS Y BÓVEDAS DE LADRILLO - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/21AAW-ARCOS%20Y%20B%C3%93VEDAS%20DE%20LADRILLO%20-%20Varios.md) | Revisar aplicación. |
| 21ABL | [FÁBRICAS DE BLOQUES - Limpieza y tratamiento](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AB_F%C3%81BRICAS_DE_BLOQUES/21ABL-F%C3%81BRICAS%20DE%20BLOQUES%20-%20Limpieza%20y%20tratamiento.md) | Revisar aplicación. |
| 21ABR | [FÁBRICAS DE BLOQUES - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AB_F%C3%81BRICAS_DE_BLOQUES/21ABR-F%C3%81BRICAS%20DE%20BLOQUES%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21ABS | [FÁBRICAS DE BLOQUES - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AB_F%C3%81BRICAS_DE_BLOQUES/21ABS-F%C3%81BRICAS%20DE%20BLOQUES%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21ABW | [FÁBRICAS DE BLOQUES - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AB_F%C3%81BRICAS_DE_BLOQUES/21ABW-F%C3%81BRICAS%20DE%20BLOQUES%20-%20Varios.md) | Revisar aplicación. |
| 21ACL | [CANTERÍA - Limpieza y tratamientos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AC_CANTER%C3%8DA/21ACL-CANTER%C3%8DA%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21ACR | [CANTERÍA - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AC_CANTER%C3%8DA/21ACR-CANTER%C3%8DA%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21ACS | [CANTERÍA - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AC_CANTER%C3%8DA/21ACS-CANTER%C3%8DA%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21ACW | [CANTERÍA - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AC_CANTER%C3%8DA/21ACW-CANTER%C3%8DA%20-%20Varios.md) | Revisar aplicación. |
| 21AEL | [CERRAMIENTOS ESPECIALES - Limpieza y tratamientos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AE_CERRAMIENTOS_ESPECIALES/21AEL-CERRAMIENTOS%20ESPECIALES%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21AER | [CERRAMIENTOS ESPECIALES - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AE_CERRAMIENTOS_ESPECIALES/21AER-CERRAMIENTOS%20ESPECIALES%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21AES | [CERRAMIENTOS ESPECIALES - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AE_CERRAMIENTOS_ESPECIALES/21AES-CERRAMIENTOS%20ESPECIALES%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21AEW | [CERRAMIENTOS ESPECIALES - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AE_CERRAMIENTOS_ESPECIALES/21AEW-CERRAMIENTOS%20ESPECIALES%20-%20Varios.md) | Revisar aplicación. |
| 21ALA | [LADRILLO - Apertura y modificaciones de huecos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/21ALA-LADRILLO%20-%20Apertura%20y%20modificaciones%20de%20huecos.md) | Revisar aplicación. |
| 21ALL | [LADRILLO - Limpieza y tratamientos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/21ALL-LADRILLO%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21ALM | [LADRILLO - Macizados y recrecidos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/21ALM-LADRILLO%20-%20Macizados%20y%20recrecidos.md) | Revisar aplicación. |
| 21ALR | [LADRILLO - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/21ALR-LADRILLO%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21ALS | [LADRILLO - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/21ALS-LADRILLO%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21ALW | [LADRILLO - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/21ALW-LADRILLO%20-%20Varios.md) | Revisar aplicación. |
| 21APL | [PREFABRICADOS - Limpieza y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AP_PREFABRICADOS/21APL-PREFABRICADOS%20-%20Limpieza%20y%20reparaciones.md) | Revisar aplicación. |
| 21APR | [PREFABRICADOS - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AP_PREFABRICADOS/21APR-PREFABRICADOS%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21APS | [PREFABRICADOS - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AP_PREFABRICADOS/21APS-PREFABRICADOS%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21APW | [PREFABRICADOS - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AP_PREFABRICADOS/21APW-PREFABRICADOS%20-%20Varios.md) | Revisar aplicación. |
| 21ATL | [CERRAMIENTOS TIPO - Limpieza y tratamientos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AT_CERRAMIENTOS_TIPO/21ATL-CERRAMIENTOS%20TIPO%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21ATR | [CERRAMIENTOS TIPO - Refuerzos y adaptaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AT_CERRAMIENTOS_TIPO/21ATR-CERRAMIENTOS%20TIPO%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21ATS | [CERRAMIENTOS TIPO - Sustituciones y reparaciones](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AT_CERRAMIENTOS_TIPO/21ATS-CERRAMIENTOS%20TIPO%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21ATW | [CERRAMIENTOS TIPO - Varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AT_CERRAMIENTOS_TIPO/21ATW-CERRAMIENTOS%20TIPO%20-%20Varios.md) | Revisar aplicación. |
| 21AWM | [VARIOS - Macizados y recrecidos](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AW_VARIOS/21AWM-VARIOS%20-%20Macizados%20y%20recrecidos.md) | Revisar aplicación. |
| 21EML | [Mobiliario - Limpieza y tratamientos](21_MANTENIMIENTO/21E_EQUIPAMIENTO/21EM_MOBILIARIO/21EML-Mobiliario%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21EMR | [Mobiliario - Refuerzos y adaptaciones](21_MANTENIMIENTO/21E_EQUIPAMIENTO/21EM_MOBILIARIO/21EMR-Mobiliario%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21EMS | [Mobiliario - Sustituciones y reposiciones](21_MANTENIMIENTO/21E_EQUIPAMIENTO/21EM_MOBILIARIO/21EMS-Mobiliario%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21EMV | [Mobiliario - Varios](21_MANTENIMIENTO/21E_EQUIPAMIENTO/21EM_MOBILIARIO/21EMV-Mobiliario%20-%20Varios.md) | Revisar aplicación. |
| 21ICA | [CLIMATIZACIÓN - Aire acondicionado](21_MANTENIMIENTO/21I_INSTALACIONES/21IC_CLIMATIZACI%C3%93N/21ICA-CLIMATIZACI%C3%93N%20-%20Aire%20acondicionado.md) | Revisar aplicación. |
| 21ICC | [CLIMATIZACIÓN - Calefacción](21_MANTENIMIENTO/21I_INSTALACIONES/21IC_CLIMATIZACI%C3%93N/21ICC-CLIMATIZACI%C3%93N%20-%20Calefacci%C3%B3n.md) | Revisar aplicación. |
| 21ICG | [CLIMATIZACIÓN - Griferías](21_MANTENIMIENTO/21I_INSTALACIONES/21IC_CLIMATIZACI%C3%93N/21ICG-CLIMATIZACI%C3%93N%20-%20Grifer%C3%ADas.md) | Revisar aplicación. |
| 21ICV | [CLIMATIZACIÓN - Ventilación](21_MANTENIMIENTO/21I_INSTALACIONES/21IC_CLIMATIZACI%C3%93N/21ICV-CLIMATIZACI%C3%93N%20-%20Ventilaci%C3%B3n.md) | Revisar aplicación. |
| 21ICW | [CLIMATIZACIÓN - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IC_CLIMATIZACI%C3%93N/21ICW-CLIMATIZACI%C3%93N%20-%20Varios.md) | Revisar aplicación. |
| 21IEA | [ELÉCTRICAS - Acometidas](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IEA-EL%C3%89CTRICAS%20-%20Acometidas.md) | Revisar aplicación. |
| 21IEI | [ELÉCTRICAS - Interruptores](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IEI-EL%C3%89CTRICAS%20-%20Interruptores.md) | Revisar aplicación. |
| 21IEK | [ELÉCTRICAS - Contadores](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IEK-EL%C3%89CTRICAS%20-%20Contadores.md) | Revisar aplicación. |
| 21IEL | [ELÉCTRICAS - Puntos de luz](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IEL-EL%C3%89CTRICAS%20-%20Puntos%20de%20luz.md) | Revisar aplicación. |
| 21IEP | [ELÉCTRICAS - Puestas a tierra](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IEP-EL%C3%89CTRICAS%20-%20Puestas%20a%20tierra.md) | Revisar aplicación. |
| 21IER | [ELÉCTRICAS - Lineas generales de alimentación](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IER-EL%C3%89CTRICAS%20-%20Lineas%20generales%20de%20alimentaci%C3%B3n.md) | Revisar aplicación. |
| 21IET | [ELÉCTRICAS - Tomas de corriente](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IET-EL%C3%89CTRICAS%20-%20Tomas%20de%20corriente.md) | Revisar aplicación. |
| 21IEW | [ELÉCTRICAS - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/21IEW-EL%C3%89CTRICAS%20-%20Varios.md) | Revisar aplicación. |
| 21IFA | [FONTANERÍA - Acometidas y contadores](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFA-FONTANER%C3%8DA%20-%20Acometidas%20y%20contadores.md) | Revisar aplicación. |
| 21IFC | [FONTANERÍA - Canalización agua caliente](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFC-FONTANER%C3%8DA%20-%20Canalizaci%C3%B3n%20agua%20caliente.md) | Revisar aplicación. |
| 21IFD | [FONTANERÍA - Desagües](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFD-FONTANER%C3%8DA%20-%20Desag%C3%BCes.md) | Revisar aplicación. |
| 21IFF | [FONTANERÍA - Calanizaciones agua fría](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFF-FONTANER%C3%8DA%20-%20Calanizaciones%20agua%20fr%C3%ADa.md) | Revisar aplicación. |
| 21IFS | [FONTANERÍA - Aparatos sanitarios](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFS-FONTANER%C3%8DA%20-%20Aparatos%20sanitarios.md) | Revisar aplicación. |
| 21IFT | [FONTANERÍA - Termos y calentadores](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFT-FONTANER%C3%8DA%20-%20Termos%20y%20calentadores.md) | Revisar aplicación. |
| 21IFW | [FONTANERÍA - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/21IFW-FONTANER%C3%8DA%20-%20Varios.md) | Revisar aplicación. |
| 21IKD | [COMUNICACIÓN - Datos](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKD-COMUNICACI%C3%93N%20-%20Datos.md) | Revisar aplicación. |
| 21IKE | [COMUNICACIÓN - Electroacústicas](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKE-COMUNICACI%C3%93N%20-%20Electroac%C3%BAsticas.md) | Revisar aplicación. |
| 21IKF | [COMUNICACIÓN - Infraestructuras](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKF-COMUNICACI%C3%93N%20-%20Infraestructuras.md) | Revisar aplicación. |
| 21IKI | [COMUNICACIÓN - Intercomunicación](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKI-COMUNICACI%C3%93N%20-%20Intercomunicaci%C3%B3n.md) | Revisar aplicación. |
| 21IKR | [COMUNICACIÓN - Radio](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKR-COMUNICACI%C3%93N%20-%20Radio.md) | Revisar aplicación. |
| 21IKS | [COMUNICACIÓN - Sustitución y reposiciones](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKS-COMUNICACI%C3%93N%20-%20Sustituci%C3%B3n%20y%20reposiciones.md) | Revisar aplicación. |
| 21IKT | [COMUNICACIÓN - Telefonía](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKT-COMUNICACI%C3%93N%20-%20Telefon%C3%ADa.md) | Revisar aplicación. |
| 21IKV | [COMUNICACIÓN - Televisión](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKV-COMUNICACI%C3%93N%20-%20Televisi%C3%B3n.md) | Revisar aplicación. |
| 21IKW | [COMUNICACIÓN - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/21IKW-COMUNICACI%C3%93N%20-%20Varios.md) | Revisar aplicación. |
| 21ILB | [GASES Y LICUADOS - Butano](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILB-GASES%20Y%20LICUADOS%20-%20Butano.md) | Revisar aplicación. |
| 21ILC | [GASES Y LICUADOS - Gas ciudad](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILC-GASES%20Y%20LICUADOS%20-%20Gas%20ciudad.md) | Revisar aplicación. |
| 21ILF | [GASES Y LICUADOS - Fuel-oil](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILF-GASES%20Y%20LICUADOS%20-%20Fuel-oil.md) | Revisar aplicación. |
| 21ILG | [GASES Y LICUADOS - Gasóleo](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILG-GASES%20Y%20LICUADOS%20-%20Gas%C3%B3leo.md) | Revisar aplicación. |
| 21ILN | [GASES Y LICUADOS - Gas Natural](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILN-GASES%20Y%20LICUADOS%20-%20Gas%20Natural.md) | Revisar aplicación. |
| 21ILP | [GASES Y LICUADOS - Propano](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILP-GASES%20Y%20LICUADOS%20-%20Propano.md) | Revisar aplicación. |
| 21ILW | [GASES Y LICUADOS - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/21ILW-GASES%20Y%20LICUADOS%20-%20Varios.md) | Revisar aplicación. |
| 21IMA | [ELECTRO-MECÁNICAS - Ascensores y montacargas](21_MANTENIMIENTO/21I_INSTALACIONES/21IM_ELECTRO_MEC%C3%81NICAS/21IMA-ELECTRO-MEC%C3%81NICAS%20-%20Ascensores%20y%20montacargas.md) | Revisar aplicación. |
| 21IMB | [ELECTRO-MECÁNICAS - Equipos de bombeo](21_MANTENIMIENTO/21I_INSTALACIONES/21IM_ELECTRO_MEC%C3%81NICAS/21IMB-ELECTRO-MEC%C3%81NICAS%20-%20Equipos%20de%20bombeo.md) | Revisar aplicación. |
| 21IME | [ELECTRO-MECÁNICAS - Escaleras, rampas y tapices](21_MANTENIMIENTO/21I_INSTALACIONES/21IM_ELECTRO_MEC%C3%81NICAS/21IME-ELECTRO-MEC%C3%81NICAS%20-%20Escaleras%2C%20rampas%20y%20tapices.md) | Revisar aplicación. |
| 21IMW | [ELECTRO-MECÁNICAS - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IM_ELECTRO_MEC%C3%81NICAS/21IMW-ELECTRO-MEC%C3%81NICAS%20-%20Varios.md) | Revisar aplicación. |
| 21INL | [ENERGÍA SOLAR - Limpieza y tratamientos](21_MANTENIMIENTO/21I_INSTALACIONES/21IN_ENERG%C3%8DA_SOLAR/21INL-ENERG%C3%8DA%20SOLAR%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21INR | [ENERGÍA SOLAR - Refuerzos y adaptaciones](21_MANTENIMIENTO/21I_INSTALACIONES/21IN_ENERG%C3%8DA_SOLAR/21INR-ENERG%C3%8DA%20SOLAR%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21INS | [ENERGÍA SOLAR - Sustituciones y reposiciones](21_MANTENIMIENTO/21I_INSTALACIONES/21IN_ENERG%C3%8DA_SOLAR/21INS-ENERG%C3%8DA%20SOLAR%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21INW | [ENERGÍA SOLAR - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IN_ENERG%C3%8DA_SOLAR/21INW-ENERG%C3%8DA%20SOLAR%20-%20Varios.md) | Revisar aplicación. |
| 21IOL | [ENERGÍA FOTOVOLTAICA - Limpieza y tratamientos](21_MANTENIMIENTO/21I_INSTALACIONES/21IO_ENERG%C3%8DA_FOTOVOLTAICA/21IOL-ENERG%C3%8DA%20FOTOVOLTAICA%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21IOR | [ENERGÍA FOTOVOLTAICA - Refuerzos y adaptaciones](21_MANTENIMIENTO/21I_INSTALACIONES/21IO_ENERG%C3%8DA_FOTOVOLTAICA/21IOR-ENERG%C3%8DA%20FOTOVOLTAICA%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21IOS | [ENERGÍA FOTOVOLTAICA - Sustituciones y reposiciones](21_MANTENIMIENTO/21I_INSTALACIONES/21IO_ENERG%C3%8DA_FOTOVOLTAICA/21IOS-ENERG%C3%8DA%20FOTOVOLTAICA%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21IOW | [ENERGÍA FOTOVOLTAICA - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IO_ENERG%C3%8DA_FOTOVOLTAICA/21IOW-ENERG%C3%8DA%20FOTOVOLTAICA%20-%20Varios.md) | Revisar aplicación. |
| 21IPI | [PROTECCIONES - Contra incendios](21_MANTENIMIENTO/21I_INSTALACIONES/21IP_PROTECCIONES/21IPI-PROTECCIONES%20-%20Contra%20incendios.md) | Revisar aplicación. |
| 21IPP | [PROTECCIONES - Pararrayos](21_MANTENIMIENTO/21I_INSTALACIONES/21IP_PROTECCIONES/21IPP-PROTECCIONES%20-%20Pararrayos.md) | Revisar aplicación. |
| 21IPR | [PROTECCIONES - Antirrobo](21_MANTENIMIENTO/21I_INSTALACIONES/21IP_PROTECCIONES/21IPR-PROTECCIONES%20-%20Antirrobo.md) | Revisar aplicación. |
| 21IPW | [PROTECCIONES - Varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IP_PROTECCIONES/21IPW-PROTECCIONES%20-%20Varios.md) | Revisar aplicación. |
| 21KAL | [Armarios - Limpieza y tratamientos](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KA_ARMARIOS/21KAL-Armarios%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21KAR | [Armarios - Refuerzos y adaptaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KA_ARMARIOS/21KAR-Armarios%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21KAS | [Armarios - Sustituciones y reparaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KA_ARMARIOS/21KAS-Armarios%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21KAV | [Armarios - Varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KA_ARMARIOS/21KAV-Armarios%20-%20Varios.md) | Revisar aplicación. |
| 21KBL | [Barandillas y rejas - Limpieza y tratamiento](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KB_BARANDILLAS_Y_REJAS/21KBL-Barandillas%20y%20rejas%20-%20Limpieza%20y%20tratamiento.md) | Revisar aplicación. |
| 21KBR | [Barandillas y rejas - Refuerzo y adaptaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KB_BARANDILLAS_Y_REJAS/21KBR-Barandillas%20y%20rejas%20-%20Refuerzo%20y%20adaptaciones.md) | Revisar aplicación. |
| 21KBS | [Barandillas y rejas - Sustituciones y reparaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KB_BARANDILLAS_Y_REJAS/21KBS-Barandillas%20y%20rejas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21KBV | [Barandillas y rejas - Varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KB_BARANDILLAS_Y_REJAS/21KBV-Barandillas%20y%20rejas%20-%20Varios.md) | Revisar aplicación. |
| 21KCL | [Celosías y persianas - Limpieza y tratamientos](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KC_CELOS%C3%8DAS_Y_PERSIANAS/21KCL-Celos%C3%ADas%20y%20persianas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21KCR | [Celosías y persianas - Refuerzos y adaptaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KC_CELOS%C3%8DAS_Y_PERSIANAS/21KCR-Celos%C3%ADas%20y%20persianas%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21KCS | [Celosías y persianas - Sustituciones y reposiciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KC_CELOS%C3%8DAS_Y_PERSIANAS/21KCS-Celos%C3%ADas%20y%20persianas%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21KCW | [Celosías y persianas - Varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KC_CELOS%C3%8DAS_Y_PERSIANAS/21KCW-Celos%C3%ADas%20y%20persianas%20-%20Varios.md) | Revisar aplicación. |
| 21KML | [Mamparas - Limpieza y tratamientos](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KM_MAMPARAS/21KML-Mamparas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21KMR | [Mamparas - Refuerzos y adaptaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KM_MAMPARAS/21KMR-Mamparas%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21KMS | [Mamparas - Sustituciones y reparaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KM_MAMPARAS/21KMS-Mamparas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21KMW | [Mamparas - Varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KM_MAMPARAS/21KMW-Mamparas%20-%20Varios.md) | Revisar aplicación. |
| 21KPL | [Puertas - Limpieza y tratamientos](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KP_PUERTAS/21KPL-Puertas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21KPR | [Puertas - Refuerzos y adaptaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KP_PUERTAS/21KPR-Puertas%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21KPS | [Puertas - Sustituciones y reparaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KP_PUERTAS/21KPS-Puertas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21KPV | [Puertas - Varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KP_PUERTAS/21KPV-Puertas%20-%20Varios.md) | Revisar aplicación. |
| 21KVL | [Ventanas - Limpieza y tratamientos](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KV_VENTANAS/21KVL-Ventanas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21KVR | [Ventanas - Refuerzos y adaptaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KV_VENTANAS/21KVR-Ventanas%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21KVS | [Ventanas - Sustituciones y reparaciones](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KV_VENTANAS/21KVS-Ventanas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21KVW | [Ventanas - Varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KV_VENTANAS/21KVW-Ventanas%20-%20Varios.md) | Revisar aplicación. |
| 21PEA | [Exteriores - Acrílicas](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEA-Exteriores%20-%20Acr%C3%ADlicas.md) | Revisar aplicación. |
| 21PEB | [Exteriores - Barniz](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEB-Exteriores%20-%20Barniz.md) | Revisar aplicación. |
| 21PEC | [Exteriores - Cal](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEC-Exteriores%20-%20Cal.md) | Revisar aplicación. |
| 21PEE | [Exteriores - Esmalte](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEE-Exteriores%20-%20Esmalte.md) | Revisar aplicación. |
| 21PEO | [Exteriores - Óleo](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEO-Exteriores%20-%20%C3%93leo.md) | Revisar aplicación. |
| 21PEP | [Exteriores - Pétreas](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEP-Exteriores%20-%20P%C3%A9treas.md) | Revisar aplicación. |
| 21PES | [Exteriores - Silicato](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PES-Exteriores%20-%20Silicato.md) | Revisar aplicación. |
| 21PEV | [Exteriores - Varios](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/21PEV-Exteriores%20-%20Varios.md) | Revisar aplicación. |
| 21PIL | [Interiores - Limpieza y tratamientos](21_MANTENIMIENTO/21P_PINTURAS/21PI_INTERIORES/21PIL-Interiores%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21PIS | [Interiores - Sustituciones](21_MANTENIMIENTO/21P_PINTURAS/21PI_INTERIORES/21PIS-Interiores%20-%20Sustituciones.md) | Revisar aplicación. |
| 21PIT | [Interiores - Trabajos especiales](21_MANTENIMIENTO/21P_PINTURAS/21PI_INTERIORES/21PIT-Interiores%20-%20Trabajos%20especiales.md) | Revisar aplicación. |
| 21PIW | [Interiores - Varios](21_MANTENIMIENTO/21P_PINTURAS/21PI_INTERIORES/21PIW-Interiores%20-%20Varios.md) | Revisar aplicación. |
| 21PVL | [Varios - Limpieza y tratamientos](21_MANTENIMIENTO/21P_PINTURAS/21PV_VARIOS/21PVL-Varios%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21PVS | [Varios - Sustituciones](21_MANTENIMIENTO/21P_PINTURAS/21PV_VARIOS/21PVS-Varios%20-%20Sustituciones.md) | Revisar aplicación. |
| 21PVT | [Varios - Trabajos especiales](21_MANTENIMIENTO/21P_PINTURAS/21PV_VARIOS/21PVT-Varios%20-%20Trabajos%20especiales.md) | Revisar aplicación. |
| 21PVW | [Varios - Varios](21_MANTENIMIENTO/21P_PINTURAS/21PV_VARIOS/21PVW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 21QHL | [Horizontales - Limpieza y tratamientos](21_MANTENIMIENTO/21Q_CUBIERTAS/21QH_HORIZONTALES/21QHL-Horizontales%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21QHR | [Horizontales - Refuerzos y adaptaciones](21_MANTENIMIENTO/21Q_CUBIERTAS/21QH_HORIZONTALES/21QHR-Horizontales%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21QHS | [Horizontales - Sustituciones y reparaciones](21_MANTENIMIENTO/21Q_CUBIERTAS/21QH_HORIZONTALES/21QHS-Horizontales%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21QHW | [Horizontales - Varios](21_MANTENIMIENTO/21Q_CUBIERTAS/21QH_HORIZONTALES/21QHW-Horizontales%20-%20Varios.md) | Revisar aplicación. |
| 21QIL | [Inclinadas - Limpieza y tratamientos](21_MANTENIMIENTO/21Q_CUBIERTAS/21QI_INCLINADAS/21QIL-Inclinadas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21QIR | [Inclinadas - Refuerzo y adaptaciones](21_MANTENIMIENTO/21Q_CUBIERTAS/21QI_INCLINADAS/21QIR-Inclinadas%20-%20Refuerzo%20y%20adaptaciones.md) | Revisar aplicación. |
| 21QIS | [Inclinadas - Sustituciones y reparaciones](21_MANTENIMIENTO/21Q_CUBIERTAS/21QI_INCLINADAS/21QIS-Inclinadas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21QIW | [Inclinadas - Varios](21_MANTENIMIENTO/21Q_CUBIERTAS/21QI_INCLINADAS/21QIW-Inclinadas%20-%20Varios.md) | Revisar aplicación. |
| 21RPP | [Peldaños - Peldaños](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RP_PELDA%C3%91OS/21RPP-Pelda%C3%B1os%20-%20Pelda%C3%B1os.md) | Revisar aplicación. |
| 21RPW | [Peldaños - Varios](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RP_PELDA%C3%91OS/21RPW-Pelda%C3%B1os%20-%20Varios.md) | Revisar aplicación. |
| 21RSL | [Suelos - Limpieza y tratamientos](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RS_SUELOS/21RSL-Suelos%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21RSR | [Suelos - Refuerzos y adaptaciones](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RS_SUELOS/21RSR-Suelos%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21RSS | [Suelos - Sustituciones y reparaciones](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RS_SUELOS/21RSS-Suelos%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21RSW | [Suelos - Varios](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RS_SUELOS/21RSW-Suelos%20-%20Varios.md) | Revisar aplicación. |
| 21RTL | [Techos - Limpieza y tratamientos](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RT_TECHOS/21RTL-Techos%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21RTR | [Techos - Refuerzos y adaptaciones](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RT_TECHOS/21RTR-Techos%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21RTS | [Techos - Sustituciones y reparaciones](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RT_TECHOS/21RTS-Techos%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21RTW | [Techos - Varios](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RT_TECHOS/21RTW-Techos%20-%20Varios.md) | Revisar aplicación. |
| 21RVL | [Paramentos verticales - Limpieza y tratamientos](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RV_PARAMENTOS_VERTICALES/21RVL-Paramentos%20verticales%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21RVR | [Paramentos verticales - Refuerzos y adaptaciones](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RV_PARAMENTOS_VERTICALES/21RVR-Paramentos%20verticales%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21RVS | [Paramentos verticales - Sustituciones y reparaciones](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RV_PARAMENTOS_VERTICALES/21RVS-Paramentos%20verticales%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21RVW | [Paramentos verticales - Varios](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RV_PARAMENTOS_VERTICALES/21RVW-Paramentos%20verticales%20-%20Varios.md) | Revisar aplicación. |
| 21SCL | [Redes colgadas - Limpieza y tratamientos](21_MANTENIMIENTO/21S_SANEAMIENTO/21SC_REDES_COLGADAS/21SCL-Redes%20colgadas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21SCR | [Redes colgadas - Refuerzos y adaptaciones](21_MANTENIMIENTO/21S_SANEAMIENTO/21SC_REDES_COLGADAS/21SCR-Redes%20colgadas%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21SCS | [Redes colgadas - Sustituciones y reparaciones](21_MANTENIMIENTO/21S_SANEAMIENTO/21SC_REDES_COLGADAS/21SCS-Redes%20colgadas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21SCW | [Redes colgadas - Varios](21_MANTENIMIENTO/21S_SANEAMIENTO/21SC_REDES_COLGADAS/21SCW-Redes%20colgadas%20-%20Varios.md) | Revisar aplicación. |
| 21SEL | [Redes enterradas - Limpieza y tratamientos](21_MANTENIMIENTO/21S_SANEAMIENTO/21SE_REDES_ENTERRADAS/21SEL-Redes%20enterradas%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21SER | [Redes enterradas - Refuerzos y adaptaciones](21_MANTENIMIENTO/21S_SANEAMIENTO/21SE_REDES_ENTERRADAS/21SER-Redes%20enterradas%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21SES | [Redes enterradas - Sustituciones y reparaciones](21_MANTENIMIENTO/21S_SANEAMIENTO/21SE_REDES_ENTERRADAS/21SES-Redes%20enterradas%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21SEW | [Redes enterradas - Varios](21_MANTENIMIENTO/21S_SANEAMIENTO/21SE_REDES_ENTERRADAS/21SEW-Redes%20enterradas%20-%20Varios.md) | Revisar aplicación. |
| 21SVL | [Redes verticales - Limpieza y tratamiento](21_MANTENIMIENTO/21S_SANEAMIENTO/21SV_REDES_VERTICALES/21SVL-Redes%20verticales%20-%20Limpieza%20y%20tratamiento.md) | Revisar aplicación. |
| 21SVR | [Redes verticales - Refuerzos y adaptaciones](21_MANTENIMIENTO/21S_SANEAMIENTO/21SV_REDES_VERTICALES/21SVR-Redes%20verticales%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21SVS | [Redes verticales - Sustituciones y reparaciones](21_MANTENIMIENTO/21S_SANEAMIENTO/21SV_REDES_VERTICALES/21SVS-Redes%20verticales%20-%20Sustituciones%20y%20reparaciones.md) | Revisar aplicación. |
| 21SVW | [Redes verticales - Varios](21_MANTENIMIENTO/21S_SANEAMIENTO/21SV_REDES_VERTICALES/21SVW-Redes%20verticales%20-%20Varios.md) | Revisar aplicación. |
| 21SWW | [Varios - Varios](21_MANTENIMIENTO/21S_SANEAMIENTO/21SW_VARIOS/21SWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 21TLM | [Limpieza y tratamientos - Mobiliario](21_MANTENIMIENTO/21T_TRABAJOS_PREVIOS/21TL_LIMPIEZA_Y_TRATAMIENTOS/21TLM-Limpieza%20y%20tratamientos%20-%20Mobiliario.md) | Revisar aplicación. |
| 21TLP | [Limpieza y tratamientos - Paramentos verticales y horizontales](21_MANTENIMIENTO/21T_TRABAJOS_PREVIOS/21TL_LIMPIEZA_Y_TRATAMIENTOS/21TLP-Limpieza%20y%20tratamientos%20-%20Paramentos%20verticales%20y%20horizontales.md) | Revisar aplicación. |
| 21VAL | [Vidrios aislantes - Limpieza y tratamientos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VA_VIDRIOS_AISLANTES/21VAL-Vidrios%20aislantes%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21VAR | [Vidrios aislantes - Refuerzo y adaptaciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VA_VIDRIOS_AISLANTES/21VAR-Vidrios%20aislantes%20-%20Refuerzo%20y%20adaptaciones.md) | Revisar aplicación. |
| 21VAS | [Vidrios aislantes - Sustituciones y reposiciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VA_VIDRIOS_AISLANTES/21VAS-Vidrios%20aislantes%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21VAW | [Vidrios aislantes - Varios](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VA_VIDRIOS_AISLANTES/21VAW-Vidrios%20aislantes%20-%20Varios.md) | Revisar aplicación. |
| 21VLL | [Vidrios laminados - Limpieza y tratamientos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VL_VIDRIOS_LAMINADOS/21VLL-Vidrios%20laminados%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21VLR | [Vidrios laminados - Refuerzos y adaptaciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VL_VIDRIOS_LAMINADOS/21VLR-Vidrios%20laminados%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21VLS | [Vidrios laminados - Sustituciones y reposiciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VL_VIDRIOS_LAMINADOS/21VLS-Vidrios%20laminados%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21VLW | [Vidrios laminados - Varios](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VL_VIDRIOS_LAMINADOS/21VLW-Vidrios%20laminados%20-%20Varios.md) | Revisar aplicación. |
| 21VNL | [Vidrios sencillos - Limpieza y tratamientos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VN_VIDRIOS_SENCILLOS/21VNL-Vidrios%20sencillos%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21VNR | [Vidrios sencillos - Refuerzo y adaptaciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VN_VIDRIOS_SENCILLOS/21VNR-Vidrios%20sencillos%20-%20Refuerzo%20y%20adaptaciones.md) | Revisar aplicación. |
| 21VNS | [Vidrios sencillos - Sustituciones y reposiciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VN_VIDRIOS_SENCILLOS/21VNS-Vidrios%20sencillos%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21VNW | [Vidrios sencillos - Varios](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VN_VIDRIOS_SENCILLOS/21VNW-Vidrios%20sencillos%20-%20Varios.md) | Revisar aplicación. |
| 21VTL | [Vidrios templados - Limpieza y tratamientos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VT_VIDRIOS_TEMPLADOS/21VTL-Vidrios%20templados%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21VTR | [Vidrios templados - Refuerzos y adaptaciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VT_VIDRIOS_TEMPLADOS/21VTR-Vidrios%20templados%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21VTS | [Vidrios templados - Sustituciones y reposiciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VT_VIDRIOS_TEMPLADOS/21VTS-Vidrios%20templados%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21VTV | [Vidrios templados - Varios](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VT_VIDRIOS_TEMPLADOS/21VTV-Vidrios%20templados%20-%20Varios.md) | Revisar aplicación. |
| 21VWL | [Varios - Limpieza y tratamientos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VW_VARIOS/21VWL-Varios%20-%20Limpieza%20y%20tratamientos.md) | Revisar aplicación. |
| 21VWR | [Varios - Refuerzos y adaptaciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VW_VARIOS/21VWR-Varios%20-%20Refuerzos%20y%20adaptaciones.md) | Revisar aplicación. |
| 21VWS | [Varios - Sustituciones y reposiciones](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VW_VARIOS/21VWS-Varios%20-%20Sustituciones%20y%20reposiciones.md) | Revisar aplicación. |
| 21VWW | [Varios - Varios](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VW_VARIOS/21VWW-Varios%20-%20Varios.md) | Revisar aplicación. |
| 21XWW | [Varios - Varios](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XW_VARIOS/21XWW-Varios%20-%20Varios.md) | Revisar aplicación. |
