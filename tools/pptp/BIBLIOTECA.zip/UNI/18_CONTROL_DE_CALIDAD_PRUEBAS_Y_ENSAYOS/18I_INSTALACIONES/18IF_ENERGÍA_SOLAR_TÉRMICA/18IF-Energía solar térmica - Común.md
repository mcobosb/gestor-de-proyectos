"""
# Energía solar térmica - Común

**Clasificación:** 18IF. **Capítulo:** control de calidad pruebas y ensayos. **Familia:** instalaciones.

"""
## Descripción

Control, prueba o ensayo destinado a verificar las prestaciones del material, elemento o instalación identificado, conforme al plan de control del proyecto.

El objeto de esta ficha es «energía solar térmica», dentro de «instalaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Definir lote, muestreo y método aplicable antes de tomar muestras. Identificar ubicación y condiciones, usar equipos calibrados y personal o laboratorio competente y emitir un informe trazable. Someter los resultados a la aceptación de la dirección facultativa.

Aprobar un protocolo propio del servicio, con aislamiento y condiciones seguras; documentar instrumentos, tramos, consignas y resultados.

Para la variante «energía solar térmica» se comprobarán expresamente instalación, magnitudes, protocolo y límites reglamentarios. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

El informe recogerá muestra o elemento, método y edición, condiciones, resultados, incertidumbre cuando proceda y criterio de evaluación. Un resultado sin umbral de proyecto no acredita conformidad.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

ud de ensayo, muestra, serie o prueba definida, con informe incluido según presupuesto. Diferenciar muestreo, desplazamiento y restitución cuando no formen parte del precio; no abonar aparte controles ya incluidos en la unidad ejecutada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
