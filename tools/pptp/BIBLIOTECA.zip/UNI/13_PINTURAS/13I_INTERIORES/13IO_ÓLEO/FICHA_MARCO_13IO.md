# óleo

**Clasificación:** 13IO. **Capítulo:** pinturas. **Familia:** interiores.

## Descripción

Sistemas de pintura, barniz o protección superficial sobre el soporte y en el ambiente especificados.

El objeto de esta ficha es «óleo», dentro de «interiores». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Identificar y preparar el soporte, eliminar partes no adheridas y comprobar humedad y condiciones ambientales. Aplicar imprimación y capas compatibles respetando consumos y tiempos del sistema aprobado, con ventilación y protección de zonas contiguas.

Comprobar compatibilidad con el soporte interior, ventilación y condiciones de uso y limpieza del local.

Para la variante «óleo» se comprobarán expresamente soporte, acabado, emisiones y resistencia al uso. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar uniformidad, adherencia, cubrición y espesor del sistema cuando su función lo requiera; registrar producto, lote y condiciones de aplicación.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de superficie tratada con regla de huecos y desarrollo de elementos; piezas singulares en m o ud cuando se tipifiquen. Precisar preparación y capas incluidas, sin multiplicar la medición por número de manos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
