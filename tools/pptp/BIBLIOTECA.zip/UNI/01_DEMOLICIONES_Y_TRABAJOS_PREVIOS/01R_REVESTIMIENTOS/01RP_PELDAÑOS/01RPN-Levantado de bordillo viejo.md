"""
## Registro de cambios
- Versión: 4 | Autor: - | Fecha: 11/11/2026 | Cambio: Rev.01
- Versión: 3 | Autor: - | Fecha: 11/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de peldaños - piedras naturales

**Clasificación BCCA:** `01RPN`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Piedras naturales**, dentro de **Peldaños**.
Aplicable a las partidas cuyo código BCCA comienza por `01RPN`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RPN00001 - LEVANTADO DE PELDAÑO Y ZANQUÍN DE PIEDRA NATURAL

**Unidad:** m.

Levantado de peldaño y zanquín de piedra natural, incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medida la longitud inicial por la arista de intersección entre huella y tabica.

### 01RPN00002 - LEVANTADO DE PELDAÑO Y ZANQUÍN DE PIEDRA NATURAL APROV. 50%

**Unidad:** m.

Levantado de peldaño y zanquín de piedra natural, con aprovechamiento para la propiedad del 50%, incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medida la longitud inicial por la arista de intersección entre huella y tabica.

### 01RPN90001 - DEMOLICIÓN SELECTIVA M. MAN. DE PELDAÑO Y ZANQUÍN DE PIEDRA NAT.

**Unidad:** m.

Demolición selectiva con medios manuales de peldaño y zanquín de piedra natural. Medida la longitud inicial por la arista de intersección entre huella y tabica.

### 01RPN90002 - DEMOL. SELECTIVA M. MAN. PELDAÑO Y ZANQUÍN PIEDRA NAT. REUT. 50%

**Unidad:** m.

Demolición selectiva con medios manuales de peldaño y zanquín de piedra natural, con reutilización en la obra del 50%. Medida la longitud inicial por la arista de intersección entre huella y tabica.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Peldaños

**Clasificación:** 01RP  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Levantado y demolición de bordillo existente de granito mediante medios mecánicos y/o manuales en las zonas delimitadas de proyecto, incluyendo la rotura o saneado de su base o solera de hormigón y mortero de agarre desprendido. Incluye pequeñas ayudas de albañilería, medios auxiliares, acopio, carga, transporte y gestión de materiales sobrantes a vertedero autorizado o planta de reciclaje (con canon de vertido desglosado en el estudio de gestión de residuos).

#### Ejecución
	**1. Previos:** Inspección y marcado del tramo de bordillo a retirar, localización y protección de redes de servicios o elementos colindantes a conservar (como acera o calzada adyacentes), y delimitación de la zona de actuación.
	**2. Levantado y demolición:** Desmontado y levantado del bordillo de granito mediante combinación de medios mecánicos (retroexcavadora/pico demoledor) y trabajos manuales con palanqueta y martillo. Picado de la solera y riostra de hormigón de apoyo existente sin dañar los pavimentos o firmes colindantes que deban permanecer.
	**3. Carga, limpieza y transporte:** Recogida, acopio, carga de las piezas retiradas y escombros generados, ayudas de albañilería para la limpieza del cimiento o soporte resultante, y transporte de residuos (RCDs) a vertedero o gestor autorizado, incluyendo la tramitación de los vales de vertido.

#### Medición
	* **Unidad de medida:** Metro lineal (m) de bordillo de granito levantado.
	* **Criterio:** Longitud real ejecutada in situ y comprobada a lo largo del trazado del bordillo retirado.

#### Valoración
El precio unitario (€/m) incluye:
	* Mano de obra, herramientas manuales, maquinaria (medios mecánicos) y medios auxiliares necesarios.
	* Levantado del bordillo de granito, picado de la base/solera de hormigón y mortero de agarre, acopio intermedio y limpieza del tramo.
	* Ayudas de albañilería para la adecuación de la zona de trabajo.
	* Carga de materiales sobrantes, transporte a vertedero/gestor autorizado y gestión de residuos (con canon de vertido contemplado según Estudio de Gestión de Residuos).