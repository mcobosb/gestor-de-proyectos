"""
# Retirada de peldaños - varios

**Clasificación BCCA:** `01RPW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Peldaños**.
Aplicable a las partidas cuyo código BCCA comienza por `01RPW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Peldaños

**Clasificación:** 01RP  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, desmontaje o demolición selectiva de peldaños de revestimiento existentes (huella, contrahuella y remates) exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar servicios/redes ocultas, proteger los elementos colindantes a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el revestimiento limitando el levantado al acabado y material de agarre desprendido, sin dañar la estructura base de la escalera ni los peldaños continuos a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes y gestionar la entrega de residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Metro lineal (m) de peldaño retirado (o metro cuadrado, m², según desglose del presupuesto).
* **Criterio:** Longitud o superficie neta realmente ejecutada y comprobada sobre la geometría de la escalera.

#### Valoración
El precio unitario (€/m o €/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado y medios auxiliares.
* Demolición, desmontaje, acopio intermedio y limpieza de la zona.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
