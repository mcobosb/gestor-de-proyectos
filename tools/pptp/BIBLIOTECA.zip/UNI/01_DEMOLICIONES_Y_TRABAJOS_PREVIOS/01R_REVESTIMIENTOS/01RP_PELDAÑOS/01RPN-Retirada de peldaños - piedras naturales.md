"""
# Retirada de peldaños - piedras naturales

**Clasificación BCCA:** `01RPN`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Piedras naturales**, dentro de **Peldaños**.
Aplicable a las partidas cuyo código BCCA comienza por `01RPN`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RPN00001 - LEVANTADO DE PELDAÑO Y ZANQUÍN DE PIEDRA NATURAL

**Unidad:** m.

Levantado de peldaño y zanquín de piedra natural, incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medida la longitud inicial por la arista de intersección entre huella y tabica.

### 01RPN00002 - LEVANTADO DE PELDAÑO Y ZANQUÍN DE PIEDRA NATURAL APROV. 50%

**Unidad:** m.

Levantado de peldaño y zanquín de piedra natural, con aprovechamiento para la propiedad del 50%, incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medida la longitud inicial por la arista de intersección entre huella y tabica.

### 01RPN90001 - DEMOLICIÓN SELECTIVA M. MAN. DE PELDAÑO Y ZANQUÍN DE PIEDRA NAT.

**Unidad:** m.

Demolición selectiva con medios manuales de peldaño y zanquín de piedra natural. Medida la longitud inicial por la arista de intersección entre huella y tabica.

### 01RPN90002 - DEMOL. SELECTIVA M. MAN. PELDAÑO Y ZANQUÍN PIEDRA NAT. REUT. 50%

**Unidad:** m.

Demolición selectiva con medios manuales de peldaño y zanquín de piedra natural, con reutilización en la obra del 50%. Medida la longitud inicial por la arista de intersección entre huella y tabica.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Peldaños

**Clasificación:** 01RP  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, desmontaje o demolición selectiva de peldaños de revestimiento existentes (huella, contrahuella y remates) exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar servicios/redes ocultas, proteger los elementos colindantes a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el revestimiento limitando el levantado al acabado y material de agarre desprendido, sin dañar la estructura base de la escalera ni los peldaños continuos a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes y gestionar la entrega de residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Metro lineal (m) de peldaño retirado (o metro cuadrado, m², según desglose del presupuesto).
* **Criterio:** Longitud o superficie neta realmente ejecutada y comprobada sobre la geometría de la escalera.

#### Valoración
El precio unitario (€/m o €/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado y medios auxiliares.
* Demolición, desmontaje, acopio intermedio y limpieza de la zona.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
