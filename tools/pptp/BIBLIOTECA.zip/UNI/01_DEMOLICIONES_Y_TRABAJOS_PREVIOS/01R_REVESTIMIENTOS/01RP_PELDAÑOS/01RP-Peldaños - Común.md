# Peldaños - Común

**Clasificación:** 01RP  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

## Descripción
Retirada, desmontaje o demolición selectiva de peldaños de revestimiento existentes (huella, contrahuella y remates) exclusivamente en las zonas delimitadas del proyecto.

## Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar servicios/redes ocultas, proteger los elementos colindantes a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el revestimiento limitando el levantado al acabado y material de agarre desprendido, sin dañar la estructura base de la escalera ni los peldaños continuos a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes y gestionar la entrega de residuos a gestor autorizado.

## Medición
* **Unidad de medida:** Metro lineal (m) de peldaño retirado (o metro cuadrado, m², según desglose del presupuesto).
* **Criterio:** Longitud o superficie neta realmente ejecutada y comprobada sobre la geometría de la escalera.

## Valoración
El precio unitario (€/m o €/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado y medios auxiliares.
* Demolición, desmontaje, acopio intermedio y limpieza de la zona.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).