# REVESTIMIENTOS - varios - Común

**Clasificación:** 01RW  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

## Descripción
Retirada, desmontaje o demolición selectiva de revestimientos no clasificados expresamente en las partidas principales (partida residual), requiriéndose la concreción del elemento y material en la documentación contractual antes de su aplicación.

## Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar servicios/redes ocultas, proteger los elementos a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el revestimiento concreto limitando el levantado a las capas autorizadas, sin dañar los soportes ni elementos colindantes a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de bordes y entregar los residuos a gestor autorizado.

## Medición
* **Unidad de medida:** Unidad (ud), metro lineal (m) o metro cuadrado (m²), según la naturaleza del elemento a retirar definida en el cuadro de precios.
* **Criterio:** Cantidad neta realmente ejecutada y comprobada sobre la geometría de la obra.

## Valoración
El precio unitario (€/ud, €/m o €/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria y medios auxiliares.
* Demolición, desmontaje, acopio intermedio y limpieza de la superficie o zona afectada.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).