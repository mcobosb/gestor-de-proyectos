"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de varios - alféizares

**Clasificación BCCA:** `01RWA`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Alféizares**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `01RWA`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RWA90001 - DEMOLICIÓN SELECTIVA DE ALFÉIZAR DE PIEDRA ARTIFICIAL

**Unidad:** m.

Demolición selectiva de alféizar de piedra artificial. Medida la anchura libre del hueco.

### 01RWA90002 - DEMOLICIÓN SELECTIVA DE ALFÉIZAR DE PIEZAS CERÁMICAS

**Unidad:** m.

Demolición selectiva de alféizar de piezas cerámicas. Medida la anchura libre del hueco.

### 01RWA90003 - DEMOLICIÓN SELECTIVA DE ALFÉIZAR DE PIEDRA NATURAL

**Unidad:** m.

Demolición selectiva de alféizar de piedra natural. Medida la anchura libre del hueco.

### 01RWA90004 - DEMOLICIÓN SELECTIVA DE ALFÉIZAR PIEDRA NATURAL APROV. DEL 50%

**Unidad:** m.

Demolición selectiva de alféizar de piedra natural, incluso p.p. de aprovechamiento del 50% para la propiedad. Medida la anchura libre del hueco.

### 01RWA90005N - DEMOLICIÓN SELECTIVA DE ALFÉIZAR DE CHAPA DE ACERO

**Unidad:** m².

Demolición selectiva de alféizar de chapa de acero. Medida la anchura libre del hueco.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### REVESTIMIENTOS - varios

**Clasificación:** 01RW  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, desmontaje o demolición selectiva de revestimientos no clasificados expresamente en las partidas principales (partida residual), requiriéndose la concreción del elemento y material en la documentación contractual antes de su aplicación.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar servicios/redes ocultas, proteger los elementos a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el revestimiento concreto limitando el levantado a las capas autorizadas, sin dañar los soportes ni elementos colindantes a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de bordes y entregar los residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Unidad (ud), metro lineal (m) o metro cuadrado (m²), según la naturaleza del elemento a retirar definida en el cuadro de precios.
* **Criterio:** Cantidad neta realmente ejecutada y comprobada sobre la geometría de la obra.

#### Valoración
El precio unitario (€/ud, €/m o €/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria y medios auxiliares.
* Demolición, desmontaje, acopio intermedio y limpieza de la superficie o zona afectada.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
