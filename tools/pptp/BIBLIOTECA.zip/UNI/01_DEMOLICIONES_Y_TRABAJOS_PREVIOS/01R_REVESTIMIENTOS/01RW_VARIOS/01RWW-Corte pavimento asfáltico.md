"""
## Registro de cambios
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.02
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de varios

**Clasificación BCCA:** `01RWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `01RWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### REVESTIMIENTOS - varios

**Clasificación:** 01RW  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Corte por medios mecánicos mediante disco de diamante de pavimento de mezcla bituminosa (asfáltico) o de hormigón en calzada, hasta una profundidad de 12 cm, previo a los trabajos de zanjado, demolición o apertura de calas. Incluye la parte proporcional de replanteo, marcaje de las líneas de corte y disposición de maquinaria auxiliar de obra.

#### Ejecución
	**1. Previos:** Comprobar y marcar mediante replanteo previo el trazado del corte de forma limpia y rectilínea. Verificar la ausencia de servicios o instalaciones ocultas que puedan resultar dañadas y comprobar el correcto estado, refrigeración por agua y alineación del disco de diamante.
	**2. Corte:** Ejecutar el corte continuo del pavimento hasta alcanzar la profundidad especificada de 12 cm, manteniendo una velocidad constante para evitar desconchados, fisuras no deseadas o roturas en los bordes del pavimento colindante a conservar.
	**3. Control y remate:** Limpiar inmediatamente la lechada y los lodos generados por el agua de refrigeración del corte, revisar la perpendicularidad y acabado del plano de corte, y proteger el borde ejecutado hasta la fase posterior de demolición o excavación.

#### Medición
	* **Unidad de medida:** Metro lineal (m).
	* **Criterio:** Longitud neta de corte realmente ejecutada sobre el terreno y verificada según los planos o las instrucciones de la Dirección de Obra.

#### Valoración
El precio unitario (€/m) incluye:
	* Parte proporcional de replanteo, trazado y marcaje previo de las líneas de corte.
	* Mano de obra especializada, uso de cortadora de disco de diamante, discos de repuesto, agua de refrigeración y maquinaria auxiliar necesaria.
	* Limpieza y retirada del lodo o restos generados por el corte.
	* Medios de protección, señalización y seguridad propios de la operación.