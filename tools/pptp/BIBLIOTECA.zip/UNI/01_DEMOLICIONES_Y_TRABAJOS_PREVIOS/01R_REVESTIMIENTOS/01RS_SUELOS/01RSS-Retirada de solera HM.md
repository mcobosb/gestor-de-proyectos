"""
## Registro de cambios
- Versión: 4 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de suelos - soleras

**Clasificación BCCA:** `01RSS`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Soleras**, dentro de **Suelos**.
Aplicable a las partidas cuyo código BCCA comienza por `01RSS`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RSS00001 - DEMOLICIÓN DE SOLERA DE HORMIGÓN EN MASA DE 10 cm CARGA MANUAL

**Unidad:** m2.

Demolición de solera de hormigón en masa de 10 cm de espesor, con medios mecánicos, incluso carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSS00002 - DEMOLICIÓN DE SOLERA DE HORMIGÓN EN MASA DE 10 cm CARGA MECÁNICA

**Unidad:** m2.

Demolición de solera de hormigón en masa de 10 cm de espesor, cón medios mecánicos, incluso carga mecánica y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSS90002 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE SOLERA DE HORMIGÓN EN MASA

**Unidad:** m2.

Demolición selectiva con medios mecánicos de solera de hormigón en masa de 10 cm de espesor. Medida la superficie inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Suelos

**Clasificación:** 01RS  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Demolición por medios mecánicos de solera de hormigón en masa de 10 cm de espesor existente en la superficie delimitada del proyecto, previa a la ejecución de los nuevos pavimentos o canalizaciones. Incluye la rotura, picado, carga mecánica y el transporte del material resultante a vertedero o gestor autorizado.

#### Ejecución
	**1. Previos:** Comprobar la ausencia o desconexión de servicios e instalaciones subyacentes, proteger las estructuras o elementos colindantes a conservar y delimitar la zona de actuación mediante corte previo si fuese necesario.
	**2. Demolición:** Ejecutar el picado y rotura de la solera de hormigón mediante el uso de maquinaria mecánica adecuada (martillo neumático/hidráulico o minicargadora), controlando el espesor de 10 cm para no alterar ni dañar el terreno base o las capas inferiores a conservar.
	**3. Control y remate:** Realizar el acopio, carga mecánica inmediata del material demolido, limpieza de la superficie remanente y verificación del estado del soporte resultante.

#### Medición
	* **Unidad de medida:** Metro cuadrado (m²) de solera demolida.
	* **Criterio:** Superficie neta inicial realmente ejecutada y comprobada sobre plano o figura geométrica en obra.

#### Valoración
El precio unitario (€/m²) incluye:
	* Mano de obra, herramientas manuales, maquinaria de picado/demolición y medios auxiliares.
	* Demolición del hormigón en masa de 10 cm de espesor, acopio e inspección de la superficie resultante.
	* Carga mecánica del material sobrante, transporte a vertedero o gestor autorizado de RCDs y abono de las correspondientes tasas de vertido.
