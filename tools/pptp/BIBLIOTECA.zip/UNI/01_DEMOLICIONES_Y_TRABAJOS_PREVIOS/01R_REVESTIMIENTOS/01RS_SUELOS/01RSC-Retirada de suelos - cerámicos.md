"""
# Retirada de suelos - cerámicos

**Clasificación BCCA:** `01RSC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Cerámicos**, dentro de **Suelos**.
Aplicable a las partidas cuyo código BCCA comienza por `01RSC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RSC00001 - LEVANTADO DE SOLADO Y RODAPIÉ DE BALDOSAS CERÁMICAS

**Unidad:** m2.

Lev antado de solado y rodapié de baldosas cerámicas incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSC00002 - DESMONTADO DE RODAPIÉ DE BALDOSAS CERÁMICAS

**Unidad:** m.

Desmontado de rodapié de baldosas cerámicas, incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medida la longitud inicial.

### 01RSC90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE SOLADO Y RODAPIÉ BALD. CER.

**Unidad:** m2.

Demolición selectiva con medios manuales de solado y rodapié de baldosas cerámicas. Medida la superficie inicial.

### 01RSC90002 - DEMOLICIÓN SELECTIVA M. MANUALES DE RODAPIÉ DE BALDOSAS CERÁM.

**Unidad:** m.

Demolición selectiva con medios manuales de rodapié de baldosas cerámicas. Medida la longitud inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Suelos

**Clasificación:** 01RS  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, levantado o demolición selectiva de pavimentos y revestimientos horizontales de suelo existentes exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar redes/servicios ocultos, proteger los elementos a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el pavimentado limitando el levantado a la capa de acabado y material de agarre desprendido autorizado, evitando dañar el forjado, solera o capas base a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes del corte y gestionar la entrega de residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Metro cuadrado (m²) de suelo retirado.
* **Criterio:** Superficie neta realmente ejecutada y comprobada sobre plano o figura geométrica en obra.

#### Valoración
El precio unitario (€/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado/levantado y medios auxiliares.
* Demolición, levantado, acopio intermedio y limpieza de la superficie resultante.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
