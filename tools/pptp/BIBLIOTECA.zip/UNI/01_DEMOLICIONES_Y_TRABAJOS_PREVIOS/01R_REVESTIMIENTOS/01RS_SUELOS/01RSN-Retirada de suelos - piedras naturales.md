"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de suelos - piedras naturales

**Clasificación BCCA:** `01RSN`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Piedras naturales**, dentro de **Suelos**.
Aplicable a las partidas cuyo código BCCA comienza por `01RSN`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RSN00100 - LEVANTADO DE SOLADO Y RODAPIÉ DE PIEDRA NATURAL

**Unidad:** m2.

Demolición de solado y rodapié de piedra natural, incluso p.p. de carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSN00110 - LEVANTADO DE SOLADO Y RODAPIÉ PIEDRA NATURAL, APROV. DEL 50%

**Unidad:** m2.

Lev antado de solado y rodapié de piedra natural, incluso p.p. de aprov echamiento del 50% para la propiedad, carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSN00200 - DESMONTADO DE RODAPIÉ DE PIEDRA NATURAL

**Unidad:** m.

Desmontado de rodapié de piedra natural, incluso p.p. de carga manual y transporte de material sobrante a v ertedero. Medida la longitud inicial.

### 01RSN00210 - LEVANTADO DE RODAPIÉ PIEDRA NATURAL CÓN APROV. DEL 50%

**Unidad:** m.

Lev antado de rodapié de piedra natural incluso p.p. de aprov echamiento del 50% para la propiedad, carga manual y transporte de material sobrante a v ertedero. Medida la longitud inicial.

### 01RSN90100 - DEMOLICIÓN SELECTIVA M. MANUALES DE SOLADO Y RODAPIÉ DE PIEDRA

**Unidad:** m2.

Demolición selectiva con medios manuales de solado y rodapié de piedra natural. Medida la superficie inicial.

### 01RSN90110 - DEMOLICIÓN SELECTIVA M. MANUALES DE SOLADO Y RODAPIÉ PIEDRA NAT.

**Unidad:** m2.

Demolición selectiva con medios manuales de solado y rodapié de piedra natural, con reutilización en la obra del 50%. Medida la superficie inicial.

### 01RSN90200 - DEMOLICIÓN SELECTIVA M. MANUALES DE RODAPIÉ DE PIEDRA NATURAL

**Unidad:** m.

Demolición selectiva con medios manuales de rodapié de piedra natural. Medida la longitud inicial.

### 01RSN90210 - DEMOLICIÓN SELECTIVA M. MANUALES DE RODAPIÉ PIEDRA NATURAL

**Unidad:** m.

Demolición selectiva con medios manuales de rodapié de piedra natural. Medida la longitud inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Suelos

**Clasificación:** 01RS  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, levantado o demolición selectiva de pavimentos y revestimientos horizontales de suelo existentes exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar redes/servicios ocultos, proteger los elementos a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el pavimentado limitando el levantado a la capa de acabado y material de agarre desprendido autorizado, evitando dañar el forjado, solera o capas base a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes del corte y gestionar la entrega de residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Metro cuadrado (m²) de suelo retirado.
* **Criterio:** Superficie neta realmente ejecutada y comprobada sobre plano o figura geométrica en obra.

#### Valoración
El precio unitario (€/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado/levantado y medios auxiliares.
* Demolición, levantado, acopio intermedio y limpieza de la superficie resultante.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
