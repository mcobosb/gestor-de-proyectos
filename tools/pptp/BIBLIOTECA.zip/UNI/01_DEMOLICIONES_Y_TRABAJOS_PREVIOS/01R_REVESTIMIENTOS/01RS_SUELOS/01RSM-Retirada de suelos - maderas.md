"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de suelos - maderas

**Clasificación BCCA:** `01RSM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Maderas**, dentro de **Suelos**.
Aplicable a las partidas cuyo código BCCA comienza por `01RSM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RSM00001 - LEVANTADO DE ENTARIMADO SOBRE RASTRELES CON APROV. DEL 50%

**Unidad:** m2.

Levantado de entarimado sobre rastreles y rodapié de madera, incluso p.p. de aprovechamiento del 50% para la propiedad, ayudas de albañilería, carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSM00002 - LEVANTADO DE PARQUE Y RODAPIÉ DE MADERA

**Unidad:** m2.

Levantado de parque y rodapié de madera, incluso carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSM00003 - DESMONTADO DE RODAPIÉ DE MADERA CON APROV. DEL 50%

**Unidad:** m.

Desmontado de rodapié de madera incluso p.p. de aprovechamiento del 50% para la propiedad, carga manual y transporte de material sobrante a vertedero. Medida la longitud inicial.

### 01RSM00010 - DEMOLICIÓN DE ENTARIMADO SOBRE RASTRELES

**Unidad:** m2.

Demolición de entarimado sobre rastreles y rodapié de madera incluso carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSM00011 - DEMOLICIÓN DE PARQUE Y RODAPIÉ DE MADERA I/MORTERO DE BASE

**Unidad:** m2.

Demolición de parque y rodapié de madera incluso mortero de base, carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSM00012 - DEMOLICIÓN DE RODAPIÉ DE MADERA

**Unidad:** m.

Demolición de rodapié de madera incluso carga manual y transporte de material sobrante a v ertedero. Medida la longitud inicial.

### 01RSM90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE ENTARIMADO SOBRE RASTRELES

**Unidad:** m2.

Demolición selectiva con medios manuales de entarimado sobre rastreles y rodapié de madera, ayudas de albañilería, con reutilización en la obra del 50%. Medida la superficie inicial.

### 01RSM90002 - DEMOLICIÓN SELECTIVA M. MANUALES DE PARQUE Y RODAPIÉ DE MADERA

**Unidad:** m2.

Demolición selectiva de parque y rodapié de madera. Medida la superficie inicial.

### 01RSM90003 - DEMOLICIÓN SELECTIVA M. MANUALES DE RODAPIÉ DE MADERA

**Unidad:** m.

Demolición selectiva con medios manuales de rodapié de madera. Medida la longitud inicial.

### 01RSM90010 - DEMOLICIÓN SELECTIVA M. MANUALES DE ENTARIMADO SOBRE RASTRELES

**Unidad:** m2.

Demolición selectiva con medios manuales de entarimado sobre rastreles y rodapié de madera. Medida la superficie inicial.

### 01RSM90011 - DEMOLICIÓN MASIVA M. MAN. DE PARQUE Y RODAPIÉ MAD. I/MORT. BASE

**Unidad:** m2.

Demolición masiva con medios manuales de parque y rodapié de madera, incluso mortero de base. Medida la superficie inicial.

### 01RSM90012 - DEMOLICIÓN SELECTIVA M. MANUALES DE RODAPIÉ DE MADERA

**Unidad:** m.

Demolición selectiva con medios manuales de rodapié de madera. Medida la longitud inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Suelos

**Clasificación:** 01RS  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, levantado o demolición selectiva de pavimentos y revestimientos horizontales de suelo existentes exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar redes/servicios ocultos, proteger los elementos a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el pavimentado limitando el levantado a la capa de acabado y material de agarre desprendido autorizado, evitando dañar el forjado, solera o capas base a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes del corte y gestionar la entrega de residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Metro cuadrado (m²) de suelo retirado.
* **Criterio:** Superficie neta realmente ejecutada y comprobada sobre plano o figura geométrica en obra.

#### Valoración
El precio unitario (€/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado/levantado y medios auxiliares.
* Demolición, levantado, acopio intermedio y limpieza de la superficie resultante.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
