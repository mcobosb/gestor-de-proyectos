"""
## Registro de cambios
- Versión: 5 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 4 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de suelos - hidráulicos

**Clasificación BCCA:** `01RSH`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Hidráulicos**, dentro de **Suelos**.
Aplicable a las partidas cuyo código BCCA comienza por `01RSH`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RSH00001 - LEVANTADO DE SOLADO CON BALDOSAS HIDRÁULICAS CARGA MANUAL

**Unidad:** m2.

Lev antado de solado con baldosas hidráulicas, incluso carga manual y p.p. de transporte de material sobrante a v ertedero. Medida la superficie inicial.

### 01RSH00002 - LEVANTADO DE SOLADO CON BALDOSAS HIDRÁULICAS CARGA MECÁNICA

**Unidad:** m2.

Lev antado de solado con baldosas hidráulicas, incluso carga mecánica y p.p. de transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSH90002 - DEMOLICION SELECTIVA M. MECÁNICOS DE SOLADO CON BALD. HIDRÁUL.

**Unidad:** m2.

Demolición selectiva con medios mecánicos de solado con baldosas hidráulicas. Medida la superficie inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Suelos

**Clasificación:** 01RS  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, levantado o demolición selectiva por medios mecánicos de pavimentos y revestimientos horizontales de suelo existentes —incluido solado con baldosas hidráulicas— exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
	**1. Previos:** Comprobar la estabilidad del soporte, localizar redes/servicios ocultos, proteger los elementos a conservar y disponer los medios de segregación de residuos de construcción y demolición (RCDs).
	**2. Desmontaje/Demolición:** Ejecutar el levantado mecánico del solado de baldosas hidráulicas limitando la demolición a la capa de acabado y material de agarre desprendido autorizado, evitando dañar el forjado, solera o capas base a conservar.
	**3. Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes del corte y realizar la carga mecánica del material sobrante para su gestión y transporte.

#### Medición
	* **Unidad de medida:** Metro cuadrado (m²) de suelo retirado.
	* **Criterio:** Superficie neta inicial realmente ejecutada y comprobada sobre plano o figura geométrica en obra.

#### Valoración
El precio unitario (€/m²) incluye:
	* Mano de obra, herramientas manuales, maquinaria de picado/levantado y medios auxiliares.
	* Demolición, levantado, acopio intermedio y limpieza de la superficie resultante.
	* Carga mecánica, transporte del material sobrante a vertedero o gestor autorizado y pago de las correspondientes tasas o cánones de vertido (previstos en el Estudio de Gestión de Residuos).
