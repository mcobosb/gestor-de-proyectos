"""
# Retirada de suelos - ligeros

**Clasificación BCCA:** `01RSL`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Ligeros**, dentro de **Suelos**.
Aplicable a las partidas cuyo código BCCA comienza por `01RSL`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01RSL00001 - LEVANTADO DE SOLADO DE MATERIAL LIGERO

**Unidad:** m2.

Levantado de solado de material ligero y rodapié de madera, incluso carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSL00010 - LEVANTADO DE SOLADO DE MATERIAL LIGERO, I/MORTERO DE BASE

**Unidad:** m2.

Levantado de solado de material ligero y rodapié de madera, incluso mortero de base, carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial.

### 01RSL90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE SOLADO DE MATERIAL LIGERO

**Unidad:** m2.

Demolición selectiva con medios manuales de solado de material ligero y rodapié de madera. Medida la superficie inicial.

### 01RSL90010 - DEMOLICIÓN MASIVA M. MAN. SOLADO DE MATERIAL LIG. I/MORT. BASE

**Unidad:** m2.

Demolición masiva con medios manuales de solado de material ligero y rodapié de madera, incluso mortero de base. Medida la superficie inicial.

### 01RSL90011 - LEVANTADO DE PVC A MANO

**Unidad:** m2.

M2. Lev antado, por medios manuales, de parquet, corcho, PVC, goma o moqueta pegados/recibidos sobre solera base (también a demoler), i/retirada de escombros a pie de carga y p.p. de costes indirectos, según NTE/ADD-10.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Suelos

**Clasificación:** 01RS  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Revestimientos  

"""
#### Descripción
Retirada, levantado o demolición selectiva de pavimentos y revestimientos horizontales de suelo existentes exclusivamente en las zonas delimitadas del proyecto.

#### Ejecución
1. **Previos:** Comprobar la estabilidad del soporte, localizar redes/servicios ocultos, proteger los elementos a conservar y disponer los medios de segregación de residuos (RCDs).
2. **Desmontaje/Demolición:** Retirar el pavimentado limitando el levantado a la capa de acabado y material de agarre desprendido autorizado, evitando dañar el forjado, solera o capas base a conservar.
3. **Control y remate:** Limpiar el soporte remanente, verificar la estabilidad de los bordes del corte y gestionar la entrega de residuos a gestor autorizado.

#### Medición
* **Unidad de medida:** Metro cuadrado (m²) de suelo retirado.
* **Criterio:** Superficie neta realmente ejecutada y comprobada sobre plano o figura geométrica en obra.

#### Valoración
El precio unitario (€/m²) incluye:
* Mano de obra, herramientas manuales, maquinaria de picado/levantado y medios auxiliares.
* Demolición, levantado, acopio intermedio y limpieza de la superficie resultante.
* Carga, transporte y tasas de gestión de residuos de construcción y demolición (RCDs).
