# Demolición de conducciones de saneamiento - Común

**Clasificación:** 01UA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Retirada de tuberías de saneamiento enterradas que deban eliminarse.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 3–8. Transcripción para trazabilidad.

Consiste en el conjunto de operaciones necesarias para la demolición de construcciones, muros, firmes, aceras y obras de fábrica afectadas, y el consiguiente transporte de todos los productos al lugar de empleo o vertedero.
Su ejecución incluye:
- Derribo de obras de fábrica o construcciones, o demoliciones de las aceras y pavimentos.
- Retirada de los materiales de derribo.

## Ejecución

Localizar la conducción, mantener el servicio mediante solución aprobada, excavar con protección del terreno y de las redes vecinas y retirar los tubos sin contaminar el entorno. Identificar materiales peligrosos antes de romper o cortar tuberías antiguas y aplicar su normativa específica cuando existan.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 9–13. Transcripción para trazabilidad.

Será de aplicación lo indicado en el Artículo 301 del PG-3.
El equipo necesario para la ejecución de la demolición será aprobado por el Director de las obras y se mantendrá, en todo momento, en condiciones de trabajo satisfactorias.
La demolición se llevará a cabo en las zonas que indique el Proyecto y en su defecto donde indique el Director de las obras que determinará también la profundidad de demolición necesaria.
Los materiales procedentes de las demoliciones se retirarán a vertedero salvo indicación en contrario del Director de obras.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 550–553. Transcripción para trazabilidad.

Se define como demolición la operación de derribo de todas las edificaciones, obras de fábrica, estructuras, pavimentos e instalaciones que obstaculicen la construcción de una obra o que sea necesario hacer desaparecer para dar por terminada la ejecución de la misma, incluso la retirada de los materiales resultantes a vertedero o en su lugar de empleo o acopio definitivo.
Las operaciones de derribo o excavación se efectuarán con las precauciones necesarias para lograr unas condiciones de seguridad suficientes y evitar daños en las obras o instalaciones que no hayan de ser demolidas y de acuerdo con lo que sobre el particular ordene el Director de la obra, quien designará y marcará los elementos de las obras a demoler que se deban conservar intactos para su aprovechamiento posterior, así como las condiciones para el transporte y acopio de los mismos. En cualquier caso, el Contratista requerirá autorización expresa para los derribos.
Cuando los firmes, pavimentos, bordillos u otros elementos deban reponerse a la finalización de las obras a que afecten, la reposición se realizará en el plazo más breve posible y en condiciones análogas a las existentes antes de su demolición.

## Medición y valoración

Medir la longitud realmente retirada hasta el entronque con el pozo o imbornal existente, comprobada con la dirección de obra, conforme a 5.2.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1106–1106. Transcripción para trazabilidad.

Las demoliciones de saneamientos enterrados se abonarán por longitud realmente medida en obra, hasta el punto de entronque con el pozo o imbornal existente y según el precio que figura en el Cuadro de Precios nº 1, constatada esta longitud con el Director de obra. Si esto no fuera así se utilizará las longitudes usadas en las mediciones de proyecto.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
