"""
# Retirada de alcantarillado - depuración y vertido

**Clasificación BCCA:** `01UAD`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Depuración y vertido**, dentro de **ALCANTARILLADO**.
Aplicable a las partidas cuyo código BCCA comienza por `01UAD`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

"""
### Demolición de conducciones de saneamiento
"""

**Clasificación:** 01UA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Retirada de tuberías de saneamiento enterradas que deban eliminarse.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 3–8. Transcripción para trazabilidad.
"""

Consiste en el conjunto de operaciones necesarias para la demolición de construcciones, muros, firmes, aceras y obras de fábrica afectadas, y el consiguiente transporte de todos los productos al lugar de empleo o vertedero.
Su ejecución incluye:
- Derribo de obras de fábrica o construcciones, o demoliciones de las aceras y pavimentos.
- Retirada de los materiales de derribo.

#### Ejecución

Localizar la conducción, mantener el servicio mediante solución aprobada, excavar con protección del terreno y de las redes vecinas y retirar los tubos sin contaminar el entorno. Identificar materiales peligrosos antes de romper o cortar tuberías antiguas y aplicar su normativa específica cuando existan.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 9–13. Transcripción para trazabilidad.
"""

Será de aplicación lo indicado en el Artículo 301 del PG-3.
El equipo necesario para la ejecución de la demolición será aprobado por el Director de las obras y se mantendrá, en todo momento, en condiciones de trabajo satisfactorias.
La demolición se llevará a cabo en las zonas que indique el Proyecto y en su defecto donde indique el Director de las obras que determinará también la profundidad de demolición necesaria.
Los materiales procedentes de las demoliciones se retirarán a vertedero salvo indicación en contrario del Director de obras.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 550–553. Transcripción para trazabilidad.
"""

Se define como demolición la operación de derribo de todas las edificaciones, obras de fábrica, estructuras, pavimentos e instalaciones que obstaculicen la construcción de una obra o que sea necesario hacer desaparecer para dar por terminada la ejecución de la misma, incluso la retirada de los materiales resultantes a vertedero o en su lugar de empleo o acopio definitivo.
Las operaciones de derribo o excavación se efectuarán con las precauciones necesarias para lograr unas condiciones de seguridad suficientes y evitar daños en las obras o instalaciones que no hayan de ser demolidas y de acuerdo con lo que sobre el particular ordene el Director de la obra, quien designará y marcará los elementos de las obras a demoler que se deban conservar intactos para su aprovechamiento posterior, así como las condiciones para el transporte y acopio de los mismos. En cualquier caso, el Contratista requerirá autorización expresa para los derribos.
Cuando los firmes, pavimentos, bordillos u otros elementos deban reponerse a la finalización de las obras a que afecten, la reposición se realizará en el plazo más breve posible y en condiciones análogas a las existentes antes de su demolición.

#### Medición y valoración

Medir la longitud realmente retirada hasta el entronque con el pozo o imbornal existente, comprobada con la dirección de obra, conforme a 5.2.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1106–1106. Transcripción para trazabilidad.
"""

Las demoliciones de saneamientos enterrados se abonarán por longitud realmente medida en obra, hasta el punto de entronque con el pozo o imbornal existente y según el precio que figura en el Cuadro de Precios nº 1, constatada esta longitud con el Director de obra. Si esto no fuera así se utilizará las longitudes usadas en las mediciones de proyecto.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Demolición de pozos de saneamiento
"""

**Clasificación:** 01UA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Demolición y retirada de pozos de registro existentes afectados por la obra.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 3–8. Transcripción para trazabilidad.
"""

Consiste en el conjunto de operaciones necesarias para la demolición de construcciones, muros, firmes, aceras y obras de fábrica afectadas, y el consiguiente transporte de todos los productos al lugar de empleo o vertedero.
Su ejecución incluye:
- Derribo de obras de fábrica o construcciones, o demoliciones de las aceras y pavimentos.
- Retirada de los materiales de derribo.

#### Ejecución

Reconocer la red en servicio, prever desvíos o bombeos aprobados y aislar las conexiones. Comprobar la atmósfera y evitar la entrada en espacios confinados sin procedimiento específico. Desmontar tapa y fábrica con estabilidad del terreno y retirar los residuos de forma controlada.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 9–13. Transcripción para trazabilidad.
"""

Será de aplicación lo indicado en el Artículo 301 del PG-3.
El equipo necesario para la ejecución de la demolición será aprobado por el Director de las obras y se mantendrá, en todo momento, en condiciones de trabajo satisfactorias.
La demolición se llevará a cabo en las zonas que indique el Proyecto y en su defecto donde indique el Director de las obras que determinará también la profundidad de demolición necesaria.
Los materiales procedentes de las demoliciones se retirarán a vertedero salvo indicación en contrario del Director de obras.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 550–553. Transcripción para trazabilidad.
"""

Se define como demolición la operación de derribo de todas las edificaciones, obras de fábrica, estructuras, pavimentos e instalaciones que obstaculicen la construcción de una obra o que sea necesario hacer desaparecer para dar por terminada la ejecución de la misma, incluso la retirada de los materiales resultantes a vertedero o en su lugar de empleo o acopio definitivo.
Las operaciones de derribo o excavación se efectuarán con las precauciones necesarias para lograr unas condiciones de seguridad suficientes y evitar daños en las obras o instalaciones que no hayan de ser demolidas y de acuerdo con lo que sobre el particular ordene el Director de la obra, quien designará y marcará los elementos de las obras a demoler que se deban conservar intactos para su aprovechamiento posterior, así como las condiciones para el transporte y acopio de los mismos. En cualquier caso, el Contratista requerirá autorización expresa para los derribos.
Cuando los firmes, pavimentos, bordillos u otros elementos deban reponerse a la finalización de las obras a que afecten, la reposición se realizará en el plazo más breve posible y en condiciones análogas a las existentes antes de su demolición.

#### Medición y valoración

Medir por metro lineal de altura del pozo, constatada con la dirección antes de demoler; en ausencia de esa comprobación, el original remite a las alturas de las mediciones del proyecto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1105–1105. Transcripción para trazabilidad.
"""

Las demoliciones de pozos de saneamiento se abonarán por metro lineal de altura real de pozo, y según el precio que figura en el Cuadro de Precios nº 1, constatada esta altura con el Director de obra, previo a proceder a su demolición. Si esto no fuera así se utilizará las alturas usadas en las mediciones de proyecto.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
