# Demolición de aceras y pavimentos - Común

**Clasificación:** 01UP  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Urbanización y firmes  

## Descripción
Levantado y demolición selectiva de aceras, pavimentos, bordillos y capas de firme afectadas por las obras, manteniendo la integridad de las superficies colindantes y los servicios urbanos que deban conservarse.

## Ejecución
1. **Previos:** Replantear y marcar de forma precisa los límites de la actuación. Localizar servicios enterrados, proteger elementos remanentes y prever accesos/itinerarios peatonales seguros.
2. **Corte y demolición:** Ejecutar un corte previo con disco sobre la capa de rodadura o pavimento para evitar desconchones o fisuras fuera de la zona autorizada. Levantado de capas de pavimento y soleras evitando dañar conducciones subterráneas.
3. **Control y remate:** Carga inmediata de los materiales derribados, separación de RCDs para su traslado a gestor autorizado y limpieza del soporte resultante.

## Medición
* **Unidad de medida:** Metro cuadrado (m²) de acera o pavimento demolido (o metro cúbico, m³, para demoliciones masivas de elementos de gran espesor/obras de fábrica según cuadro de precios).
* **Criterio:** Superficie neta realmente demolida y levantada sobre plano o geometría comprobada in situ, descontando huecos y zonas no afectadas.

## Valoración
El precio unitario (€/m² o €/m³) incluye:
* Mano de obra, herramientas, maquinaria de corte, martillos neumático/hidráulicos y medios auxiliares.
* Corte perimetral con disco, demolición, levantado, acopio e itinerarios de seguridad.
* Carga, transporte, descarga y tasas de vertedero o gestor autorizado de residuos de construcción y demolición (RCDs).