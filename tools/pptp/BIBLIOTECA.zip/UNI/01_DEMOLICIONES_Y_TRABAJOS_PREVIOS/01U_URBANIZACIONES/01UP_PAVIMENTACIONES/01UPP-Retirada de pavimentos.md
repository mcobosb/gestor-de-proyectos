"""
## Registro de cambios
- Versión: 3 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 2 | Autor: - | Fecha: 10/11/2026 | Cambio: Rev.01
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de pavimentaciones - pavimentos

**Clasificación BCCA:** `01UPP`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Pavimentos**, dentro de **PAVIMENTACIONES**.
Aplicable a las partidas cuyo código BCCA comienza por `01UPP`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01UPP00010 - Demolición de pavimentos de adoquines

**Unidad:** m2.

Demolición de pavimento exterior de adoquines y capa de arena con martillo neumático y carga manual sobre camión o contenedor. Medida la superficie demolida.

### 01UPP00020 - Demolición de pavimento de hormigón

**Unidad:** m2.

Demolición de pavimento exterior de hormigón en masa con retroexcavadora y martillo rompedor. Carga mecánica sobre camión o contenedor. Medida la superficie demolida.

### 01UPP00030 - Demolición de pavimento de asfalto

**Unidad:** m2.

Demolición de pavimento asfáltico en calzada, con martillo neumático y carga manual sobre camión o contenedor. Incluida p/p del corte previo del contorno del pavimento. Medida la superficie demolida.

### 01UPP00040 - Demolición de pavimento baldosas

**Unidad:** m2.

Demolición de pavimento de baldosas cerámicas, de hormigón, de piedra natural o de terrazo con medios manuales y carga manual sobre camión o contenedor. Inlcuida p/p de picado de agarre. Medida la superficie demolida.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Demolición de aceras y pavimentos

**Clasificación:** 01UP  
**Capítulo:** Demoliciones y trabajos previos  
**Familia:** Urbanización y firmes  

"""
#### Descripción
Levantado y demolición selectiva de aceras, pavimentos, bordillos y capas de firme afectadas por las obras, manteniendo la integridad de las superficies colindantes y los servicios urbanos que deban conservarse.

#### Ejecución
	**1. Previos:** Replantear y marcar de forma precisa los límites de la actuación. Localizar servicios enterrados, proteger elementos remanentes y prever accesos/itinerarios peatonales seguros.
	**2. Corte y demolición:** Ejecutar un corte previo con disco sobre la capa de rodadura o pavimento para evitar desconchones o fisuras fuera de la zona autorizada. Levantado de capas de pavimento y soleras evitando dañar conducciones subterráneas.
	**3. Control y remate:** Carga inmediata de los materiales derribados, separación de RCDs para su traslado a gestor autorizado y limpieza del soporte resultante.

#### Medición
	* **Unidad de medida:** Metro cuadrado (m²) de acera o pavimento demolido (o metro cúbico, m³, para demoliciones masivas de elementos de gran espesor/obras de fábrica según cuadro de precios).
	* **Criterio:** Superficie neta realmente demolida y levantada sobre plano o geometría comprobada in situ, descontando huecos y zonas no afectadas.

#### Valoración
El precio unitario (€/m² o €/m³) incluye:
	* Mano de obra, herramientas, maquinaria de corte, martillos neumático/hidráulicos y medios auxiliares.
	* Corte perimetral con disco, demolición, levantado, acopio e itinerarios de seguridad.
	* Carga, transporte, descarga y tasas de vertedero o gestor autorizado de residuos de construcción y demolición (RCDs).
