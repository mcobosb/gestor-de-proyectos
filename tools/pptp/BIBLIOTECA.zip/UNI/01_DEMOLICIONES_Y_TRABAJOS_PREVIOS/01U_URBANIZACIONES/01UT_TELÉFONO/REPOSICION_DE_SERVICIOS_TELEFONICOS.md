# Reposición de servicios telefónicos

**Clasificación:** 01UT. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Desvío o reposición de redes telefónicas y sus infraestructuras afectadas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1023–1026. Transcripción para trazabilidad.

El contratista realizará las operaciones y desvíos de aquellos Servicios que la Dirección de Obra considere como afectados, teniendo en cuenta lo especificado por las compañías suministradoras.
Toda la obra se realizará según los Métodos de construcciones y Seguridad y Salud.
Se definirán como unidades de obra que comprenden todos los materiales y trabajos necesarios para restituir las condiciones de servicio iniciales con la nueva situación del trazado del proyecto, de acuerdo con la entidad concesionaria del servicio.

## Ejecución

Coordinar con el operador, localizar cables, aprobar trazado, interrupciones y solución de empalme y protección. Ejecutar con personal competente, respetar radios y esfuerzos y comprobar el servicio antes de cerrar y recibir.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1032–1034. Transcripción para trazabilidad.

El Contratista realizará las operaciones y desvíos de los Servicios telefónicos afectados por la obra de acuerdo con lo que se establece en los planos del proyecto y en las correspondientes mediciones y presupuestos, siguiendo además las normas de la Compañía Telefónica y las Instrucciones de la Dirección de Obra.
Toda obra se realizará según los métodos de Construcciones y Seguridad y Salud en el Trabajo.

## Medición y valoración

Según las partidas y unidades del presupuesto y los trabajos autorizados, sin abonar reparaciones imputables al contratista como reposiciones previstas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1108–1111. Transcripción para trazabilidad.

Se medirán y abonarán por la dimensión especificada en el Cuadro de Precios, metro lineal (ml), metro cuadrado (m²), metro cúbico (m³), de la unidad realmente ejecutada y referida únicamente a aquellas que, a juicio del Director de la obra, sean consecuencia obligada de la ejecución del Proyecto contratado.
Los precios incluyen todas las operaciones, materiales, mano de obra, maquinaria y medios auxiliares necesarios para la completa ejecución y perfecto acabado.
Todas las reparaciones de roturas o averías en los diversos servicios públicos o particulares, los tendrá que realizar obligatoriamente el Contratista por su cuenta exclusiva y sin derecho a abono de cantidad alguna.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
