# Reposición de líneas eléctricas

**Clasificación:** 01UE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Desplazamiento o reposición autorizada de líneas eléctricas afectadas por las obras.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1023–1026. Transcripción para trazabilidad.

El contratista realizará las operaciones y desvíos de aquellos Servicios que la Dirección de Obra considere como afectados, teniendo en cuenta lo especificado por las compañías suministradoras.
Toda la obra se realizará según los Métodos de construcciones y Seguridad y Salud.
Se definirán como unidades de obra que comprenden todos los materiales y trabajos necesarios para restituir las condiciones de servicio iniciales con la nueva situación del trazado del proyecto, de acuerdo con la entidad concesionaria del servicio.

## Ejecución

Aprobar nuevo trazado con el titular, establecer consignación y verificar ausencia de tensión por personal autorizado según RD 614/2001. Ejecutar la red conforme al reglamento de su tensión, probar y legalizar cuando proceda antes de restituir el servicio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1027–1031. Transcripción para trazabilidad.

Para proceder al desplazamiento y reposición de líneas eléctricas, se procederá a determinar la disposición más adecuada del nuevo trazado.
Todas las operaciones se realizarán cuidadosamente por personal especializado, siguiendo las órdenes del Ingeniero Técnico Director e indicaciones de la Compañía Suministradora.
Cuando se vaya a realizar la conexión se comprobará especialmente que no haya tensión en la línea.
Se procederá según las normas de buena práctica constructiva, siguiendo la reglamentación e instrucciones y las indicaciones del Ingeniero Técnico Director.

## Medición y valoración

Aplicar los m, ud u otra magnitud de cada partida aprobada de reposición; no abonar daños por mala ejecución como servicio afectado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1108–1111. Transcripción para trazabilidad.

Se medirán y abonarán por la dimensión especificada en el Cuadro de Precios, metro lineal (ml), metro cuadrado (m²), metro cúbico (m³), de la unidad realmente ejecutada y referida únicamente a aquellas que, a juicio del Director de la obra, sean consecuencia obligada de la ejecución del Proyecto contratado.
Los precios incluyen todas las operaciones, materiales, mano de obra, maquinaria y medios auxiliares necesarios para la completa ejecución y perfecto acabado.
Todas las reparaciones de roturas o averías en los diversos servicios públicos o particulares, los tendrá que realizar obligatoriamente el Contratista por su cuenta exclusiva y sin derecho a abono de cantidad alguna.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
