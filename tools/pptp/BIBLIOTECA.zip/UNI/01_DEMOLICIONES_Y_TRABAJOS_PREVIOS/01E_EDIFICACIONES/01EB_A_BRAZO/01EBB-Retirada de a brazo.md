"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de a brazo

**Clasificación BCCA:** `01EBB`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **A brazo**, dentro de **A brazo**.
Aplicable a las partidas cuyo código BCCA comienza por `01EBB`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01EBB00001 - DEMOLICIÓN EDIFICIO MEDIANERAS, MUROS DE FÁBRICA, M. MANUALES

**Unidad:** m3.

Demolición total de edificio, situado entre medianeras, desde la cara superior de la cimentación, con estructura de muros de fábrica y cuatro plantas de altura máxima, realizada con medios manuales, incluso p.p. de apeos, carga mecánica y transporte de escombros a vertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB00020 - DEMOLICIÓN EDIFICIO MEDIANERAS, ESTRUC. METÁLICA, M. MANUALES

**Unidad:** m3.

Demolición total de edificio, situado entre medianeras, desde la cara superior de la cimentación, con estructura metálica y cuatro plantas de altura máxima, realizada con medios manuales, incluso p.p. de apeos, carga mecánica y transporte de escombros a v ertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB00100 - DEMOLICIÓN EDIFICIO EXENTO, MUROS DE FÁBRICA, M. MANUALES

**Unidad:** m3.

Demolición total de edificio ex ento, desde la cara superior de la cimentación, con estructura de muros de fábrica y cuatro plantas de altura máxima, realizada con medios manuales, incluso p.p. de apeos, carga mecánica, y transporte de escombros a vertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB00120 - DEMOLICIÓN EDIFICIO EXENTO, ESTRUC. METÁLICA, M. MANUALES

**Unidad:** m3.

Demolición total de edificio exento, desde la cara superior de la cimentación, con estructura metálica y cuatro plantas de altura máxima, realizada con medios manuales, incluso p.p. de apeos, carga mecánica y transporte de escombros a vertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB00200 - DEMOLICIÓN NAVE EXENTA, MURO DE FÁBRICA, CUB. MADERA, M. MAN.

**Unidad:** m3.

Demolición total de nave exenta, desde la cara superior de la solera, con muros de fábrica y estructura de cubierta de madera, realizada con medios manuales, incluso p.p. de apeos, carga mecánica y transporte de escombros a vertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB00201 - DEMOLICIÓN NAVE EXENTA, MURO DE FÁBRICA, CUB. METÁLICA, M. MAN.

**Unidad:** m3.

Demolición total de nave exenta, desde la cara superior de la solera, con muros de fábrica y estructura de cubierta metálica, realizada con medios manuales, incluso p.p. de apeos, carga mecánica y transporte de escombros a vertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB00220 - DEMOLICIÓN NAVE EXENTA, ESTRUCTURA METÁLICA, M. MANUALES

**Unidad:** m3.

Demolición total de nave exenta, desde la cara superior de la solera, con estructura metálica, realizada con medios manuales, incluso p.p. de apeos, carga mecánica, y transporte de escombros a vertedero. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificacion.

### 01EBB90001 - DEMOLICIÓN MASIVA M. MANUALES DE EDIFICIO MEDIANERO MUROS FÁBR.

**Unidad:** m3.

Demolición masiva con medios manuales de edificio, situado entre medianeras, desde la cara superior de la cimentación, con estructura de muros de fábrica y cuatro plantas de altura máxima, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

### 01EBB90020 - DEMOLICIÓN MASIVA M. MANUALES DE EDIFICIO MEDIANERO ESTR. MET.

**Unidad:** m3.

Demolición masiva con medios manuales de edificio, situado entre medianeras, desde la cara superior de la cimentación, con estructura metálica y cuatro plantas de altura máxima, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

### 01EBB90100 - DEMOLICIÓN MASIVA M. MANUALES DE EDIFICIO EXENTO MUROS FÁBR.

**Unidad:** m3.

Demolición masiva con medios manuales de edificio exento, desde la cara superior de la cimentación, con estructura de muros de fábrica y cuatro plantas de altura máxima, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

### 01EBB90120 - DEMOLICIÓN MASIVA M. MANUALES DE EDIFICIO EXENTO ESTR. MET.

**Unidad:** m3.

Demolición masiva con medios manuales de edificio exento, desde la cara superior de la cimentación, con estructura metálica y cuatro plantas de altura máxima, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

### 01EBB90200 - DEMOLICIÓN MASIVA M. MAN. DE NAVE EXENTA MUROS FÁBR. CUB. MAD.

**Unidad:** m3.

Demolición masiva con medios manuales de nave exenta, desde la cara superior de la solera, con muros de fábrica y estructura de cubierta de madera, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

### 01EBB90201 - DEMOLICIÓN MASIVA M. MAN. DE NAVE EXENTA MUROS FÁBR. CUB. MET.

**Unidad:** m3.

Demolición masiva con medios manuales de nave exenta, desde la cara superior de la solera, con muros de fábrica y estructura de cubierta metálica, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

### 01EBB90220 - DEMOLICIÓN MASIVA M. MANUALES DE NAVE EXENTA ESTR. METÁLICA

**Unidad:** m3.

Demolición masiva con medios manuales de nave exenta, desde la cara superior de la solera, con estructura metálica, incluso p.p. de apeos. Medido el volumen aparente inicial definido por la superficie exterior de los elementos básicos de la edificación.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### A brazo

**Clasificación:** 01EB. **Capítulo:** demoliciones y trabajos previos. **Familia:** edificaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «a brazo», dentro de «edificaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

El método de derribo necesita análisis de estabilidad y de afección al entorno; no se deduce sólo del medio indicado en el catálogo.

Para la variante «a brazo» se comprobarán expresamente procedimiento de demolición, perímetro de protección y secuencia autorizada. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
