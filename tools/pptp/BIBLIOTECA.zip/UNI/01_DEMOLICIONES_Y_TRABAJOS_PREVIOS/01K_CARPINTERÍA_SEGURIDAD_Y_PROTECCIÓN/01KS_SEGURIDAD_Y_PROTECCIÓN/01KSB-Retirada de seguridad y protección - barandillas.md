"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de seguridad y protección - barandillas

**Clasificación BCCA:** `01KSB`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Barandillas**, dentro de **Seguridad y protección**.
Aplicable a las partidas cuyo código BCCA comienza por `01KSB`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01KSB00001 - DESMONTADO DE BARANDILLA METÁLICA

**Unidad:** m.

Desmontado de barandilla metálica incluso p.p. de ay udas de albañilería. Medida la longitud total desmontada.

### 01KSB90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE BARANDILLA METALICA

**Unidad:** m.

Demolición selectiva con medios manuales de barandilla metálica, incluso p.p. de ayudas de albañilería. Medida la longitud total desmontada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Seguridad y protección

**Clasificación:** 01KS. **Capítulo:** demoliciones y trabajos previos. **Familia:** carpintería seguridad y protección.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «seguridad y protección», dentro de «carpintería seguridad y protección». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Asegurar hojas y paños antes de liberar fijaciones; clasificar elementos reutilizables y proteger huecos abiertos.

Para la variante «seguridad y protección» se comprobarán expresamente dimensiones, peso, anclajes, recuperación y cierre provisional del hueco. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
