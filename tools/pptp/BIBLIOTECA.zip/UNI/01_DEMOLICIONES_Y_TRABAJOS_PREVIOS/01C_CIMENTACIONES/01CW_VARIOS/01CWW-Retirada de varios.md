"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de varios

**Clasificación BCCA:** `01CWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `01CWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01CWW00002 - DEMOLICIÓN CON M. MECÁNICOS FABR. LADRILLO EXC. TIERRA C. MED.

**Unidad:** m3.

Demolición con medios mecánicos de fábrica de ladrillo, en elementos de cimentación, incluso, p.p. de compresor, excavación de tierras de consistencia media, hasta una profundidad máxima de 4 m, carga mecánica y transporte de material sobrante a v ertedero. Medido el v olumen inicial.

### 01CWW00003 - DEMOLICIÓN POR BATACHES DE CIMENTACIÓN DE HORMIGÓN EN MASA

**Unidad:** m3.

Demolición por bataches de cimentación de hormigón en masa, con medios mecánicos hasta una profundidad máxima de 3 m y una longitud inferior a 1,50 m, incluso excavación de tierras de consistencia media, perfilados, p.p. de compresor, apeos, extracción manual a los bordes, carga mecánica y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CWW00010 - DEMOLICIÓN PARCIAL CON M. MECÁNICOS DE PILOTES DE HORM. ARMADO

**Unidad:** m3.

Demolición parcial con medios mecánicos de pilotes de hormigón armado, incluso p.p. de compresor o martillo percutor y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CWW00100 - DEMOLICIÓN PARCIAL CON M. MECÁNICOS DE PANTALLAS DE HORM. ARMADO

**Unidad:** m3.

Demolición parcial con medios mecánicos de pantallas de hormigón armado, incluso p.p. de compresor o martillo percutor y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CWW00200 - DEMOLICIÓN PARCIAL CON M. MECÁNICOS DE CIMIENTOS FABR. LADRILLO

**Unidad:** m3.

Demolición parcial con medios mecánicos de cimientos de fábrica de ladrillo, incluso p.p. de compresor o martillo percutor, carga manual y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CWW00300 - DEMOLICIÓN PARCIAL CON M. MECÁNICOS DE CIMIENTOS DE MAMPOSTERÍA

**Unidad:** m3.

Demolición parcial con medios mecánicos de cimientos de mampostería, incluso p.p. de compresor o martillo percutor, carga manual y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CWW90001 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE FABRICA DE LADRILLO MACIZO

**Unidad:** m3.

Demolición selectiva con medios mecánicos de fábrica de ladrillo macizo, en elementos de cimentación, incluso p.p. de compresor. Medido el volumen inicial.

### 01CWW90002 - DEMOLICIÓN MASIVA M. MEC. DE FABR. LADRILLO EXC. Y RELL. TIERRAS

**Unidad:** m3.

Demolición masiva con medios mecánicos de fábrica de ladrillo, en elementos de cimentación, incluso p.p. de compresor, excavación y relleno de tierras de consistencia media, hasta una profundidad máxima de 4 m. Medido el volumen inicial.

### 01CWW90003 - DEMOLICIÓN MASIVA M. MECÁNICOS POR BATACHES DE CIMENT. DE H.M.

**Unidad:** m3.

Demolición masiva con medios mecánicos por bataches de cimentación de hormigón en masa, hasta una profundidad máxima de 3 m y una longitud inferior a 1,50 m, incluso excavación, perfilados, extracción manual a los bordes y rellenos de tierras de consistencia media, p.p. de compresor y apeos. Medido el volumen inicial.

### 01CWW90010 - DEMOLICIÓN MASIVA M. MECÁNICOS DE PILOTES DE HORMIGÓN ARMADO

**Unidad:** m3.

Demolición masiva con medios mecánicos de pilotes de hormigón armado, incluso p.p. de compresor o martillo percutor. Medido el volumen inicial.

### 01CWW90100 - DEMOLICIÓN MASIVA M. MECÁNICOS DE PANTALLAS DE HORMIGÓN ARMADO

**Unidad:** m3.

Demolición masiva con medios mecánicos de pantallas de hormigón armado, incluso p.p. de compresor o martillo percutor. Medido el volumen inicial.

### 01CWW90200 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE CIMIENTOS DE FABR. DE LAD.

**Unidad:** m3.

Demolición selectiva con medios mecánicos de cimientos de fábrica de ladrillo, incluso p.p. de compresor o martillo percutor. Medido el volumen inicial.

### 01CWW90300 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE CIMIENTOS DE MAMPOSTERÍA

**Unidad:** m3.

Demolición selectiva con medios mecánicos de cimientos de mamposteria, incluso p.p. de compresor o martillo percutor. Medido el volumen inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### CIMENTACIONES - varios

**Clasificación:** 01CW. **Capítulo:** demoliciones y trabajos previos. **Familia:** cimentaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Comprobar cimentaciones y cargas de construcciones próximas; no retirar apoyos de elementos que deban permanecer.

Para la variante «varios» se comprobarán expresamente profundidad, continuidad y conexiones de la cimentación existente. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
