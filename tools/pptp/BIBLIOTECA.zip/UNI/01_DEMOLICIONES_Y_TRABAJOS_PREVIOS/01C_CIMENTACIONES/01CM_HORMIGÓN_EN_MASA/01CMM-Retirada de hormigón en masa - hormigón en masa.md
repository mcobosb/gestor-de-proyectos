"""
# Retirada de hormigón en masa - hormigón en masa

**Clasificación BCCA:** `01CMM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Hormigón en masa**, dentro de **Hormigón en masa**.
Aplicable a las partidas cuyo código BCCA comienza por `01CMM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01CMM00001 - DEMOLICIÓN CON M. MANUALES DE HORMIGÓN EN MASA CARGA MANUAL

**Unidad:** m3.

Demolición con medios manuales de hormigón en masa en elementos de cimentación, incluso carga manual y p.p. de transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CMM00003 - DEMOLICIÓN CON M. MANUALES DE HORMIGÓN EN MASA CARGA MECÁNICA

**Unidad:** m3.

Demolición con medios manuales de hormigón en masa en elementos de cimentación, incluso carga mecánica, p.p. de compresor y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CMM00100 - DEMOLICIÓN PARCIAL CON M. MECÁNICOS LOSAS DE HORMIGÓN EN MASA

**Unidad:** m3.

Demolición parcial con medios mecánicos de losas de hormigón en masa, incluso p.p. de compresor o martillo percutor, carga manual y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CMM00200 - CAJEADO DE 5 cm, CON M. MECÁNICOS DE LOSAS DE HORMIGÓN EN MASA

**Unidad:** m2.

Cajeado de 5 cm, con medios mecánicos de losas de hormigón en masa, incluso p.p. de compresor o martillo percutor, carga manual y transporte de material sobrante a vertedero. Medida la superficie ejecutada.

### 01CMM00300 - REBAJE DE 10 cm, CON M. MECÁNICOS DE LOSAS DE HORMIGÓN EN MASA

**Unidad:** m2.

Rebaje de 10 cm, con medios mecánicos de losas de hormigón en masa, incluso p.p. de compresor o martillo percutor, carga manual y transporte de material sobrante a vertedero. Medida la superficie ejecutada.

### 01CMM00400 - DEMOLICIÓN PARCIAL CON M. MECÁNICOS DE MACIZOS DE HORM. EN MASA

**Unidad:** m3.

Demolición parcial con medios mecánicos de macizos de hormigón en masa, incluso p.p. de compresor o martillo
percutor, carga manual y transporte de material sobrante a vertedero. Medido el volumen inicial.

### 01CMM90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE HORMIGÓN EN MASA

**Unidad:** m3.

Demolición selectiva con medios manuales de hormigón en masa en elementos de cimentación. Medido el volumen inicial.

### 01CMM90002 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE HORMIGÓN EN MASA

**Unidad:** m3.

Demolición selectiva con medios mecánicos de hormigón en masa en elementos de cimentación, incluso p.p. de compresor. Medido el volumen inicial.

### 01CMM90004 - DEMOLICIÓN SELECTIVA M. MECÁNICOS HORM. EN MASA EXC.TIERRAS C/M

**Unidad:** m3.

Demolición selectiva con medios mecánicos de hormigón en masa en elementos de cimentación, incluso p.p. de compresor, excavación de tierras de consistencia media, hasta una profundidad máxima de 4 m y relleno posterior. Medido el volumen inicial.

### 01CMM90100 - DEMOLICIÓN SELECTIVA M. MECÁNICOS LOSAS DE HORMIGÓN EN MASA

**Unidad:** m3.

Demolición selectiva con medios mecánicos de losas de hormigón en masa, incluso p.p. de compresor o martillo percutor. Medido el volumen inicial.

### 01CMM90200 - DEMOLICIÓN SELECTIVA M. MEC. PARA CAJEADO DE 5 cm LOSAS H.M.

**Unidad:** m2.

Demolición selectiva con medios mecánicos para cajeado de 5 cm, de losas de hormigón en masa, incluso p.p. de compresor o martillo percutor. Medida la superficie ejecutada.

### 01CMM90300 - DEMOLICIÓN SELECTIVA M. MEC. PARA REBAJE DE 10 cm LOSAS H.M.

**Unidad:** m2.

Demolición selectiva con medios mecánicos para rebaje de 10 cm, con medios mecánicos de losas de hormigón en masa, incluso p.p. de compresor o martillo percutor. Medida la superficie ejecutada.

### 01CMM90400 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE MACIZOS DE HORM. EN MASA

**Unidad:** m3.

Demolición selectiva con medios mecánicos de macizos de hormigón en masa, incluso p.p. de compresor o martillo percutor. Medido el volumen inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Hormigón en masa

**Clasificación:** 01CM. **Capítulo:** demoliciones y trabajos previos. **Familia:** cimentaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «hormigón en masa», dentro de «cimentaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Comprobar cimentaciones y cargas de construcciones próximas; no retirar apoyos de elementos que deban permanecer.

Para la variante «hormigón en masa» se comprobarán expresamente profundidad, continuidad y conexiones de la cimentación existente. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
