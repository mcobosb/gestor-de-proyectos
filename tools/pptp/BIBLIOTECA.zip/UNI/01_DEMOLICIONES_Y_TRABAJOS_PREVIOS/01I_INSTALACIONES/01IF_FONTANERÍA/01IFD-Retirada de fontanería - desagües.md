"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de fontanería - desagües

**Clasificación BCCA:** `01IFD`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Desagües**, dentro de **Fontanería**.
Aplicable a las partidas cuyo código BCCA comienza por `01IFD`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01IFD00001 - DESMONTADO DE DESAGÜE DE URINARIO CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de urinario con tubo de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD00002 - DESMONTADO DE DESAGÜE DE BAÑERA CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de bañera con tubo de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD00003 - DESMONTADO DEDESAGÜE DE PLATO, CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de plato ducha con tubo de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD00004 - DESMONTADO DE DESAGÜE DE FREGADERO CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de fregadero con tubo de plomo incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unida terminada.

### 01IFD00005 - DESMONTADO DE DESAGÜE DE INODORO, MANGUETÓN DE PLOMO

**Unidad:** u.

Desmontado de desagüe de inodoro con manguetón de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD00006 - DESMONTADO DE DESAGÜE DE LAVABO CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de lavabo con tubo de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD00007 - DESMONTADO DE DESAGÜE DE BIDE CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de bide con tubo de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD00008 - DESMONTADO DE DESAGÜE DE PILA CON TUBO DE PLOMO

**Unidad:** u.

Desmontado de desagüe de pila con tubo de plomo, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFD90001 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE URINARIO CON SELECC. PLOMO

**Unidad:** u.

Demolición masiva con medios manuales de desagüe de urinario con selección de tubo de plomo. Medida la cantidad ejecutada

### 01IFD90002 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE BAÑERA CON SELECC. PLOMO

**Unidad:** u.

Demolición de desagüe de bañera con selección de tubo de plomo. Medida la cantidad ejecutada

### 01IFD90003 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE PLATO DUCHA CON SELECC. PLOMO

**Unidad:** u.

Demolición masiva de desagüe de plato ducha con tubo de plomo. Medida la cantidad ejecutada

### 01IFD90004 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE FREGADERO CON SELECC. PLOMO

**Unidad:** u.

Demolición selectiva con medios manuales de desagüe de fregadero con selección de tubo de plomo. Medida la cantidad ejecutada

### 01IFD90005 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE INODORO CON SELECC. PLOMO

**Unidad:** u.

Demolición masiva de desagüe de inodoro con selección de manguetón de plomo. Medida la cantidad ejecutada

### 01IFD90006 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE LAVABO CON SELECC. PLOMO

**Unidad:** u.

Demolición masiva de desagüe de lavabo con selección de tubo de plomo. Medida la cantidad ejecutada

### 01IFD90007 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE BIDE CON SELECC. PLOMO

**Unidad:** u.

Demolición masiva con medios manuales de desagüe de bidé con selección de tubo de plomo. Medida la cantidad ejecutada

### 01IFD90008 - DEMOLICIÓN MASIVA M. MAN. DESAGÜE DE PILA CON SELECC. PLOMO

**Unidad:** u.

Demolición masiva de desagüe de pila con selección de tubo de plomo. Medida la cantidad ejecutada

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Fontanería

**Clasificación:** 01IF. **Capítulo:** demoliciones y trabajos previos. **Familia:** instalaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «fontanería», dentro de «instalaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Coordinar con el titular la desconexión, consignación y verificación de ausencia de energía o fluido antes del desmontaje.

Para la variante «fontanería» se comprobarán expresamente servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
