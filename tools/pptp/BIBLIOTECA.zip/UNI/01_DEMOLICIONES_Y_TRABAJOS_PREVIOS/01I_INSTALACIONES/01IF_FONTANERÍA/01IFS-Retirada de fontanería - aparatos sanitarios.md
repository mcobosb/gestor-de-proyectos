"""
# Retirada de fontanería - aparatos sanitarios

**Clasificación BCCA:** `01IFS`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Aparatos sanitarios**, dentro de **Fontanería**.
Aplicable a las partidas cuyo código BCCA comienza por `01IFS`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01IFS00001 - DESMONTADO DE BAÑERA Y EQUIPO DE GRIFERÍA

**Unidad:** u.

Desmontado de bañera para revestir y equipo de grifería, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00002 - DESMONTADO DE PLATO DUCHA Y EQUIPO DE GRIFERÍA

**Unidad:** u.

Desmontado de plato ducha y equipo de grifería, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00003 - DESMONTADO DE FREGADERO Y EQUIPO DE GRIFERÍA

**Unidad:** u.

Desmontado de fregadero y equipo de grifería. Medida la unidad terminada.

### 01IFS00004 - DESMONTADO DE INODORO DE TANQUE BAJO

**Unidad:** u.

Desmontado de inodoro de tanque bajo. Medida la unidad terminada.

### 01IFS00005 - DESMONTADO DE INODORO DE TANQUE ALTO

**Unidad:** u.

Desmontado de inodoro de tanque alto. Medida la unidad terminada.

### 01IFS00006 - DESMONTADO DE LAVABO PEDESTAL Y EQUIPO DE GRIFERÍA

**Unidad:** u.

Desmontado de lav abo pedestal y equipo de grifería. Medida la unidad terminada.

### 01IFS00007 - DESMONTADO DE BIDÉ Y EQUIPO DE GRIFERÍA

**Unidad:** u.

Desmontado de bide y equipo de grifería. Medida la unidad terminada.

### 01IFS00008 - DESMONTADO DE PILA Y EQUIPO DE GRIFERÍA

**Unidad:** u.

Desmontado de pila y equipo de grifería. Medida la unidad terminada.

### 01IFS00009 - DESMONTADO DE URINARIO Y CISTERNA COMPLEMENTARIA

**Unidad:** u.

Desmontado de urinario y cisterna complementaria. Medida la unidad terminada.

### 01IFS00011 - DESMONTADO DE BAÑERA Y EQUIPO DE GRIFERÍA, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de bañera para revestir y equipo de grifería, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00012 - DESMONTADO DE PLATO DUCHA Y EQ. DE GRIFERÍA, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de plato ducha y equipo de grifería, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00013 - DESMONTADO DE FREGADERO Y EQ. DE GRIFERÍA, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de fregadero y equipo de grifería, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00014 - DESMONTADO DE INODORO DE TANQUE BAJO, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de inodoro de tanque bajo, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00015 - DESMONTADO DE INODORO DE TANQUE ALTO, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de inodoro de tanque alto, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00016 - DESMONTADO DE LAVABO PEDESTAL Y EQ. GRIFERÍA, SIN APROVECHAM.

**Unidad:** u.

Desmontado de lav abo pedestal y equipo de grifería, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00017 - DESMONTADO DE BIDÉ Y EQUIPO DE GRIFERÍA, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de bide y equipo de grifería, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00018 - DESMONTADO DE PILA Y EQUIPO DE GRIFERÍA, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de pila y equipo de grifería, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS00019 - DESMONTADO DE URINARIO Y CISTERNA COMPLEM, SIN APROVECHAMIENTO

**Unidad:** u.

Desmontado de urinario y cisterna complementaria, sin ningun tipo de aprovechamiento, incluso p.p. de carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IFS90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE BAÑERA Y EQ. GRIFERÍA

**Unidad:** u.

Demolición selectiva con medios manuales de bañera para revestir y equipo de grifería. Medida la cantidad ejecutada.

### 01IFS90002 - DEMOLICIÓN SELECTIVA M. MANUALES DE PLATO DUCHA Y EQ. GRIFERÍA

**Unidad:** u.

Demolición selectiva de plato ducha y equipo de grifería. Medida la cantidad ejecutada.

### 01IFS90003 - DEMOLICIÓN SELECTIVA M. MANUALES DE FREGADERO Y EQ. GRIFERÍA

**Unidad:** u.

Demolición selectiva con medios manuales de fregadero y equipo de grifería. Medida la cantidad ejecutada.

### 01IFS90004 - DEMOLICIÓN SELECTIVA M. MANUALES DE INODORO DE TANQUE BAJO

**Unidad:** u.

Demolición selectiva con medios manuales de inodoro de tanque bajo. Medida la cantidad ejecutada.

### 01IFS90005 - DEMOLICIÓN SELECTIVA M. MANUALES DE INODORO DE TANQUE ALTO

**Unidad:** u.

Demolición selectiva con medios manuales de inodoro de tanque alto. Medida la cantidad ejecutada.

### 01IFS90006 - DEMOLICIÓN SELECTIVA M. MAN. DE LAVABO PEDESTAL Y EQ. GRIFERÍA

**Unidad:** u.

Demolición selectiva con medios manuales de lavabo pedestal y equipo de grifería. Medida la cantidad ejecutada.

### 01IFS90007 - DEMOLICIÓN SELECTIVA M. MANUALES DE BIDÉ Y EQ. GRIFERÍA

**Unidad:** u.

Demolición selectiva con medios manuales de bidé y equipo de grifería. Medida la cantidad ejecutada.

### 01IFS90008 - DEMOLICIÓN SELECTIVA M. MANUALES DE PILA Y EQ. GRIFERÍA

**Unidad:** u.

Demolición selectiva con medios manuales de pila y equipo de grifería. Medida la cantidad ejecutada.

### 01IFS90009 - DEMOLICIÓN SELECTIVA M. MANUALES DE URINARIO Y CISTERNA

**Unidad:** u.

Demolición selectiva con medios manuales de urinario y cisterna complementaria. Medida la cantidad ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Fontanería

**Clasificación:** 01IF. **Capítulo:** demoliciones y trabajos previos. **Familia:** instalaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «fontanería», dentro de «instalaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Coordinar con el titular la desconexión, consignación y verificación de ausencia de energía o fluido antes del desmontaje.

Para la variante «fontanería» se comprobarán expresamente servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
