"""
# Retirada de eléctricas - varios

**Clasificación BCCA:** `01IEW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Eléctricas**.
Aplicable a las partidas cuyo código BCCA comienza por `01IEW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01IEW00001 - DESMONTADO DE CUADRO GENERAL DE PROTECCIÓN

**Unidad:** u.

Desmontado de cuadro general de proteccion, incluso p.p. de ayudas de albañilería, carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IEW00002 - DESMONTADO DE CUADRO INDIVIDUAL

**Unidad:** u.

Desmontado de cuadro indiv idual incluso p.p. de ayudas de albañilería. Medida la unidad terminada.

### 01IEW00003 - DESMONTADO DE CUADRO INDIVIDUAL, CARGA Y TRANSPORTE A VERTEDERO

**Unidad:** u.

Desmontado de cuadro indiv idual incluso p.p. de ayudas de albañilería, carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IEW00051 - DESMONTADO INST. ELÉC. VIVIENDA (SUP. <=100 m2)

**Unidad:** u.

Desmontado de instalación eléctrica completa de vivienda, de superficie igual o menor de 100 m2, formada por: cajas de proteccion, interruptores, circuitos, puntos de luz, tomas de corriente, etc., incluso p.p. de ayudas de albañilería, carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IEW00052 - DESMONTADO INST. ELÉC. VIVIENDA (SUP. 100-200 m2)

**Unidad:** u.

Desmontado de instalación eléctrica completa de vivienda, de superficie entre 100 y 200 m2, formada por: cajas de proteccion, interruptores, circuitos, puntos de luz, tomas de corriente, etc., incluso p.p. de ay udas de albañilería, carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IEW00053 - DESMONTADO INST. ELÉC. VIVIENDA (SUP. >200 m2)

**Unidad:** u.

Desmontado de instalación eléctrica completa de vivienda, de superficie may or de 200 m2, formada por: cajas de proteccion, interruptores, circuitos, puntos de luz, tomas de corriente, etc., incluso p.p. de ayudas de albañilería, carga y transporte de material sobrante a vertedero. Medida la unidad terminada.

### 01IEW90001 - DEMOLICIÓN MASIVA M. MANUALES DE CUADRO GENERAL DE PROTECCIÓN

**Unidad:** u.

Demolición masiva con medios manuales de cuadro general de protección. Medida la cantidad ejecutada.

### 01IEW90002 - DEMOLICIÓN MASIVA M. MANUALES DE CUADRO INDIVIDUAL

**Unidad:** u.

Demolición masiva con medios manuales de cuadro individual. Medida la cantidad ejecutada.

### 01IEW90051 - DEMOLICIÓN MASIVA M. MAN. DE INST. ELÉC. VIV. (SUP. <=100 m2)

**Unidad:** u.

Demolición masiva con medios manuales de instalación eléctrica completa de vivienda, de superficie igual o menor de 100 m2, formada por: cajas de protección, interruptores, circuitos, puntos de luz, tomas de corriente, etc. Medida la cantidad ejecutada.

### 01IEW90051N - DEMOLICIÓN MASIVA M. MAN. DE INST. ELÉC. (SUP. <=100 m2)

**Unidad:** u.

Demolición masiva con medios manuales de instalación eléctrica completa, de superficie igual o menor de 100 m2, formada por: cajas de protección, interruptores, circuitos, puntos de luz, tomas de corriente, etc. Medida la cantidad ejecutada.

### 01IEW90052 - DEMOLICIÓN MASIVA M. MAN. DE INST. ELÉC. VIV. (SUP. 100-200 m2)

**Unidad:** u.

Demolición masiva con medios manuales de instalación eléctrica completa de vivienda, de superficie entre 100 y 200 m2, formada por: cajas de protección, interruptores, circuitos, puntos de luz, tomas de corriente, etc. Medida la cantidad ejecutada.

### 01IEW90052N - DESMONTADO DE INSTALACIÓN DE ELÉCTRICA EN ASEOS

**Unidad:** u.

Demolicón con medios manuales de instalación eléctrica completa de aseos, incluso carga y transporte en contenedorr, a vertedero autorizado o punto de gestión de residuos, de las materias obtenidas. Medida la cantidad ejecutada.

### 01IEW90053 - DEMOLICIÓN MASIVA M. MAN. DE INST. ELÉC. VIV. (SUP. >200 m2)

**Unidad:** u.

Demolición masiva con medios manuales de instalación eléctrica completa de vivienda, de superficie mayor de 200 m2, formada por: cajas de protección, interruptores, circuitos, puntos de luz, tomas de corriente, etc. Medida la cantidad ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Eléctricas

**Clasificación:** 01IE. **Capítulo:** demoliciones y trabajos previos. **Familia:** instalaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «eléctricas», dentro de «instalaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Coordinar con el titular la desconexión, consignación y verificación de ausencia de energía o fluido antes del desmontaje.

Para la variante «eléctricas» se comprobarán expresamente servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
