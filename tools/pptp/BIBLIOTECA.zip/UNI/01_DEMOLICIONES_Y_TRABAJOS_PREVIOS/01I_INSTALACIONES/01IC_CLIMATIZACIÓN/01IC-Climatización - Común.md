# Climatización - Común

**Clasificación:** 01IC. **Capítulo:** demoliciones y trabajos previos. **Familia:** instalaciones.

## Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «climatización», dentro de «instalaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Coordinar con el titular la desconexión, consignación y verificación de ausencia de energía o fluido antes del desmontaje.

Para la variante «climatización» se comprobarán expresamente servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
