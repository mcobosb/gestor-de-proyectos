"""
# Retirada de climatización - aire acondicionado

**Clasificación BCCA:** `01ICA`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Aire acondicionado**, dentro de **Climatización**.
Aplicable a las partidas cuyo código BCCA comienza por `01ICA`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01ICA00100 - DESMONTAJE DE EQUIPO DE CLIMATIZACIÓN

**Unidad:** u.

Desmontaje de aparato de aire acondicionado, consistente en la desconexión y desmontado de alimentación eléctrica al equipo, extracción de cualquier gas refrigerante conforme a normativa aplicable mediante bomba de vacío y llenado de recipiente para su posterior gestión del resíduo, desmontado de unidad exterior incluso soportes anclados a fachada, desmontado de unidad interior, desmontado de tuberías aisladas de gas refrigerante, canaletas de superficie y tuberías de desagüe, cegado de hueco restituyendo las condiciones iniciales del cerramiento en el caso de equipos de ventana.  Incluso restitución de revestimiento y acabado con pintura de color y textura similar a la existente.  Medida la unidad ejecutada.

### 01ICA00200 - DESPLAZAMIENTO DE AIRE ACONDICIONADO A PLANO EXTERIOR

**Unidad:** u.

Circuito de otros usos, instalado con cable de cobre de tres conductores H07V-K de 2,5 mm2 de sección nominal, empotrado y aislado con tubo de PVC flexible de 13 mm de diámetro, incluso p.p. de cajas de derivación y ayudas de albañilería; construido según REBT. Medida la longitud ejecutada desde la caja de protección hasta la caja de registro del ultimo recinto suministrado.

### 01ICA00300 - DESMONTAJE DE UNIDAD INTERIOR DE SISTEMA DE AIRE ACONDICIONADO

**Unidad:** u.

Desmontaje de unidad interior de sistema de aire acondicionado, de pared, de 50 Kg de peso máximo, con medios manuales, y recuperación del material para su posterior ubicación en otro emplazamiento, y carga manual sobre camión o contenedor. El precio incluye el desmontaje de los accesorios y de los soportes de fijación y la obturación de las conducciones conectadas al elemento.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Climatización

**Clasificación:** 01IC. **Capítulo:** demoliciones y trabajos previos. **Familia:** instalaciones.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «climatización», dentro de «instalaciones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Coordinar con el titular la desconexión, consignación y verificación de ausencia de energía o fluido antes del desmontaje.

Para la variante «climatización» se comprobarán expresamente servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
