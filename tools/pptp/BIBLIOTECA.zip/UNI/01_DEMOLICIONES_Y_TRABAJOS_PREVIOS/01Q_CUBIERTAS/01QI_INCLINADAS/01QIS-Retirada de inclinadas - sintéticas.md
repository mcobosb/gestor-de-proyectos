"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de inclinadas - sintéticas

**Clasificación BCCA:** `01QIS`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Sintéticas**, dentro de **Inclinadas**.
Aplicable a las partidas cuyo código BCCA comienza por `01QIS`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01QIS00001 - DESMONTADO CUBIERTA DE CHAPA ONDULADA MAT. SINTÉTICOS

**Unidad:** m2.

Desmontado, con medios manuales, de cubierta de chapa ondulada de materiales sintéticos, incluso desmontado de cumbreras, limahoyas, canalones, encuentros con paramentos y p.p. de carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial en verdadera magnitud.

### 01QIS90001 - DEMOLICIÓN MASIVA M. MAN. CUBIERTA DE CHAPA ONDULADA MAT. SINT.

**Unidad:** m2.

Demolición masiva con medios manuales, de cubierta de chapa ondulada de materiales sintéticos, incluso demolición de cumbreras, limahoyas, canalones, encuentros con paramentos. Medida la superficie inicial en verdadera magnitud.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Inclinadas

**Clasificación:** 01QI. **Capítulo:** demoliciones y trabajos previos. **Familia:** cubiertas.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «inclinadas», dentro de «cubiertas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Comprobar estabilidad y protección frente a caídas, retirar por fases y mantener la evacuación provisional de agua.

Para la variante «inclinadas» se comprobarán expresamente composición de cubierta, accesos, protecciones y cierre provisional. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
