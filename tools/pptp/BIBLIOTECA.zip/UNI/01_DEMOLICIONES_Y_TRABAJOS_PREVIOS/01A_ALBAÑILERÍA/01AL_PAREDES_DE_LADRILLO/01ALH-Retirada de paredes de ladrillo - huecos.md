"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de paredes de ladrillo - huecos

**Clasificación BCCA:** `01ALH`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Huecos**, dentro de **Paredes de ladrillo**.
Aplicable a las partidas cuyo código BCCA comienza por `01ALH`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01ALH00001 - DEMOLICIÓN DE CITARA DE L/H CON M. MANUALES

**Unidad:** m2.

Demolición de citara de ladrillo hueco con medios manuales, incluso carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial deduciendo huecos.

### 01ALH00002 - DEMOLICIÓN DE CITARA DE L/H CON M. MECÁNICOS

**Unidad:** m2.

Demolición de citara de ladrillo hueco con medios mecánicos, incluso carga mecánica y transporte de material sobrante a vertedero. Medida la superficie inicial deduciendo huecos.

### 01ALH00003 - DEMOLICIÓN DE MURO DE L/H CON M. MANUALES

**Unidad:** m3.

Demolición de muro de ladrillo hueco con medios manuales, incluso carga manual y transporte de material sobrante a vertedero. Medido el volumen inicial deduciendo huecos.

### 01ALH00004 - DEMOLICIÓN DE MURO DE L/H CON M. MECÁNICOS

**Unidad:** m3.

Demolición de muro de ladrillo hueco con medios mecánicos, incluso carga mecánica y transporte de material sobrante a vertedero. Medido el volumen inicial deduciendo huecos.

### 01ALH00005 - DEMOLICIÓN DE DOBLE TABIQUE A LA CAPUCHINA

**Unidad:** m2.

Demolición de doble tabique a la capuchina de ladrillo hueco sencillo, con medios manuales, incluso carga manual y transporte de material sobrante a vertedero. Medida la superficie inicial deduciendo huecos.

### 01ALH00006 - DEMOLICIÓN DE MURO DE L/H M. MANUALES T. CONTENEDOR

**Unidad:** m3.

Demolición de muro de ladrillo hueco con medios manuales, incluso transporte de material sobrante a contenedor colocado en obra a una distancia media de 50 m. Medido el volumen inicial deduciendo huecos.

### 01ALH00007 - DEMOLICIÓN DE MURO DE L/H M. MANUALES, C. MANUAL, T. CONTENEDOR

**Unidad:** m3.

Demolición de muro de ladrillo hueco con medios manuales, incluso carga manual y transporte de material sobrante a vertedero con contenedor. Medido el volumen inicial deduciendo huecos.

### 01ALH00008 - DEMOLICIÓN DE CITARA DE L/H M. MANUALES, C. MECÁNICA, T. VERT.

**Unidad:** m2.

Demolición de citara de ladrillo hueco con medios manuales, incluso carga mecánica y transporte de material sobrante a vertedero. Medido la superficie inicial deduciendo huecos.

### 01ALH00009 - DEMOLICIÓN DE MURO DE L/H M. MANUALES, C. MECÁNICA, T. VERT.

**Unidad:** m3.

Demolición de muro de ladrillo hueco con medios manuales, incluso carga mecánica y transporte de material sobrante a vertedero. Medido el volumen inicial deduciendo huecos.

### 01ALH00010 - DEMOLICIÓN DE PARTICIÓN INTERIOR DE CITARA DE LADRILLO HUECO

**Unidad:** m2.

Demolición de partición interior de citara de ladrillo hueco, con medios manuales, incluso rev estimientos continuos, delcolgado de carpintería, desmontado de cerco, p.p. de instalaciones, alicatados, carga mecánica y transporte de material sobrante a vertedero. Medida la superfice inicial deduciendo huecos.

### 01ALH90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE CITARA DE L/H

**Unidad:** m2.

Demolición selectiva con medios manuales de citara de ladrillo hueco. Medida la superficie inicial deduciendo huecos.

### 01ALH90002 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE CITARA DE L/H

**Unidad:** m2.

Demolición selectiva con medios mecánicos de citara de ladrillo hueco. Medida la superficie inicial deduciendo huecos.

### 01ALH90003 - DEMOLICIÓN SELECTIVA M. MANUALES DE MURO DE L/H

**Unidad:** m3.

Demolición selectiva con medios manuales de muro de ladrillo hueco. Medido el volumen inicial deduciendo huecos.

### 01ALH90004 - DEMOLICIÓN SELECTIVA M. MECÁNICOS DE MURO DE L/H

**Unidad:** m3.

Demolición selectiva con medios mecánicos de muro de ladrillo hueco. Medido el volumen inicial deduciendo huecos.

### 01ALH90005 - DEMOLICIÓN SELECTIVA M. MANUALES DE DOBLE TABIQUE A LA CAPUCHINA

**Unidad:** m2.

Demolición selectiva con medios manuales de doble tabique a la capuchina de ladrillo hueco sencillo. Medida la superficie inicial deduciendo huecos.

### 01ALH90010 - DEMOLICIÓN MASIVA M. MANUALES DE PARTICIÓN INTERIOR CITARA L/H

**Unidad:** m2.

Demolición masiva con medios manuales de partición interior de citara de ladrillo hueco con guarncido de yeso. Medida la superfice inicial deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Paredes de ladrillo

**Clasificación:** 01AL. **Capítulo:** demoliciones y trabajos previos. **Familia:** albañilería.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «paredes de ladrillo», dentro de «albañilería». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Identificar si la fábrica arriostra o soporta otras partes; aprobar apeos y límites de retirada antes de desmontarla.

Para la variante «paredes de ladrillo» se comprobarán expresamente función resistente de la fábrica, aparejo y elementos que permanecen. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
