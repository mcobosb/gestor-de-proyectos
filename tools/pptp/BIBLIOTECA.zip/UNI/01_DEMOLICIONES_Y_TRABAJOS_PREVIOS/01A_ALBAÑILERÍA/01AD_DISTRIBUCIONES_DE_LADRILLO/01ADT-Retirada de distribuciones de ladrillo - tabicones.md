"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de distribuciones de ladrillo - tabicones

**Clasificación BCCA:** `01ADT`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Tabicones**, dentro de **Distribuciones de ladrillo**.
Aplicable a las partidas cuyo código BCCA comienza por `01ADT`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01ADT00001 - DEMOLICIÓN DE TABICÓN DE LAD. GAFA, C. MECÁNICA, T. VERTEDERO

**Unidad:** m2.

Demolición de tabicón de ladrillo gafa con medios manuales, incluso carga mecánica y transporte de material sobrante a vertedero. Medida la superficie inicial deduciendo huecos.

### 01ADT00002 - DEMOLICIÓN DE TABICÓN DE LADRILLO GAFA, T. A CONTENEDOR

**Unidad:** m2.

Demolición de tabicón de ladrillo gafa con medios manuales, incluso trasporte de material sobrante a contenedor colocado en obra a una distancia media de 50 m. Medida la superficie inicial deduciendo huecos.

### 01ADT00003 - DEMOLICIÓN DE TABICÓN DE LADRILLO, C. MANUAL, T. VERT. CONTENED.

**Unidad:** m2.

Demolición de tabicón de ladrillo con medios manuales, incluso carga manual y transporte de material sobrante a vertedero con contenedor. Medida la superficie inicial deduciendo huecos.

### 01ADT00004 - DEMOLICIÓN DE TABICÓN DE LADRILLO, C. MECÁNICA T. VERTEDERO

**Unidad:** m2.

Demolición de tabicón de ladrillo con medios manuales, incluso carga mecánica y trasporte de material sobrante a vertedero. Medida la superficie inicial deduciendo huecos.

### 01ADT00005 - DEMOLICIÓN DE PARTICIÓN INTERIOR DE TABICÓN DE L/GAFA SENCILLO

**Unidad:** m2.

Demolición de partición interior de tabicón de ladrillo gafa sencillo, con medios manuales, incluso revestimientos continuos, delcolgado de carpintería, desmontado de cerco. p.p. de instalaciones, alicatados, carga mecánica y transporte de material sobrante a vertedero. Medida la superfice inicial deduciendo huecos.

### 01ADT90001 - DEMOLICIÓN SELECTIVA M. MANUALES DE TABICÓN DE L/GAFA

**Unidad:** m2.

Demolición selectiva con medios manuales, de tabicón de ladrillo gafa. Medida la superficie inicial deduciendo huecos.

### 01ADT90004 - DEMOLICIÓN SELECTIVA M. MANUALES DE TABICÓN DE LADRILLO

**Unidad:** m2.

Demolición selectiva con medios manuales de tabicón de ladrillo. Medida la superficie inicial deduciendo huecos.

### 01ADT90005 - DEMOLICIÓN MASIVA M. MANUALES DE PARTICIÓN INTERIOR DE TABICÓN

**Unidad:** m2.

Demolición masiva con medios manuales de partición interior de tabicón de ladrillo gafa sencillo, con guarnecido de yeso. Medida la superfice inicial deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Distribuciones de ladrillo

**Clasificación:** 01AD. **Capítulo:** demoliciones y trabajos previos. **Familia:** albañilería.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «distribuciones de ladrillo», dentro de «albañilería». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Identificar si la fábrica arriostra o soporta otras partes; aprobar apeos y límites de retirada antes de desmontarla.

Para la variante «distribuciones de ladrillo» se comprobarán expresamente función resistente de la fábrica, aparejo y elementos que permanecen. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
