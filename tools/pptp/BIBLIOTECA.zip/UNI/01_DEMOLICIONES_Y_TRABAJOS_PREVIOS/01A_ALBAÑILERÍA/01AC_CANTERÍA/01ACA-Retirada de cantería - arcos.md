"""
# Retirada de cantería - arcos

**Clasificación BCCA:** `01ACA`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Arcos**, dentro de **Cantería**.
Aplicable a las partidas cuyo código BCCA comienza por `01ACA`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Cantería

**Clasificación:** 01AC. **Capítulo:** demoliciones y trabajos previos. **Familia:** albañilería.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «cantería», dentro de «albañilería». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Identificar si la fábrica arriostra o soporta otras partes; aprobar apeos y límites de retirada antes de desmontarla.

Para la variante «cantería» se comprobarán expresamente función resistente de la fábrica, aparejo y elementos que permanecen. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
