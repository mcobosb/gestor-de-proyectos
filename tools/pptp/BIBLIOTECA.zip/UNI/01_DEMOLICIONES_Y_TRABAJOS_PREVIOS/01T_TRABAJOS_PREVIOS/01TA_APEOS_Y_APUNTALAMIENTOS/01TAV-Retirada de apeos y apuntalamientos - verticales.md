"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de apeos y apuntalamientos - verticales

**Clasificación BCCA:** `01TAV`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Verticales**, dentro de **Apeos y apuntalamientos**.
Aplicable a las partidas cuyo código BCCA comienza por `01TAV`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01TAV00030 - FACHADA ESTABILIZADA CON ENTRAMADO METÁLICO HASTA 6 MESES

**Unidad:** m2.

Fachada estabilizada hasta 6 meses formada por: base de contrapeso, elementos de conexión perdidos, torre estabilizadora con perfiles metálicos aligerados, zunchados al muro con entramado metálico y elementos de unión incluso p.p. de revisión y mantenimiento, retirada de contrapesos y gestión de residuos. Medida la superficie capaz a una cara en proyección vertical.

### 01TAV00035 - FACHADA ESTABILIZADA CON ENTRAMADO METÁLICO

**Unidad:** m2.

Fachada estabilizada formada por: base de contrapeso, elementos de conexión perdidos, torre estabilizadora con perfiles metálicos aligerados, zunchados al muro con entramado metálico y elementos de unión incluso p.p. de revisión y mantenimiento, retirada de contrapesos y gestión de residuos. Medida la superficie capaz a una cara en proyección vertical.

### 01TAV00050 - ESTABILIZADOR INTERIOR HASTA 6 MESES

**Unidad:** m2.

Muro estabilizado hasta 6 meses, con estabilizador interior formado por: zunchado del muro con tensores y codales horizontales y elementos de unión incluso p.p. de revisión de mantenimiento y desmontaje. Medida la superficie capaz a una cara.

### 01TAV00055 - ESTABLIZADOR INTERIOR DE 6 A 12 MESES

**Unidad:** m2.

Muro estabilizado de 6 a 12 meses, con estabilizador interior formado por: zunchado del muro con tensores y codales horizontales y elementos de unión incluso p.p. de revisión de mantenimiento y desmontaje. Medida la superficie capaz a una cara.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Apeos y apuntalamientos

**Clasificación:** 01TA. **Capítulo:** demoliciones y trabajos previos. **Familia:** trabajos previos.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «apeos y apuntalamientos», dentro de «trabajos previos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Justificar el trabajo previo por la necesidad de la fase de obra; registrar estado inicial y condiciones para su retirada o finalización. Dimensionar y mantener los apeos hasta que exista transferencia de cargas aprobada; registrar colocación y retirada.

Para la variante «apeos y apuntalamientos» se comprobarán expresamente alcance temporal, interfaces y condiciones de reposición; cargas provisionales, apoyos y fases de descarga. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
