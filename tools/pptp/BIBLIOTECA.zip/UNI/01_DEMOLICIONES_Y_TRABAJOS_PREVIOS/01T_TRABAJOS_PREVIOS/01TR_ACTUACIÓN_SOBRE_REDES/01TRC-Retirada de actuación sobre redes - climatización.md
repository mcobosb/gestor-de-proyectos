"""
# Retirada de actuación sobre redes - climatización

**Clasificación BCCA:** `01TRC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Climatización**, dentro de **Actuación sobre redes**.
Aplicable a las partidas cuyo código BCCA comienza por `01TRC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Reposición y desvío de servicios afectados

**Clasificación:** 01TR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Trabajos autorizados para restituir las condiciones de servicio de redes afectadas por el proyecto, diferenciados de la reparación de daños imputables al contratista.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1023–1026. Transcripción para trazabilidad.
"""

El contratista realizará las operaciones y desvíos de aquellos Servicios que la Dirección de Obra considere como afectados, teniendo en cuenta lo especificado por las compañías suministradoras.
Toda la obra se realizará según los Métodos de construcciones y Seguridad y Salud.
Se definirán como unidades de obra que comprenden todos los materiales y trabajos necesarios para restituir las condiciones de servicio iniciales con la nueva situación del trazado del proyecto, de acuerdo con la entidad concesionaria del servicio.

#### Ejecución

Inventariar y localizar servicios, coordinar con titulares y aprobar desvíos y secuencias de corte antes de intervenir. Mantener suministros y accesos según la solución acordada, probar la reposición y entregar documentación de su ubicación final.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 542–543. Transcripción para trazabilidad.
"""

Antes de comenzar las obras, el Contratista, basado en los planos y datos de que disponga, o reconocimientos efectuados, deberá estudiar y replantear sobre el terreno los servicios e instalaciones afectadas, considerando la mejor forma de ejecutar los trabajos para no dañarlos y señalando los que, en último extremo, considera necesario modificar. Si el Director de la obra se muestra conforme, solicitará de las Empresas u Organismos correspondientes la modificación de estas instalaciones, abonándose los trabajos que sean necesarios realizar.

#### Medición y valoración

Por las unidades previstas en el cuadro de precios para reposiciones necesarias autorizadas, conforme a 5.3. Las reparaciones de roturas imputables al contratista no se convierten en partidas nuevas.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1108–1111. Transcripción para trazabilidad.
"""

Se medirán y abonarán por la dimensión especificada en el Cuadro de Precios, metro lineal (ml), metro cuadrado (m²), metro cúbico (m³), de la unidad realmente ejecutada y referida únicamente a aquellas que, a juicio del Director de la obra, sean consecuencia obligada de la ejecución del Proyecto contratado.
Los precios incluyen todas las operaciones, materiales, mano de obra, maquinaria y medios auxiliares necesarios para la completa ejecución y perfecto acabado.
Todas las reparaciones de roturas o averías en los diversos servicios públicos o particulares, los tendrá que realizar obligatoriamente el Contratista por su cuenta exclusiva y sin derecho a abono de cantidad alguna.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
