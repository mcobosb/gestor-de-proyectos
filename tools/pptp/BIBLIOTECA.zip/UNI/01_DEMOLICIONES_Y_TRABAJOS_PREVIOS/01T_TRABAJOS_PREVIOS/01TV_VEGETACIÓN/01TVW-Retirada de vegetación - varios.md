"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de vegetación - varios

**Clasificación BCCA:** `01TVW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Vegetación**.
Aplicable a las partidas cuyo código BCCA comienza por `01TVW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Desbroce y limpieza del terreno

**Clasificación:** 01TV. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Retirada de vegetación, tocones, broza y materiales no deseables de las zonas autorizadas, conservando el arbolado y las referencias señaladas.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 18–22. Transcripción para trazabilidad.
"""

Se define como el trabajo consistente en retirar y extraer de las zonas de obras y de las zonas que se designen por la dirección facultativa todos los árboles, troncos, plantas, tierra vegetal, maleza, broza, escombros, basuras o cualquier otro material no deseable.
Su ejecución incluye tanto la excavación de los materiales como su retirada.
Se efectuará únicamente donde lo indique el Director de la Obra, manteniendo las zonas no urbanizables que lindan con la urbanización y las zonas de protección de arroyos libres de vertidos.

#### Ejecución

Replantear las zonas y los elementos protegidos, retirar selectivamente la vegetación y acopiar por separado la tierra vegetal recuperable. Gestionar los residuos vegetales y restantes fracciones sin vertidos indiscriminados. Comprobar con la dirección las profundidades de destoconado antes de ejecutar.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 23–28. Transcripción para trazabilidad.
"""

Se efectuará con las precauciones necesarias para conseguir unas condiciones de seguridad suficientes y evitar daños a estructuras existentes.
La Dirección Facultativa designará y marcará los elementos que haga falta conservar intactos. Ningún hito de propiedad o marca topográfica desaparecerá hasta que una persona autorizada por la Dirección Facultativa haya referenciado su situación o aprobado su desplazamiento.
No se cortará ningún árbol sin autorización expresa de la Dirección Facultativa que habrá definido y marcado claramente los que se haya de conservar. Todos los troncos y raíces serán eliminados hasta una profundidad no inferior a un metro por debajo de la explanada. También se eliminarán las tierras vegetales de forma que no queden sustancias vegetales a menos de 1 m. de la cota de la explanada definitiva.
En los terraplenes se eliminarán todos los troncos o raíces con diámetro superior a 10 cm con el fin que no quede ninguno en el cimiento del terraplén, ni a menos de 30 cm de profundidad sobre la superficie natural del terreno. En terraplenes con altura inferior a 1 cm se eliminará también todo tipo se sustancia orgánico vegetal hasta una profundidad de 1 m por debajo de la explanada definitiva.
Las tierras vegetales se transportarán a vertedero o se recogerán en las zonas que indique la Dirección de Obras, con el fin de formar posteriormente las zonas verdes.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 544–549. Transcripción para trazabilidad.
"""

Antes de comenzar los trabajos se procederá, en las zonas designadas por el Director de la obra, a la extracción y retirada de todos los árboles, tocones, plantas, maderas caídas, broza, escombros, basuras, vallados, y, en general, de todo material indeseable y cuya eliminación no esté incluida en el concepto de demoliciones.
Las operaciones necesarias se efectuarán con las precauciones adecuadas para lograr unas condiciones de seguridad suficiente y evitar daños en las estructuras que puedan resultar afectadas o molestas a los ocupantes de zonas próximas a la obra y de acuerdo con las instrucciones del Director de la obra, quien designará los elementos que hayan de conservar intactos, los árboles que deban ser trasplantados y las precauciones especiales en la retirada de elementos que puedan ser aprovechables.
Tanto en los desmontes como en el terreno natural que vaya a servir de base a los terraplenes, todos los tocones y raíces mayores de diez centímetros (10 cm) de diámetro serán eliminados hasta una profundidad no inferior a cincuenta centímetros (50 cm) por debajo de la explanación o del terreno.
Se tendrá especial cuidado de no dañar ni desplazar ningún hito, marca de propiedad o punto de referencia de datos topográficos de cualquier clase, hasta que un agente autorizado haya referenciado de otro modo su situación o aprobado su desplazamiento.
Todos los productos que deban conservarse se retirarán a los lugares que designe el Director de la obra y el resto será eliminado por el Contratista en forma adecuada.

#### Medición y valoración

Medir en m² la superficie desbrozada aceptada. El original remite el abono de la tierra vegetal a los precios de excavación; evitar solaparlo con el cajeado y el transporte.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 29–30. Transcripción para trazabilidad.
"""

Se abonará por m² (metros cuadrados) desbrozados con la aprobación de la Dirección Facultativa. Las tierras vegetales se abonarán a los precios de excavación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
