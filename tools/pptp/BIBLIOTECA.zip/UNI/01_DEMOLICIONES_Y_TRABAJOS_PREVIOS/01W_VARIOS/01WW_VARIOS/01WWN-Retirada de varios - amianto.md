"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Retirada de varios - amianto

**Clasificación BCCA:** `01WWN`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Amianto**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `01WWN`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Demoliciones de construcciones y obras de fábrica

**Clasificación:** 01WW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Derribo controlado de construcciones, muros y obras de fábrica que interfieren con el proyecto, con retirada y clasificación de los productos. Los pavimentos y las redes con unidad propia se desarrollan en fichas separadas.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 3–8. Transcripción para trazabilidad.
"""

Consiste en el conjunto de operaciones necesarias para la demolición de construcciones, muros, firmes, aceras y obras de fábrica afectadas, y el consiguiente transporte de todos los productos al lugar de empleo o vertedero.
Su ejecución incluye:
- Derribo de obras de fábrica o construcciones, o demoliciones de las aceras y pavimentos.
- Retirada de los materiales de derribo.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 550–551. Transcripción para trazabilidad.
"""

Se define como demolición la operación de derribo de todas las edificaciones, obras de fábrica, estructuras, pavimentos e instalaciones que obstaculicen la construcción de una obra o que sea necesario hacer desaparecer para dar por terminada la ejecución de la misma, incluso la retirada de los materiales resultantes a vertedero o en su lugar de empleo o acopio definitivo.

#### Ejecución

Delimitar y reconocer los elementos a demoler, localizar y desconectar los servicios, aprobar el procedimiento y ejecutar el derribo en una secuencia que mantenga la estabilidad. Proteger los elementos conservados, controlar polvo y proyecciones y separar los residuos para entrega documentada a gestor autorizado. Aplicar el artículo 301 del PG-3 por remisión del pliego y el plan de seguridad; no iniciar trabajos sobre materiales sospechosos de contener amianto sin su identificación y el procedimiento legal específico.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 9–13. Transcripción para trazabilidad.
"""

Será de aplicación lo indicado en el Artículo 301 del PG-3.
El equipo necesario para la ejecución de la demolición será aprobado por el Director de las obras y se mantendrá, en todo momento, en condiciones de trabajo satisfactorias.
La demolición se llevará a cabo en las zonas que indique el Proyecto y en su defecto donde indique el Director de las obras que determinará también la profundidad de demolición necesaria.
Los materiales procedentes de las demoliciones se retirarán a vertedero salvo indicación en contrario del Director de obras.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 552–553. Transcripción para trazabilidad.
"""

Las operaciones de derribo o excavación se efectuarán con las precauciones necesarias para lograr unas condiciones de seguridad suficientes y evitar daños en las obras o instalaciones que no hayan de ser demolidas y de acuerdo con lo que sobre el particular ordene el Director de la obra, quien designará y marcará los elementos de las obras a demoler que se deban conservar intactos para su aprovechamiento posterior, así como las condiciones para el transporte y acopio de los mismos. En cualquier caso, el Contratista requerirá autorización expresa para los derribos.
Cuando los firmes, pavimentos, bordillos u otros elementos deban reponerse a la finalización de las obras a que afecten, la reposición se realizará en el plazo más breve posible y en condiciones análogas a las existentes antes de su demolición.

#### Medición y valoración

Medir en m³ el volumen realmente demolido según los datos iniciales y finales. El texto incluye la retirada; no certificar de nuevo el transporte de los mismos productos sin verificar su partida contractual.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 14–17. Transcripción para trazabilidad.
"""

Las demoliciones se abonarán por metros cúbicos (m3) realmente demolidos y retirados de su emplazamiento, medido por diferencia entre los datos iniciales, tomados inmediatamente antes de comenzar la demolición, y los datos finales, tomados inmediatamente después de finalizar la misma.
En el caso de demolición de aceras y pavimentos el precio será por metro cuadrado (m2) de superficie de acera realmente demolida.
El precio incluye la retirada de los productos sobrantes a vertedero.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
