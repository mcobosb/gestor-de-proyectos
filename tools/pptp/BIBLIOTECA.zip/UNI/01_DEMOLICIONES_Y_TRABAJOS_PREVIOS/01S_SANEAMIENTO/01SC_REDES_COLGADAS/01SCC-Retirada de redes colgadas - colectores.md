"""
# Retirada de redes colgadas - colectores

**Clasificación BCCA:** `01SCC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Colectores**, dentro de **Redes colgadas**.
Aplicable a las partidas cuyo código BCCA comienza por `01SCC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01SCC00001 - DESMONTADO DE COLECTOR COLGADO DE FIBROCEMENTO

**Unidad:** m.

Desmontado de colector colgado de fibrocemento, incluso p.p. de carga manual y transporte de material sobrante a vertedero. Medida la longitud inicial.

### 01SCC00002 - DESMONTADO DE COLECTOR COLGADO DE PVC

**Unidad:** m.

Desmontado de colector colgado de PVC, incluso p.p. de carga manual y transporte de material sobrante a vertedero. Medida la longitud inicial.

### 01SCC90002 - DEMOLICIÓN SELECTIVA DE COLECTOR COLGADO DE PVC

**Unidad:** m.

Demolición selectiva de colector colgado de PVC. Medida la longitud inicial.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Redes colgadas

**Clasificación:** 01SC. **Capítulo:** demoliciones y trabajos previos. **Familia:** saneamiento.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «redes colgadas», dentro de «saneamiento». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Vaciar y aislar la red, prevenir exposición biológica y mantener la evacuación provisional; los recintos confinados requieren procedimiento específico.

Para la variante «redes colgadas» se comprobarán expresamente tipo de red, aislamiento, estado sanitario y sistema provisional. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
