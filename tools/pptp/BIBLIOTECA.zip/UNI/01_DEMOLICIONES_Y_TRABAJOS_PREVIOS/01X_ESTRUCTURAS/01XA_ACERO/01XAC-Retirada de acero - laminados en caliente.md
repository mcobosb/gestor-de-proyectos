"""
# Retirada de acero - laminados en caliente

**Clasificación BCCA:** `01XAC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Laminados en caliente**, dentro de **Acero**.
Aplicable a las partidas cuyo código BCCA comienza por `01XAC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 01XAC00001 - DESMONTADO ESTRUC. METÁLICA AC. LAMINADO EN CALIENTE

**Unidad:** kg.

Desmontado de estructura metálica de acero laminado en caliente, incluso p.p. de aprov echamiento del 70% para la propiedad y transporte de material sobrante a vertedero. Medido el peso nominal inicial.

### 01XAC00002 - DESMONTADO ESTRUC. METÁLICA CON FORJADOS METÁLICOS

**Unidad:** m2.

Desmontado de estructura metálica de acero laminado en caliente con forjados metálicos, realizado con medios mecánicos, incluso p.p. de aprovechamiento del 70 % para la propiedad de los elementos metálicos, carga mecánica y transporte de material sobrante a vertedero. Medida la superficie inicial de forjado deduciendo huecos may ores de 1 m2.

### 01XAC00003 - DESMONTADO ESTRUC. METÁLICA CON FORJADOS HORMIGÓN

**Unidad:** m2.

Desmontado de estructura metálica de acero laminado en caliente con forjados de hormigon, realizado con medios mecánicos, incluso p.p. de aprovechamiento del 70% para la propiedad de los elementos metálicos, carga mecánica y transporte de material sobrante a vertedero. Medida la superficie inicial de forjado deduciendo huecos may ores de 1 m2.

### 01XAC90001 - DEMOLICIÓN SELECTIVA M. MAN. DE ESTRUC. MET. AC. LAM. CALIENTE

**Unidad:** kg.

Demolición selectiva con medios manuales de estructura metálica de acero laminado en caliente, incluso p.p. de reutilización en la obra del 70%. Medido en peso nominal inicial.

### 01XAC90002 - DEMOLICIÓN SELECTIVA M. MECANICOS DE ESTRUC. MET. CON FORJ. MET.

**Unidad:** m2.

Demolición selectiva con medios mecánicos de estructura metálica de acero laminado en caliente con forjados metálicos, realizado con medios mecánicos, incluso p.p. de reutilización en la obra del 70%. Medida la superficie inicial de forjado deduciendo huecos mayores de 1 m2.

### 01XAC90003 - DEMOLICIÓN MASIVA M. MECANICOS DE ESTRUC. MET. CON FORJ. HORM.

**Unidad:** m2.

Demolición masiva con medios mecánicos de estructura metálica de acero laminado en caliente con forjados de hormigón, realizado con medios mecánicos, incluso p.p. de reutilización en la obra del 70%. Medida la superficie inicial de forjado deduciendo huecos mayores de 1 m2.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### ESTRUCTURAS - acero

**Clasificación:** 01XA. **Capítulo:** demoliciones y trabajos previos. **Familia:** estructuras.

"""
#### Descripción

Retirada, desmontaje o demolición selectiva de elementos existentes y trabajos previos, exclusivamente en las zonas autorizadas.

El objeto de esta ficha es «acero», dentro de «estructuras». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Levantar el estado previo, localizar redes y comprobar la estabilidad de lo que se conserva. Aprobar la secuencia de intervención, los apeos y la segregación de residuos antes de intervenir. Proteger los elementos recuperables y detener los trabajos ante materiales o servicios no identificados.

Comprobar caminos de carga y estabilidad provisional; aprobar apuntalamiento y orden de liberación de uniones.

Para la variante «acero» se comprobarán expresamente esquema resistente, cargas, uniones y plan de desmontaje. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar el límite de retirada, la estabilidad del remanente, la protección de terceros y la trazabilidad del material recuperado o entregado a gestor.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Se medirá por la unidad y con los límites establecidos en el cuadro de precios aprobado, computando la cantidad neta realmente ejecutada y aceptada.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
