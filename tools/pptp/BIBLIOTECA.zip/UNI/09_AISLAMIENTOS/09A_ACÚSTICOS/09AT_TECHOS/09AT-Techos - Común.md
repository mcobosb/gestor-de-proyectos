# Techos - Común

**Clasificación:** 09AT. **Capítulo:** aislamientos. **Familia:** acústicos.

## Descripción

Capas y sistemas de aislamiento o impermeabilización que proporcionan la prestación prevista en el cerramiento o la instalación.

El objeto de esta ficha es «techos», dentro de «acústicos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Verificar sequedad, limpieza y regularidad del soporte. Instalar sin discontinuidades, con juntas, solapes y fijaciones propios del sistema. Resolver encuentros, pasos y puentes y proteger la capa antes de ocultarla o aplicar revestimientos.

Evitar puentes acústicos y contactos rígidos no previstos; mantener juntas y sellados del sistema completo.

Para la variante «techos» se comprobarán expresamente prestación acústica, masa, rigidez y composición del cerramiento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar espesor, continuidad y compatibilidad; inspeccionar puntos singulares y realizar las pruebas de prestación o estanqueidad previstas antes de cerrar.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de superficie realmente tratada con espesor y sistema definidos; juntas y coquillas en m y tratamientos puntuales en ud. Precisar solapes, recortes y huecos; no incrementar automáticamente la superficie útil por mermas.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
