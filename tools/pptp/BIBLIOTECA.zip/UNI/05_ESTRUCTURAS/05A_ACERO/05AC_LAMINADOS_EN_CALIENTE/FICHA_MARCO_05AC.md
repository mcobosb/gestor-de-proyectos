# laminados en caliente

**Clasificación:** 05AC. **Capítulo:** estructuras. **Familia:** acero.

## Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «laminados en caliente», dentro de «acero». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Verificar identificación de perfiles, uniones, apriete o soldadura, tolerancias de montaje y continuidad de la protección.

Para la variante «laminados en caliente» se comprobarán expresamente clase de acero, ejecución, soldaduras, tornillos y protección anticorrosiva y de fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

kg de acero conforme a despiece aprobado y a la regla contractual sobre longitudes y masa nominal; fijar tratamiento de empalmes, tornillos, soldaduras y mermas. No añadir pérdidas de taller ni protección si ya están incluidas en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
