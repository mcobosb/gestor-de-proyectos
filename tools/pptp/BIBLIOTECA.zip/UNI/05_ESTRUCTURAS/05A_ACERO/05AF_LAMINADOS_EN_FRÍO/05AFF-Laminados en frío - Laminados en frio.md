"""
# Laminados en frío - Laminados en frio

**Clasificación BCCA:** `05AFF`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Laminados en frio**, dentro de **Laminados en frío**.
Aplicable a las partidas cuyo código BCCA comienza por `05AFF`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05AFF80010 - ACERO PERFILES LAMINADOS EN FRIO TIPO S275JR

**Unidad:** kg.

Acero en perfiles laminados en frío tipo S 275 JR, en elementos estructurales varios, incluso corte, elaboración, montaje y p.p. de elementos de unión, lijado e imprimación con 40 micras de minio de plomo; construido según CTE. Medido en peso nominal.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Laminados en frío

**Clasificación:** 05AF. **Capítulo:** estructuras. **Familia:** acero.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «laminados en frío», dentro de «acero». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Verificar identificación de perfiles, uniones, apriete o soldadura, tolerancias de montaje y continuidad de la protección.

Para la variante «laminados en frío» se comprobarán expresamente clase de acero, ejecución, soldaduras, tornillos y protección anticorrosiva y de fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

kg de acero conforme a despiece aprobado y a la regla contractual sobre longitudes y masa nominal; fijar tratamiento de empalmes, tornillos, soldaduras y mermas. No añadir pérdidas de taller ni protección si ya están incluidas en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
