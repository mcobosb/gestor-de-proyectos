"""
# Varios - Varios

**Clasificación BCCA:** `05FWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `05FWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05FWW90001 - FORJADO CHAPA COLABORANTE 10 cm ESPESOR

**Unidad:** m².

Forjado mediante chapa colaborante de 10 cm de espesor y 0,75 mm de espesor de chapa, realizado con hormigón armado tipo HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, complementarias con acero B 500 S, incluso p.p. de macizado de apoyos, encofrados complementarios, apeos, desencofrado, vibrado y curado; construido según CodE, NCSR-02 y CTE. Medida la superficie de fuera a fuera deduciendo huecos mayores de 1 m2.

### 05FWW90002 - FORJADO CHAPA COLABORANTE 15 cm ESPESOR

**Unidad:** m².

Forjado mediante chapa colaborante de 15 cm de espesor y 0,75 mm de espesor de chapa, realizado con hormigón armado tipo HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, complementarias con acero B 500 S, incluso p.p. de macizado de apoyos, encofrados complementarios, apeos, desencofrado, vibrado y curado; construido según CodE, NCSR-02 y CTE. Medida la superficie de fuera a fuera deduciendo huecos mayores de 1 m2.

### 05FWW90003 - FORJADO CHAPA COLABORANTE 20 cm ESPESOR

**Unidad:** m².

Forjado mediante chapa colaborante de 20 cm de espesor y 0,75 mm de espesor de chapa, realizado con hormigón armado tipo HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, complementarias con acero B 500 S, incluso p.p. de macizado de apoyos, encofrados complementarios, apeos, desencofrado, vibrado y curado; construido CodE, NCSR-02 y CTE. Medida la superficie de fuera a fuera deduciendo huecos mayores de 1 m2.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### FORJADOS - varios

**Clasificación:** 05FW. **Capítulo:** estructuras. **Familia:** forjados.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Comprobar apoyos, piezas de entrevigado, continuidad y apeos del forjado; no retirar éstos sin justificación resistente.

Para la variante «varios» se comprobarán expresamente tipología, canto, luces, cargas de ejecución y desapuntalamiento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
