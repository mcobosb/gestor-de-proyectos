"""
# Estructuras completas - Hormigón

**Clasificación BCCA:** `05WCH`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Hormigón**, dentro de **Estructuras completas**.
Aplicable a las partidas cuyo código BCCA comienza por `05WCH`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05WCH80020 - ESTRUCTURA HORM. ARM. C/FORJ. VIG. ARM. 25+5 cm

**Unidad:** m2.

Estructrura de hormigón armado HA-25/P/20/XC2, consistencia plástica, tamaño máximo del árido 20 mm, para luces de hasta 5 m, con 14kg/m2 de cuantía de acero y vigas planas, compuesta por: forjado unidireccional de canto 25+5 cm e intereje de 70 cm, con viguetas semirresistentes de armaduras rígidas, bovedillas de hormigón, armaduras de acero B 400 S, mallazo electrosoldado B 500 T, capa de compresión de 5 cm, incluso p.p. de vigas, zunchos, pilares, losas de escalera con peldañeado "in situ" de H.A., macizado de apoyos, encofrados complementarios, apeos, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según EFHE, Código Estructural y NCSR-02. Medida la superficie de fuera a fuera de los forjados deduciendo huecos mayores de 1 m2.

### 05WCH80050 - ESTRUCTURA HORM. ARM. C/FORJ. VIG. PRET. AUTORR. 25+5 cm

**Unidad:** m2.

Estructrura de hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, para luces de hasta 5 m, con 13kg/m2 de cuantía de acero y vigas planas, compuesta por: forjado unidireccional de canto 25+5 cm e intereje de 70 cm, con viguetas pretensadas autorresistentes, bovedillas de hormigón, armaduras de acero B 400 S, mallazo electrosoldado B 500 T, capa de compresión de 5 cm, incluso p.p. de vigas, zunchos, pilares, losas de escalera con peldañeado "in situ" de H.A., macizado de apoyos, encofrados complementarios, apeos, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según EFHE, Código Estructural y NCSR-02. Medida la superficie de fuera a fuera de los forjados deduciendo huecos mayores de 1 m2.

### 05WCH80070 - ESTRUCTURA HORM. ARM. C/FORJ. DOBLE VIG. ARM. 25+5 cm

**Unidad:** m2.

Estructrura de hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, para luces de hasta 5 m, con 12kg/m2 de cuantía de acero y vigas planas, compuesta por: forjado unidireccional de canto 25+5 cm e intereje de 70 cm, con doble vigueta semirresistente de armaduras rígidas, bovedillas de hormigón, armaduras de acero B 400 S, mallazo electrosoldado B 500 T, capa de compresión de 5 cm, incluso p.p. de vigas, zunchos, pilares, losas de escalera con peldañeado "in situ" de H.A., macizado de apoyos, encofrados complementarios, apeos, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según EFHE, Código Estructural y NCSR-02. Medida la superficie de fuera a fuera de los forjados deduciendo huecos mayores de 1 m2.

### 05WCH80090 - ESTRUCTURA HORM. ARM. C/FORJ. "IN SITU" 25+5 cm

**Unidad:** m2.

Estructrura de hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, para luces de hasta 5 m, con 16kg/m2 de cuantía de acero y vigas planas, compuesta por: forjado unidireccional "in situ" de canto 25+5 cm e intereje de 70 cm, bovedillas de hormigón, armaduras de acero B 400 S, mallazo electrosoldado B 500 T, capa de compresión de 5 cm, incluso p.p. de vigas, zunchos, pilares, losas de escalera con peldañeado "in situ" de H.A., macizado de apoyos, encofrados complementarios, apeos, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según EFHE, Código Estructural y NCSR-02. Medida la superficie de fuera a fuera de los forjados deduciendo huecos mayores de 1 m2.

### 05WCH80110 - ESTRUCTURA HORM. ARM. C/FORJ. RETICULAR 25+5 cm LUCES 5x5 m

**Unidad:** m2.

Estructrura de hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, para luces de hasta 5x5 m, con 16kg/m2 de cuantía de acero y vigas planas, compuesta por: forjado retícular aligerado con casetones de hormigón no recuperables, de canto 25+5 cm, armaduras de acero B 400 S, mallazo electrosoldado B 500 T, capa de compresión de 5 cm, incluso p.p. de vigas, zunchos, pilares, losas de escalera con peldañeado "in situ" de H.A., macizado de capiteles, encofrados complementarios, apeos, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según EFHE, Código Estructural y NCSR-02. Medida la superficie de fuera a fuera de los forjados deduciendo huecos mayores de 1 m2.

### 05WCH80120 - ESTRUCTURA HORM. ARM. C/FORJ. RETICULAR 30+5 cm LUCES 5x5 m

**Unidad:** m2.

Estructrura de hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, para luces de hasta 5x5 m, con 14kg/m2 de cuantía de acero y vigas planas, compuesta por: forjado retícular aligerado con casetones de hormigón no recuperables, de canto 30+5 cm, armaduras de acero B 400 S, mallazo electrosoldado B 500 T, capa de compresión de 5 cm, incluso p.p. de vigas, zunchos, pilares, losas de escalera con peldañeado "in situ" de H.A., macizado de capiteles, encofrados complementarios, apeos, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según EFHE, Código Estructural y NCSR-02. Medida la superficie de fuera a fuera de los forjados deduciendo huecos mayores de 1 m2.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Estructuras completas

**Clasificación:** 05WC. **Capítulo:** estructuras. **Familia:** varios.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «estructuras completas», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Definir el sistema resistente y sus interfaces; las estructuras especiales y tratamientos requieren especificación propia.

Para la variante «estructuras completas» se comprobarán expresamente sistema, materiales, fases, puntos de control y prestaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
