"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Estructuras especiales

**Clasificación BCCA:** `05WEE`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Estructuras especiales**, dentro de **Estructuras especiales**.
Aplicable a las partidas cuyo código BCCA comienza por `05WEE`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05WEE80010 - ACERO ESTRUCTURA ESPACIAL S275JR PERF. LAMINADOS

**Unidad:** kg.

Estructura espacial con acero S 275 JR, con perfiles laminados, p.p. de soldadura, nudos y piezas especiales, capa de imprimación antioxidante, montaje y colocación; según CTE. Medido en peso nominal.

### 05WEE80020 - ACERO ESTRUCTURA ESPACIAL ACERO LAMINADO S275JR PERFIL TUBULAR

**Unidad:** kg.

Acero laminado S 275 JR, en perfiles tubulares para estructuras espaciales, incluso soldaduras, nudos, despuntes, capa de imprimación antioxidante, p.p. de piezas especiales y elementos de unión, montaje y colocación; según CTE. Medido en peso nominal.

### 05WEE80050 - ESTRUCTURA MALLA ESPACIAL DIST. <30 m PERFIL LAMINADO

**Unidad:** m2.

Estructura espacial con acero S 275 JR, con perfiles tubulares, para luces hasta 30 m, con carga máxima de 0,8 kN/m2 y canto de 2,3 m, p.p. de soldadura, tornillos, nudos y piezas especiales, capa de imprimación antioxidante, montaje y colocación; según NCSR-0 CTE. Medida la superficie ejecutada de fuera a fuera.

### 05WEE80060 - ESTRUCTURA MALLA ESPACIAL DIST. <45 m PERFIL TUBULAR

**Unidad:** m2.

Estructura espacial con acero S 275 JR, con perfiles tubulares, para luces hasta 45 m, con carga máxima de 0,8 kN/m2 y un canto de 3 m, p.p. de soldadura, tornillos, nudos y piezas especiales, capa de imprimación antioxidante, montaje y colocación; según NCSR-02, CTE. Medida la superficie ejecutada medida de fuera a fuera.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Estructuras especiales

**Clasificación:** 05WE. **Capítulo:** estructuras. **Familia:** varios.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «estructuras especiales», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Definir el sistema resistente y sus interfaces; las estructuras especiales y tratamientos requieren especificación propia.

Para la variante «estructuras especiales» se comprobarán expresamente sistema, materiales, fases, puntos de control y prestaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
