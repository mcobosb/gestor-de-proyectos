"""
# Laminadas - Vigas

**Clasificación BCCA:** `05MLV`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Vigas**, dentro de **Laminadas**.
Aplicable a las partidas cuyo código BCCA comienza por `05MLV`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05MLV00001 - MADERA LAMINADA GL-24 VIGAS DIRECTRIZ RECTA HASTA 12 m

**Unidad:** m3.

Madera laminada GL-24 de coníferas con adhesivo tipo 1, en vigas de directriz recta, piezas de hasta 12 m, con uniones mecánicas de acero galvanizado en caliente, incluso tratamiento contra xilófagos con penetración media; según CTE. Medido el volumen ejecutado.

### 05MLV80030 - MADERA LAMINADA GL-24 JÁCENAS DIRECTRIZ RECTA LUZ <5 m

**Unidad:** m.

Madera laminada GL-24 de coníferas con adhesivo tipo 1, en jácenas de directriz recta, piezas hasta 5 m, con uniones mecánicas de acero galvanizado en caliente, incluso tratamiento contra xilófagos con penetración media; según CTE. Medida la longitud ejecutada.

### 05MLV80040 - MADERA LAMINADA GL-24 JÁCENAS DIRECTRIZ RECTA LUZ 5-10 m

**Unidad:** m.

Madera laminada GL-24 de coníferas con adhesivo tipo 1, en jácenas de directriz recta, piezas entre 5 a 10 m, con uniones mecánicas de acero galvanizado en caliente, incluso tratamiento contra xilófagos con penetración media; según CTE. Medida la longitud ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Laminadas

**Clasificación:** 05ML. **Capítulo:** estructuras. **Familia:** madera.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «laminadas», dentro de «madera». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Verificar clase resistente y humedad de madera, apoyos, uniones y protección frente a agua y agentes bióticos.

Para la variante «laminadas» se comprobarán expresamente clase de servicio, durabilidad, uniones y resistencia al fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
