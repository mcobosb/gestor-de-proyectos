"""
# Tradicionales - Tradicionales

**Clasificación BCCA:** `05MTT`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Tradicionales**, dentro de **Tradicionales**.
Aplicable a las partidas cuyo código BCCA comienza por `05MTT`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05MTT80010 - SOPORTE VERTICAL MADERA PINO TRATADA 20X20 cm

**Unidad:** m.

Soporte vertical de madera de pino tratada de 20x20 cm, para una altura máxima de 4 m, incluso p.p. de cortes, ensambles y aplomado; según CTE. Medida la longitud ejecutada.

### 05MTT80020 - JÁCENA MADERA PINO TRATADA 20X24 cm

**Unidad:** m.

Jácena de madera de pino tratada de 20x20 cm, incluso p.p. de cortes, ensambles y aplomado y elementos de atado y refuerzo; según CTE. Medida la longitud ejecutada.

### 05MTT80030 - CORREA MADERA PINO TRATADA 15x20 cm

**Unidad:** m.

Correa de madera de pino tratada de 20x20 cm, incluso p.p. de cortes, ensambles y aplomado y elementos de atado y refuerzo; según CTE. Medida la longitud ejecutada.

### 05MTT80050 - VIGUETA MADERA PINO 17x20 cm

**Unidad:** m.

Vigueta de madera de pino tratada de 17x20 cm, incluso p.p. de cortes, ensambles y aplomado y elementos de atado y refuerzo, según CTE. Medida la longitud ejecutada.

### 05MTT80060 - CERCHA MADERA PINO TRATADA HASTA 7 m

**Unidad:** m3.

Cercha de madera de pino flandes hasta 7 m, con pares, tornapuntas, tirantes, jabalcones y pendolón, incluso material de ensamble estructural, como tirantillas, uniones reforzadas con piezas de acero galvanizado y p.p. de cortes, ensambles, aplomado, elementos de atado y refuerzo; según CTE, Medido el volumen ejecutado.

### 05MTT80070 - CERCHA MADERA PINO TRATADA DE 7 A 12 m

**Unidad:** m3.

Cercha de madera de pino flandes de 7 a 12 m, con pares, tornapuntas, tirantes, jabalcones y pendolón, incluso tratamiento fungicida, material de ensamble estructural, como tirantillas, uniones reforzadas con piezas de acero galvanizado y p.p. de cortes, ensambles, aplomado, elementos de atado y refuerzo; según CTE. Medido el volumen de madera ejecutado.

### 05MTT80080 - TABLERO DE MADERA MACHIEMBR. TRATADA 22 mm ESP.

**Unidad:** m2.

Entablonado con tablero de madera de pino flandes, machihembrada, de 22 mm de espesor, incluso elementos sustentantes para su colocación; según CTE. Medida la superficie ejecutada.

### 05MTT80090 - TABLERO DE MADERA MACHIEMBR. TRATADA 40 mm ESP.

**Unidad:** m2.

Entablonado con tablero de madera de pino flandes, machihembrada, de 40 mm de espesor, incluso elementos sustentantes para su colocación; según CTE. Medida la superficie ejecutada.

### 05MTT80100 - ESTRUCTURA C/FORJADO Y SOP. DE MADERA PINO FLANDES

**Unidad:** m2.

Estructura con forjado y soportes de madera de pino flandes, para luces hasta 4 m, formada por soportes de 20x20 cm, jácenas de 20x24 cm, viguetas de 17x20 cm separadas 50 cm interejes, con tablero de madera machihembrada de 22 mm de espesor, film de polietileno, capa de compesión de H.A. de 5 cm de espesor, armadura de reparto de acero B 500 T, incluso material de ensamble estructural, p.p. de cortes, ensambles, aplomado, elementos de atado y refuerzo; según CTE. Medida la superficie de fuera a fuera deduciendo huecos mayores de 1 m2.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Tradicionales

**Clasificación:** 05MT. **Capítulo:** estructuras. **Familia:** madera.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «tradicionales», dentro de «madera». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Verificar clase resistente y humedad de madera, apoyos, uniones y protección frente a agua y agentes bióticos.

Para la variante «tradicionales» se comprobarán expresamente clase de servicio, durabilidad, uniones y resistencia al fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
