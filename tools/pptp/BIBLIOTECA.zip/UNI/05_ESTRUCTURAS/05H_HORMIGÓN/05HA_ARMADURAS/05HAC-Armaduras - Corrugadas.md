"""
# Armaduras - Corrugadas

**Clasificación BCCA:** `05HAC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Corrugadas**, dentro de **Armaduras**.
Aplicable a las partidas cuyo código BCCA comienza por `05HAC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05HAC00010 - ACERO EN BARRAS CORRUGADAS TIPO B400S

**Unidad:** kg.

Acero en barras corrugadas tipo B 400 S para elementos estructurales varios, incluso corte, labrado, colocación y p.p. de atado con alambre recocido, separadores y puesta en obra; según instrucción del Código Estructural. Medido en peso nominal.

### 05HAC00015 - ACERO EN BARRAS CORRUGADAS TIPO B500S

**Unidad:** kg.

Acero en barras corrugadas tipo B 500 S para elementos estructurales varios, incluso corte, labrado, colocación y p.p. de atado con alambre recocido, separadores y puesta en obra; según instrucción del Código Estructural. Medido en peso nominal.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Armaduras de acero corrugado para hormigón

**Clasificación:** 05HA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Barras corrugadas para armar los elementos de hormigón conforme al Código Estructural y a los despieces aprobados.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 442–444. Transcripción para trazabilidad.
"""

Serán barras corrugadas de límite elástico 5.100 Kg/cm² y cumplirá con el Código Estructural.

#### Ejecución

Recibir acero identificado y trazable con documentación y controles exigibles. Cortar, doblar y montar conforme a planos sin calentamiento o soldadura no autorizados. Mantener posición mediante atado y separadores adecuados; comprobar anclajes, solapos y recubrimientos antes de hormigonar. El recubrimiento nominal será c_nom = c_min + Δc_dev según exposición y control, no un valor universal.

#### Medición y valoración

Por kg deducidos de los planos de construcción y masas nominales de cada diámetro. Resolver el tratamiento de solapes y despuntes conforme a la partida antes de certificar.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 445–446. Transcripción para trazabilidad.
"""

Se medirá y abonará por kilogramos (Kg), realmente colocados en obra, deducidos de los planos de construcción. En el precio de la unidad está incluido el abono de las mermas, despuntes y solapes.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1148–1150. Transcripción para trazabilidad.
"""

Las armaduras de acero empleadas en hormigón armado se medirán por kilogramos (kg), realmente empleados, deducidos de los planos de construcción, en las mediciones del proyecto por medición de su longitud y aplicando los pesos unitarios correspondientes a los distintos diámetros empleados. A estas mediciones podrá aplicárseles como máximo, un cinco por ciento (5%) de aumento, en concepto de empalmes de despuntes.
El abono se efectuará de acuerdo con los precios indicados en el presupuesto, en el que se incluyen las partidas de adquisición del material, corte, doblado y colocación del mismo.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
