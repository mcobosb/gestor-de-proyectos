# Hormigón de 35 MPa para elementos prefabricados

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Hormigón al que el original asigna resistencia de 35 N/mm² en pozos de saneamiento y otros elementos prefabricados.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 848–852. Transcripción para trazabilidad.

Como norma general, la utilización de los distintos hormigones se efectuará atendiendo a la siguiente relación:
- Hormigón con una resistencia de 35 N/mm2:
- Pozos de saneamiento prefabricados.
- Elementos prefabricados.

## Ejecución

Completar la designación y exposición según el elemento; comprobar documentación del prefabricado, resistencia, durabilidad y uniones bajo su norma de producto y el Código Estructural cuando corresponda. No confundir resistencia del hormigón con capacidad resistente de todo el producto.

## Medición y valoración

Normalmente integrado en el precio del prefabricado o del pozo. Sólo por m³ si existe una partida específica de ese hormigón, sin duplicar el producto completo.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
