# Hormigón de 25 MPa para arquetas y pozos armados - Común

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Hormigón al que el documento asigna 25 N/mm² para arquetas de abastecimiento y pozos de registro armados in situ.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 856–858. Transcripción para trazabilidad.

- Hormigón con una resistencia de 25 N/mm2:
- Arquetas de abastecimiento.
- Pozos de registro armados in situ .

## Ejecución

Completar designación conforme a exposición y función, comprobar recubrimientos y juntas, hormigonar y compactar evitando desplazamientos de conexiones y realizar curado y controles conforme al Código Estructural.

## Medición y valoración

Integrado en la arqueta o pozo si su partida es completa; por m³ del hormigón sólo si está desglosado en el presupuesto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
