"""
# Para armar - Muros

**Clasificación BCCA:** `05HHM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Muros**, dentro de **Para armar**.
Aplicable a las partidas cuyo código BCCA comienza por `05HHM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05HHM00003 - HORMIGÓN PARA ARMAR HA-25/P/20/XC2 EN MUROS

**Unidad:** m3.

Hormigón para armar HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros, suministrado y puesto en obra, incluso p.p. de limpieza de fondos, vibrado, curado, pasos de tuberías, reservas necesarias y ejecución de juntas; construido según CodE y NCSR-02. Medido el volumen teórico ejecutado.

### 05HHM00103 - HORMIGÓN PARA ARMAR HA-30/P/20/XC2 EN MUROS

**Unidad:** m3.

Hormigón para armar HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en muros, suministrado y puesto en obra, incluso p.p. de limpieza de fondos, vibrado, curado, pasos de tuberías, reservas necesarias y ejecución de juntas; construido según CodE y NCSR-02. Medido el volumen teórico ejecutado.

### 05HHM00153 - HORMIGÓN PARA ARMAR HA-35/P/20/XC2 EN MUROS

**Unidad:** m3.

Hormigón para armar HA-35/P/20/IIa, consistencia plástica y tamaño máximo del árido 20 mm, en muros, suministrado y puesto en obra, incluso p.p. de limpieza de fondos, vibrado, curado, pasos de tuberías, reservas necesarias y ejecución de juntas; construido según CodE y NCSR-02. Medido el volumen teórico ejecutado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

"""
### Hormigón de 25 MPa para arquetas y pozos armados
"""

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Hormigón al que el documento asigna 25 N/mm² para arquetas de abastecimiento y pozos de registro armados in situ.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 856–858. Transcripción para trazabilidad.
"""

- Hormigón con una resistencia de 25 N/mm2:
- Arquetas de abastecimiento.
- Pozos de registro armados in situ .

#### Ejecución

Completar designación conforme a exposición y función, comprobar recubrimientos y juntas, hormigonar y compactar evitando desplazamientos de conexiones y realizar curado y controles conforme al Código Estructural.

#### Medición y valoración

Integrado en la arqueta o pozo si su partida es completa; por m³ del hormigón sólo si está desglosado en el presupuesto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Hormigón de 30 MPa para losas de aparcamiento y rigolas
"""

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Hormigón de resistencia indicada de 30 N/mm² para losas de aparcamiento y rigolas citadas en 4.13.2.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 853–855. Transcripción para trazabilidad.
"""

- Hormigón con una resistencia de 30 N/mm2:
- Losas de aparcamiento.
- Rigolas.

#### Ejecución

Definir sección, armadura, juntas y exposición del elemento. Preparar soporte, colocar y compactar sin segregación, ejecutar acabado, pendientes y juntas y asegurar curado. Cuando se requiera resistencia a flexotracción, comprobarla según proyecto y no deducirla sólo de la compresión.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 879–894. Transcripción para trazabilidad.
"""

Los hormigones de los elementos prefabricados (bordillos, caz, etc.) tendrán una resistencia al desgaste, según la norma UNE 7015 y con un recorrido de doscientos cincuenta metros (250 m.), inferior a dos con cincuenta milímetros (2,50 mm).
Los hormigones empleados en losas de aparcamientos tendrán una resistencia característica a flexotracción de cuatro newton por milímetro cuadrado (4 N/mm2).
Los hormigones que deberán utilizarse cuando exista peligro de ataque por aguas selenitosas, o existan contactos con terrenos yesíferos, deberán contener la dosificación adecuada de cemento Portland resistente al yeso (denominación SR).
Los citados hormigones, como norma general, deberán adoptarse cuando el porcentaje de sulfato soluble en agua expresado en SO4 de las muestras del suelo sea superior al cero con dos por ciento (0,2 %); o cuando en las muestras de agua del subsuelo, el contenido en SO4 sea superior a cuatrocientas partes por millón (0,04 %). El cemento a emplear será I 42,5/SR (UNE 80303).
La consistencia de todos los hormigones que se utilicen, salvo circunstancias justificadas ante la Inspección de la obra, será plástica corresponderá a un asiento del cono de Abrams comprendido entre tres (3) centímetros y cinco (5)centímetros con una tolerancia de _1.
En zanjas, rellenos de trasdos, etc., serán de consistencia blanda (asiento 6 9 centímetros) e incluso fluida (asiento10 15 centímetros).
En condiciones ambientales normales (no calurosas) el tiempo transcurrido entre la adición de agua del amasado al cemento y a los áridos y la colocación del hormigón, no será mayor de una hora y media (1 1/2 h).
Los hormigones de central transportados por cubas agitadoras, deberán ponerse en obra dentro de la hora y media posterior a la adición de agua del amasado, no siendo admisibles los amasijos con un tiempo superior. Cada carga de hormigón fabricado en central irá acompañada de una hoja de suministro que estará en todo momento a disposición de la Inspección Facultativa.
El recubrimiento nominal de las armaduras de los hormigones en función de la clase de exposición ambiental, para conseguir una adecuada durabilidad, seré el siguiente:
[Falta el recubrimiento nominal]
Todos los hormigones se compactarán y curarán debidamente. A título orientativo el método de compactación adecuado para hormigones plásticos es la vibración normal. La duración mínima del curado será de 5 días. La altura máxima de vertido libre del hormigón, será de un metro (1 m.). Deberá suspenderse el hormigonado cuando la temperatura de ambiente sea superior a cuarenta grados centígrados (40 ºC) y siempre que se prevea que, dentro de las cuarenta y ocho horas (48 h.) siguientes, pueda descender la temperatura ambiente por debajo de cero grados centígrados (0 ºC).

En las losas de aparcamientos, deberán disponerse juntas de retracción a distancias inferiores a seis metros (6 m.), disponiendo las superficies de encuentro a testa y sellando las juntas horizontales con un mástic bituminoso. Las juntas de hormigonado, deberán ajustarse siempre que sea posible a las de retracción, y en caso contrario, deberán adoptarse las medidas necesarias para asegurar la perfecta unión de las masas en contacto y obtener una correcta superficie vista.
La parada en el proceso de hormigonado superior a treinta minutos (30 min.), requerirá realizar una junta de hormigonado correctamente dispuesta en el punto en que se encuentra la unidad, si técnicamente es admisible. Si no fuera admisible dicha junta, deberá demolerse lo ejecutado hasta el punto donde se pueda realizar.
Todos los muros deberán disponer de mechinales y de berenjenos en los lugares que disponga la Inspección de la obra.
Los defectos deberán ser corregidos por cuenta del Contratista, de acuerdo con las indicaciones de la Inspección de la obra.

#### Medición y valoración

Integrado en la unidad de losa o rigola si se abona completa; por m³ únicamente cuando así lo defina el presupuesto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Hormigón de 35 MPa para elementos prefabricados
"""

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Hormigón al que el original asigna resistencia de 35 N/mm² en pozos de saneamiento y otros elementos prefabricados.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 848–852. Transcripción para trazabilidad.
"""

Como norma general, la utilización de los distintos hormigones se efectuará atendiendo a la siguiente relación:
- Hormigón con una resistencia de 35 N/mm2:
- Pozos de saneamiento prefabricados.
- Elementos prefabricados.

#### Ejecución

Completar la designación y exposición según el elemento; comprobar documentación del prefabricado, resistencia, durabilidad y uniones bajo su norma de producto y el Código Estructural cuando corresponda. No confundir resistencia del hormigón con capacidad resistente de todo el producto.

#### Medición y valoración

Normalmente integrado en el precio del prefabricado o del pozo. Sólo por m³ si existe una partida específica de ese hormigón, sin duplicar el producto completo.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Hormigones- materiales, ejecución y control
"""

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Mezclas de cemento, agua, áridos y, en su caso, adiciones y aditivos para los elementos definidos en el proyecto. Cada hormigón requiere designación completa, función y exposición.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 447–447. Transcripción para trazabilidad.
"""

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 702–847. Transcripción para trazabilidad.
"""

En todo lo referente a esta materia se estará a lo dispuesto en la Código Estructural y en el Pliego de prescripciones Técnicas Generales para Obras de Carreteras y Puentes (PG 3/75).
El contratista está obligado inexcusablemente a conseguir las resistencias mínimas características señaladas para cada tipo de hormigón, para lo cual además de la adecuada dosificación y clasificación de los áridos empleará la cantidad de cemento necesario para obtenerla.

Los distintos tipos de hormigón a emplear en las obras, son los que se definen en el siguiente cuadro:

Tabla 27.1.a Código Estructural. Clases generales de exposición ambiental.
Clase	Designación	Tipo de Ambiente / Proceso	Ejemplos de Aplicación
Sin riesgo	X0	Sin riesgo de corrosión ni ataque. Hormigón sin armar o en ambiente muy seco.	Elementos interiores de edificios con humedad muy baja; cimentaciones en suelos no agresivos sin armadura.
Corrosión por carbonatación	XC1	Seco o permanentemente húmedo.	Interiores de edificios (viviendas, oficinas) o elementos sumergidos permanentemente en agua dulce.
	XC2	Húmedo, raramente seco.	Cimentaciones, depósitos de agua, elementos en contacto prolongado con el suelo.
	XC3	Humedad moderada.	Exteriores protegidos de la lluvia (porches, soportales) e interiores con humedad relativa media-alta.
	XC4	Cíclicamente húmedo y seco.	Exteriores expuestos a la lluvia (fachadas, elementos urbanos, estructuras descubiertas).
Corrosión por cloruros (Marinos)	XS1	Expuesto a sales marinas en el aire (niebla marina).	Estructuras situadas en la costa pero no en contacto directo con el agua de mar (hasta varios kilómetros de la costa).
	XS2	Sumergido permanentemente en agua de mar.	Estructuras marinas totalmente sumergidas.
	XS3	Zonas de marea, oleaje y escorrentía marina.	Pilotes, muelles y elementos situados en la zona de carrera de marea o salpicadura directa.
Corrosión por cloruros (No Marinos)	XD1	Humedad moderada con cloruros deshelantes en el aire.	Estructuras expuestas a aerosoles con sales fundentes (puentes o viales en zonas de montaña).
	XD2	Húmedo, raramente seco, con sales deshelantes.	Piscinas, elementos expuestos a aguas industriales cargadas con cloruros.
	XD3	Cíclicamente húmedo y seco con sales deshelantes.	Tableros de puentes, elementos de viario urbano con tratamiento invernal de sal y zonas de salpicadura.

Tabla 27.1.b Código estructural. Clases específicas de exposicion ambiental.
Clase	Designación	Tipo de Ataque	Ejemplos de Aplicación / Criterio
Hielo / Deshielo	XF1	Saturación moderada de agua sin sales deshelantes.	Superficies verticales expuestas a la lluvia y a la congelación.
	XF2	Saturación moderada de agua con sales deshelantes.	Elementos de carreteras o viales urbanos expuestos a heladas y pulverización de sal.
	XF3	Alta saturación de agua sin sales deshelantes.	Superficies horizontales (cubiertas, bordillos) donde el agua se acumula y se congela.
	XF4	Alta saturación de agua con sales deshelantes o agua de mar.	Tableros de puentes, pavimentos y estructuras en zonas de alta montaña tratadas con sal.
Ataque Químico	XA1	Ambiente químico débilmente agresivo.	Suelos o aguas subterráneas con baja concentración de sulfatos o agresividad ácida débil.
	XA2	Ambiente químico moderadamente agresivo.	Suelos o aguas con presencia moderada de sulfatos (p. ej., yesos), aguas residuales industriales.
	XA3	Ambiente químico fuertemente agresivo.	Depuradoras, canalizaciones de aguas residuales no tratadas, suelos altamente sulfatados.
Erosión	XM1	Abrasión moderada.	Pavimentos urbanos e industriales con tráfico ligero o moderado de vehículos con neumáticos.
	XM2	Abrasión elevada.	Pavimentos con tráfico pesado continuo, elementos hidráulicos con transporte de sedimentos.
	XM3	Abrasión muy elevada.	Pistas de rodadura de maquinaria pesada, tuberías y cauces con alta carga sólida en suspensión.

El cemento a emplear será I 42,5 (UNE 80301), que a efectos del Codigo Estructural se trata de un cemento de endurecimiento rápido, siempre que su relación agua/cemento sea menor o igual que 0,50.
El tamaño máximo del árido será el definido en la designación del hormigón, pero en ausencia de ésta el Ingeniero Inspector de la obra podrá decidir el más conveniente en cada caso y para cada tipo de hormigón.
Los requisitos de dosificación serán los siguientes:

Tabla 43.2.1.a del Código Estructural. Requisitos de dosificación del hormigón.
Clase de Exposición Ambiental	Tipo de Hormigón	Máxima relación agua/cemento (a/c)	Mínimo contenido de cemento (kg/m3)
X0 (Sin riesgo de ataque/corrosión)	Masa / Armado / Pretensado	—	200
XC1 (Corrosión por carbonatación - Seco/Húmedo permanente)	Masa
Armado
Pretensado	0,65
0,65
0,60	225
275
300
XC2 (Corrosión por carbonatación - Húmedo raro seco)	Masa
Armado
Pretensado	0,60
0,60
0,55	250
275
300
XC3 (Corrosión por carbonatación - Humedad moderada)	Armado
Pretensado	0,55
0,55	300
300
XC4 (Corrosión por carbonatación - Cíclico húmedo/seco)	Armado
Pretensado	0,50
0,50	300
300
XS1 (Cloruros marinos - Niebla marina)	Armado
Pretensado	0,50
0,45	300
325
XS2 (Cloruros marinos - Sumergido)	Armado
Pretensado	0,50
0,45	325
350
XS3 (Cloruros marinos - Zonas de marea/salpicadura)	Armado
Pretensado	0,45
0,45	325
350
XD1 (Cloruros no marinos - Humedad moderada)	Armado
Pretensado	0,50
0,45	300
325
XD2 (Cloruros no marinos - Húmedo raro seco)	Armado
Pretensado	0,50
0,45	325
350
XD3 (Cloruros no marinos - Cíclico húmedo/seco / Deshelantes)	Armado
Pretensado	0,45
0,45	325
350
XF1 (Hielo/Deshielo - Sin sales, saturación moderada)	Armado
Pretensado	0,55
0,50	300
300
XF2 (Hielo/Deshielo - Con sales, saturación moderada)	Armado
Pretensado	0,50
0,45	300
325
XF3 (Hielo/Deshielo - Sin sales, alta saturación)	Armado
Pretensado	0,50
0,45	300
325
XF4 (Hielo/Deshielo - Con sales/Agua de mar, alta saturación)	Armado
Pretensado	0,45
0,45	325
350
XA1 (Ataque químico - Débil)	Masa
Armado
Pretensado	0,55
0,55
0,50	275
300
325
XA2 (Ataque químico - Moderado)	Masa
Armado
Pretensado	0,50
0,50
0,45	300
325
350
XA3 (Ataque químico - Fuerte)	Masa
Armado
Pretensado	0,45
0,45
0,45	325
350
350

La resistencia característica mínima esperada del hormigón serán:

Clase de Exposición Ambiental	Hormigón Masa	Hormigón Armado	Hormigón Pretensado
X0 (Sin riesgo)	20	25	25
XC1 (Carbonatación - Seco / Húmedo permanente)	20	25	30
XC2 (Carbonatación - Húmedo raro seco)	25	25	30
XC3 (Carbonatación - Humedad moderada)	—	30	30
XC4 (Carbonatación - Cíclico húmedo/seco)	—	30	30
XS1 (Cloruros marinos - Niebla marina)	—	30	35
XS2 (Cloruros marinos - Sumergido)	—	30	35
XS3 (Cloruros marinos - Zonas de marea/salpicadura)	—	35	35
XD1 (Cloruros no marinos - Humedad moderada)	—	30	35
XD2 (Cloruros no marinos - Húmedo raro seco)	—	30	35
XD3 (Cloruros no marinos - Cíclico húmedo/seco)	—	35	35
XF1 (Hielo/deshielo - Sin sales, saturación moderada)	—	30	30
XF2 (Hielo/deshielo - Con sales, saturación moderada)	—	30	35
XF3 (Hielo/deshielo - Sin sales, alta saturación)	—	30	35
XF4 (Hielo/deshielo - Con sales, alta saturación)	—	35	35
XA1 (Ataque químico - Débil)	25	30	30
XA2 (Ataque químico - Moderado)	30	30	35
XA3 (Ataque químico - Fuerte)	35	35	35

#### Ejecución

Aplicar el Código Estructural dentro de su ámbito: aprobar dosificación y documentación, controlar recepción y consistencia, colocar sin segregación, compactar y curar según cemento, ambiente y desarrollo resistente. Las estructuras requieren al menos 20 MPa en masa y 25 MPa armadas o pretensadas, además de las exigencias de durabilidad. Determinar recubrimiento nominal como mínimo más margen de ejecución conforme a 43.4.1 y 44; la dirección debe reflejarlo en planos. El curado se justificará conforme a 52.5, sin convertir un número genérico de días en garantía de cumplimiento. Verificar desencofrado, juntas y ensayos.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 848–911. Transcripción para trazabilidad.
"""

Como norma general, la utilización de los distintos hormigones se efectuará atendiendo a la siguiente relación:
- Hormigón con una resistencia de 35 N/mm2:
- Pozos de saneamiento prefabricados.
- Elementos prefabricados.
- Hormigón con una resistencia de 30 N/mm2:
- Losas de aparcamiento.
- Rigolas.
- Hormigón con una resistencia de 25 N/mm2:
- Arquetas de abastecimiento.
- Pozos de registro armados in situ .
- Hormigón con una resistencia de 20 N/mm2:
- Pozos de registro sin armar in situ .
- Hormigón con una resistencia de 15 N/mm2:
- Aceras de hormigón.
- Soleras reforzadas de aceras.
- Arquetas de tomas de agua.
- Sumideros.
- Rellenos en muretes de bloques.
- Cimentación de cerramientos.
- Macizos de contrarresto.
- Rellenos reforzados.
- Hormigón con una resistencia de 12,5 N/mm2:
- Soleras de aceras.
- Asiento de tuberías.
- Rellenos.
- Envuelta de conductos.
- Capa de limpieza.
- Hormigón con una resistencia de 6 N/mm2:
- Sustitución de terrenos degradados.
- Trasdosados.
Los hormigones de los elementos prefabricados (bordillos, caz, etc.) tendrán una resistencia al desgaste, según la norma UNE 7015 y con un recorrido de doscientos cincuenta metros (250 m.), inferior a dos con cincuenta milímetros (2,50 mm).
Los hormigones empleados en losas de aparcamientos tendrán una resistencia característica a flexotracción de cuatro newton por milímetro cuadrado (4 N/mm2).
Los hormigones que deberán utilizarse cuando exista peligro de ataque por aguas selenitosas, o existan contactos con terrenos yesíferos, deberán contener la dosificación adecuada de cemento Portland resistente al yeso (denominación SR).
Los citados hormigones, como norma general, deberán adoptarse cuando el porcentaje de sulfato soluble en agua expresado en SO4 de las muestras del suelo sea superior al cero con dos por ciento (0,2 %); o cuando en las muestras de agua del subsuelo, el contenido en SO4 sea superior a cuatrocientas partes por millón (0,04 %). El cemento a emplear será I 42,5/SR (UNE 80303).
La consistencia de todos los hormigones que se utilicen, salvo circunstancias justificadas ante la Inspección de la obra, será plástica corresponderá a un asiento del cono de Abrams comprendido entre tres (3) centímetros y cinco (5)centímetros con una tolerancia de _1.
En zanjas, rellenos de trasdos, etc., serán de consistencia blanda (asiento 6 9 centímetros) e incluso fluida (asiento10 15 centímetros).
En condiciones ambientales normales (no calurosas) el tiempo transcurrido entre la adición de agua del amasado al cemento y a los áridos y la colocación del hormigón, no será mayor de una hora y media (1 1/2 h).
Los hormigones de central transportados por cubas agitadoras, deberán ponerse en obra dentro de la hora y media posterior a la adición de agua del amasado, no siendo admisibles los amasijos con un tiempo superior. Cada carga de hormigón fabricado en central irá acompañada de una hoja de suministro que estará en todo momento a disposición de la Inspección Facultativa.
El recubrimiento nominal de las armaduras de los hormigones en función de la clase de exposición ambiental, para conseguir una adecuada durabilidad, seré el siguiente:
[Falta el recubrimiento nominal]
Todos los hormigones se compactarán y curarán debidamente. A título orientativo el método de compactación adecuado para hormigones plásticos es la vibración normal. La duración mínima del curado será de 5 días. La altura máxima de vertido libre del hormigón, será de un metro (1 m.). Deberá suspenderse el hormigonado cuando la temperatura de ambiente sea superior a cuarenta grados centígrados (40 ºC) y siempre que se prevea que, dentro de las cuarenta y ocho horas (48 h.) siguientes, pueda descender la temperatura ambiente por debajo de cero grados centígrados (0 ºC).

En las losas de aparcamientos, deberán disponerse juntas de retracción a distancias inferiores a seis metros (6 m.), disponiendo las superficies de encuentro a testa y sellando las juntas horizontales con un mástic bituminoso. Las juntas de hormigonado, deberán ajustarse siempre que sea posible a las de retracción, y en caso contrario, deberán adoptarse las medidas necesarias para asegurar la perfecta unión de las masas en contacto y obtener una correcta superficie vista.
La parada en el proceso de hormigonado superior a treinta minutos (30 min.), requerirá realizar una junta de hormigonado correctamente dispuesta en el punto en que se encuentra la unidad, si técnicamente es admisible. Si no fuera admisible dicha junta, deberá demolerse lo ejecutado hasta el punto donde se pueda realizar.
Todos los muros deberán disponer de mechinales y de berenjenos en los lugares que disponga la Inspección de la obra.
Los defectos deberán ser corregidos por cuenta del Contratista, de acuerdo con las indicaciones de la Inspección de la obra.

Los elementos empleados y el sistema utilizado para el transporte del hormigón deben estar dispuestos de forma que se evite la disgregación y excesiva exudación del hormigón, así como también que aseguren que el tiempo que se invierta hasta la colocación sea inferior al que determina el comienzo del fraguado.

El hormigón, una vez colocado, debe vibrarse, amasada por amasada, hasta el punto de que no haya duda en cuanto a su completa consolidación. Se efectuará una vibración sistemática que asegure su completa consolidación, sobre todo en la parte en que se juntan las amasadas.
El tiempo de duración del vibrado en cada punto lo indicará la textura del hormigón, el sonido del vibrador y la sensación que produce en la mano del que lo maneja, debiendo estar comprendido entre los cinco (5) y quince (15) segundos de cada período. Cuando en un período total del vibrado se aprecie una reflexión excesiva del mortero en el hormigón, se modificará su resistencia para que permita un vibrado enérgico sin disgregarse.

El curado del hormigón se efectuará manteniendo húmedas sus superficies por lo menos durante quince (15) días, mediante riegos cuya frecuencia y duración fijará el Director de las obras de acuerdo con la temperatura y humedad del ambiente. El Contratista podrá proponer otra forma de curado que será autorizada así lo considere conveniente el Director de la Obra.
La temperatura del agua en el primer riego no será muy inferior a la que tenga entonces la superficie del hormigón. Se evitarán las sobrecargas, vibraciones y demás causas que puedan provocar la fisuración del hormigón.

La retirada de apoyos en los encofrados no podrá hacerse antes de cumplir los plazos fijados por la vigente Instrucción. Para efectuar esta operación se precisará la autorización del Director de la Obra, el cual determinará la forma de proceder de acuerdo con las circunstancias de cada caso.
Cuando se trate de apoyos y encofrados laterales, el contratista se atendrá a las normas dadas por el Director de las Obras, según la temperatura y humedad del ambiente, relación agua/cemento  empleado y resultado de las probetas ensayo, al objeto de que el desencofrado se efectúe cuando convenga al curado del hormigón y necesidades de la obra, sin la posibilidad de que sufra distorsiones o daños por dicha causa.
No se enlucirá ni se taparán los defectos o coqueras que aparezcan sin la autorización del Director de la Obra, quién resolverá en cada caso la forma de corregir el defecto.

El Director de la Obra suspenderá el hormigonado cuando la temperatura ambiente alcance los cuarenta (40) grados centígrados o, siendo inferior, se tema que la temperatura del hormigón al colocarlo sea superior a los treinta grados centígrados, para evitar lo cual se procurará amasar en agua fría, regar los áridos, emplear cementos no calientes y proteger los áridos y demás elementos de la acción directa de los rayos del sol.

El Contratista está obligado a llevar un control interno de las tareas específicas que le competen dentro del proceso constructivo, así como a controlar que los subcontratistas y proveedores disponen de sus propios controles internos.
Los controles se realizarán según instrucción, y las especificaciones del director de las obras.

#### Medición y valoración

Por m³ del tipo colocado según planos y modificaciones aprobadas, sin excesos no autorizados. Incluye transporte, puesta en obra, compactación, curado y demás operaciones descritas; armaduras y encofrados sólo se separan si el presupuesto lo prevé.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad.
"""

Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad.
"""

En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1143–1147. Transcripción para trazabilidad.
"""

Todas las fábricas de hormigón se medirán por metro cúbico (mi) y de acuerdo con las dimensiones indicadas en las mediciones o en los planos, o con las posibles correcciones efectuadas con la aprobación del Director de la Obra.
El abono se efectuará por aplicación de los precios del presupuesto, que se refiere a fábrica colocada, terminada y cualquiera que sea la procedencia de los materiales, de acuerdo con los distintos tipos de hormigón y su lugar de emplazamiento. Se incluye así mismo en el precio, el encofrado en aquellas partidas que lo requieran y que no hayan sido medidas en otra unidad específica.
No será de abono el exceso de fábrica que haya sido colocada por defectos en las excavaciones o por cualquier otro motivo que no haya sido debidamente aprobado por el Director de la Obra.
Asimismo, no se abonarán las operaciones que sea preciso efectuar para limpiar, enlucir y reparar las superficies de hormigón en las que se acusen irregularidades de los encofrados superiores a las tolerancias o que presenten aspecto defectuoso.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
