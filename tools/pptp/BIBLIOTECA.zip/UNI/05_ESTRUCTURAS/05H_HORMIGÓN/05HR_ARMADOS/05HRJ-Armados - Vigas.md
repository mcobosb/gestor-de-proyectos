"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Armados - Vigas

**Clasificación BCCA:** `05HRJ`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Vigas**, dentro de **Armados**.
Aplicable a las partidas cuyo código BCCA comienza por `05HRJ`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05HRJ80010 - HORM. ARM. HA-25/P/20/XC2 EN VIGAS PLANAS I/ENC. REVESTIR

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas planas, para revestir, suministrado y puesta en obra, armadura de acero B 400 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80020 - HORM. ARM. HA-30/P/20/XC2 EN VIGAS PLANAS I/ENC. REVESTIR

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas planas, para revestir, suministrado y puesta en obra, armadura de acero B 500 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80040 - HORM. ARM. HA-25/P/20/XC2 EN VIGAS PLANAS I/ENC. MAD. VISTO

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas planas, para quedar visto, suministrado y puesta en obra, armadura de acero B 500 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80050 - HORM. ARM. HA-30/P/20/XC2 EN VIGAS PLANAS I/ENC. MAD. VISTO

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas planas, para quedar visto, suministrado y puesta en obra, armadura de acero B 500 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80100 - HORM. ARM. HA-25/P/20/XC2 EN VIGAS DESCUELGUE I/ENC. REVESTIR

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas de descuelgue, para revestir, suministrado y puesta en obra, armadura de acero B 400 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80110 - HORM. ARM. HA-30/P/20/XC2 EN VIGAS DESCUELGUE I/ENC. REVESTIR

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas de descuelgue, para revestir, suministrado y puesta en obra, armadura de acero B 500 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80150 - HORM. ARM. HA-25/P/20/XC2 EN VIGAS DESCUELGUE I/ENC. MAD. VISTO

**Unidad:** m3.

Hormigón armado HA-25/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas de descuelgue, para quedar visto, suministrado y puesta en obra, armadura de acero B 400 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

### 05HRJ80160 - HORM. ARM. HA-30/P/20/XC2 EN VIGAS DESCUELGUE I/ENC. MAD. VISTO

**Unidad:** m3.

Hormigón armado HA-30/P/20/XC2, consistencia plástica y tamaño máximo del árido 20 mm, en vigas de descuelgue, para quedar visto, suministrado y puesta en obra, armadura de acero B 500 S con una cuantía de 95 kg/m3, incluso p.p. de encofrado de madera, desencofrado, limpieza de fondos, ferrallado, separadores, vibrado y curado; construido según Código Estructural  y NCSR-02. Medido el volumen teórico ejecutado.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Armados

**Clasificación:** 05HR. **Capítulo:** estructuras. **Familia:** hormigón.

"""
#### Descripción

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «armados», dentro de «hormigón». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

Inspeccionar armado y moldes antes de hormigonar; controlar recepción, compactación, juntas y curado.

Para la variante «armados» se comprobarán expresamente resistencia, exposición, recubrimientos y secuencia de hormigonado. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
