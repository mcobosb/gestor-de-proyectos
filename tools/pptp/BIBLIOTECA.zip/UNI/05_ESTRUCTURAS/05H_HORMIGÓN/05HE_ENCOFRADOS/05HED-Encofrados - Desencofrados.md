"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Encofrados - Desencofrados

**Clasificación BCCA:** `05HED`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Desencofrados**, dentro de **Encofrados**.
Aplicable a las partidas cuyo código BCCA comienza por `05HED`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 05HED00001 - DESENCOFRADO ELEM. HORM. A REVESTIR ENC. CON MADERA

**Unidad:** m2.

Desencofrado de elementos estructurales varios de hormigón para revestir, encofrados con madera, incluso p.p. de limpieza y reparación; según Código Estructural. Medida la superficie de encofrado útil.

### 05HED00051 - DESENCOFRADO ELEM. HORM. A REVESTIR ENC. CON PANELES METÁLICOS

**Unidad:** m2.

Desencofrado de elementos estructurales varios de hormigón para revestir, encofrados con paneles metálicos, incluso p.p. de limpieza y reparación; según Código Estructural. Medida la superficie de encofrado útil.

### 05HED00101 - DESENCOFRADO ELEM. HORM. VISTO ENC. CON MADERA

**Unidad:** m2.

Desencofrado de elementos estructurales varios de hormigón visto, encofrados con madera, incluso p.p. de limpieza y reparación; según Código Estructural. Medida la superficie de encofrado útil.

### 05HED00151 - DESENCOFRADO ELEM. HORM. VISTO ENC. CON PANELES METÁLICOS

**Unidad:** m2.

Desencofrado de elementos estructurales varios de hormigón visto, encofrados con paneles metálicos, incluso p.p. de limpieza y reparación; según Código Estructural. Medida la superficie de encofrado útil.

### 05HED80060 - DESENCOFRADO ELEM. HORM. VISTO ENC. TUBO CARTÓN

**Unidad:** m2.

Desencofrado de elementos estructurales varios de hormigón visto, encofrados con tubo de cartón, incluso p.p. de limpieza y reparación; según Código Estructural. Medida la superficie de encofrado útil.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

"""
### Encofrado curvo de paramentos verticales
"""

**Clasificación:** 05HE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Molde provisional para superficies curvas verticales de hormigón con radios y acabado definidos en planos.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 432–439. Transcripción para trazabilidad.
"""

Los encofrados a emplear en las obras serán metálicos o de otro material rígido que reúna análogas condiciones de eficacia.

Se definen los siguientes encofrados:
- Encofrado plano en paramentos verticales e inclinados.
- Encofrado curvo en paramentos verticales.
- Encofrado en tableros, dinteles y bóvedas.

#### Ejecución

Dimensionar paneles, rigidización, tirantes y apoyo para la presión de hormigonado y comprobar radio y aplomado. Garantizar estanqueidad, limpieza y compatibilidad del desencofrante. Retirar conforme a resistencia alcanzada y procedimiento aprobado según el Código Estructural.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 903–906. Transcripción para trazabilidad.
"""

La retirada de apoyos en los encofrados no podrá hacerse antes de cumplir los plazos fijados por la vigente Instrucción. Para efectuar esta operación se precisará la autorización del Director de la Obra, el cual determinará la forma de proceder de acuerdo con las circunstancias de cada caso.
Cuando se trate de apoyos y encofrados laterales, el contratista se atendrá a las normas dadas por el Director de las Obras, según la temperatura y humedad del ambiente, relación agua/cemento  empleado y resultado de las probetas ensayo, al objeto de que el desencofrado se efectúe cuando convenga al curado del hormigón y necesidades de la obra, sin la posibilidad de que sufra distorsiones o daños por dicha causa.
No se enlucirá ni se taparán los defectos o coqueras que aparezcan sin la autorización del Director de la Obra, quién resolverá en cada caso la forma de corregir el defecto.

#### Medición y valoración

Por m² reales de contacto de la superficie curva según planos y partida, incluidos desmontaje y auxiliares, evitando doble abono con el hormigón.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 440–441. Transcripción para trazabilidad.
"""

Se medirán y abonarán los metros cuadrados (m²) de encofrado en cada tipo empleado en obra, deducidos de los planos de construcción, por las superficies de hormigón que han de contener. Incluye, igualmente, el precio unitario las operaciones de encofrado, desencofrado, limpieza de encofrado, cimbras y cuantas operaciones se requieran para que las obras sean acordes con los planos de construcción y el Pliego de Prescripciones.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1143–1147. Transcripción para trazabilidad.
"""

Todas las fábricas de hormigón se medirán por metro cúbico (mi) y de acuerdo con las dimensiones indicadas en las mediciones o en los planos, o con las posibles correcciones efectuadas con la aprobación del Director de la Obra.
El abono se efectuará por aplicación de los precios del presupuesto, que se refiere a fábrica colocada, terminada y cualquiera que sea la procedencia de los materiales, de acuerdo con los distintos tipos de hormigón y su lugar de emplazamiento. Se incluye así mismo en el precio, el encofrado en aquellas partidas que lo requieran y que no hayan sido medidas en otra unidad específica.
No será de abono el exceso de fábrica que haya sido colocada por defectos en las excavaciones o por cualquier otro motivo que no haya sido debidamente aprobado por el Director de la Obra.
Asimismo, no se abonarán las operaciones que sea preciso efectuar para limpiar, enlucir y reparar las superficies de hormigón en las que se acusen irregularidades de los encofrados superiores a las tolerancias o que presenten aspecto defectuoso.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Encofrado plano de paramentos verticales e inclinados
"""

**Clasificación:** 05HE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Molde rígido provisional para obtener paramentos planos de hormigón según geometría de proyecto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 432–439. Transcripción para trazabilidad.
"""

Los encofrados a emplear en las obras serán metálicos o de otro material rígido que reúna análogas condiciones de eficacia.

Se definen los siguientes encofrados:
- Encofrado plano en paramentos verticales e inclinados.
- Encofrado curvo en paramentos verticales.
- Encofrado en tableros, dinteles y bóvedas.

#### Ejecución

Aplicar el Código Estructural: comprobar estabilidad, resistencia y estanqueidad del sistema, soportes y uniones; limpiar e impregnar con desencofrante compatible sin contaminar armaduras. Verificar dimensiones y recubrimientos antes del vertido y desencofrar sólo con resistencia suficiente y autorización.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 903–906. Transcripción para trazabilidad.
"""

La retirada de apoyos en los encofrados no podrá hacerse antes de cumplir los plazos fijados por la vigente Instrucción. Para efectuar esta operación se precisará la autorización del Director de la Obra, el cual determinará la forma de proceder de acuerdo con las circunstancias de cada caso.
Cuando se trate de apoyos y encofrados laterales, el contratista se atendrá a las normas dadas por el Director de las Obras, según la temperatura y humedad del ambiente, relación agua/cemento  empleado y resultado de las probetas ensayo, al objeto de que el desencofrado se efectúe cuando convenga al curado del hormigón y necesidades de la obra, sin la posibilidad de que sufra distorsiones o daños por dicha causa.
No se enlucirá ni se taparán los defectos o coqueras que aparezcan sin la autorización del Director de la Obra, quién resolverá en cada caso la forma de corregir el defecto.

#### Medición y valoración

Por m² de superficie de contacto con el hormigón según planos. Incluye colocación, desencofrado, limpieza y medios descritos; no abonar aparte cuando esté integrado en la unidad de hormigón.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 440–441. Transcripción para trazabilidad.
"""

Se medirán y abonarán los metros cuadrados (m²) de encofrado en cada tipo empleado en obra, deducidos de los planos de construcción, por las superficies de hormigón que han de contener. Incluye, igualmente, el precio unitario las operaciones de encofrado, desencofrado, limpieza de encofrado, cimbras y cuantas operaciones se requieran para que las obras sean acordes con los planos de construcción y el Pliego de Prescripciones.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1143–1147. Transcripción para trazabilidad.
"""

Todas las fábricas de hormigón se medirán por metro cúbico (mi) y de acuerdo con las dimensiones indicadas en las mediciones o en los planos, o con las posibles correcciones efectuadas con la aprobación del Director de la Obra.
El abono se efectuará por aplicación de los precios del presupuesto, que se refiere a fábrica colocada, terminada y cualquiera que sea la procedencia de los materiales, de acuerdo con los distintos tipos de hormigón y su lugar de emplazamiento. Se incluye así mismo en el precio, el encofrado en aquellas partidas que lo requieran y que no hayan sido medidas en otra unidad específica.
No será de abono el exceso de fábrica que haya sido colocada por defectos en las excavaciones o por cualquier otro motivo que no haya sido debidamente aprobado por el Director de la Obra.
Asimismo, no se abonarán las operaciones que sea preciso efectuar para limpiar, enlucir y reparar las superficies de hormigón en las que se acusen irregularidades de los encofrados superiores a las tolerancias o que presenten aspecto defectuoso.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.

### Encofrados y cimbras de tableros, dinteles y bóvedas
"""

**Clasificación:** 05HE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Moldes y sistemas de apeo temporal para ejecutar elementos elevados de hormigón.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 432–439. Transcripción para trazabilidad.
"""

Los encofrados a emplear en las obras serán metálicos o de otro material rígido que reúna análogas condiciones de eficacia.

Se definen los siguientes encofrados:
- Encofrado plano en paramentos verticales e inclinados.
- Encofrado curvo en paramentos verticales.
- Encofrado en tableros, dinteles y bóvedas.

#### Ejecución

Disponer proyecto o justificación del sistema de apeo según su entidad, apoyos resistentes y arriostramiento. Controlar montaje, deformaciones y secuencia de vertido y no retirar apoyos hasta comprobar la resistencia y autorizar el descimbrado conforme al Código Estructural. Prever las cargas de fases posteriores.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 903–906. Transcripción para trazabilidad.
"""

La retirada de apoyos en los encofrados no podrá hacerse antes de cumplir los plazos fijados por la vigente Instrucción. Para efectuar esta operación se precisará la autorización del Director de la Obra, el cual determinará la forma de proceder de acuerdo con las circunstancias de cada caso.
Cuando se trate de apoyos y encofrados laterales, el contratista se atendrá a las normas dadas por el Director de las Obras, según la temperatura y humedad del ambiente, relación agua/cemento  empleado y resultado de las probetas ensayo, al objeto de que el desencofrado se efectúe cuando convenga al curado del hormigón y necesidades de la obra, sin la posibilidad de que sufra distorsiones o daños por dicha causa.
No se enlucirá ni se taparán los defectos o coqueras que aparezcan sin la autorización del Director de la Obra, quién resolverá en cada caso la forma de corregir el defecto.

#### Medición y valoración

Por m² de contacto de encofrado con el hormigón según 3.22, incluyendo cimbras y las operaciones descritas salvo partida específica contractual.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 440–441. Transcripción para trazabilidad.
"""

Se medirán y abonarán los metros cuadrados (m²) de encofrado en cada tipo empleado en obra, deducidos de los planos de construcción, por las superficies de hormigón que han de contener. Incluye, igualmente, el precio unitario las operaciones de encofrado, desencofrado, limpieza de encofrado, cimbras y cuantas operaciones se requieran para que las obras sean acordes con los planos de construcción y el Pliego de Prescripciones.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
