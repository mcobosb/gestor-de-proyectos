# Encofrado plano de paramentos verticales e inclinados - Común

**Clasificación:** 05HE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Molde rígido provisional para obtener paramentos planos de hormigón según geometría de proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 432–439. Transcripción para trazabilidad.

Los encofrados a emplear en las obras serán metálicos o de otro material rígido que reúna análogas condiciones de eficacia.

Se definen los siguientes encofrados:
- Encofrado plano en paramentos verticales e inclinados.
- Encofrado curvo en paramentos verticales.
- Encofrado en tableros, dinteles y bóvedas.

## Ejecución

Aplicar el Código Estructural: comprobar estabilidad, resistencia y estanqueidad del sistema, soportes y uniones; limpiar e impregnar con desencofrante compatible sin contaminar armaduras. Verificar dimensiones y recubrimientos antes del vertido y desencofrar sólo con resistencia suficiente y autorización.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 903–906. Transcripción para trazabilidad.

La retirada de apoyos en los encofrados no podrá hacerse antes de cumplir los plazos fijados por la vigente Instrucción. Para efectuar esta operación se precisará la autorización del Director de la Obra, el cual determinará la forma de proceder de acuerdo con las circunstancias de cada caso.
Cuando se trate de apoyos y encofrados laterales, el contratista se atendrá a las normas dadas por el Director de las Obras, según la temperatura y humedad del ambiente, relación agua/cemento  empleado y resultado de las probetas ensayo, al objeto de que el desencofrado se efectúe cuando convenga al curado del hormigón y necesidades de la obra, sin la posibilidad de que sufra distorsiones o daños por dicha causa.
No se enlucirá ni se taparán los defectos o coqueras que aparezcan sin la autorización del Director de la Obra, quién resolverá en cada caso la forma de corregir el defecto.

## Medición y valoración

Por m² de superficie de contacto con el hormigón según planos. Incluye colocación, desencofrado, limpieza y medios descritos; no abonar aparte cuando esté integrado en la unidad de hormigón.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 440–441. Transcripción para trazabilidad.

Se medirán y abonarán los metros cuadrados (m²) de encofrado en cada tipo empleado en obra, deducidos de los planos de construcción, por las superficies de hormigón que han de contener. Incluye, igualmente, el precio unitario las operaciones de encofrado, desencofrado, limpieza de encofrado, cimbras y cuantas operaciones se requieran para que las obras sean acordes con los planos de construcción y el Pliego de Prescripciones.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1143–1147. Transcripción para trazabilidad.

Todas las fábricas de hormigón se medirán por metro cúbico (mi) y de acuerdo con las dimensiones indicadas en las mediciones o en los planos, o con las posibles correcciones efectuadas con la aprobación del Director de la Obra.
El abono se efectuará por aplicación de los precios del presupuesto, que se refiere a fábrica colocada, terminada y cualquiera que sea la procedencia de los materiales, de acuerdo con los distintos tipos de hormigón y su lugar de emplazamiento. Se incluye así mismo en el precio, el encofrado en aquellas partidas que lo requieran y que no hayan sido medidas en otra unidad específica.
No será de abono el exceso de fábrica que haya sido colocada por defectos en las excavaciones o por cualquier otro motivo que no haya sido debidamente aprobado por el Director de la Obra.
Asimismo, no se abonarán las operaciones que sea preciso efectuar para limpiar, enlucir y reparar las superficies de hormigón en las que se acusen irregularidades de los encofrados superiores a las tolerancias o que presenten aspecto defectuoso.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
