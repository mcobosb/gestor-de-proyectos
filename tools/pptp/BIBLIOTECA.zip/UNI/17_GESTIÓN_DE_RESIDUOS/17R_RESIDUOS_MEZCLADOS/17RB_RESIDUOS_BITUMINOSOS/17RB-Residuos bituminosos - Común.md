"""
# Residuos bituminosos - Común

**Clasificación:** 17RB. **Capítulo:** gestión de residuos. **Familia:** residuos mezclados.

"""
## Descripción

Separación, acopio, traslado y entrega de la fracción de residuo identificada, sin presumir su carácter inerte ni su posibilidad de reutilización.

El objeto de esta ficha es «residuos bituminosos», dentro de «residuos mezclados». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Identificar origen y código LER y comprobar la posible peligrosidad antes de mezclar o mover residuos. Segregar en recipientes o zonas compatibles, evitar dispersión y entregar por la vía autorizada para la fracción concreta, conservando los documentos de seguimiento.

Caracterizar mezclas y justificar la separación en origen; no usar la categoría mezclados para eludir la segregación exigible.

Para la variante «residuos bituminosos» se comprobarán expresamente composición de la mezcla y operaciones de separación. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Contrastar inventario, pesos, transportista, autorización del destinatario y aceptación de la operación. La reutilización y el fin de condición de residuo requieren justificación específica.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Preferentemente t acreditadas por pesada y justificantes de entrega, si así lo establece el presupuesto; si se usa m³, fijar medición y conversión justificadas. Distinguir contenedor, carga, transporte y tratamiento y no repetirlos si los incluye la demolición.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
