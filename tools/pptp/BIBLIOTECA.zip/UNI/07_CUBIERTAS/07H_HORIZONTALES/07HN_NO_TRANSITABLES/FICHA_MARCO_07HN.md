# no transitables

**Clasificación:** 07HN. **Capítulo:** cubiertas. **Familia:** horizontales.

## Descripción

Sistemas de cubierta y sus capas, encuentros y elementos de iluminación, definidos como una solución compatible de protección frente al agua y al ambiente.

El objeto de esta ficha es «no transitables», dentro de «horizontales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Verificar el soporte y las pendientes. Colocar las capas en el orden del sistema aprobado, resolver sumideros, juntas, petos y penetraciones y proteger la impermeabilización antes de recibir las capas superiores. Mantener la seguridad frente a caídas.

Comprobar pendientes, capas separadoras y continuidad de la impermeabilización en una cubierta horizontal.

Para la variante «no transitables» se comprobarán expresamente uso transitable o no, capas, pendientes y sistema impermeable. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Inspeccionar continuidad, fijaciones y encuentros y efectuar la prueba de estanqueidad prevista, con carga y evacuación compatibles con la estructura.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m² de cubierta con criterio expreso de superficie en proyección o desarrollada; remates y juntas en m y lucernarios en ud o m² tipificado. Precisar las capas incluidas para evitar medir dos veces aislamiento o impermeabilización.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
