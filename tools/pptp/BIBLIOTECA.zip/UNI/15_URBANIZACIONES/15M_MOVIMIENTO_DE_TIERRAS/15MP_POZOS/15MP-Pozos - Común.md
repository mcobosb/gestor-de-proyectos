# Pozos - Común

**Clasificación:** 15MP. **Capítulo:** urbanizaciones. **Familia:** movimiento de tierras.

## Descripción

Elementos de urbanización y redes exteriores definidos por los planos, el presupuesto y las condiciones del titular del espacio o servicio.

El objeto de esta ficha es «pozos», dentro de «movimiento de tierras». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Coordinar replanteo y servicios existentes, mantener itinerarios seguros y ejecutar por fases compatibles con el tráfico y otras redes. Revisar apoyos, cotas y encuentros antes de ocultar elementos y reponer las superficies afectadas.

Levantar perfiles, controlar estabilidad y servicios y verificar cada capa antes de cubrirla.

Para la variante «pozos» se comprobarán expresamente geometría, geotecnia, sostenimiento y compactación. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar geometría, funcionalidad, accesibilidad y recepción por el titular; documentar trazados y elementos ocultos mediante planos finales.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

ud de elemento completo de tipología, dimensiones y prestaciones definidas, instalado y con la recepción exigida. Precisar conexiones, anclajes, pruebas y obra civil incluidos, evitando certificar de nuevo componentes del conjunto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
