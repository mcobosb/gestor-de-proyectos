# Compactaciones - Común

**Clasificación:** 15MC  
**Capítulo:** Urbanizaciones  
**Familia:** Movimiento de tierras  

## Descripción
Densificación mecánica del terreno natural, fondos de excavación, subbasamentos o capas de relleno (terraplenes, pedraplenes, cunas de zanjas y trasdós de estructuras) mediante maquinaria adecuada, para alcanzar la capacidad portante y el grado de compactación especificados en el proyecto geotécnico.

## Ejecución
1. **Previos:** Comprobar la cota del plano de apoyo, la inexistencia de agua, barro, materias orgánicas o suelos inestables, y verificar el cumplimiento de las características del material a compactar (granulometría y plasticidad).
2. **Puesta en obra y compactado:** Extendido del material en tongadas de espesor uniforme según los medios mecánicos autorizados. Humectación o desecación hasta alcanzar la humedad óptima del ensayo Próctor. Compactación mediante rodillo vibratorio, compactador neumático o bandeja vibrante hasta lograr el porcentaje de densidad exigido (ej. ≥ 95% o ≥ 100% del Próctor Modificado según la zona).
3. **Control y recepción:** Realización de ensayos de densidad y humedad *in situ* (mediante sonda nuclear o método de la arena) y ensayos de placa de carga para comprobar los módulos de deformación antes de autorizar el vertido de la capa superior.

## Medición
* **Unidad de medida:** Metro cúbico (m³) de material compactado en perfil teórico, o Metro cuadrado (m²) de superficie de fondo/plano de apoyo compactado.
* **Criterio:** Volumen o superficie neta realmente compactada y aceptada por la Dirección Facultativa conforme a las secciones de proyecto (sin abono de sobreanchos no autorizados).

## Valoración
El precio unitario (€/m³ o €/m²) incluye:
* Mano de obra, maquinaria de compactación (rodillos, compactadores, bandejas) y medios auxiliares.
* Aportación de agua para humectación o labores de laboreo/oreado para ajuste de humedad.
* Nivelación, perfilado y refino de las tongadas o del plano final de compactación.
* Realización de los ensayos geotécnicos de densidad *in situ* y placas de carga de recepción.