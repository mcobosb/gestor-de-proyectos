# Hidrantes contra incendios - Común

**Clasificación:** 15SH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Puntos de suministro de agua para extinción conectados a la red, definidos por el proyecto y las condiciones de protección contra incendios aplicables.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 319–320. Transcripción para trazabilidad.

HIDRANTES
Deberán estar normalizados y cumplirán con las prescripciones del Servicio Municipal de Bomberos.

## Ejecución

Seleccionar el tipo y prestaciones conforme al RIPCI dentro de su ámbito y coordinar con el servicio de bomberos. Instalar con accesibilidad, protección, aislamiento y anclaje adecuados, mantener su señalización y realizar las comprobaciones hidráulicas y funcionales exigibles antes de la recepción.

## Medición y valoración

Medir en ud independiente instalada y probada según 3.16.7 y el alcance de la partida.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad.

Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
