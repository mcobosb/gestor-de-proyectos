# Acometidas y ramales de polietileno

**Clasificación:** 15SA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Conexiones de abastecimiento a parcelas y ramales de pequeño diámetro; el original menciona polietileno de baja densidad para determinados diámetros.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 204–211. Transcripción para trazabilidad.

La unión entre tubos será mediante:
- Accesorios específicos para P.E.
- Uniones universales para tubos rígidos.
- Soldadura a tope por termofusión.
- Manguitos electrosoldables.
La soldadura se considerará inadecuada para acometidas o para ramales de diámetro inferior a 110 mm, para los cuales sólo se admitirán uniones mediante accesorios convencionales en latón estampado, aluminio, fundición dúctil o gris, con las especificaciones contempladas en los apartados correspondientes.
Estas acometidas o ramales de diámetros inferiores se harán exclusivamente en polietileno de baja densidad conforme a las normas UNE53-131 y 53-133.

## Ejecución

Coordinar el corte y conexión con el servicio de aguas, verificar la aptitud sanitaria y presión del sistema y emplear accesorios compatibles con el material. Ejecutar llave y arqueta accesibles y pasatubos cuando proceda. Probar, limpiar y desinfectar sin contaminar la red existente.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 291–320. Transcripción para trazabilidad.

Todos los elementos y/o piezas especiales deberán contar con el suficiente macizo de anclaje, a tracción o compresión, efectuado con hormigón de resistencia característica de al menos, 175 Kg/cm² o se emplearán juntas resistentes a la tracción.
Todos los elementos y piezas especiales deberán contar con el suficiente macizo de anclaje, atracción o comprensión, efectuado con hormigón de resistencia característica de al menos, 175 Kg/cm², o se emplearán juntas resistentes a la tracción.
Las tuberías de agua se dispondrán por encima de las tuberías de saneamiento. Las desviaciones máximas admisibles serán de 5º para tubos de 100 a 150mm.
Se deberá realizar una prueba de tubería en tramos con longitud máxima de 100 metros, no autorizándose el tapado de la tubería hasta la aprobación de la prueba.
Las arquetas que se ejecute serán las indicadas en planos y no reposarán sobre los tubos haciéndose arcos de descarga para su paso.
Si se realizaran acometidas a parcelas se dispondrán en la acera arquetas de acometida, dotadas de llave de corte, disponiendo de un pasatubos desde las arquetas hasta la parcela, con objeto de evitar el levantamiento posterior de las aceras.
PRUEBAS A REALIZAR EN LA OBRA
Las obras a incorporar al Servicio, serán recepcionadas por los técnicos municipales competentes o personas por ellos delegadas.
Las instalaciones se someterán a las siguientes clases de prueba:
- Prueba de presión interior.
- Prueba de estanqueidad.
PRUEBAS DE PRESIÓN INTERIOR
A medida que se monten, las tuberías se someterán a la prueba de presión interior por tramos no superiores a 500 m.
La presión de prueba será necesaria para que en el punto más bajo resulte como mínimo 1´4 veces la máxima presión. Entre el punto más bajo y el más alto del tramo a probar no será superior al 10% la presión de prueba.
La tubería llenará por la parte más baja y se abrirá bocas a fin de extraer el aire. Cuando se prueben tuberías de fibrocemento o de hormigón, se recomienda mantenerlas llena desde 24 horas antes de la prueba.
La bomba de prueba se proveerá de dos manómetros, uno de ellos de comprobación, aportado por la Dirección de la Obra o el Servicio.
Una vez la tubería esté llena y libre de aire, se elevará la presión a un ritmo no superior a 100 KPA/mínimo (1 Kg/cm² y min.) hasta alcanzar el valor fijado para la prueba.
Seguidamente se cerrará la tubería durante 30 minutos. La prueba se considerará satisfactoria cuando en este tiempo la presión no baje más de (P/5), siendo P la presión de prueba.
En caso de que el resultado de la prueba sea negativo, se arreglará la avería y se volverá a repetir.
Si durante las pruebas de presión se producen roturas a un 6% de los tubos ensayados, se rechazará el lote de tubos. Si salen más de un 4% de uniones defectuosas, se rechazará todo el lote del que  formen parte.
Una vez el resultado de las pruebas de presión sea satisfactorio, se podrá hacer la prueba de estanqueidad.
PRUEBAS DE ESTANQUEIDAD
Se llenará a tubería teniendo la precaución de extraer todo el aire.
La prueba se efectuará a una presión equivalente a la máxima de trabajo en el punto más desfavorable.
La prueba se realizará cerrando la red a probar y alimentándola mediante un contador.
Se medirá la cantidad de agua necesaria, V, para mantener durante dos horas la presión de prueba. La prueba se considerará satisfactoria si resulta:
V< K x L x D
siendo: L la longitud de la tubería en m; D, diámetro interior en m; V, volumen aportado en litros; K, coeficiente que depende de si la tubería es hormigón armado (K = 0,4), hormigón prensado (K = 0,25), fibrocemento (K = 0,35), fundición (K = 0,3), acero (K = 0,35)o plástico (K =  0,35).
HIDRANTES
Deberán estar normalizados y cumplirán con las prescripciones del Servicio Municipal de Bomberos.

## Medición y valoración

Aplicar la partida de acometida completa si existe; en otro caso, separar longitud de tubo y accesorios únicamente como determine el presupuesto. El original no fija un precio autónomo para toda acometida.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad.

Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
