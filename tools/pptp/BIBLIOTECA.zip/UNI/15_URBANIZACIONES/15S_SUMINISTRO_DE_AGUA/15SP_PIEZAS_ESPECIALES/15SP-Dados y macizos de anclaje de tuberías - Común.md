# Dados y macizos de anclaje de tuberías - Común

**Clasificación:** 15SP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Bloques de hormigón que transmiten al terreno los empujes de codos, derivaciones y otras piezas de la red.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 266–267. Transcripción para trazabilidad.

EJECUCIÓN DE TOPES EN LAS CURVAS, CONOS Y DERIVACIONES
Las curvas, conos y tés se anclarán por el lado por donde se dirige la resultante de las fuerzas de presión internas.

## Ejecución

Dimensionar para presión de prueba y de servicio, empujes y capacidad del terreno. Excavar hasta apoyo estable, construir sin englobar juntas ni tornillos y asegurar resistencia suficiente antes de cargar o probar. Aplicar el Código Estructural cuando el hormigón tenga función estructural.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 268–270. Transcripción para trazabilidad.

Se excavará hasta llegar a terreno consistente, se hará un encofrado no englobando las uniones y tornillos de las bridas, y se rellenará de hormigón en masa.
Las dimensiones de los topes serán las que fija la “Normativa para Redes de Distribución de Agua Potable” de la Asociación Española de Abastecimiento y Saneamiento.
De no resultar posible la construcción de un tope de las medidas que figuren en la norma, se construirá según las instrucciones del facultativo responsable del servicio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 954–959. Transcripción para trazabilidad.

Los cambios de alineación o rasante de gran radio, deberán realizarse con tubos rectos o de acuerdo con lo indicado en los planos del proyecto.

Se colocarán bloques de empuje en todos los codos o cambios de dirección bruscos de la tubería, aún cuando éstos no estuviesen específicamente señalados en los planos. Las dimensiones y peso serán las adecuadas en función de la velocidad y altura de presión de cada tramo de tubería.
Estos bloques de empuje, deberán construirse una vez montados los tubos y las piezas especiales, fundiendo el hormigón entre las zanjas y la parte lateral e inferior de los mismos.
En ningún caso, el hormigón deberá interferir en las juntas de las piezas, perturbando su posible reparación.

## Medición y valoración

El original cita topes incluidos en el metro de tubo y dados por ud. Adoptar sólo el criterio de la partida aprobada y no certificar el mismo bloque dos veces.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad.

Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
