# Válvulas de compuerta - Común

**Clasificación:** 15SV. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Válvulas de corte para abastecimiento, de cierre elástico y dimensiones y presión compatibles con la red.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 218–235. Transcripción para trazabilidad.

Válvulas de compuerta
Se usarán para diámetros comprendidos entre 100 mm y 300 mm.
Su presión nominal mínima será de 16 kg/ cm², con una presión de prueba de estanqueidad de 24 kg/ cm².
Las válvulas cumplirán las normas siguientes:
- ISO 2531 86 ISO 7259 88.
- ISO 5752 82 ISO 5208 82.
- ISO 1083 ISO 9001 o bien ISO 9002.
Tendrán el cuerpo y la tapa de fundición dúctil FGE 42 12 UNE 36.118 (aproximadamente equivalente a GS 400.15 según AFNOR NF A 32.201 o GGG 40 según DIN 1.693), también llamada fundición nodular, revestidos interior y exteriormente con mínimo garantizado.
El obturador estará fabricado también en fundición dúctil, revestido completamente con caucho sintético o EPDM, y garantizará la estanqueidad de la válvula por compresión del caucho contra el cuerpo de la válvula, que carecerá por completo de asientos de estanqueidad o de guías para el opérculo.
La tornillería de cierre de la tapa con el cuerpo será de acero protegida contra la corrosión mediante un sellado de resina o mastic, o bien carecer de tornillos.
El husillo estará fabricado en acero inoxidable forjado en frío, de un solo bloque desde el obturador hasta el extremo de maniobra y su estanqueidad estará garantizada mediante una o varias juntas tóricas, con lo cual carecerán de prensaestopas o similares.
El cierre será de giro obligatoriamente horario, en la red de distribución.
La hembra, o collarín de empuje, será de bronce o latón extraído, de una sola pieza.
Las válvulas podrán ser:
- Con platinas ISO PN 16, de la serie 14 corta , es decir, de longitud 0,4*DN+150mm, y su unión a los tubos se efectuarán de acuerdo con el art.3.3.2.1, usadas en general para todo tipo de canalizaciones.
- Con extremos provistos de manguitos de polietileno electrosoldable.
Válvulas de retención

## Ejecución

Comprobar sentido de maniobra, materiales y revestimientos de aptitud sanitaria, compatibilidad de bridas y accesibilidad. Instalar sin transmitir esfuerzos de tubería al cuerpo y prever desmontaje y accionamiento. Ensayar maniobra y estanqueidad con el tramo.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 271–290. Transcripción para trazabilidad.

ARQUETAS PARA VALVULERÍA.
Este apartado se refiere a elementos como válvulas de retención, reguladoras de presión o de caudal, ventosas y demás elementos de valvulería con excepción de las válvulas de corte, que se dispondrán enterradas, de preferencias, hasta un diámetro de 300 mm y se dispondrán en arquetas para mariposas de mayores diámetros, del modo que se determina a continuación.
INSTALACIÓN
Se efectuará de forma que sea posible desmontar la válvula sin necesidad de cortar la tubería.
ALOJAMIENTO
Todas las válvulas se ubicarán en una arqueta que será suficiente para permitir, sin necesidad se romperla, el cambio de la válvula existente por otra de iguales características.
En caso de que sea necesario, por estar la tubería demasiado profunda, bajar al interior de la cámara, se dotará a ésta de una entrada, de un diámetro no inferior a 60 cm, y una escalera adosada a la pared, provista de pates metálicos forrados de polipropileno. En la instalación de válvulas mariposa la arqueta tendrá una abertura que permita la extracción del desmultiplicador.
La tapa de la arqueta no sobresaldrá de la rasante de la calle y llevará impreso “Abastecimiento de Agua” o “Agua Potable”. Estarán provistas de taladros para facilitar el levantamiento. Serán de fundición y deberán ser capaces de resistir las cargas móviles reguladas en la norma UNE 82-211-83.
Se prohíben expresamente los pates conformados con acero para la construcción, debiendo ser pates fabricados específicamente como tales, en material inoxidable, de acero forrado de polipropileno o similares.
La cámara que deba construirse en calzada tendrá las siguientes características:
- Solera: de 15 cm de espesor de hormigón de resistencia característica de 100 Kg/cm².
- Muros: De hormigón de resistencia característica de 250 Kg/cm² y 20 cm de espesor, a los que se dispondrá de armadura de reparto según las cuantías mínimas definidas en el CODIGO ESTRUCTURAL.
- Acabado: Enfoscado sin maestrear de paredes con mortero 1:3 de 15 mm de espesor con  acabado bruñido. Ángulos redondeados.
Las paredes de la arqueta no se apoyarán en ningún caso sobre las tuberías, haciéndose pasamuros.
INSTALACIÓN DE TUBERÍA
Se procurará instalar la tubería en viales públicos y bajo la acera de acuerdo con las recomendaciones del fabricante. Antes de su colocación se inspeccionarán los tubos interior y exteriormente para evitar suciedad, adherencias, etc. En el interior y grietas, defectos de protección, etc., en el exterior.
La tubería no se apoyará sobre el fondo de la zanja sino que se colocará una capa de arena fina o gravilla, de unos 10 cm de espesor, para asegurar el perfecto asiento de la tubería se efectuará con los medios mecánicos adecuados.
Una vez en la zanja cada tubo deberá alinearse perfectamente con los ya colocados sin forzar los tubos, excepto en los tubos de polietileno en los que se efectuará un serpenteo dentro de la zanja para prevenir los efectos de la dilatación.
Las uniones en su caso, los cambios de dirección o sección y las derivaciones se realizarán con los correspondientes accesorios o piezas especiales. En los cambios de dirección las alineaciones rectas serán tangentes a las piezas empleadas.
En caso de instalación de tuberías con pendientes superiores al 20% de la tubería se colocará en sentido ascendente o se emplearán juntas resistentes a la tracción.

## Medición y valoración

Medir en ud instalada y probada cuando exista precio independiente, según 3.16.7.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad.

Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
