# Tubería de polietileno PE100 para abastecimiento

**Clasificación:** 15SC. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Conducción de polietileno de alta densidad PE100 para agua, con diámetro y presión definidos en el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 190–203. Transcripción para trazabilidad.

Las tuberías utilizadas para abastecimiento de agua serán de polietileno de alta densidad y fundición.
La red de distribución proyectada es de tubería de Fundición Dúctil de 100 mm de diámetro, marca PAM Saint-Gobain o equivalente, C-40 Biozilanium y PN16 de presión de trabajo.
Las tuberías de polietileno serán conforme a las normas UNE 53966 para polietileno de alta densidad PE 100 y poseerán marca de calidad AENOR.

Todas ellas deberán llevar impresas las siguientes características:
- Marca de fabricante.
- Año de fabricación.
- Diámetro nominal.
- Presión nominal.
- Timbrado.
- Norma de fabricación.
El timbrado de las tuberías a utilizar será el especificado en memoria y planos, o bien el que resulte adecuado a las presiones de trabajo obtenidas en el anejo de cálculo. No obstante lo anterior el timbraje no podrá ser inferior a una presión de 10 Kg/cm².

## Ejecución

Verificar identificación, presión admisible, compatibilidad de tubos y accesorios y aptitud para contacto con agua de consumo. Manipular sin rayados, apoyar uniformemente y ejecutar uniones por procedimiento cualificado según fabricante. Probar con un método que tenga en cuenta el comportamiento viscoelástico del PE, limpiar y desinfectar antes del servicio. Comprobar la serie UNE-EN 12201 y UNE-EN 805 aplicables.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 204–217. Transcripción para trazabilidad.

La unión entre tubos será mediante:
- Accesorios específicos para P.E.
- Uniones universales para tubos rígidos.
- Soldadura a tope por termofusión.
- Manguitos electrosoldables.
La soldadura se considerará inadecuada para acometidas o para ramales de diámetro inferior a 110 mm, para los cuales sólo se admitirán uniones mediante accesorios convencionales en latón estampado, aluminio, fundición dúctil o gris, con las especificaciones contempladas en los apartados correspondientes.
Estas acometidas o ramales de diámetros inferiores se harán exclusivamente en polietileno de baja densidad conforme a las normas UNE53-131 y 53-133.

Las uniones de los tubos de polietileno de alta densidad se podrán hacer como se ha descrito en el apartado anterior, y también mediante soldadura a tope o accesorios retráctiles electrosoldables, según las especificaciones del fabricante, estando, en principio, indicados todos los accesorios adecuados para el P.E. de baja densidad, en los diámetros en que existan comercialmente, a condición de que la conducción se suministre en tubos rígidos y no por rollos.

Se utilizarán para diámetros en los que el polietileno se suministra en tubos rígidos, para facilitar posibles reparaciones con accesorios convencionales.
Por ser el polietileno un material de rápida evolución, los tipos de P.E. de media densidad, banda azul, etc., que no dispongan todavía de homologación AENOR, precisarán de la aprobación expresa del Servicio de Aguas, y, en general, son a evitar.
La realización de los distintos tipos de soldadura por termofusión, sea manguito retráctil electrosoldable, sea soldadura a tope en canalización, se realizará bajo las especificaciones del fabricante, que deberá ser suministrado tanto de la junta como del generador eléctrico correspondiente, y dicho fabricante deberá asegurar la adecuación del tubo a su procedimiento, en caso de ser de otra procedencia.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 249–265. Transcripción para trazabilidad.

EJECUCIÓN DE LAS OBRAS
Las zanjas para la instalación de tuberías tendrán un ancho mínimo de 50 cm superior al diámetro exterior del tubo, y una profundidad suficiente para instalar la tubería de forma que quede una altura mínima entre la generatriz superior del tubo y la superficie de 80 cm.
La profundidad máxima de una zanja será, por el contrario de 1,00 m en aceras y de 1,40 bajo calzadas, salvo acuerdo en contra del Servicio de Aguas.
No obstante, lo determinado en el apartado anterior, en el caso de conducciones bajo cargas pesadas, o enterradas a gran profundidad, será de aplicación obligatoria la metodología de cálculo y dimensionamiento de timbrajes según UNE 88.211 90.
El fondo de la zanja se rasanteará y nivelará, extendiendo posteriormente una capa de arena, de 10 cm como mínimo, incrementándose en función del diámetro de la tubería a instalar.
Una vez montada la tubería se tapará hasta 10cm por encima del tubo con arena, compactado perfectamente los lados del tubo.
El resto de la zanja se rellenará con zahorra o material granular seleccionado procedente de la excavación, escogiendo lo fino y separando las piedras, tierra vegetal o contenido en materia orgánica.
La primera compactación se hará cuando haya como mínimo 50cm de tierra sobre el tubo.
El sobrante de la excavación se retirará y llevará a un vertedero.
Se prestará especial atención a todo lo referente a higiene y seguridad en el trabajo, en lo relativo a la disposición de escalas para el acceso a la zanja, la disposición de pasarelas para el acceso a ambos lados, el respeto de las bermas libres de tierra a ambos lados, el entibamiento cuajado o semicuajado para profundidades mayores de 1.50 m, o cuando las circunstancias del terreno lo aconsejen, el uso de casco y material de seguridad personal y colectiva y las señalizaciones que permitan la correcta regulación del tráfico rodado y peatonal.
ROTURA Y REPOSICIÓN DE FIRMES Y ACERAS
Al proceder a la rotura y reposición de firmes y aceras se respetará los accesos a las casas, instalándose provisionalmente dichos accesos si fuera necesario y limitando al mínimo el entorpecimiento del tránsito.
Los pavimentos que se repongan no desmerecerán de los existentes antes de hacer las obras en calidad y aspecto.
Si se dañara otro servicio se dará inmediatamente a la entidad responsable para proceder a su reparación.
Se observarán las normas establecidas por el Ayuntamiento para la ejecución de las obras que afecten a viales y tránsito.
PASO DE CARRETERAS
En los cruces de carreteras, se cumplirán las normas y condiciones que imponga la Administración competente.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 285–320. Transcripción para trazabilidad.

INSTALACIÓN DE TUBERÍA
Se procurará instalar la tubería en viales públicos y bajo la acera de acuerdo con las recomendaciones del fabricante. Antes de su colocación se inspeccionarán los tubos interior y exteriormente para evitar suciedad, adherencias, etc. En el interior y grietas, defectos de protección, etc., en el exterior.
La tubería no se apoyará sobre el fondo de la zanja sino que se colocará una capa de arena fina o gravilla, de unos 10 cm de espesor, para asegurar el perfecto asiento de la tubería se efectuará con los medios mecánicos adecuados.
Una vez en la zanja cada tubo deberá alinearse perfectamente con los ya colocados sin forzar los tubos, excepto en los tubos de polietileno en los que se efectuará un serpenteo dentro de la zanja para prevenir los efectos de la dilatación.
Las uniones en su caso, los cambios de dirección o sección y las derivaciones se realizarán con los correspondientes accesorios o piezas especiales. En los cambios de dirección las alineaciones rectas serán tangentes a las piezas empleadas.
En caso de instalación de tuberías con pendientes superiores al 20% de la tubería se colocará en sentido ascendente o se emplearán juntas resistentes a la tracción.
Todos los elementos y/o piezas especiales deberán contar con el suficiente macizo de anclaje, a tracción o compresión, efectuado con hormigón de resistencia característica de al menos, 175 Kg/cm² o se emplearán juntas resistentes a la tracción.
Todos los elementos y piezas especiales deberán contar con el suficiente macizo de anclaje, atracción o comprensión, efectuado con hormigón de resistencia característica de al menos, 175 Kg/cm², o se emplearán juntas resistentes a la tracción.
Las tuberías de agua se dispondrán por encima de las tuberías de saneamiento. Las desviaciones máximas admisibles serán de 5º para tubos de 100 a 150mm.
Se deberá realizar una prueba de tubería en tramos con longitud máxima de 100 metros, no autorizándose el tapado de la tubería hasta la aprobación de la prueba.
Las arquetas que se ejecute serán las indicadas en planos y no reposarán sobre los tubos haciéndose arcos de descarga para su paso.
Si se realizaran acometidas a parcelas se dispondrán en la acera arquetas de acometida, dotadas de llave de corte, disponiendo de un pasatubos desde las arquetas hasta la parcela, con objeto de evitar el levantamiento posterior de las aceras.
PRUEBAS A REALIZAR EN LA OBRA
Las obras a incorporar al Servicio, serán recepcionadas por los técnicos municipales competentes o personas por ellos delegadas.
Las instalaciones se someterán a las siguientes clases de prueba:
- Prueba de presión interior.
- Prueba de estanqueidad.
PRUEBAS DE PRESIÓN INTERIOR
A medida que se monten, las tuberías se someterán a la prueba de presión interior por tramos no superiores a 500 m.
La presión de prueba será necesaria para que en el punto más bajo resulte como mínimo 1´4 veces la máxima presión. Entre el punto más bajo y el más alto del tramo a probar no será superior al 10% la presión de prueba.
La tubería llenará por la parte más baja y se abrirá bocas a fin de extraer el aire. Cuando se prueben tuberías de fibrocemento o de hormigón, se recomienda mantenerlas llena desde 24 horas antes de la prueba.
La bomba de prueba se proveerá de dos manómetros, uno de ellos de comprobación, aportado por la Dirección de la Obra o el Servicio.
Una vez la tubería esté llena y libre de aire, se elevará la presión a un ritmo no superior a 100 KPA/mínimo (1 Kg/cm² y min.) hasta alcanzar el valor fijado para la prueba.
Seguidamente se cerrará la tubería durante 30 minutos. La prueba se considerará satisfactoria cuando en este tiempo la presión no baje más de (P/5), siendo P la presión de prueba.
En caso de que el resultado de la prueba sea negativo, se arreglará la avería y se volverá a repetir.
Si durante las pruebas de presión se producen roturas a un 6% de los tubos ensayados, se rechazará el lote de tubos. Si salen más de un 4% de uniones defectuosas, se rechazará todo el lote del que  formen parte.
Una vez el resultado de las pruebas de presión sea satisfactorio, se podrá hacer la prueba de estanqueidad.
PRUEBAS DE ESTANQUEIDAD
Se llenará a tubería teniendo la precaución de extraer todo el aire.
La prueba se efectuará a una presión equivalente a la máxima de trabajo en el punto más desfavorable.
La prueba se realizará cerrando la red a probar y alimentándola mediante un contador.
Se medirá la cantidad de agua necesaria, V, para mantener durante dos horas la presión de prueba. La prueba se considerará satisfactoria si resulta:
V< K x L x D
siendo: L la longitud de la tubería en m; D, diámetro interior en m; V, volumen aportado en litros; K, coeficiente que depende de si la tubería es hormigón armado (K = 0,4), hormigón prensado (K = 0,25), fibrocemento (K = 0,35), fundición (K = 0,3), acero (K = 0,35)o plástico (K =  0,35).
HIDRANTES
Deberán estar normalizados y cumplirán con las prescripciones del Servicio Municipal de Bomberos.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 926–959. Transcripción para trazabilidad.

Cumplirán las especificaciones mínimas establecidas en otros apartados de este proyecto.

En el caso de que fuese admitido por la Dirección Facultativa otro tipo de tubería de la prevista en proyecto, el Contratista presentará una oferta del nuevo diámetro de los tubos y de sus características principales de velocidad, pérdida de carga, timbraje, etc., que serán análogas (siempre del lado de la seguridad) a las que han servido de base en los cálculos.
Se sobreentiende que la autorización para el cambio de tipo de la tubería, no presupone derecho a modificación del precio correspondiente de los Cuadros de precios, que permanecerán inalterables en cualquier caso.

Las tuberías habrán de ser calculadas para soportar las siguientes cargas por:
- Carga de relleno de mil ochocientos (1.800) kg/m3. Como mínimo de acuerdo con el perfil correspondiente.
- En la zona de paso de caminos o carreteras o próximas a ellos, eje de trece (13) toneladas más un cincuenta por ciento (50%) por impactos.

Todos los elementos de la tubería llevarán las marcas distintas siguientes, impresas por cualquier procedimiento que asegure su duración permanente.
- Marca de fábrica
- Diámetro interior en mm.
- Marca de identificación de orden, edad o serie que permita encontrar la fecha de fabricación y modalidades de las pruebas de recepción y entrega.
- Marca de localización que permita identificar la situación de los tubos en el terreno en relación con los planos y datos facilitados por el Contratista.

Con las tuberías y sobre el número de muestras que determine el Director de las Obras, se realizarán los ensayos generales prescritos en el Pliego de Prescripciones Técnicas Generales para Obras de Carreteras y Puentes (PG 3), para el tipo de material que se emplea. Estos ensayos podrán ser ejecutados, si así lo desea el director de las Obras, con un laboratorio oficial y siempre a las expensas del contratista.
Especialmente, en el ensayo de flexión transversal, deberá obtenerse una carga de fisuración superior a los tres mil quinientos (3.500) kilogramos por metro lineal de tubería útil, para todos aquellos tramos (cruces de caminos, etc.), en que a juicio del Director de las obras, sea posible el tráfico material rodante pesado, actual o futuro.

Con carácter general, es de plena aplicación lo preceptuado al respecto en el artículo 8.01., del P.P.T.P.A.P.

En lo referente a excavación y relleno de la misma, es preceptivo lo indicado en el Pliego de Condiciones Generales para Obras de Carreteras y Puentes (PG 3).
El ancho de la zanja viene definido por la sección tipo indicada en los planos, que se considera suficiente para los trabajos de colocación, sin embargo si por cualquier consideración el Contratista modificase esta dimensión por propia conveniencia, no podrá exigir aumento alguno en los volúmenes de excavación y por lo tanto en los precios correspondientes. La profundidad de la zanja viene dada por la cota roja de los perfiles longitudinales del trazado, sin embargo deberá cuidarse, con pequeñas rectificaciones del mismo si fuesen necesarias, que en todo momento el recubrimiento de la tubería sobre la arista superior de la misma, sea de un ( 1 ) metro. Excepcionalmente en algún pequeño tramo podrá aceptarse un recubrimiento de sesenta (60) centímetros, siempre que exista garantía de que no haya circulación rodada superior. En caso contrario deberá disponerse una losa de reparto de hormigón armado, que será sometida a la aprobación del Director de las Obras.
Como norma general los tubos se bajarán al fondo de la zanja con los elementos adecuados, según el peso y la longitud del tubo y la posible entibación de la zanja. Se centrarán debidamente con los adyacentes, y a continuación se procederá a fijarlos.
Las tuberías y zanjas se mantendrán libres de agua mediante los correspondientes desagües en la excavación y si fuera preciso se agotará el agua con bomba.
Cuando las pendientes de las zanjas sean superiores al diez por ciento (10%), la tubería se colocará en sentido ascendente. Si a juicio del Director de las Obras, no es posible colocarla en sentido ascendente, se tomarán las precauciones debidas para evitar el deslizamiento de los tubos. Si se precisa reajustar algún tubo, deberá levantarse el relleno y prepararlo como para su primera colocación.
Cuando se interrumpa la colocación de la tubería se taponarán los extremos libres, para impedir la entrada de agua o cuerpos extraños, y al reanudar el trabajo se examinará con todo cuidado el interior de la tubería, por si pudiera haberse introducido algún cuerpo extraño en la misma.

Los cambios de alineación o rasante de gran radio, deberán realizarse con tubos rectos o de acuerdo con lo indicado en los planos del proyecto.

Se colocarán bloques de empuje en todos los codos o cambios de dirección bruscos de la tubería, aún cuando éstos no estuviesen específicamente señalados en los planos. Las dimensiones y peso serán las adecuadas en función de la velocidad y altura de presión de cada tramo de tubería.
Estos bloques de empuje, deberán construirse una vez montados los tubos y las piezas especiales, fundiendo el hormigón entre las zanjas y la parte lateral e inferior de los mismos.
En ningún caso, el hormigón deberá interferir en las juntas de las piezas, perturbando su posible reparación.

## Medición y valoración

Medir en m de tubería instalada, conectada y probada, con los conceptos incluidos en 3.16.7, sin duplicar uniones ni pruebas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad.

Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1157–1159. Transcripción para trazabilidad.

La tubería se medirá por metro lineal (ml) de tubería realmente colocada en obra, según los distintos diámetros y timbrajes.
El abono se efectuará aplicando a estas mediciones los precios que se indican en el presupuesto, los cuales se refieren a tubería colocada, y acabada, después de haber sido sometida satisfactoriamente a las pruebas que se indican en este pliego.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
