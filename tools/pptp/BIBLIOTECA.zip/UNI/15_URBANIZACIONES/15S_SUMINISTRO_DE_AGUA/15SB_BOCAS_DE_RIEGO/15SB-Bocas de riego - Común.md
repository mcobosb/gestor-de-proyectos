# Bocas de riego - Común

**Clasificación:** 15SB. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Puntos de conexión para riego citados entre los accesorios independientes de la red.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 323–327. Transcripción para trazabilidad.

Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego

## Ejecución

Aprobar diámetro, presión y sistema de conexión, instalar con válvula y alojamiento accesible y proteger frente al retorno de agua no potable según el riesgo y las condiciones sanitarias de la red. Comprobar funcionamiento y estanqueidad.

## Medición y valoración

Por ud instalada y probada según 3.16.7 y el cuadro de precios, con el alcance del alojamiento y accesorios que éste determine.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad.

Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
