# Arquetas de alumbrado - Común

**Clasificación:** 15EE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Registros para facilitar tendido, derivaciones autorizadas y mantenimiento del cableado de alumbrado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 359–361. Transcripción para trazabilidad.

Las redes se instalarán discurriendo en todo su trazado por terrenos de acceso públicos, como viales no accesibles al tráfico rodado, lo harán a una profundidad mínima de 0,4 metros medidos desde la generatriz superior del tubo hasta solería o revestimiento terminado, se colocara una cinta señalizadora que advierta de la existencia de cable de alumbrado exterior, situada a una distancia mínima del nivel del suelo de 0,10 m y a 0,25 m por encima del tubo, y aumentándose la profundidad a 0.6 metros y reforzándose con prisma de hormigón en masa de 200 Kg./cm² de 15 cm de espesor en los cruces de los viales o zonas aptas para el tráfico rodado. Se instalará una canalización vacía de las mismas características antes mencionadas para posibles ampliaciones de la instalación, indicada en los planos como Las arquetas serán de 0,40 x 0,40 x 0,50 m, para derivaciones y cambios de dirección, y de 0,60 x 0,60 x 0,50 m en cruces de calzada.
Se dispondrán de arquetas o registros en número suficiente para la colocación y reposición de los conductores.
Las tapaderas serán de fundición, en el fondo de todas las arquetas se colocará un lecho absorbente.

## Ejecución

Construir con dimensiones aprobadas, entradas de conductos sin aristas y drenaje compatible con el terreno y el servicio. Colocar tapa resistente a las cargas y a rasante; los empalmes autorizados deberán garantizar continuidad, aislamiento y estanqueidad conforme al REBT.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 362–363. Transcripción para trazabilidad.

EJECUCIÓN DE OBRA
Las instalaciones y puesta en obra de los tubos protectores deberán cumplir según ITBT 21 y en su defecto lo prescrito en la norma UNE 20460 5 523 y en la ITC BT 19 y ITC BT 20.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1018–1022. Transcripción para trazabilidad.

Las arquetas se construirán con el tipo de hormigón indicado en los planos, tanto para la solera como para alzados y cuando así se indique en los planos se construirán de fábrica de ladrillo macizo, enfoscadas interiormente.
Cuando sean de hormigón, el espesor de las soleras y los alzados será al menos de veinte (20) centímetros.
En caso de construirse de fábrica de ladrillo no será inferior a diez (10) centímetros.
En general, se tendrán en cuenta las especificaciones según la Norma Tecnológica de la Edificación NTE/ISS, y siguiendo las especificaciones de los planos.

## Medición y valoración

Por ud realmente terminada con excavación, cuerpo, cerco y tapa conforme a 3.17.4, comprobando que no estén ya incluidos en otra unidad.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 364–367. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
La canalización se medirá por m.l. realmente ejecutado. El precio comprende la excavación de la zanja en cualquier tipo de terreno, reposición de acera o calzada si procede el caso, arena en lecho y protección de los tubos necesarios, la cinta de señalización, el relleno y compactación de la zanja al 95% del Proctor modificado, el alambre guía incluso la protección en cruces si en el proyecto no se especifica dicha protección.
Se medirán por uds completamente terminadas realmente ejecutado.
El precio incluye la excavación necesaria, la arqueta, cerco y tapa según indicación de la D.T.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
