# Canalizaciones subterráneas de alumbrado

**Clasificación:** 15EE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Conductos enterrados para los cables del alumbrado, con protección y reservas previstas en el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 356–361. Transcripción para trazabilidad.

DESCRIPCIÓN
Se realizarán las canalizaciones subterráneas mediante tuberías de polietileno corrugado de 110 m. Ø, Según norma UNE EN 50086 2 4 y sus características mínimas serán, para las instalaciones ordinarias las indicadas en la tabla 8 del R.B.T.
Las redes se instalarán discurriendo en todo su trazado por terrenos de acceso públicos, como viales no accesibles al tráfico rodado, lo harán a una profundidad mínima de 0,4 metros medidos desde la generatriz superior del tubo hasta solería o revestimiento terminado, se colocara una cinta señalizadora que advierta de la existencia de cable de alumbrado exterior, situada a una distancia mínima del nivel del suelo de 0,10 m y a 0,25 m por encima del tubo, y aumentándose la profundidad a 0.6 metros y reforzándose con prisma de hormigón en masa de 200 Kg./cm² de 15 cm de espesor en los cruces de los viales o zonas aptas para el tráfico rodado. Se instalará una canalización vacía de las mismas características antes mencionadas para posibles ampliaciones de la instalación, indicada en los planos como Las arquetas serán de 0,40 x 0,40 x 0,50 m, para derivaciones y cambios de dirección, y de 0,60 x 0,60 x 0,50 m en cruces de calzada.
Se dispondrán de arquetas o registros en número suficiente para la colocación y reposición de los conductores.
Las tapaderas serán de fundición, en el fondo de todas las arquetas se colocará un lecho absorbente.

## Ejecución

Aplicar ITC-BT-09 y 21: comprobar trazado y dimensiones, preparar el asiento, disponer los tubos sin aplastamientos, colocar señalización y proteger los cruces. ITC-BT-09 establece diámetro interior mínimo de 60 mm, profundidad mínima de 0,40 m medida desde la cota inferior del tubo y, en cruces de calzada, hormigonado y tubo de reserva. El original exige 0,40 m desde la generatriz superior y 0,60 m en cruces: conservar estas condiciones particulares salvo modificación aprobada y no confundir sus referencias geométricas con la del reglamento. Comprobar también la adecuación del diámetro a los cables y realizar prueba de paso antes del tendido.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 362–363. Transcripción para trazabilidad.

EJECUCIÓN DE OBRA
Las instalaciones y puesta en obra de los tubos protectores deberán cumplir según ITBT 21 y en su defecto lo prescrito en la norma UNE 20460 5 523 y en la ITC BT 19 y ITC BT 20.

## Medición y valoración

Medir en m terminados con excavación, rellenos, protección y reposiciones incluidas según 3.17.4. Las arquetas se miden por ud cuando tengan partida propia.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 364–367. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
La canalización se medirá por m.l. realmente ejecutado. El precio comprende la excavación de la zanja en cualquier tipo de terreno, reposición de acera o calzada si procede el caso, arena en lecho y protección de los tubos necesarios, la cinta de señalización, el relleno y compactación de la zanja al 95% del Proctor modificado, el alambre guía incluso la protección en cruces si en el proyecto no se especifica dicha protección.
Se medirán por uds completamente terminadas realmente ejecutado.
El precio incluye la excavación necesaria, la arqueta, cerco y tapa según indicación de la D.T.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
