# Soportes, báculos y columnas de alumbrado

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Elementos resistentes de sustentación de luminarias con sus cimentaciones, anclajes y accesos de mantenimiento.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 382–385. Transcripción para trazabilidad.

DESCRIPCIÓN
Los soportes de las luminarias de alumbrado exterior, se ajustarán a la normativa vigente (en el caso de que sea de acero deberán cumplir el RD 2642/85, RD 401/89 y OM de 16/5/89). Los soportes, sus anclajes y cimentaciones, se dimensionarán de forma que resistan las solicitaciones mecánicas, particularmente teniendo en cuenta la acción del viento, con un coeficiente de seguridad no inferior a 2,5, considerando las luminarias completas instaladas en el soporte.
Los soportes que lo requieran, deberán poseer una abertura de dimensiones adecuadas al equipo eléctrico para acceder a los elementos de protección y maniobra; la parte inferior de dicha abertura estará situada, como mínimo, a 0,30 m de la rasante y estará dotada de puerta o trampilla con grado de protección IP44 según UNE 20324 (EN 60529) e IK 10 según UNE EN 50102. La puerta solamente se podrá abrir mediante el empleo de útiles especiales y dispondrán de un borne a tierra cuando sea metálico.

## Ejecución

Verificar cálculo frente al viento con las luminarias instaladas, documentación de producto y protección anticorrosiva. Ejecutar cimentación y pernos con geometría aprobada, respetar la resistencia antes del izado, aplomar y apretar conforme a fabricante. Disponer acceso protegido y conexión de las partes metálicas a la red de tierra según ITC-BT-09.

## Medición y valoración

Por ud completamente instalada, incluida excavación y cimentación según 3.17.6 y las características de su partida.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 386–387. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
Se medirán por Uds. Completamente terminadas realmente ejecutado, incluido cimentación y excavación necesaria según indicaciones de la D.T.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1170–1171. Transcripción para trazabilidad.

Se medirán por unidades de iguales características realmente colocadas.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
