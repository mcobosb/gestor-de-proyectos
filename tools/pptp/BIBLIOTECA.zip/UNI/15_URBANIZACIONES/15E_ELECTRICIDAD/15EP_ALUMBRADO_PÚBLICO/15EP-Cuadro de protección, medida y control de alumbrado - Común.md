# Cuadro de protección, medida y control de alumbrado - Común

**Clasificación:** 15EP  
**Capítulo:** Instalaciones de alumbrado exterior  
**Familia:** Cuadros y centros de mando  

## Descripción
Suministro, montaje, conexiado y puesta en servicio del conjunto del armario/cuadro general de mando, protección, medida y control para los circuitos de la red de alumbrado público exterior, conforme al REBT (ITC-BT-09 e ITC-BT-08).

## Ejecución
1. **Previos y envolvente:** Instalación del armario sobre peana de hormigón en ubicación autorizada. Comprobar que la envolvente garantice un grado de protección mínimo IP55 (UNE 20324) e IK10 (UNE-EN 50102), con cierre de seguridad de acceso exclusivo para personal autorizado y puerta a altura útil entre 1,30 m y 2,00 m. Módulo de medida segregado e independiente de los equipos de protección y control.
2. **Montaje y conexionado:** Conectar firmemente las masas del cuadro a la red de tierra de la instalación. Instalación y cableado del interruptor general automático (IGA), interruptores diferenciales con reenganche automático, magnetotérmicos de protección por circuito, contactores, reloj astronómico / fotocélula de mando y equipo de medida conforme al esquema unifilar de proyecto.
3. **Control y ensayos:** Verificación del correcto tarado y coordinación de protecciones frente a sobreintensidades y contactos indirectos. Comprobación del accionamiento manual y automático de los circuitos, medición de la resistencia de tierra y emisión de los protocolos de verificación previos a la puesta en servicio.

## Medición
* **Unidad de medida:** Unidad (ud) de cuadro de protección, medida y control completamente instalado, cableado, probado y en funcionamiento.
* **Criterio:** Número de unidades efectivamente montadas e inspeccionadas in situ con aprobación de la Dirección Facultativa.

## Valoración
El precio unitario (€/ud) incluye:
* Suministro, transporte y colocación de la envolvente (armoire/armario) con sus accesorios de fijación y peana de apoyo.
* Suministro y montaje de toda la aparamenta de corte, protección (IGA, diferenciales, magnetotérmicos), mando (reloj astronómico, contactores), medida y borneros.
* Cableado interno, etiquetado, embornado de líneas de entrada/salida y conexión a la red de tierra.
* Medios auxiliares, herramientas, ensayos de continuidad, aislamiento, salto de diferencial y comprobaciones de funcionamiento.