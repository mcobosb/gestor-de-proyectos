# Luminarias, lámparas y proyectores

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Equipos de iluminación exterior completos, con su fuente luminosa y auxiliares.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 388–393. Transcripción para trazabilidad.

DESCRIPCIÓN
Las luminarias utilizadas en el alumbrado exterior serán conforma a la mona UNE EN 60598 2 3 y la UNE EN 60598 2 5 en el caso de proyectores exteriores.
La conexión se realizará mediante cables flexibles, que penetren en la luminaria con la holgura suficiente para evitar que las oscilaciones de ésta provoquen esfuerzos perjudiciales en los cables y en los terminales de conexión, utilizándose dispositivos que no disminuyan el grado de protección de luminaria IPX3 según UNE 20324.
La suspensión de las luminarias se hará mediante cable de acero protegido contra la corrosión, de sección suficiente para que, posea una resistencia mecánica con coeficiente de seguridad no inferior a 3,5.
La altura mínima sobre el nivel del suelo será de 6m.

## Ejecución

Seleccionar equipos conforme al estudio luminotécnico y al REBT, con protección ambiental y mecánica adecuada al lugar. Montar y orientar según cálculo sin alterar los grados de protección y sin esfuerzos en los cables. Verificar encendido, regulación, consumo y prestaciones luminotécnicas conforme al RD 1890/2008 cuando sea aplicable.

## Medición y valoración

Por ud instalada y comprobada, con lámpara o fuente luminosa y cableado de conexión incluidos según 3.17.7.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 394–395. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
Se medirán por Uds. Completamente terminadas realmente ejecutado, incluido lámpara y cableado de conexión, según indicaciones de la D.T.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1170–1171. Transcripción para trazabilidad.

Se medirán por unidades de iguales características realmente colocadas.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
