# Conductores eléctricos de alumbrado

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Cables de alimentación y conexión interior de los puntos de luz del alumbrado exterior.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 368–377. Transcripción para trazabilidad.

DESCRIPCIÓN
Para la alimentación eléctrica de las luminarias, se utilizarán conductores que serán del tipo plastigrón UNE RV 0.6/1 kv con una sección mínima, cuando discurran enterrados de 6 mm² para una tensión de prueba de 4000 voltios y con aislamiento de Polietileno reticulado, con cobre como material conductor y deberán cumplir los requisitos especificados en la parte correspondiente de la norma UNE HD 603.
El conductor neutro de cada circuito que parte de cuadro, no podrá ser utilizado por ningún otro circuito.
Las derivaciones y empalmes que se hayan de realizar, siempre se efectuarán en las arquetas o armarios de que dispongan las luminarias, y en ningún caso, podrán quedar estos en el interior de los tubos.
Estas derivaciones se efectuarán siempre aplicando elementos en los que se garantice una perfecta continuidad del conductor y el aislamiento, así como, su estanqueidad y resistencia a la corrosión, para lo que se utilizará cintas vulcanizables y del tipo normal.
Los empalmes y derivaciones deberán realizarse en caja de bornas adecuadas, situadas dentro de los soportes de las luminarias, y a una altura mímica de 0,3 m. sobre el nivel del suelo en una arqueta registrable, que garanticen, en ambos casos, la continuidad, el aislamiento y la estanqueidad del conductor.
Las secciones de estos conductores será la adecuada a las intensidades, según la Tabla II, Columna 007, afectada por el coeficiente 0,8 por tratarse de conductores canalizados bajo tubo y caída de tensión prevista, para sección del neutro será conforme a lo indicado en la tabla 1 de la ITC BT 07.
La caída de tensión máxima permitida entre el origen y el final de cada circuito será del 3% de la nominal.
Las conexiones de las luminarias a las redes generales de alumbrado se realizarán utilizándose conductores RV0.6/1kv de 2x6mm² en cobre, ascendiendo a través del tubo de los báculos o columnas hasta las luminarias con conductor del mismo tipo de 2x2,5 mm², reforzándose mediante tubo de plástico o cualquier otro sistema adecuado en los puntos donde el conductor pueda dañarse.

## Ejecución

Dimensionar sección, caída de tensión y protecciones conforme a ITC-BT-09 y al cálculo. Para redes subterráneas de alimentación, utilizar cables de cobre de tensión asignada 0,6/1 kV y sección mínima de 6 mm², incluido neutro, sin confundirlos con el cableado interior de soportes. Tender sin dañar cubierta ni exceder esfuerzos y radios del fabricante. Identificar y comprobar continuidad y aislamiento.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 378–379. Transcripción para trazabilidad.

EJECUCIÓN DE OBRA
El conductor se introducirá dentro del tubo de protección mediante un cable guía cuidando que no sufra torsiones ni daños de cobertura. Se exigirá protocolo de ensayo por cada bobina. El instalador cuidará que no se produzca daños ni torsiones en su cubierta al sacarlo de la bobina.

## Medición y valoración

Medir en m de cable colocado y conectado con el criterio de la partida; diferenciar metro de cable multipolar y metro de conductor unipolar para evitar multiplicaciones indebidas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 380–381. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
Se medirán por ml. Completamente terminadas realmente ejecutado.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
