# Luminarias, lámparas y proyectores - Común

**Clasificación:** 15EP  
**Capítulo:** Instalaciones de alumbrado exterior  
**Familia:** Equipos de iluminación y proyectores  

## Descripción
Suministro, montaje, orientación y puesta en servicio de luminarias de alumbrado público y proyectores exteriores, incluyendo la fuente luminosa (módulos LED o lámparas), equipos de alimentación/control (drivers/reactancias) y elementos de conexión, conforme al REBT (ITC-BT-09) y a la eficiencia energética en alumbrado exterior (RD 1890/2008).

## Ejecución
1. **Previos:** Verificar certificados de calidad, cumplimiento de las normas UNE-EN 60598-2-3 (luminarias) o UNE-EN 60598-2-5 (proyectores), marcado CE, flujo hemisférico superior instalado (FHS inst) y grados de protección (IP/IK) de proyecto.
2. **Montaje y fijación:** Fijación mecánica de la luminaria sobre brazo, columna, báculo o suspensión de cable de acero (coeficiente de seguridad ≥ 3,5). Altura mínima sobre rasante de 6,00 m. Conexión eléctrica mediante cable flexible sin tracciones mecánicas ni oscilaciones que dañen los terminales, garantizando la estanqueidad en la entrada del cable (mínimo IPX3 según UNE 20324).
3. **Orientación y control:** Orientación y reglaje angular según los diagramas fotométricos del estudio luminotécnico. Comprobación del encendido, niveles de iluminación (luxes y uniformidad), regulación de flujo nocturno, consumo y correcto funcionamiento global.

## Medición
* **Unidad de medida:** Unidad (ud) de luminaria o proyector completamente instalado, conexionado, orientado y probado.
* **Criterio:** Número de unidades efectivamente montadas e inspeccionadas in situ con aprobación de la Dirección Facultativa.

## Valoración
El precio unitario (€/ud) incluye:
* Suministro, transporte, almacenamiento y elevación de luminarias, proyectores, drivers, módulos LED/lámparas y equipos auxiliares.
* Fijación mecánica a soporte, herrajes, brazos o sistemas de suspensión de cable.
* Cable flexible interior de conexión, pequeño material de conexionado y estanqueidad.
* Mano de obra, camión cesta o medios mecánicos de elevación, herramientas y medios auxiliares.
* Orientación fotométrica, comprobación de niveles lumínicos y ensayos de funcionamiento.