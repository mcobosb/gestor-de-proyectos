# Conductores eléctricos de alumbrado - Común

**Clasificación:** 15EP  
**Capítulo:** Instalaciones de alumbrado exterior  
**Familia:** Cableado y conexiones  

## Descripción
Suministro, tendido, conexionado y prueba de cables y conductores eléctricos de cobre (tensión asignada 0,6/1 kV, tipo RV/RV-K con aislamiento de polietileno reticulado) para la red subterránea de distribución de alumbrado público y la derivación interior de báculos o columnas hasta la luminaria, conforme al REBT (ITC-BT-09 e ITC-BT-07).

## Ejecución
1. **Previos:** Comprobar la continuidad y la limpieza de los tubos de protección enterrados. Verificar certificados de garantía, marcado CE y protocolo de ensayo de las bobinas de cable.
2. **Tendido y conexionado:** Extracción del cable mediante guiado cuidadoso para evitar torsiones, pellizcos o tracciones excesivas que dañen la cubierta. Alimentación subterránea en sección mínima de 6 mm² (con neutro independiente por circuito y caída de tensión máxima del 3%). Derivación ascendente interior por columna/báculo en cable 2x2,5 mm² protegido frente a rozaduras. Realización de empalmes y conexiones exclusivamente en cajas de bornas de arquetas o puertas de báculos (mínimo a 0,30 m sobre el nivel del suelo) mediante elementos estancos, vulcanizados y resistentes a la corrosión.
3. **Control y ensayos:** Verificación del etiquetado/código de colores, pruebas de continuidad y ensayos de resistencia de aislamiento previo y posterior al tapado de arquetas.

## Medición
* **Unidad de medida:** Metro lineal (m) de cable colocado, conexionado y probado (especificando si se mide metro de cable multipolar o metro de conductor unipolar según la definición de la partida).
* **Criterio:** Longitud neta realmente ejecutada e inspeccionada in situ entre puntos de conexión, descontando el sobrante no utilizado.

## Valoración
El precio unitario (€/m) incluye:
* Suministro, transporte, almacenamiento y tendido del conductor o cable multipolar.
* Guías, lubricantes de tracción, pequeño material de conexionado, terminales, cajas de bornas y cintas vulcanizables/aislantes.
* Mano de obra, herramientas y medios auxiliares de embobinado, guiado y conexiado.
* Pruebas de continuidad, ensayos de aislamiento y verificación eléctrica de la línea.