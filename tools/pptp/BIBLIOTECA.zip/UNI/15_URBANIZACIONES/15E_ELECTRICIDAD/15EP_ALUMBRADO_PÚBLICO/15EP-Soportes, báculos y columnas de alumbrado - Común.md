# Soportes, báculos y columnas de alumbrado - Común

**Clasificación:** 15EP  
**Capítulo:** Instalaciones de alumbrado exterior  
**Familia:** Soportes y cimentaciones  

## Descripción
Suministro, izado, aplomado y fijación de soportes metálicos o de fibra (columnas, báculos o candelabros) para la sustentación de luminarias de alumbrado exterior, incluyendo sus cimentaciones de hormigón, pernos de anclaje, periquito de acceso, caja de bornas y conexión a tierra (conforme al REBT ITC-BT-09).

## Ejecución
1. **Cimentación y anclajes:** Excavación de la zanja/pozo de cimentación, colocación del marco con pernos de anclaje, tubos de canalización de entrada/salida de cables y vertido/compactación del hormigón según dimensiones de proyecto, respetando los tiempos de curado antes de someterlo a cargas.
2. **Izado y aplomado:** Verificación del cumplimiento normativo del soporte (solicitaciones mecánicas y resistencia al viento con coeficiente de seguridad ≥ 2,5). Izado del soporte, alineación, aplomado mediante doble tuerca/arandela y apriete al par especificado por el fabricante.
3. **Registro y puesta a tierra:** Trampilla/puerta de registro con grado de protección IP44 e IK10, a una altura mínima de 0,30 m sobre la rasante y apertura con llave especial. Montaje de la placa/caja de conexiones con fusibles y conexión del borne de tierra del soporte metálico a la red general de tierra.

## Medición
* **Unidad de medida:** Unidad (ud) de columna o báculo completamente terminado e instalado.
* **Criterio:** Número de unidades efectivamente colocadas, aplomadas y aceptadas por la Dirección Facultativa.

## Valoración
El precio unitario (€/ud) incluye:
* Excavación, encofrado, vertido de hormigón y relleno perimetral para la cimentación.
* Suministro, transporte, almacenamiento e izado de báculos/columnas, brazos, pernos y platinas de anclaje.
* Puerta de registro con cerradura de seguridad, placa de montaje interior, caja de conexiones, fusibles y toma de tierra.
* Mano de obra, grúa/camión pluma, herramientas, medios auxiliares y comprobaciones de estabilidad y aplomado.