# Cuadro de protección, medida y control de alumbrado

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Conjunto de mando, seccionamiento y protección de los circuitos de alumbrado exterior.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 350–353. Transcripción para trazabilidad.

DESCRIPCIÓN
Los cuadros, además de la correspondiente caja de I.C.P., contendrán los elementos reflejados en la medición, la envolvente del cuadro, proporcionará un grado de protección mínima IP55 según UNE 20324 e IK10 según UNE EN50102 y dispondrá de un sistema de cierre que permita el acceso exclusivo al mismo, del personal autorizado, con su puerta de acceso situada a una altura comprendida entre 2 y 1,3 m. Los elementos de medida estarán situados en un módulo independiente.
Las partes metálicas del cuadro irán conectada a tierra.

## Ejecución

Aplicar ITC-BT-09: montar envolvente con protección al menos IP55 e IK10, acceso reservado y elementos de medida segregados; conectar las masas a tierra. Seleccionar y coordinar protecciones frente a sobreintensidad y contactos indirectos y comprobar accionamiento automático y manual. Verificar instalación y documentación antes de la puesta en servicio.

## Medición y valoración

Medir por ud completamente instalada y comprobada, con los equipos y conexiones de su partida.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 354–355. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
El cuadro de protección se medirá como Uds. De obra completamente terminada, realmente ejecutada.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
