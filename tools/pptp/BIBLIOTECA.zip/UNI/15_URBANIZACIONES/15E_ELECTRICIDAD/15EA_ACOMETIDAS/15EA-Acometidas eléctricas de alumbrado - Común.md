# Acometidas eléctricas de alumbrado - Común

**Clasificación:** 15EA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Enlace desde la red de distribución hasta los equipos de medida del alumbrado público.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 332–337. Transcripción para trazabilidad.

DESCRIPCIÓN
La acometida podrá ser subterránea o aérea, según proceda, con cables aislados, y se realizará de acuerdo con las prescripciones particulares de la compañía suministradora.
La acometida enterrada irá a una profundidad mínima de 0,6 mts y se ejecutará según la ITC BT 07, el tubo empleado será de polietileno corrugado de doble pared y diámetro del tubo será según la tabla 9 de la ITC BT 21, normalmente de 90 mm de diámetro.
Los conductores serán del tipo RV 0.6/1kv en aluminio y enlazará desde la red de baja tensión arqueta próxima al C.T. o desde el cuadro de baja tensión del transformador, según aconseje la compañía, hasta los equipos de medida, donde se conectarán a través de los elementos bimetálicos adecuados que garanticen las conexiones y eviten la aparición de corrientes galvánicas y la restauración de los aislamientos mediante las cintas normal y vulcanizable.

## Ejecución

Coordinar trazado y conexión con la distribuidora, ejecutar por empresa instaladora habilitada y aplicar ITC-BT-11 y las ITC-BT-06 o 07 según sea aérea o subterránea. Verificar sección, protección mecánica y terminales compatibles con aluminio y cobre. Realizar conexión sin tensión y comprobaciones reglamentarias.

## Medición y valoración

El original separa m de canalización y m de conductor con conexionado, incluyendo en la canalización las operaciones auxiliares descritas. Ajustar la medición al presupuesto y no duplicar zanjas ni reposiciones.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 338–340. Transcripción para trazabilidad.

MEDICIÓN Y ABONO
La canalización se medirá por m.l. realmente ejecutado. El precio comprende la excavación de la zanja en cualquier tipo de terreno, reposición de acera o calzada si procede el caso, arena en lecho y protección de los tubos necesarios, la cinta de señalización, el relleno y compactación de la zanja al 95 % del Proctor modificado, el alambre guía incluso la protección en cruces si en el proyecto no se especifica dicha protección.
Los conductores se medirán por ml. Completamente terminados realmente ejecutado, incluso conexionado.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
