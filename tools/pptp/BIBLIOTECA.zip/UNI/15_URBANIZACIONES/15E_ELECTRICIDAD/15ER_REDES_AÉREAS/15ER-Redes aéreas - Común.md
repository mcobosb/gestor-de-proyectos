# Redes aéreas - Común

**Clasificación:** 15ER. **Capítulo:** urbanizaciones. **Familia:** electricidad.

## Descripción

Elementos de urbanización y redes exteriores definidos por los planos, el presupuesto y las condiciones del titular del espacio o servicio.

El objeto de esta ficha es «redes aéreas», dentro de «electricidad». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Coordinar replanteo y servicios existentes, mantener itinerarios seguros y ejecutar por fases compatibles con el tráfico y otras redes. Revisar apoyos, cotas y encuentros antes de ocultar elementos y reponer las superficies afectadas.

Coordinar con el titular eléctrico; comprobar canalizaciones, puesta a tierra y protecciones antes de la puesta en servicio. Comprobar apoyos, flechas, gálibos y distancias de seguridad conforme a la tensión y al reglamento específico.

Para la variante «redes aéreas» se comprobarán expresamente tensión, potencia, titularidad y reglamentación eléctrica correspondiente; tensión, vano, conductor y cargas de viento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar geometría, funcionalidad, accesibilidad y recepción por el titular; documentar trazados y elementos ocultos mediante planos finales.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Medir con la base propia del elemento: m de red o bordillo, m² de pavimento, m³ de tierras u hormigón y ud de equipo o registro. Delimitar excavaciones, reposiciones y pruebas incluidas para evitar duplicidades.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
