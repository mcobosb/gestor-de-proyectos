# Pozos de registro de saneamiento - Común

**Clasificación:** 15AP  
**Capítulo:** Redes de evacuación y drenaje  
**Familia:** Registros y singularidades  

## Descripción
Ejecución de pozos de registro para la inspección, ventilación, conexión y mantenimiento de la red de saneamiento, construidos in situ (hormigón o fábrica de ladrillo macizo) o mediante anillos prefabricados de hormigón armado, incluyendo la formación de caz, el fuste, la cono de reducción o losa de coronación, el enfocado interior, los pates de acceso y la instalación del cerco y tapa de fundición.

## Ejecución
1. **Previos:** Comprobar la cota de la solera de excavación y la alineación de llegada/salida de los colectores. Disponer la solera base de hormigón (mínimo HM-20/HA-25 y espesor según proyecto, con un mínimo de 20 cm).
2. **Construcción y fuste:** 
   - *In situ:* Levantado de pared de ladrillo macizo (mínimo 10 cm enfoscado interiormente con mortero de cemento) o paredes de hormigón in situ (mínimo 20 cm).
   - *Prefabricado:* Montaje de modulación de hormigón (HA-25) ensamblada con juntas elásticas de estanqueidad (UNE-EN 1917 / UNE 127011).
   - Formar el caz de circulación continua en el fondo para evitar la acumulación de sedimentos.
   - Colocar pates de acero revestido de polipropileno para profundidades superiores a 1,20 m, respetando las alineaciones de bajada.
3. **Coronación y remate:** Instalar el cono de reducción o losa superior de hormigón, recibir el cerco y colocar la tapa de fundición enrasada con la rasante definitiva del terreno o pavimento. Realizar pruebas de estanqueidad y verificar las medidas de seguridad y accesibilidad.

## Medición
* **Unidad de medida:** Metro lineal (m) de pozo realmente ejecutado, medido desde la cota de la solera base hasta la cota superior de la tapa de coronación (o por Unidad, ud, completamente terminada si así está especificado en el cuadro de precios).
* **Criterio:** Altura o cantidad neta comprobada e inspeccionada in situ.

## Valoración
El precio unitario (€/m o €/ud) incluye:
* Excavación complementaria, encofrados, hormigones de solera y fuste o suministro y ensamblado de módulos prefabricados.
* Formación de caz de fondo, enfoscado/bruñido interior y sellado estanco en conexiones de tuberías.
* Suministro e instalación de pates de acceso.
* Suministro, recibido y ajuste del cerco y tapa de fundición (incluidas marcas o personalización solicitadas).
* Pruebas hidráulicas de estanqueidad, medios auxiliares y limpieza interior del pozo.