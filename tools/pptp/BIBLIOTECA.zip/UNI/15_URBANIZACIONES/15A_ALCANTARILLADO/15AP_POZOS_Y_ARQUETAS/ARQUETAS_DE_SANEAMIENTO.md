# Arquetas de saneamiento

**Clasificación:** 15AP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Registros de la red de saneamiento para conexiones, cambios y mantenimiento, construidos de fábrica u hormigón según planos.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 151–153. Transcripción para trazabilidad.

Se definen como las obras que completan el sistema de drenaje, ejecutadas en obra de fábrica donde ingieren otros colectores, acometidas, etc.

## Ejecución

Ejecutar fondo y paredes sobre apoyo estable, conectar las conducciones sin cargas puntuales, formar las pendientes de circulación y enfoscar cuando corresponda. Instalar marco y tapa a rasante, comprobar estanqueidad y accesibilidad y utilizar la clase de tapa adecuada al lugar de instalación.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 154–160. Transcripción para trazabilidad.

Para su ejecución se utilizará hormigón HM 20 y ladrillo macizo.
En caso de ejecutarse con elementos prefabricados se utilizarán hormigones mínimos de HA 25.
El fondo de los pozos de registro se ejecutará con hormigón, formando un caz para la circulación de agua, y evitar el depósito de suciedad.
Se enfoscarán interiormente con mortero de cemento.
Se colocarán pates de acero forrados con polipropileno en pozos con altura superior a 1.20 m de altura.
Los pozos prefabricados en hormigón tendrán junta de goma y cumplirán con la normativa UNE 127011.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1018–1022. Transcripción para trazabilidad.

Las arquetas se construirán con el tipo de hormigón indicado en los planos, tanto para la solera como para alzados y cuando así se indique en los planos se construirán de fábrica de ladrillo macizo, enfoscadas interiormente.
Cuando sean de hormigón, el espesor de las soleras y los alzados será al menos de veinte (20) centímetros.
En caso de construirse de fábrica de ladrillo no será inferior a diez (10) centímetros.
En general, se tendrán en cuenta las especificaciones según la Norma Tecnológica de la Edificación NTE/ISS, y siguiendo las especificaciones de los planos.

## Medición y valoración

El apartado 3.12 sólo concreta el abono de pozos. Para arquetas, proponer ud completamente terminada conforme a su partida y dimensiones, sujeta a aprobación; comprobar si marco y tapa se incluyen y no medirlos dos veces.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 161–163. Transcripción para trazabilidad.

Los pozos de registro se abonarán por ml realmente ejecutados, independientemente de altura total que tengan.
En esta unidad está incluida el cerco y tapa de fundición, salvo indicación en contra en el Presupuesto. En este caso no se abonarán los ml de cada pozo hasta no esté recibido el cerco y colocada la tapa. Asimismo, queda incluido dentro de la unidad el coste de personalización de arquetas según indique la Dirección Facultativa.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1160–1161. Transcripción para trazabilidad.

Se medirán y abonarán por unidades realmente ejecutadas (ud) con arreglo a este proyecto y las órdenes escritas del Director de la Obra, y se aplicarán los diferentes precios para cada una de ellas, en función a sus dimensiones, resistencia exigida o tipología.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
