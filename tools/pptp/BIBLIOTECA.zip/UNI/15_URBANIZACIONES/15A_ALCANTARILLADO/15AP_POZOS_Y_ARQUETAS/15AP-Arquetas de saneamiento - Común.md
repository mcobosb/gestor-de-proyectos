# Arquetas de saneamiento - Común

**Clasificación:** 15AP  
**Capítulo:** Redes de evacuación y drenaje  
**Familia:** Registros y singularidades  

## Descripción
Ejecución de arquetas de registro, paso, formación de caídas, pie de bajante o acometida para la red de saneamiento y drenaje, construidas in situ (de fábrica de ladrillo u hormigón) o prefabricadas, incluyendo la formación de caz, el enfoscado interior, el conexiado de colectores y la instalación de marco y tapa.

## Ejecución
1. **Previos:** Comprobar cotas de llegada y salida de colectores, rasante de acabado y nivel del fondo de zanja/excavación. Preparar una solera de apoyo de hormigón (mínimo 10-20 cm de espesor según tipología).
2. **Construcción y conexiado:** Levantado de paredes (fábrica de ladrillo macizo de al menos 10 cm enfoscada y enlucida interiormente con mortero de cemento rico, o paredes de hormigón HM-20 de 20 cm) o montaje de módulos prefabricados de hormigón (HA-25 con juntas elásticas). Formar la media caña o caz en el fondo sobre la solera para encauzar el flujo sin retenciones. Introducir y sellar los extremos de los colectores garantizando la estanqueidad sin transmitir cargas mecánicas directas.
3. **Remate y coronación:** Enrasar el alzado, recibir el marco e instalar la tapa metálica o de fundición adecuada a la clase de carga según la ubicación. Comprobar la estanqueidad global y la limpieza del interior.

## Medición
* **Unidad de medida:** Unidad (ud) de arqueta completamente terminada, clasificada por tipo, dimensiones interiores y profundidad.
* **Criterio:** Número de unidades efectivamente construidas, probadas y aceptadas por la Dirección Facultativa.

## Valoración
El precio unitario (€/ud) incluye:
* Excavación complementaria, encofrados y vertido de solera y alzados de hormigón o levantado de fábrica de ladrillo macizo.
* Suministro y colocación de elementos prefabricados, morteros de agarre y enfoscado/bruñido interior.
* Formación de caz de encauzamiento en el fondo y sellado estanco del conexiado de tuberías.
* Suministro, colocación y recibido de marco y tapa de fundición (incluidas marcas o personalización según proyecto).
* Ensayos de estanqueidad y limpieza final de la arqueta.