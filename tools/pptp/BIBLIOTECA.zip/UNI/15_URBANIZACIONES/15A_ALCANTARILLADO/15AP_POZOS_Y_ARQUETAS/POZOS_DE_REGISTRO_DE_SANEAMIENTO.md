# Pozos de registro de saneamiento

**Clasificación:** 15AP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Pozos de acceso y conexión de colectores de saneamiento, prefabricados o ejecutados in situ.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 151–153. Transcripción para trazabilidad.

Se definen como las obras que completan el sistema de drenaje, ejecutadas en obra de fábrica donde ingieren otros colectores, acometidas, etc.

## Ejecución

Construir la base y canal de paso, disponer juntas y conexiones estancas y ejecutar el fuste y coronación conforme al cálculo y los planos. Comprobar la documentación de prefabricados, habitualmente bajo UNE-EN 1917 según producto, y de pates y tapas. No acceder al pozo sin medidas específicas frente a atmósferas peligrosas y caídas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 154–160. Transcripción para trazabilidad.

Para su ejecución se utilizará hormigón HM 20 y ladrillo macizo.
En caso de ejecutarse con elementos prefabricados se utilizarán hormigones mínimos de HA 25.
El fondo de los pozos de registro se ejecutará con hormigón, formando un caz para la circulación de agua, y evitar el depósito de suciedad.
Se enfoscarán interiormente con mortero de cemento.
Se colocarán pates de acero forrados con polipropileno en pozos con altura superior a 1.20 m de altura.
Los pozos prefabricados en hormigón tendrán junta de goma y cumplirán con la normativa UNE 127011.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1018–1022. Transcripción para trazabilidad.

Las arquetas se construirán con el tipo de hormigón indicado en los planos, tanto para la solera como para alzados y cuando así se indique en los planos se construirán de fábrica de ladrillo macizo, enfoscadas interiormente.
Cuando sean de hormigón, el espesor de las soleras y los alzados será al menos de veinte (20) centímetros.
En caso de construirse de fábrica de ladrillo no será inferior a diez (10) centímetros.
En general, se tendrán en cuenta las especificaciones según la Norma Tecnológica de la Edificación NTE/ISS, y siguiendo las especificaciones de los planos.

## Medición y valoración

El original prescribe metro lineal de pozo ejecutado e incluye cerco y tapa salvo exclusión del presupuesto. Confirmar el criterio geométrico y su correspondencia con el cuadro de precios.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 161–163. Transcripción para trazabilidad.

Los pozos de registro se abonarán por ml realmente ejecutados, independientemente de altura total que tengan.
En esta unidad está incluida el cerco y tapa de fundición, salvo indicación en contra en el Presupuesto. En este caso no se abonarán los ml de cada pozo hasta no esté recibido el cerco y colocada la tapa. Asimismo, queda incluido dentro de la unidad el coste de personalización de arquetas según indique la Dirección Facultativa.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1160–1161. Transcripción para trazabilidad.

Se medirán y abonarán por unidades realmente ejecutadas (ud) con arreglo a este proyecto y las órdenes escritas del Director de la Obra, y se aplicarán los diferentes precios para cada una de ellas, en función a sus dimensiones, resistencia exigida o tipología.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
