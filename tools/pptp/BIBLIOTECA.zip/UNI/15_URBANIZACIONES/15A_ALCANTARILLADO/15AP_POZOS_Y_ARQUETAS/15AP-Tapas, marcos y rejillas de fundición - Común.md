# Tapas, marcos y rejillas de fundición - Común

**Clasificación:** 15AP  
**Capítulo:** Redes de evacuación y drenaje  
**Familia:** Registros y singularidades  

## Descripción
Suministro, recibido e instalación de conjuntos de marco y tapa o marco y rejilla de fundición nodular para el cierre, registro o captación de aguas en arquetas, pozos e imbornales, con la clase resistente (UNE-EN 124) y geometría adecuadas a su ubicación en calzada o acera.

## Ejecución
1. **Previos:** Comprobar marcados de fábrica, clase de carga (ej. D400 en calzada, B125/C250 en acera/arcén), marcado del servicio ("Saneamiento", "Agua Potable", etc.) y cumplimiento de normativa de accesibilidad (aberturas orientadas en itinerarios peatonales).
2. **Asiento y recibido:** Disponer una bancada de apoyo continuo de hormigón/mortero sobre la coronación de la estructura base. Ajustar el marco nivelado para garantizar que la tapa o rejilla quede perfectamente enrasada con el pavimento definitivo, evitando resaltes, hundimientos o balanceos.
3. **Control y remate:** Verificar la estabilidad del asiento, la estanqueidad/ajuste de la tapa en la pestaña de apoyo (mínimo 8 mm) y la facilidad de apertura con las llaves o taladros de elevación autorizados.

## Medición
* **Unidad de medida:** Unidad (ud) instalada y comprobada (únicamente cuando exista partida específica e independiente en el cuadro de precios).
* **Criterio:** Número de unidades ejecutadas in situ y aceptadas. Sin abono si el elemento ya está repercutido en la unidad de pozo, arqueta o imbornal.

## Valoración
El precio unitario (€/ud) incluye:
* Suministro, transporte, descarga y acopio de marcos, tapas, trampillones rellenables o rejillas de fundición nodular.
* Mortero o hormigón de recibido, nivelado y enrase con la rasante de acabado de calzada o acera.
* Limpieza del alojamiento y verificación final de enrase y apertura.