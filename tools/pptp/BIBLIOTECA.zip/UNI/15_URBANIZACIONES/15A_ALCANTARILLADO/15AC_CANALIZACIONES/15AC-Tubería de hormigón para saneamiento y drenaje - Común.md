# Tubería de hormigón para saneamiento y drenaje - Común

**Clasificación:** 15AC  
**Capítulo:** Redes de evacuación y drenaje  
**Familia:** Canalizaciones enterradas  

## Descripción
Suministro, instalación y prueba de conducciones enterradas formadas por tubos de hormigón (armado o machihembrado) para la evacuación de aguas pluviales o residuales por gravedad, conforme a la alineación, rasante y diámetros de proyecto.

## Ejecución
1. **Previos:** Comprobar la rasante y ancho del fondo de zanja. Extender y compactar una cama o lecho de asiento granular (arena o árido d < 13 mm) de 10 cm de espesor al 95% del Próctor Modificado. Verificar que los tubos estén marcados de fábrica y sin fisuras o desperfectos.
2. **Colocación y rejuntado:** Montaje de los tubos en sentido ascendente (desde aguas abajo hacia aguas arriba), garantizando el apoyo continuo en toda la generatriz inferior. Ejecución de juntas estancas (mediante campana con junta elástica o mortero según tipo). Disponer macizos/bloques de empuje de hormigón en codos y cambios de dirección sin obstruir las juntas de inspección.
3. **Relleno y prueba de estanqueidad:** Relleno lateral y superior envolvente por tongadas compactadas. Realizar la prueba hidráulica de estanqueidad (llenado del tramo obturado durante 30 min y comprobación de nulas fugas) de la totalidad del tramo antes del tapado definitivo de las juntas y la recepción.

## Medición
* **Unidad de medida:** Metro lineal (m) de tubería colocada y probada, desglosada por diámetro nominal y clase/resistencia.
* **Criterio:** Longitud neta realmente ejecutada sobre el eje de la traza, descontando la luz interior ocupada por los pozos de registro y arquetas.

## Valoración
El precio unitario (€/m) incluye:
* Suministro, transporte, descarga y bajada a zanja de tubos y piezas especiales.
* Suministro, extendido y compactado de la cama de asiento (salvo existencia de partida específica).
* Montaje, centrado, ejecución de juntas, conexiado a pozos/arquetas y ejecuciones de bloques de empuje.
* Realización de los ensayos de estanqueidad, materiales y pruebas hidráulicas de recepción.