# Tubería de hormigón para saneamiento y drenaje

**Clasificación:** 15AC. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Conducción enterrada de hormigón para evacuación de aguas, con resistencia, diámetro y juntas definidos por el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 131–137. Transcripción para trazabilidad.

Esta unidad comprenderá la aportación, colocación y prueba de las tuberías necesarias para excavación de las aguas de saneamiento.
Condiciones que han de cumplir los materiales.
Las tuberías de hormigón serán armadas clase 180 y cumplirán con las prescripciones UNE 127010.
El contratista quede obligado a aportar los certificados de garantía que exija la Dirección Facultativa cuando las piezas sean prefabricadas.
Las tuberías hormigón irán sobre asiento de arena con un espesor de 10 cms sobre suelo adecuado, compactado al 95% del Proctor Modificado, las tuberías de hormigón irán alojadas sobre lecho de material granular de diámetro inferior a 13 mm compactado al 95% del PM y se rellenará por capas de pequeño espesor hasta un recubrimiento mínimo de 30 cms con el mismo material compactado. Los tubos serán uniformes y no tendrán irregularidades. No contendrán ningún defecto que pueda reducir su resistencia, impermeabilidad o duración.

## Ejecución

Recepcionar tubos sin fisuras ni daños en juntas, comprobar fondo y cama, instalar desde aguas abajo manteniendo pendiente y apoyo continuo y ejecutar uniones limpias y estancas. Rellenar los laterales sin desplazamiento y realizar las pruebas antes de la recepción. Contrastar la recepción y los ensayos con las normas de producto y de instalación de saneamiento aplicables, habitualmente UNE-EN 1916 y UNE-EN 1610; verificar edición y ámbito.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 138–146. Transcripción para trazabilidad.

La ejecución de las obras comprenderá las siguientes operaciones:
- Suministro del tubo.
- Preparación del asiento.
- Colocación y rejuntado de los tubos.
- Prueba de la tubería.
En la preparación del asiento se incluirá la limpieza, nivelación y compactación del terreno natural, y la ejecución de un lecho de arena de 10 cm de espesor.
La colocación de los tubos se hará en sentido ascendente.
La Dirección Facultativa podrá exigir ensayos de estanqueidad de cualquier sección o de la totalidad de la tubería. Si estas pruebas revelan defectos de estanqueidad el Contratista está obligado a levantar y ejecutar de nuevo, a su cargo, las secciones defectuosas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 926–959. Transcripción para trazabilidad.

Cumplirán las especificaciones mínimas establecidas en otros apartados de este proyecto.

En el caso de que fuese admitido por la Dirección Facultativa otro tipo de tubería de la prevista en proyecto, el Contratista presentará una oferta del nuevo diámetro de los tubos y de sus características principales de velocidad, pérdida de carga, timbraje, etc., que serán análogas (siempre del lado de la seguridad) a las que han servido de base en los cálculos.
Se sobreentiende que la autorización para el cambio de tipo de la tubería, no presupone derecho a modificación del precio correspondiente de los Cuadros de precios, que permanecerán inalterables en cualquier caso.

Las tuberías habrán de ser calculadas para soportar las siguientes cargas por:
- Carga de relleno de mil ochocientos (1.800) kg/m3. Como mínimo de acuerdo con el perfil correspondiente.
- En la zona de paso de caminos o carreteras o próximas a ellos, eje de trece (13) toneladas más un cincuenta por ciento (50%) por impactos.

Todos los elementos de la tubería llevarán las marcas distintas siguientes, impresas por cualquier procedimiento que asegure su duración permanente.
- Marca de fábrica
- Diámetro interior en mm.
- Marca de identificación de orden, edad o serie que permita encontrar la fecha de fabricación y modalidades de las pruebas de recepción y entrega.
- Marca de localización que permita identificar la situación de los tubos en el terreno en relación con los planos y datos facilitados por el Contratista.

Con las tuberías y sobre el número de muestras que determine el Director de las Obras, se realizarán los ensayos generales prescritos en el Pliego de Prescripciones Técnicas Generales para Obras de Carreteras y Puentes (PG 3), para el tipo de material que se emplea. Estos ensayos podrán ser ejecutados, si así lo desea el director de las Obras, con un laboratorio oficial y siempre a las expensas del contratista.
Especialmente, en el ensayo de flexión transversal, deberá obtenerse una carga de fisuración superior a los tres mil quinientos (3.500) kilogramos por metro lineal de tubería útil, para todos aquellos tramos (cruces de caminos, etc.), en que a juicio del Director de las obras, sea posible el tráfico material rodante pesado, actual o futuro.

Con carácter general, es de plena aplicación lo preceptuado al respecto en el artículo 8.01., del P.P.T.P.A.P.

En lo referente a excavación y relleno de la misma, es preceptivo lo indicado en el Pliego de Condiciones Generales para Obras de Carreteras y Puentes (PG 3).
El ancho de la zanja viene definido por la sección tipo indicada en los planos, que se considera suficiente para los trabajos de colocación, sin embargo si por cualquier consideración el Contratista modificase esta dimensión por propia conveniencia, no podrá exigir aumento alguno en los volúmenes de excavación y por lo tanto en los precios correspondientes. La profundidad de la zanja viene dada por la cota roja de los perfiles longitudinales del trazado, sin embargo deberá cuidarse, con pequeñas rectificaciones del mismo si fuesen necesarias, que en todo momento el recubrimiento de la tubería sobre la arista superior de la misma, sea de un ( 1 ) metro. Excepcionalmente en algún pequeño tramo podrá aceptarse un recubrimiento de sesenta (60) centímetros, siempre que exista garantía de que no haya circulación rodada superior. En caso contrario deberá disponerse una losa de reparto de hormigón armado, que será sometida a la aprobación del Director de las Obras.
Como norma general los tubos se bajarán al fondo de la zanja con los elementos adecuados, según el peso y la longitud del tubo y la posible entibación de la zanja. Se centrarán debidamente con los adyacentes, y a continuación se procederá a fijarlos.
Las tuberías y zanjas se mantendrán libres de agua mediante los correspondientes desagües en la excavación y si fuera preciso se agotará el agua con bomba.
Cuando las pendientes de las zanjas sean superiores al diez por ciento (10%), la tubería se colocará en sentido ascendente. Si a juicio del Director de las Obras, no es posible colocarla en sentido ascendente, se tomarán las precauciones debidas para evitar el deslizamiento de los tubos. Si se precisa reajustar algún tubo, deberá levantarse el relleno y prepararlo como para su primera colocación.
Cuando se interrumpa la colocación de la tubería se taponarán los extremos libres, para impedir la entrada de agua o cuerpos extraños, y al reanudar el trabajo se examinará con todo cuidado el interior de la tubería, por si pudiera haberse introducido algún cuerpo extraño en la misma.

Los cambios de alineación o rasante de gran radio, deberán realizarse con tubos rectos o de acuerdo con lo indicado en los planos del proyecto.

Se colocarán bloques de empuje en todos los codos o cambios de dirección bruscos de la tubería, aún cuando éstos no estuviesen específicamente señalados en los planos. Las dimensiones y peso serán las adecuadas en función de la velocidad y altura de presión de cada tramo de tubería.
Estos bloques de empuje, deberán construirse una vez montados los tubos y las piezas especiales, fundiendo el hormigón entre las zanjas y la parte lateral e inferior de los mismos.
En ningún caso, el hormigón deberá interferir en las juntas de las piezas, perturbando su posible reparación.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 960–972. Transcripción para trazabilidad.

Se ensayará la tubería en toda su longitud.
Las zanjas podrán estar parcialmente llenas, pero al menos las juntas estarán perfectamente descubiertas.
El costo de todas estas pruebas correrá por cuenta del contratista.
Si como consecuencia de algún fallo en la tubería y la consiguiente sustitución o nuevo acondicionamiento de uno o varios elementos, hubiese que repetir alguna prueba, ésta correrá por cuenta del contratista, así como los trabajos necesarios para su reparación.
PRUEBAS PARA TUBERÍAS DE SANEAMIENTO
Se deberá probar el cien por cien (100%) de la longitud total de la red, salvo que el Director de la Obra fije otra distinta. En ese caso, el Director de la Obra fije otra distinta. En ese caso, el Director de la Obra determinará los tramos que deberán probarse.
Una vez colocada la tubería de cada tramo, construidos los pozos y antes del relleno de la zanja, el Contratista comunicará al Director de la Obra que dicho tramo está en condiciones de ser probado. El Director de la Obra, en el caso de que decida probar ese tramo, fijará la fecha; en caso contrario, autorizará el relleno de la zanja.
Las pruebas se realizarán obturando la entrada de la tubería en el pozo de aguas abajo y cualquier otro punto por el que pudiera salirse el agua. Se llenará completamente de agua la tubería y el pozo de aguas arriba del tramo a probar.
Transcurridos treinta (30) minutos del llenado se inspeccionarán los tubos, las juntas y los pozos, comprobándose que no ha habido pérdida de agua. Todo el personal, elementos y materiales necesarios para la realización de las pruebas, serán por cuenta del contratista.
Excepcionalmente, el Director de las Obras podrá sustituir este sistema de prueba por otro suficientemente contrastado que permita la detección de fugas.
Si se aprecian fugas durante la prueba, el Contratista las corregirá, procediéndose a continuación a una nueva prueba. En este caso el tramo en cuestión no se tendrá en cuenta para el cómputo de la longitud total a ensayar.
Una vez finalizada la obra y antes de la recepción provisional, se comprobará el buen funcionamiento de la red.

## Medición y valoración

Medir en m la longitud colocada por diámetro, descontando pozos y arquetas conforme a 3.11. Incluye juntas, piezas y pruebas descritas y, si no hay partida específica, el lecho de asiento.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 147–150. Transcripción para trazabilidad.

Se abonarán por los metros de longitud, descontando longitudes debidas a pozos y arquetas, aplicadas según el diámetro del tubo.
Dentro del precio se encontrarán incluidos el suministro de los tubos, ejecución de juntas, las piezas especiales y la confluencia con los pozos, y las pruebas finales de estanqueidad y presión.
Siempre que el presupuesto no contemple una partida específica se entenderá que el material de asiento o lecho de arena queda incluido dentro del precio unitario.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1157–1159. Transcripción para trazabilidad.

La tubería se medirá por metro lineal (ml) de tubería realmente colocada en obra, según los distintos diámetros y timbrajes.
El abono se efectuará aplicando a estas mediciones los precios que se indican en el presupuesto, los cuales se refieren a tubería colocada, y acabada, después de haber sido sometida satisfactoriamente a las pruebas que se indican en este pliego.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
