# Imbornales y sumideros

**Clasificación:** 15AS. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Elementos de recogida de escorrentía superficial y conexión con los colectores, situados en los puntos bajos efectivos.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 164–167. Transcripción para trazabilidad.

Son los elementos que se ejecutarán para la recogida de la escorrentía superficial de los viales.
Se situarán comprobando que se colocan en los puntos más bajos de la calzada, aunque no coincidan con las referencias de los planos.

## Ejecución

Comprobar cotas y captación antes de colocar. Ejecutar apoyo, cuerpo y conexión estanca con pendiente adecuada, colocar sifón cuando corresponda y recibir cerco y rejilla sin resaltes. Verificar capacidad de drenaje, limpieza y compatibilidad con el tránsito y la accesibilidad conforme a la Orden TMA/851/2021.

## Medición y valoración

Medir en ud completamente terminada, incluida rejilla, bordillo buzón, arqueta, sifón si procede y conexión con excavación y rellenos según 3.13.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 168–170. Transcripción para trazabilidad.

Se medirán y abonarán por unidades completamente terminadas.
En esta unidad se encuentra incluida la rejilla, el bordillo buzón, la arqueta de recogida, el sifón en caso de sistema unitario, la tubería de conexión con los pozos de los colectores generales, así como la excavación, asiento, relleno y compactación de la zanja.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
