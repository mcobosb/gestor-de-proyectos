# setos

**Clasificación:** 15JS. **Capítulo:** urbanizaciones. **Familia:** jardinería.

## Descripción

Elementos de urbanización y redes exteriores definidos por los planos, el presupuesto y las condiciones del titular del espacio o servicio.

El objeto de esta ficha es «setos», dentro de «jardinería». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Coordinar replanteo y servicios existentes, mantener itinerarios seguros y ejecutar por fases compatibles con el tráfico y otras redes. Revisar apoyos, cotas y encuentros antes de ocultar elementos y reponer las superficies afectadas.

Comprobar suelo, drenaje y estado fitosanitario; plantar en época compatible, regar y mantener hasta la recepción prevista. Replantear alineación y densidad y prever desarrollo del seto sin invadir recorridos ni visibilidad.

Para la variante «setos» se comprobarán expresamente especie, formato, suelo, riego y periodo de establecimiento; especie, marco, altura y mantenimiento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar geometría, funcionalidad, accesibilidad y recepción por el titular; documentar trazados y elementos ocultos mediante planos finales.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Árboles y plantas aisladas: ud aceptada por especie y formato; setos: m con densidad definida; tapizantes: m² de superficie implantada. Precisar tierra, tutorado, riego, reposición de marras y mantenimiento incluidos y los hitos de recepción.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
