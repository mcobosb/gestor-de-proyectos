# Setos - Común

**Clasificación:** 15JS  
**Capítulo:** Jardinería y redes exteriores  
**Familia:** Jardinería y vegetalización  

## Descripción
Suministro, preparación del terreno y plantación de arbustos o especies vegetales alineadas para la formación de setos y cerramientos vegetales, respetando la especie, densidad, formato de presentación y dimensiones especificadas en el proyecto.

## Ejecución
1. **Previos y acondicionamiento:** Replantear la alineación del seto comprobando que su desarrollo futuro no invada itinerarios peatonales, calzadas ni marcos de visibilidad en cruces o señalización. Excavación de la zanja de plantación, descompactación del fondo, aportación de tierra vegetal y enmiendas orgánicas según especificaciones.
2. **Plantación:** Verificación del estado fitosanitario de las plantas y de la humedad del cepellón/contenedor. Colocación de los ejemplares a la distancia y densidad (plantas por metro lineal) marcadas en proyecto, enrasando el cuello de la planta con la superficie y rellenando por tongadas apisonadas para evitar bolsas de aire.
3. **Terminación y mantenimiento:** Formación de la regadera o alcorque corrido para retención de agua, riego de asentamiento abundante tras la colocación, primer recorte de formación/igualado y mantenimiento (riego, deshierbe y reposición de marras) hasta la recepción definitiva por la Dirección Facultativa.

## Medición
* **Unidad de medida:** Metro lineal (m) de seto implantado y recibido, especificado por especie, densidad de plantas por metro y altura comercial.
* **Criterio:** Longitud neta efectivamente ejecutada y comprobada sobre el eje de la alineación.

## Valoración
El precio unitario (€/m) incluye:
* Suministro, carga, transporte, descarga y acopio de los ejemplares vegetales y materiales.
* Excavación de la zanja de plantación, perfilado, aportación de tierra vegetal, sustratos y abonos.
* Colocación, aplomado, alineación, apisonado de la tierra, formación de regadera perimetral y primer podado de formación.
* Riego inicial de asentamiento, conservación, riegos de mantenimiento y reposición de marras durante el periodo de garantía.