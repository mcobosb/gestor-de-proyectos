# Plantación de árboles - Común

**Clasificación:** 15JA  
**Capítulo:** Jardinería y red de riego  
**Familia:** Arbolado y especies vegetales  

## Descripción
Suministro, transporte, acondicionamiento y plantación de árboles de las especies, perímetros de tronco, alturas y formato de presentación (raíz desnuda, cepellón en escallola/arpillera o contenedor) definidos en el proyecto, incluyendo apertura de hoyos, abonado, primer riego de asentamiento y reposición de marras.

## Ejecución
1. **Previos y acondicionamiento:** Replantear los hoyos mediante estacas evitando interferencias con redes de servicios o itinerarios peatonales. Verificar el buen estado sanitario de las plantas (sin plagas ni magulladuras). Abrir los hoyos con antelación para favorecer la aireación del terreno. Realizar las operaciones durante el periodo de reposo vegetativo (de octubre a abril).
2. **Plantación:** Disponer en el fondo del hoyo el abonado de fondo (0,5 kg de estiércol) cubierto por una capa aislante de tierra vegetal para evitar el contacto directo con las raíces. Introducir la planta recta, centrada y orientada al nivel del cuello del árbol:
   - *A raíz desnuda:* Sanear raíces rotas y extenderlas sin doblar.
   - *Con cepellón o contenedor:* Retirar tiesto o escayola con cuidado de no desmoronar el cepellón.
   Rellenar por tongadas con tierra vegetal apisonando homogéneamente para eliminar bolsas de aire y sin descalzar las raíces.
3. **Terminación y mantenimiento:** Formar un alcorque o caz perimetral con la tierra sobrante para retener el agua y aplicar un riego de asentamiento abundante inmediatamente después de la plantación. Instalar tutor o entutorado cuando esté especificado. Reponer las marras que se originen durante el periodo de garantía a cargo del contratista.

## Medición
* **Unidad de medida:** Unidad (ud) de árbol suministrado, plantado, regado y recibido.
* **Criterio:** Número de unidades ejecutadas in situ y aceptadas por la Dirección Facultativa, desglosadas por especie y tamaño comercial.

## Valoración
El precio unitario (€/ud) incluye:
* Suministro, carga, transporte, descarga y acopio de las plantas y material vegetal.
* Excavación del hoyo de plantación, extracción de piedras o escombros y aportación de tierra vegetal y estiércol/enmienda orgánica.
* Operaciones de poda de formación/raíces, colocación, enrasado, rellenado, apisonado, formación de alcorque y riego inicial.
* Suministro e instalación de tutores, vientos o amarras (si no existe partida específica).
* Conservación, riegos de mantenimiento y reposición de marras durante el plazo de garantía.