# Manto de tierra vegetal fertilizada

**Clasificación:** 15JW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Capa de tierra vegetal acondicionada para la implantación de vegetación, con preparación de soporte, mezcla y extendido.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1063–1064. Transcripción para trazabilidad.

La ejecución del manto de tierra vegetal fertilizada incluye las siguientes operaciones:

## Ejecución

Comprobar suelo y enmienda mediante los análisis previstos, retirar elementos inadecuados y trabajar con humedad que evite terrones y compactación perjudicial. Preparar y refinar el soporte, mezclar homogéneamente, extender al espesor aprobado y corregir erosiones y defectos antes de plantar.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1065–1091. Transcripción para trazabilidad.

1. Preparación del soporte del manto comprendido, si fuera necesario, el subsolado y laboreo del mismo a fin de proporcionar una capa inferior adecuada a la penetración de las raíces.
    2. Acabado y refinado de la superficie el soporte de modo que quede adaptada al futuro perfil del terreno.
    3. Extracción de la tierra vegetal.
    4. Colocación de la tierra vegetal original en pequeños montones, no mayores de doscientos decímetros cúbicos (200 dm³) para su mezcla manual o con un equipo mezclador mecánico de la tierra vegetal con las debidas cantidades de estiércol, compost o turba. En todo caso debe garantizarse una mezcla suficientemente uniforme como para que no progrese su grado de homogeneidad con la reiteración del proceso de mezclado.
    5. Carga y acarreo de la tierra vegetal fertilizada resultante a la zona de empleo, realizando las descargas en los lugares más convenientes para las operaciones posteriores.
    6. Extensión y configuración de los materiales del manto en función del espesor del material prefijado.
    7. Recogida, transporte y vertido de los componentes inadecuados y de los sobrantes, en escombrera.
La ejecución de cualquiera de las operaciones anteriores habrá de ajustarse a unas condiciones laborables adecuadas, en especial a lo que el exceso de humedad en los materiales manejados se refiere, fundamentalmente, por causas de las lluvias.
Todos los materiales habrán de manejarse en un estado de humedad en que ni se aterronen ni se compacten excesivamente, buscando unas condiciones de fiabilidad, en sentido mecánico, que puedan hallarse, para los materiales indicados, en las proximidades del grado de humedad del llamado punto de marchitamiento. En estas condiciones puede conseguirse tanto un manejo de los materiales de los suelos, como una mezcla sueloestiércol, o suelo compost, en condiciones favorables.
El tipo de maquinaria empleada, y las operaciones con ella realizadas, deben ser tal que evite la compactación excesiva del soporte y de l capa del manto vegeta. Las propiedades mecánicas de los materiales, la humedad durante la operación y el tipo de maquinaria y operaciones han de ser tenidas en cuenta conjuntamente para no originar efectos desfavorables.
Es precisa una revisión final de las propiedades y estado del manto vegetal fertilizado eliminando los posibles defectos (elementos extraños o inconvenientes en los materiales), desplazamientos o marcas de erosión en los taludes causados por la lluvia y cualquier imperfección que puede repercutir sobre el desarrollo de las futuras siembras y plantaciones.

TIERRA VEGETAL FERTILIZADA
Para determinar las características de la tierra vegetal fertilizada se realizarán los siguientes análisis:
- Análisis físicos, determinando contenido en arenas, limos y arcilla (análisis granulométrico).
- Análisis químicos, determinando contenido en materia orgánica, nitrógeno total, fósforo (P2O5), potasio (K2O) y pH.
- Determinación de oligoelementos (cuando por tratarse de un suelo agotado se sospechase la escasez de alguno de ellos): Magnesio, Hierro, Manganeso, Cobalto, Zinc, Boro.
- Determinación de otros compuestos tales como cloruros, calcio, azufre (SO4=).
ENMIENDA ORGÁNICA
Para verificar las características de las enmiendas aportadas se realizarán las pruebas siguientes:
- Densidad
- Presencia de semillas de adventicias
- Riqueza en nitrógeno
- Grado de descomposición
- Color, consistencia y humedad

El Director podrá ordenar la realización de aquellos ensayos y pruebas que juzgue oportunos para verificar el cumplimiento de las especificaciones exigidas en el presente artículo.

## Medición y valoración

El original remite a los precios unitarios de jardinería sin definir una magnitud propia. Proponer m³ de tierra extendida o m² con espesor fijado exclusivamente según la partida aprobada; no certificar ambos.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1172–1173. Transcripción para trazabilidad.

La medición y abono de las unidades del capítulo de jardinería se hará por el sistema de precios unitarios de acuerdo con los indicados en el Cuadro de Precios nº 1 y aplicados al número de unidades de la misma.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
