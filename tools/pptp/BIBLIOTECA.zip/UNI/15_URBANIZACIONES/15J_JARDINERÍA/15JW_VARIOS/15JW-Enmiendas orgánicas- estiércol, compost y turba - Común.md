# Enmiendas orgánicas- estiércol, compost y turba - Común

**Clasificación:** 15JW  
**Capítulo:** Jardinería y red de riego  
**Familia:** Insumos y acondicionadores del suelo  

## Descripción
Suministro, acopio, control de calidad y homogenización de materiales u acondicionadores orgánicos (estiércol maduro, compost vegetal o turba) para la mejora física, química y biológica de la tierra vegetal y el enriquecimiento de hoyos de plantación o zonas ajardinadas.

## Ejecución
1. **Recepción y ensayos:** Verificar certificados de origen, madurez, riqueza en nitrógeno, grado de descomposición, salinidad y ausencia de patógenos o semillas de adventicias. Comprobar densidad, humedad y consistencia del lote conforme al pliego y dictamen de la Dirección Facultativa.
2. **Mezcla y dosificación:** 
   - *Tierra vegetal:* Homogeneización en caballones/montones reducidos (≤ 200 dm³) mediante mezcla manual o mecánica hasta lograr una distribución uniforme del compost/turba/estiércol.
   - *Hoyos de plantación:* Dosificación de enmienda (ej. 0,5 kg de estiércol por hoyo) interponiendo siempre una capa intermedia aislante de tierra vegetal sin fertilizar para evitar el contacto directo con la masa radicular y prevenir quemaduras en las raíces.
3. **Control y gestión:** Controlar la estabilidad del almacenamiento para evitar lixiviaciones y verificar el cumplimiento normativo aplicable al uso de subproductos orgánicos.

## Medición
* **Unidad de medida:** Sin abono independiente (o Metro cúbico, m³, / Tonelada, t, en el caso de existir partida específica desglosada en el cuadro de precios).
* **Criterio:** Material insumo repercutido en las unidades principales de preparación del terreno, aporte de tierra vegetal o plantación.

## Valoración
* **Abono:** Unidad sin abono directo salvo existencia de partida específica. El coste de la enmienda orgánica, transporte y mezclado se encuentra proporcionalmente incluido en las unidades de obras de jardinería, siembra o plantación.
* **Incluye:** Suministro, transporte, almacenamiento, ensayos de caracterización (densidad, nitrógeno, germinación), manipulación y medios de homogenización mecánica o manual.