# Manto de tierra vegetal fertilizada - Común

**Clasificación:** 15JW  
**Capítulo:** Jardinería y red de riego  
**Familia:** Insumos y acondicionadores del suelo  

## Descripción
Preparación de la superficie de apoyo, acopio, mezcla, homogeneización, extendido y refinado de una capa de tierra vegetal abonada mediante enmiendas orgánicas (estiércol, compost o turba), destinada a servir de soporte para la posterior siembra de césped, implantación de tapizantes o plantaciones de jardinería.

## Ejecución
1. **Preparación del soporte:** Subsolado y laboreo previo del suelo natural para facilitar el enraizamiento y el drenaje. Refinado y acabado de la superficie adaptándolo a los perfiles y pendientes del terreno de proyecto.
2. **Mezcla y acondicionamiento:** Acopio de la tierra vegetal en pequeños montones (≤ 200 dm³) y mezcla manual o mecánica con las dosificaciones especificadas de enmienda orgánica hasta lograr una textura homogénea. Realizar las operaciones con la humedad adecuada (próxima al punto de marchitamiento) para evitar la formación de terrones o sobrecompactaciones por la maquinaria.
3. **Extendido y control final:** Extendido del manto al espesor fijado en proyecto mediante maquinaria ligera. Retirada de piedras, sobrantes o elementos inadecuados a escombrera. Control analítico (granulometría, pH, materia orgánica, N, P₂O₅, K₂O) y reparación final de posibles erosiones o imperfecciones antes de la siembra o plantación.

## Medición
* **Unidad de medida:** Metro cúbico (m³) de tierra vegetal fertilizada extendida, o Metro cuadrado (m²) de manto implantado con especificación expresa del espesor (según la definición del cuadro de precios).
* **Criterio:** Volumen o superficie neta realmente ejecutada, extendida e inspeccionada en obra (sin contabilizar simultáneamente ambas magnitudes para la misma superficie).

## Valoración
El precio unitario (€/m³ o €/m²) incluye:
* Laboreo, subsolado, perfilado y preparación previa de la superficie de apoyo.
* Extracción, aportación o acopio de la tierra vegetal original y suministro de enmiendas orgánicas (estiércol, compost, turba).
* Operaciones de volteo, mezclado, homogenización y refinado.
* Carga, transporte, acopio intermedio y extendido del manto con el espesor de proyecto.
* Recogida, transporte y canon de vertido de sobrantes e impropios a escombrera.
* Ensayos de laboratorio (análisis físicos, químicos, oligoelementos y control de enmiendas).