# Enmiendas orgánicas: estiércol, compost y turba

**Clasificación:** 15JW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Materiales orgánicos citados para acondicionar la tierra vegetal y los hoyos de plantación.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1067–1068. Transcripción para trazabilidad.

3. Extracción de la tierra vegetal.
    4. Colocación de la tierra vegetal original en pequeños montones, no mayores de doscientos decímetros cúbicos (200 dm³) para su mezcla manual o con un equipo mezclador mecánico de la tierra vegetal con las debidas cantidades de estiércol, compost o turba. En todo caso debe garantizarse una mezcla suficientemente uniforme como para que no progrese su grado de homogeneidad con la reiteración del proceso de mezclado.

## Ejecución

Identificar origen y aptitud del producto, verificar madurez, salinidad y ausencia de contaminantes, semillas indeseadas y riesgos sanitarios conforme a la especificación aprobada. Ajustar dosis al análisis del suelo y especie y mezclar uniformemente evitando contacto perjudicial con las raíces. Si proceden de residuos, verificar antes su régimen legal de uso.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1045–1045. Transcripción para trazabilidad.

Se incorporará en los hoyos medio (0,5) kilogramo de estiércol. Encima se situará una capa de tierra vegetal, para que no haya contacto directo entre el estiércol y las raíces de la planta, operación que se debe hacer con esmero, puesto que si el contacto se verifica, las raíces se queman.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1083–1091. Transcripción para trazabilidad.

ENMIENDA ORGÁNICA
Para verificar las características de las enmiendas aportadas se realizarán las pruebas siguientes:
- Densidad
- Presencia de semillas de adventicias
- Riqueza en nitrógeno
- Grado de descomposición
- Color, consistencia y humedad

El Director podrá ordenar la realización de aquellos ensayos y pruebas que juzgue oportunos para verificar el cumplimiento de las especificaciones exigidas en el presente artículo.

## Medición y valoración

Incluidas en la preparación de tierra vegetal o plantación cuando así se define la partida; no abonables de nuevo por su ficha de material.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1172–1173. Transcripción para trazabilidad.

La medición y abono de las unidades del capítulo de jardinería se hará por el sistema de precios unitarios de acuerdo con los indicados en el Cuadro de Precios nº 1 y aplicados al número de unidades de la misma.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
