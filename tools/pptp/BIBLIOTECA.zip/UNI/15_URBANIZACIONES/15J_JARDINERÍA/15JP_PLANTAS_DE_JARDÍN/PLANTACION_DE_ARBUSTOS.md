# Plantación de arbustos

**Clasificación:** 15JP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Suministro y plantación de arbustos en las zonas ajardinadas previstas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1035–1036. Transcripción para trazabilidad.

Todas las Obras comprendidas en este proyecto se ejecutarán de acuerdo con los planos y la Memoria, además de las indicaciones de la Dirección Facultativa, quien resolverá las cuestiones que puedan plantearse en la interrupción de aquellas y en las condiciones y detalles de ejecución.

## Ejecución

Comprobar especie, calibre y sanidad, preparar terreno y hoyos, conservar raíces o cepellón y plantar con separación y profundidad aprobadas. Evitar contacto directo de raíces con enmiendas agresivas, regar y mantener durante el establecimiento. Proteger la accesibilidad y visibilidad del viario.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1037–1058. Transcripción para trazabilidad.

El replanteo de hoyos se efectuará con cinta métrica colocando las estacas o referencias que faciliten el trabajo de apertura y colocación de árboles y arbustos.
La preparación del terreno consiste en suministrar toda la instalación, mano de obra, equipo, materiales y elementos auxiliares y en ejecutar todas las operaciones relacionadas con la preparación de las zonas que hayan de cubrirse de vegetación. Todo ello de acuerdo con lo descrito en la Memoria y los Planos correspondientes.
La excavación de hoyos es conveniente efectuarla con antelación a la operación de plantación para facilitar la aireación de la tierra. Los hoyos para la colocación de árboles y arbustos tendrán las dimensiones especificadas en los planos y en la Memoria dependiendo de la especie que se trate.
El trabajo de plantación comprende el suministro de toda la instalación, mano de obra, materiales, equipo y accesorios, y en la ejecución de todas las operaciones relacionadas con la misma. Todo ello de acuerdo con lo especificado en este Pliego de Prescripciones Técnicas, Planos y Memoria.
Durante la preparación de la plantación se cuidará de que no se sequen las raíces. Se tomarán precauciones para evitar magulladuras, rotura y otros daños físicos a las raíces, tallos o ramas de las plantas.
Para evitar que se rompan o se deterioren los cepellones, todas las plantas que estén dispuestas de esta forma, se bajarán del camión con sumo cuidado. Las plantas nunca se apilarán unas encima de las otras o tan apretadamente que puedan resultar dañadas por la compresión o el calor. Las dañadas serán retiradas, o se dispondrán de ellas según orden del Director de las obras.
Las plantas serán plantadas en el mismo día de su llegada a la obra. Cuando esto no pueda efectuarse deben cubrirse temporalmente sus raíces. La zanja para cubrir los pies de las plantas estará situada en terreno arenoso o arenoso margoso, contra el sol, el viento y las heladas. Inmediatamente después de su colocación en la zanja, la plantas se cubrirán con un mínimo de quince (15) centímetros de tierra y se regarán abundantemente con agua.
Se incorporará en los hoyos medio (0,5) kilogramo de estiércol. Encima se situará una capa de tierra vegetal, para que no haya contacto directo entre el estiércol y las raíces de la planta, operación que se debe hacer con esmero, puesto que si el contacto se verifica, las raíces se queman.
Los árboles y arbustos deben centrarse, colocarse rectos y orientar adecuadamente dentro de los orificios y zanjas al nivel apropiado para que, cuando prendan guarden con la rasante la misma relación que tenían en su anterior ubicación.
En el caso de plantación a raíz desnuda, previa la eliminación de las raíces que lleguen rotas y las que estén magulladas, arreglando los bordes para que queden lisos y sin estrías, se colocará la planta, con cuidado, de forma que las raíces queden en su posición normal y sin doblarse, arropándolas con tierra vegetal y antes de terminar de llenar el hoyo se regará hasta conseguir una perfecta unión de las raíces en el terreno.
Si las plantas se sirven en macetas o tiestos, se romperán éstos en el mismo momento de efectuar la plantación, y se situará el cepellón intacto en el hoyo regando a continuación para que se mantenga húmedo.
Las plantas con cepellón de escayola se introducirán en los hoyos debidamente preparados. A continuación se sacará el yeso del hoyo, con sumo cuidado de no resquebrajarse el cepellón. Seguidamente, se rellenará el hoyo hasta la mitad apretando la tierra por tongadas, de manera uniforme y teniendo cuidado de que el cepellón no sufra en su integridad. Se efectuará un riego y seguidamente se completará el relleno del hoyo. Se debe cuidar el que la planta tenga la misma orientación que tenía en el vivero.
En toda plantación se dará finalmente un pequeño tirón a la planta, una vez apisonada la tierra, para que traben las raíces.
No debe plantarse, en ningún caso en días de helada por efecto de descalce que produce, ni en días de fuerte viento.
Con la tierra que resulte sobrante al rellenar, se hará un alcorque superficial para facilitar el posterior riego. Al rellenar el hoyo e ir apisonando la tierra por tongadas, se hará de forma que no se deshaga el cepellón que rodea las raíces.
La plantación debe realizarse, en lo posible, durante el período de reposo vegetativo, pero evitando los días de heladas fuertes. La plantación no comenzará antes del primero de octubre ni se continuará pasado el mes de abril. Únicamente las plantas en macetas o cepellón podrán sobrepasar estas fechas, siempre que lo permita el Director de Obra.
Durante el plazo de ejecución de las obras o dentro del plazo de garantía las marras que se originen por cualquier causa serán repuestas por el Contratista, corriendo el mismo con todos los gastos que origine la reposición.

Será el que se especifique en el Contrato, contado a partir de la fecha de recepción de las plantaciones.
Durante dicho período de garantía serán de cuenta del Contratista la reposición de marras y la resiembra de las superficies falladas.
Cuando el porcentaje de marras producido durante el período de garantía sea superior al cuarenta por ciento (40%) de la plantación efectuada, el período de garantía contará a partir de la reposición de las marras antedichas.

## Medición y valoración

Por ud o por la magnitud expresamente prevista en el precio de plantación, sin convertir una densidad no definida en una superficie certificable.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1172–1173. Transcripción para trazabilidad.

La medición y abono de las unidades del capítulo de jardinería se hará por el sistema de precios unitarios de acuerdo con los indicados en el Cuadro de Precios nº 1 y aplicados al número de unidades de la misma.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
