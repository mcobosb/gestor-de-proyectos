# Siembras y resiembras

**Clasificación:** 15JT. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Implantación de cobertura vegetal por siembra, citada en las obligaciones de garantía y reposición.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1055–1058. Transcripción para trazabilidad.

Será el que se especifique en el Contrato, contado a partir de la fecha de recepción de las plantaciones.
Durante dicho período de garantía serán de cuenta del Contratista la reposición de marras y la resiembra de las superficies falladas.
Cuando el porcentaje de marras producido durante el período de garantía sea superior al cuarenta por ciento (40%) de la plantación efectuada, el período de garantía contará a partir de la reposición de las marras antedichas.

## Ejecución

Definir previamente especies, mezcla, dosis y época compatibles con clima, suelo y uso. Preparar la tierra vegetal, sembrar uniformemente, cubrir según semilla y regar sin arrastre; mantener humedad y proteger hasta establecimiento. Reponer superficies falladas en las condiciones de garantía.

## Medición y valoración

Si existe partida, proponer m² de superficie sembrada y aceptada según sus condiciones; las resiembras de garantía previstas no generan un nuevo abono.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1172–1173. Transcripción para trazabilidad.

La medición y abono de las unidades del capítulo de jardinería se hará por el sistema de precios unitarios de acuerdo con los indicados en el Cuadro de Precios nº 1 y aplicados al número de unidades de la misma.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
