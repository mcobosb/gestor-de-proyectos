# Señales y carteles verticales retrorreflectantes - Común

**Clasificación:** 15CR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Placas, señales y carteles de circulación con sus soportes y anclajes, de formas y dimensiones definidas en el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 508–526. Transcripción para trazabilidad.

Las características geométricas de las señales a utilizar serán las siguientes:
- Señal circular Diámetro 0,60 metros
- Señal triangular Lado 0,90 metros
- Señal cuadrada Lado 0,60 metros
- Señal octogonal Doble apotema 0,90 metros
- Señal rectangular 0,90*1,35 metros

- Chapa de acero galvanizado de 1,8 mm.
- Pestaña de 25 mm
- Símbolo no troquelado en chapa.
- Parte posterior: capa de pintura
- Parte delantera: imprimación y esmalte normal en color
- Lamina reflectante con el símbolo generalmente calado.
- Tortillería de acero cincado
- Abrazadera de acero pregalvanizado de 1,8 mm
- Reflectancia nivel 3ª
- Soportes de acero galvanizado

## Ejecución

Comprobar catálogo y diseño de señal vigentes, material, retrorreflexión y documentación de producto. Replantear visibilidad, gálibos y accesibilidad; ejecutar cimentación y soportes y orientar las placas sin interferir con el itinerario peatonal. Aplicar el artículo 701 del PG-3 en el ámbito previsto por el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1095–1096. Transcripción para trazabilidad.

La forma, calidad y dimensiones de las señales de tráfico y carteles indicadores, tanto en lo que se refiere a las placas como a sus elementos de sustentación y anclajes, serán de los tipos actualmente aprobados por la Dirección General de Carreteras del Ministerio de Fomento, y se colocarán en sitios marcados en Planos o que indique el Director de la obra.

## Medición y valoración

Por las unidades de señal o superficies de cartel que defina el cuadro de precios, incluidos soportes, fijaciones y operaciones auxiliares. El original no permite asignar una unidad económica única a toda señalización.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 531–534. Transcripción para trazabilidad.

La señalización, tanto horizontal como vertical, de todo el proyecto, será medida y abonada de acuerdo con los precios unitarios del proyecto. Se considerarán incluidos en los precios de las unidades de obra todo el material auxiliar necesario para la completa ejecución de las mismas, como pueden ser tornillos, remaches, soldaduras, pinturas, hincas, etc., no habiendo lugar, en ningún caso, a su abono independiente.
La medición y abono de las marcas viales longitudinales se hará por metros lineales (ml) realmente pintados. La medición y abono de las marcas viales en cebra se hará por unidades (uds) y por metros cuadrados (m²), de acuerdo con los precios unitarios.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
