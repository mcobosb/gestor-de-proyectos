# Pinturas y microesferas para señalización horizontal

**Clasificación:** 15CP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Material base y productos de postmezclado para obtener las prestaciones de las marcas viales.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 527–530. Transcripción para trazabilidad.

Marcas longitudinales en pintura acrílica termoplástica en disolución, con 720 gr/m² de pintura y 480 gr/m² de microesferas, aplicada con maquinaria automática.
Marcas transversales con pintura plástica en frío de dos componentes, con 3.000 gr/m² de microesferas, aplicada manualmente.

## Ejecución

Recepcionar productos identificados, compatibles entre sí y con el soporte, con prestaciones y documentación exigibles. Almacenar dentro de condiciones y vida útil del fabricante y dosificar con equipo calibrado conforme al sistema aprobado y al artículo 700 del PG-3. Gestionar envases y restos según su clasificación.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1092–1094. Transcripción para trazabilidad.

Cumplirán, en todo, las normas exigidas en el PG 3.
Se situarán en los sitios marcados en los Planos o que indique el Director de la obra.

## Medición y valoración

Materiales incluidos en las unidades de marca vial; no tienen abono adicional por su ficha independiente.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 531–534. Transcripción para trazabilidad.

La señalización, tanto horizontal como vertical, de todo el proyecto, será medida y abonada de acuerdo con los precios unitarios del proyecto. Se considerarán incluidos en los precios de las unidades de obra todo el material auxiliar necesario para la completa ejecución de las mismas, como pueden ser tornillos, remaches, soldaduras, pinturas, hincas, etc., no habiendo lugar, en ningún caso, a su abono independiente.
La medición y abono de las marcas viales longitudinales se hará por metros lineales (ml) realmente pintados. La medición y abono de las marcas viales en cebra se hará por unidades (uds) y por metros cuadrados (m²), de acuerdo con los precios unitarios.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
