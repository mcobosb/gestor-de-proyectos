# Pinturas y microesferas para señalización horizontal - Común

**Clasificación:** 15CP  
**Capítulo:** Señalización, balizamiento y defensas  
**Familia:** Señalización horizontal  

## Descripción
Suministro, control de calidad, almacenamiento y dosificación de productos de pintura (acrílica termoplástica en disolución o plástica en frío de dos componentes) y microesferas de vidrio de postmezclado para la ejecución de marcas viales y garantia de sus prestaciones táctiles, de retrorreflexión y antiderrapantes.

## Ejecución
1. **Recepción y almacenamiento:** Verificar certificados de calidad del fabricante, marcado CE y marcado de lote. Almacenar los productos en lugares secos, ventilados y protegidos de temperaturas extremas, respetando la vida útil indicada por el fabricante.
2. **Dosificación y mezcla:** Garantizar la compatibilidad de la pintura con el soporte y con las microesferas de vidrio. Calibrar los equipos automáticos de proyección conforme a las dosificaciones de proyecto (ej. 720 g/m² de pintura acrílica y 480 g/m² de microesferas en marcas longitudinales; 3.000 g/m² de microesferas en plástica en frío para marcas transversales) de acuerdo con el Art. 700 del PG-3.
3. **Control y gestión de residuos:** Controlar la adherencia y dotación durante el extendido. Gestionar la retirada de envases vacíos, disolventes y restos de pintura a través de un gestor de residuos autorizado.

## Medición
* **Unidad de medida:** Sin abono independiente.
* **Criterio:** Material base constitutivo de las unidades de señalización horizontal; no genera medición directa.

## Valoración
* **Abono:** Unidad sin abono directo. El coste de las pinturas, disolventes, aditivos y microesferas está repercutido e incluido proporcionalmente en los precios unitarios de las partidas definitivas de marcas viales longitudinales, transversales, cebreados y símbolos.
* **Incluye:** Suministro, transporte, almacenamiento, ensayos de laboratorio, calibración de equipos de dosificación y gestión ambiental de envases y residuos peligrosos.