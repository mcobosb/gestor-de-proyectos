# Marcas transversales, cebreados y símbolos

**Clasificación:** 15CP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Señalización horizontal de pasos, bandas, símbolos y otras superficies no longitudinales.

## Ejecución

Aprobar el sistema de aplicación y prestaciones conforme al artículo 700 del PG-3. Replantear geometría, limpiar soporte y aplicar dotaciones compatibles de material y microesferas con control de espesor, secado, retrorreflexión y deslizamiento. Mantener protección al tráfico durante el curado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1092–1094. Transcripción para trazabilidad.

Cumplirán, en todo, las normas exigidas en el PG 3.
Se situarán en los sitios marcados en los Planos o que indique el Director de la obra.

## Medición y valoración

Por m² o ud según la definición expresa de cada precio, sin contabilizar simultáneamente ambas unidades para una misma marca.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 531–534. Transcripción para trazabilidad.

La señalización, tanto horizontal como vertical, de todo el proyecto, será medida y abonada de acuerdo con los precios unitarios del proyecto. Se considerarán incluidos en los precios de las unidades de obra todo el material auxiliar necesario para la completa ejecución de las mismas, como pueden ser tornillos, remaches, soldaduras, pinturas, hincas, etc., no habiendo lugar, en ningún caso, a su abono independiente.
La medición y abono de las marcas viales longitudinales se hará por metros lineales (ml) realmente pintados. La medición y abono de las marcas viales en cebra se hará por unidades (uds) y por metros cuadrados (m²), de acuerdo con los precios unitarios.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
