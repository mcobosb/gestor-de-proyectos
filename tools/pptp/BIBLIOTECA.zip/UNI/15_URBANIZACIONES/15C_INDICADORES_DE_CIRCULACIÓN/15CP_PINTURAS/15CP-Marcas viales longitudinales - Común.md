# Marcas viales longitudinales - Común

**Clasificación:** 15CP  
**Capítulo:** Señalización, balizamiento y defensas  
**Familia:** Señalización horizontal  

## Descripción
Pintado de líneas de señalización horizontal longitudinales (continuas, discontinuas, dobles o de borde de calzada) sobre la superficie del pavimento, con el material, ancho y dosificación especificados en el proyecto para la ordenación del tráfico.

## Ejecución
1. **Previos:** Replantear los ejes y bordes de la calzada. Comprobar que el firme se encuentre limpio, seco, libre de polvo, grasa u óxidos y a una temperatura ambiental y de soporte adecuada.
2. **Aplicación:** Pintado con maquinaria automática calibrada mediante pintura acrílica termoplástica (o de dos componentes) con una dotación mínima de 720 g/m² de pintura y post-mezclado con 480 g/m² de microesferas de vidrio para garantizar la retrorreflexión (conforme al Art. 700 del PG-3).
3. **Control y secado:** Mantener el balizamiento y la protección del tráfico hasta el secado completo de la pintura. Comprobar anchos, linealidad del trazado, alineación de trazos y vanos, espesores, visibilidad nocturna/diurna y resistencia al deslizamiento (CRT).

## Medición
* **Unidad de medida:** Metro lineal (m) de línea realmente pintada, desglosada por ancho y tipología de pintura.
* **Criterio:** Longitud neta pintada comprobada in situ, descontando los vanos en líneas discontinuas salvo especificación en contra del cuadro de precios.

## Valoración
El precio unitario (€/m) incluye:
* Suministro, carga, transporte y acopio de pinturas, disolventes, aditivos y microesferas de vidrio.
* Mano de obra, maquinaría automática de trazado/pintado y medios auxiliares.
* Pre-marcado, replanteo topográfico, preparación y limpieza previa de la superficie.
* Medios de balizamiento provisional y protección de las líneas durante el secado.