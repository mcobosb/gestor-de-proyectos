# Marcas transversales, cebreados y símbolos - Común

**Clasificación:** 15CP  
**Capítulo:** Señalización, balizamiento y defensas  
**Familia:** Señalización horizontal  

## Descripción
Aplicación de pintura y marcas viales de carácter no longitudinal sobre la superficie de pavimentos o aceras (pasos de peatones, líneas de detención, bandas transversales, cebreados, flechas de dirección, inscripciones y símbolos), para la ordenación y regulación del tráfico.

## Ejecución
1. **Previos:** Replantear la geometría, dimensiones y disposición exacta de las marcas según los planos de proyecto. Comprobar que la superficie del pavimento esté limpia, seca y exenta de aceites o polvo.
2. **Aplicación:** Extendido del material de pintura (acrílica, termoplástica o plástica en frío) y sembrado automático/manual simultáneo de microesferas de vidrio, garantizando espesores, dotaciones y anchos uniformes según el Artículo 700 del PG-3.
3. **Control y secado:** Proteger la zona mediante balizamiento provisional durante el tiempo de secado para evitar huellas del tráfico. Verificar visualmente la definición de los bordes, la adherencia, la retrorreflexión y la resistencia al deslizamiento (CRT).

## Medición
* **Unidad de medida:** Metro cuadrado (m²) de superficie neta pintada (para cebreados y bandas de paso de peatones) o Unidad (ud) ejecutada (para símbolos, flechas, leyendas e inscripciones complejas).
* **Criterio:** Medición o recuento nulo de duplicidades sobre plano o geometría realmente pintada e inspeccionada en obra.

## Valoración
El precio unitario (€/m² o €/ud) incluye:
* Suministro, transporte y acopio de pinturas, disolventes, microesferas y productos de imprimación.
* Mano de obra, maquinaría de trazado/pintado, plantillas, herramientas y medios auxiliares.
* Replanteo premarcado, preparación y limpieza previa de la superficie del firme.
* Medios de balizamiento provisional y protección de las marcas durante el periodo de secado.