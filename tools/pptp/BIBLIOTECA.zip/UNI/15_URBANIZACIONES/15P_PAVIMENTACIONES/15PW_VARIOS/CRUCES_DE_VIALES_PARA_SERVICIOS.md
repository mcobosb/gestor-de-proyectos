# Cruces de viales para servicios

**Clasificación:** 15PW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Canalizaciones transversales que permiten el paso de servicios bajo el viario.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 171–173. Transcripción para trazabilidad.

Son las canalizaciones transversales que permiten los cruces de viales de todos los servicios. Se ejecutarán simultáneamente a la construcción de acometidas de alcantarillado.

## Ejecución

Coordinar servicios y ejecutar antes de las capas de firme. Verificar recubrimiento, resistencia del conjunto y protecciones según las cargas y el titular de cada red. Mantener separaciones y reservas previstas y documentar cotas y ubicación antes del relleno.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 174–175. Transcripción para trazabilidad.

Se ha de realizar su ejecución previa a la realización de la base granular, de esta manera se evitará la contaminación de la subbase.

## Medición y valoración

Medir en m dentro de la conducción correspondiente salvo partida específica. El original incluye su protección en la tubería si el presupuesto no dispone lo contrario.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 176–178. Transcripción para trazabilidad.

Salvo la indicación en contrario, los cruces de viales se medirán por ml realmente ejecutados y dentro de la unidad de conducción a que pertenezcan.
Se considera, salvo indicación en contrario del presupuesto, que la protección de la tubería en el cruce se encuentra incluida en el precio de la tubería.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
