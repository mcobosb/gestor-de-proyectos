# Cruces de viales para servicios - Común

**Clasificación:** 15PW  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Obras complementarias y zanjas en viales  

## Descripción
Ejecución de canalizaciones transversales bajo calzadas o espacios viarios destinadas al paso y protección de servicios urbanos (agua, alcantarillado, electricidad, alumbrado, telecomunicaciones o gas), incluyendo excavación de zanja, colocación de prismas/tubos de protección, protecciones mecánicas o prismas de hormigón, y relleno/compactación del prisma antes de la extensión del firme.

## Ejecución
1. **Planificación y coordinación:** Coordinar la ejecución de los cruces de forma simultánea con las acometidas de alcantarillado y con anterioridad al extendido de la subbase granular y del firme, evitando la contaminación del material de asiento o la rotura posterior de las capas pavimentadas.
2. **Zanja y colocación:** Excavación de la zanja transversal respetando los recubrimientos mínimos de cada servicio y las distancias de seguridad entre redes según la normativa sectorial aplicable (REBT, CTE, ordenanzas municipales o especificaciones de las compañías suministradoras). Tendido de conductos, colocación de separadores/distanciadores y ejecución de la protección (prismas de hormigón HM-20, losas de protección o dado de envolvente según planos).
3. **Relleno y control:** Relleno y compactación de la zanja mediante suelo seleccionado o material granular hasta el 100% del Próctor Modificado para evitar asientos diferenciales bajo la futura calzada. Disponer cinta de señalización con aviso de la red correspondiente y registrar topográficamente las cotas y coordenadas reales del cruce en los planos *as-built* previa al tapado.

## Medición
* **Unidad de medida:** Metro lineal (m) de canalización o conducción a la que pertenece el cruce (salvo existencia de partida específica desglosada en el cuadro de precios aprobado).
* **Criterio:** Longitud neta realmente ejecutada de cruce viario, medida entre bordes exteriores del ancho del vial o entre caras de pozos/arquetas de conexión.

## Valoración
* **Abono:** La protección del tubo en el cruce de vial se considera repercutida e incluida dentro del precio unitario de la propia conducción a la que da servicio, salvo que el presupuesto contemple una partida específica para el cruce.
* **Incluye:** Excavación en zanja, agotamiento o achique si procede, suministro y tendido de los tubos/fundas de protección, prisma de hormigón de envolvente o losas de reparto de cargas, cintas plásticas de señalización, relleno de zanja con suelo seleccionado compactado al 100% PM, reposición de capas base y toma de datos topográficos.