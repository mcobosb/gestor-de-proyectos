# Pavimento de aceras con losas de hormigón - Común

**Clasificación:** 15PP  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Pavimentos peatonales  

## Descripción
Suministro, trazado, asentamiento, rejuntado y sellado de pavimento peatonal en aceras mediante losas prefabricadas de hormigón de dimensiones 40 × 20 × 8 cm sin bisel, asentadas sobre una capa de arrocillo/grava fina de 3 a 4 cm de espesor y losa de apoyo de hormigón in situ (según sección de proyecto), sobre subbase compactada.

## Ejecución
1. **Previos y preparación del soporte:** Verificación de la compactación de la subbase/relleno de acera mediante suelo seleccionado al 95% del Próctor Modificado. Encofrado perimetral de huecos para alcorques, registros y bordes. Extendido y nivelación de la losa de hormigón de apoyo y posterior extendido de la cama de asiento (arrocillo de 3-4 cm) mediante maestreado con barra a la cota y pendiente transversal adecuada (≤ 2% para garantizar itinerario peatonal accesible según la Orden TMA/851/2021; 1,5% a 3% según sección teórica).
2. **Colocación de piezas:** Asentamiento a cordel de las losas de hormigón 40 × 20 × 8 cm (cumpliendo norma UNE-EN 1339), garantizando la ausencia de cejas o balanceos. Ejecución del dibujo, alineación y color aprobados por la Dirección Facultativa. Evitar remates o cortes inferiores a la mitad del tamaño de la pieza. En pozos de registro, orientar las piezas en disposición radial.
3. **Rejuntado y compacto:** Extendido de arena fina seca sobre toda la superficie para el sellado de juntas. Compactación/taqueado de las losas mediante plancha vibrante con suela de protección de caucho o pisón de madera. Barrido y repetidos sellados de junta con arena (con riego en forma de lluvia si se emplea agua) hasta el entacado y sellado definitivo de la rodadura.

## Medición
* **Unidad de medida:** Metro cuadrado (m²) de pavimento de losas de hormigón completamente terminado.
* **Criterio:** Superficie neta ejecutada in situ y aceptada por la Dirección Facultativa, midiendo de borde a borde de delimitaciones/bordillos y descontando huecos no pavimentados (alcorques, imbornales, registros superiores a la tolerancia).

## Valoración
El precio unitario (€/m²) includes:
* Suministro, carga, transporte, descarga y acopio de las losas de hormigón 40 × 20 × 8 cm sin bisel, arrocillo/grava de la cama de asiento y arena de sellado.
* Nivelación y perfilado del soporte, encofrados auxiliares en alcorques, arquetas y encuentros.
* Extendido y maestreado de la cama de arrocillo.
* Colocación, replanteo, corte de piezas a disco, sentado, taqueado vibrante y barridos sucesivos para sellado de juntas.
* Mano de obra, maquinaría, herramientas y medios auxiliares necesarios para la completa terminación de la unidad de obra.