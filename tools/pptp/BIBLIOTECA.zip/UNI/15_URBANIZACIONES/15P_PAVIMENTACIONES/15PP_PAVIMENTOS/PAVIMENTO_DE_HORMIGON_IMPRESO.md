# Pavimento de hormigón impreso

**Clasificación:** 15PP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Pavimento continuo de hormigón con acabado estampado, colorante y tratamiento superficial.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 973–974. Transcripción para trazabilidad.

## Ejecución

Dimensionar losa, soporte y juntas y comprobar cotas y pendientes. Extender y compactar el hormigón conforme a la normativa aplicable, incorporar los productos compatibles en el momento prescrito y estampar sin comprometer el curado. Ejecutar juntas, limpiar y sellar con el sistema aprobado, comprobando deslizamiento y accesibilidad en uso peatonal.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 975–990. Transcripción para trazabilidad.

Operaciones preparatorias:
    1. Preparación del terreno.
    2. Compactación del terreno al 100% PROCTOR NORMAL.
    3. Saneamiento y preparación de la base en caso de recrecidos.
    4. Cálculo y dimensionamiento de la losa indicado por la Dirección Facultativa.
    5. Descripción y situación de las juntas de dilatación y retracción proyectadas por la Dirección de la obra.
    6. Estar colocados los bordillos o en su caso encofrados perimetrales.
Ejecución:
    1. Colación y extendido del hormigón según lo dispuesto por la EH 91.
    2. Nivelado y fratasado manual del hormigón.
    3. Suministro y aplicación manual del producto colorante.
    4. Suministro y aplicación manual del producto desencofrante y de curado.
    5. Estampado del hormigón con el molde elegido, esta operación se realiza mientras el hormigón siga en el estado de fraguado plástico.
    6. Corte de juntas de dilatación y retracción.
    7. Una vez endurecido el hormigón, se procede a la limpieza con agua a presión de toda la superficie.
    8. Suministro y aplicación del componente de sellado.

## Medición y valoración

Por m² realmente ejecutados conforme a 5.18.2 y a la sección completa definida en su precio.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1166–1167. Transcripción para trazabilidad.

Se medirá y abonará por metros cuadrados (m2) realmente ejecutados tal y como se marca en planos y en el Presente Pliego.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
