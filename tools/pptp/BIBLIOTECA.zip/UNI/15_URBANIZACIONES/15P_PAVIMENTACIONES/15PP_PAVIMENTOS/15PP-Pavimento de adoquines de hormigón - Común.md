# Pavimento de adoquines de hormigón - Común

**Clasificación:** 15PP  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Pavimentos peatonales  

## Descripción
Suministro, replanteo, extensión de cama de asiento, colocación, taqueado y sellado de juntas de pavimento de adoquines prefabricados de hormigón sobre base o subbase compactada, confinado por bordillos o rígolas, conforme a las especificaciones de proyecto y la norma UNE-EN 1338.

## Ejecución
1. **Previos y preparación del soporte:** Nivelación y compactación de la subbase/capa base a la cota y pendientes transversales teóricas (1,5% a 3%, garantizando la accesibilidad según Orden TMA/851/2021). Extendido y maestreado uniforme de la cama de asiento (arena gruesa lavada o mortero seco según proyecto) mediante regle longitudinal.
2. **Colocación de adoquines:** Asentamiento a cordel de las piezas de hormigón según el patrón o aparejo definido en planos. Evitar el uso de piezas cortadas de dimensión inferior a la mitad del tamaño original. En remates perimetrales y pozos de registro, orientar la dimensión mayor del adoquín de forma radial al centro del pozo en una o dos hileras.
3. **Rejuntado, vibrado y sellado:** Extendido de arena fina seca sobre la totalidad de la superficie para el sellado de juntas. Compactación/taqueado mediante bandeja vibrante equipada con suela de neopreno/caucho o pisón de madera. Extendido de arena y barridos sucesivos (aplicando agua en forma de lluvia fina si procede) repitiendo el proceso hasta conseguir el entacado y cerrado total de las juntas. Salvo prescripción expresa con mortero coloreado, no se rejuntará con cemento.

## Medición
* **Unidad de medida:** Metro cuadrado (m²) de pavimento de adoquines de hormigón completamente ejecutado y recibido.
* **Criterio:** Superficie neta realmente ejecutada in situ sobre plano, midiendo entre caras internas de bordillos o confinamientos y descontando alcorques o registros no pavimentados.

## Valoración
El precio unitario (€/m²) incluye:
* Suministro, transporte, descarga y acopio de los adoquines prefabricados de hormigón, material de la cama de asiento (arena/mortero) y arena de sellado.
* Preparación, nivelación y maestreado de la cama de asiento.
* Colocación de adoquines, replanteo, cortes a disco, remates perimetrales y disposición radial en pozos de registro.
* Compactación con plancha vibrante con protección, aportación de arena de sellado, riegos en lluvia y barridos sucesivos.
* Mano de obra, maquinaria, herramientas y medios auxiliares necesarios para la completa terminación de la partida.