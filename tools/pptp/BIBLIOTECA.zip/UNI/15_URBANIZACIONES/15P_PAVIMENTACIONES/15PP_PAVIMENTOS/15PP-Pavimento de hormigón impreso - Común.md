# Pavimento de hormigón impreso - Común

**Clasificación:** 15PP  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Pavimentos peatonales  

## Descripción
Ejecución de pavimento continuo de hormigón in situ con acabado superficial coloreado, texturado/estampado mediante moldes en estado plástico, curado, corte de juntas y aplicación de resina de sellado, sobre base compactada confinado por bordillos o encofrados perimetrales.

## Ejecución
1. **Previos y preparación del soporte:** Nivelación y compactación de la subbase al 100% del Próctor Normal (o saneamiento de la base en caso de recrecidos). Replanteo de pendientes y cotas respetando los límites de accesibilidad (máximo 2% transversal según Orden TMA/851/2021). Verificación del encofrado perimetral o bordillos ya asentados.
2. **Vertido, coloreado y estampado:** Colocación, extendido, nivelado y fratasado manual del hormigón según especificaciones del cálculo de la losa y normativa de hormigón estructural (EAE/Código Técnico). Espolvoreado e incorporación manual del rodapies/endurecedor colorante y posterior aplicación de desmoldeante líquido o en polvo. Estampado de la superficie con los moldes seleccionados mientras el hormigón permanece en fase plástica.
3. **Corte de juntas, limpieza y sellado:** Ejecución de los cortes de las juntas de retracción y dilatación con cortadora de disco a los momentos e intervalos definidos por la Dirección Facultativa. Lavado con agua a presión de la superficie endurecida para eliminar restos de desmoldeante. Aplicación de la resina de curado y sellado final para garantizar protección superficial, durabilidad y resistencia al deslizamiento.

## Medición
* **Unidad de medida:** Metro cuadrado (m²) de pavimento de hormigón impreso totalmente terminado.
* **Criterio:** Superficie neta ejecutada in situ sobre plano, medida de borde a borde de encofrado o cara interior de bordillo, descontando huecos no pavimentados (registros o alcorques).

## Valoración
El precio unitario (€/m²) incluye:
* Compactación y preparación de la subbase/superficie de apoyo.
* Suministro, vertido, extendido, regleado y fratasado del hormigón.
* Suministro y aplicación del endurecedor/colorante, desmoldeante y resina final de sellado y curado.
* Utilización de moldes de estampado, cortes de juntas de retracción/dilatación y sellado de las mismas.
* Limpieza final de la superficie con agua a presión.
* Mano de obra, herramientas, maquinaria y medios auxiliares requeridos para la completa ejecución de la partida.