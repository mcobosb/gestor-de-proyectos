# Soleras - Común

**Clasificación:** 15PS  
**Capítulo:** Urbanizaciones  
**Familia:** Pavimentaciones  

## Descripción
Suministro, preparación del soporte, vertido, extendido, armado, fratasado/acabado, curado y ejecutado de juntas en soleras de hormigón in situ para bases de pavimentos peatonales, calzadas, losas de apoyo o superficies de urbanización exterior, conforme a los espesores, armados y resistencias de proyecto.

## Ejecución
1. **Previos y preparación del soporte:** Nivelación y compactación de la subbase/terreno de apoyo. Colocación de lámina impermeable/desolidarizante si procede y encofrados perimetrales. Replanteo de pendientes de drenaje y accesibilidad (máximo 2% transversal según Orden TMA/851/2021). Posicionamiento del armado (mallazo electrosoldado o fibras) sobre separadores homologados para garantizar el recubrimiento exigido.
2. **Vertido y acabado:** Vertido y extendido del hormigón según especificaciones del Código Estructural. Regleado, vibrado para eliminación de coqueras y fratasado manual o mecánico según la textura y acabado final de superficie especificado (fratasado fino, enreglado, impreso o desbastado).
3. **Juntas y curado:** Ejecución de juntas de retracción/dilatación (mediante corte con disco o juntas plásticas/fresadas) respetando la modulación y profundidad de proyecto. Aplicación de producto o tratamiento de curado inmediatamente después del fratasado final. Comprobar encuentros enrasados con tapas de registro, imbornales y bordillos para evitar barreras arquitectónicas.

## Medición
* **Unidad de medida:** Metro cuadrado (m²) de solera de hormigón con espesor fijado en la partida, o Metro cúbico (m³) de hormigón vertido y vibrado en solera (según desglose del cuadro de precios aprobado).
* **Criterio:** Superficie o volumen neto realmente ejecutado sobre plano y comprobado in situ, descontando alcorques o huecos sin hormigonar.

## Valoración
El precio unitario (€/m² o €/m³) incluye:
* Preparación y perfilado de la superficie de apoyo, láminas separadoras y encofrados perimetrales.
* Suministro, vertido, vibrado, regleado y fratasado del hormigón.
* Suministro, corte y colocación de armaduras (mallazo electrosoldado, separadores o fibras estructurales).
* Ejecución, modulación y sellado de juntas de dilatación y retracción.
* Suministro y aplicación de productos de curado superficial.
* Mano de obra, maquinaria, herramientas y medios auxiliares necesarios para la completa ejecución de la solera.