# Mezcla bituminosa AC32 BASE G - Común

**Clasificación:** 15PC  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Firmes y mezclas bituminosas  

## Descripción
Fabricación, transporte, extendido y compactado de mezcla bituminosa en caliente tipo AC32 BASE G (capa de base de granulometría gruesa con tamaño máximo de árido de 32 mm), elaborada con betún asfáltico 50/70 (contenido ~4,9%), áridos de machaqueo de cantera ofítica (LA ≤ 25, IL ≤ 30) y filler de aportación, extendida sobre la subbase o capa inferior debidamente acondicionada y tratada con riego de imprimación o adherencia.

## Ejecución
1. **Previos y fórmula de trabajo:** Formulación de la composición de la mezcla, aprobación por la Dirección Facultativa y ejecución del tramo de prueba obligatorio según el Art. 542 del PG-3. Comprobar la limpieza y regularidad de la superficie existente, la adecuada rotura del riego y la ausencia de agua o barro.
2. **Fabricación y transporte:** Dosificación ponderal en central (al menos 4 fracciones independientes de árido) a temperatura de mezclado ≤ 165 °C. Transporte en camiones limpios pulverizados con antiadherente no derivado del petróleo y cubiertos con lona para evitar pérdidas de temperatura durante el trayecto.
3. **Extendido y compactación:** Extendido continuo mediante extendedora autopropulsada con sistema automático de nivelación. La temperatura de la mezcla en la descarga no bajará de 130 °C. Compactación inmediata mediante tren compuesto por rodillo vibratorio metálico y compactador neumático de ruedas lisas con faldones aislantes, hasta conseguir la densidad exigida (≥ 98% del Marshall de referencia) sin roturas de grano. Escalonamiento de juntas longitudinales (≥ 15 cm) y transversales (≥ 5 m) respecto a las capas superiores.
4. **Control y recepción:** Extracción de testigos tras el enfriamiento para comprobación de espesores, densidad *in situ*, contenido de huecos (mediante compactación giratoria o vibratoria para D > 22 mm según norma UNE-EN 12697-8) y resistencia conservada tras inmersión (ITSR ≥ 80%).

## Medición
* **Unidad de medida:** Tonelada (t) de mezcla bituminosa AC32 BASE G efectivamente fabricada, extendida y compactada en obra.
* **Criterio:** Peso neto comprobado mediante tiques de báscula oficial a la entrada de la obra, limitado al volumen teórico estipulado en los perfiles transversales del proyecto.

## Valoración
El precio unitario (€/t) incluye:
* Suministro, acopio, manipulación y tratamiento de áridos ofíticos de machaqueo, filler y ligante asfáltico 50/70.
* Fabricación de la mezcla en central, aditivos, energía y combustible.
* Transporte de la mezcla a obra con protección térmica mediante lonas.
* Extendido mecánico con extendedora autopropulsada, compactación con equipos metálicos y neumáticos y remates mecánicos/manuales de bordes.
* Soluciones antiadherentes autorizadas, corte vertical y ejecución de juntas longitudinales y transversales.
* Ensayos de laboratorio para control de recepción (granulometría, densidad giratoria/vibratoria, huecos, ITSR y extracción de testigos).