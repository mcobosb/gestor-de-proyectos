# Mezcla bituminosa AC16 SURF S - Común

**Clasificación:** 15PC  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Firmes y mezclas bituminosas  

## Descripción
Fabricación, transporte, extendido y compactado de mezcla bituminosa en caliente tipo AC16 SURF S (capa de rodadura semidensa con tamaño máximo de árido de 16 mm), elaborada con betún asfáltico 50/70 (contenido ~4,9%), áridos de machaqueo de cantera ofítica (LA ≤ 25, IL ≤ 30) y filler de aportación, sobre la superficie previa dotada del correspondiente riego de adherencia o imprimación.

## Ejecución
1. **Previos y fórmula de trabajo:** Aprobación de la fórmula de trabajo y realización del tramo de prueba conforme al Art. 542 del PG-3. Comprobar la preparación y limpieza de la capa inferior, la rotura completa de la emulsión del riego preexistente y la ausencia de agua o lodos.
2. **Fabricación y transporte:** Mezclado en central con dosificación ponderal garantizando recubrimiento total del árido. Temperatura máxima de mezcla ≤ 165 °C. Transporte en camiones con caja limpia tratada con líquido antiadherente no derivado del petróleo y protegida obligatoriamente con lona para evitar pérdidas térmicas.
3. **Extendido y compactación:** Extendido continuo mediante extendedora autopropulsada con guiado de nivelación y calefacción en juntas. La mezcla llegará a la descarga y extendedora a una temperatura ≥ 130 °C. Compactación inmediata mediante equipo mixto (rodillo metálico vibratorio/estático y compactador de neumáticos con faldones) hasta alcanzar la densidad exigida (≥ 98% del Marshall de fórmula), sin arrollamientos ni rotura de áridos. Solape de juntas longitudinales (≥ 15 cm) y transversales cortadas a bisel vertical con aporte de riego de adherencia.
4. **Control de recepción:** Verificación del espesor, densidad in situ, contenido de huecos, macrotextura superficial (ensayo del círculo de arena) y resistencia al deslizamiento (CRT) antes de la apertura al tráfico.

## Medición
* **Unidad de medida:** Tonelada (t) de mezcla bituminosa AC16 SURF S realmente fabricada, extendida y compactada en obra.
* **Criterio:** Peso neto justificado mediante tiques de báscula oficial de la central comprobados in situ, limitado al volumen teórico de proyecto según las secciones teóricas aprobadas.

## Valoración
El precio unitario (€/t) incluye:
* Suministro, acopio y preparación de áridos ofíticos, filler de aportación y ligante bituminoso 50/70.
* Fabricación de la mezcla en central, aditivos, combustible y energía consumida.
* Transporte de la mezcla desde central hasta el punto de vertido en obra con protección de lonas.
* Extendido mecánico con extendedora, compactación con equipos metálicos y neumático y remate manual de esquinas/juntas.
* Corte de juntas, líquido antiadherente de cajas y tratamiento de bordes.
* Ensayos de control de calidad (granulometría, Marshall, extracción de testigos, macrotextura y CRT).