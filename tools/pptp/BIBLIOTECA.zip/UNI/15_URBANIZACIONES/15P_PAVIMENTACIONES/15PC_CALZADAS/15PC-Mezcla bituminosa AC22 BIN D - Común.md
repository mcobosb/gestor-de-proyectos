# Mezcla bituminosa AC22 BIN D - Común

**Clasificación:** 15PC  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Firmes y mezclas bituminosas  

## Descripción
Fabricación, transporte, extendido y compactado de mezcla bituminosa en caliente tipo AC22 BIN D (capa intermedia de granulometría densa con tamaño máximo de árido de 22 mm), elaborada con betún asfáltico 50/70 (contenido ~4,9%), áridos de machaqueo de cantera ofítica (LA ≤ 25, IL ≤ 30) y filler de aportación, extendida sobre capa de base debidamente tratada con riego de adherencia.

## Ejecución
1. **Previos y fórmula de trabajo:** Definición y aprobación de la fórmula de trabajo específica para la capa intermedia y verificación en el tramo de prueba conforme al Art. 542 del PG-3. Comprobación de la superficie existente, eliminación de excesos de ligante y verificación de la rotura completa de la emulsión del riego de adherencia.
2. **Fabricación y transporte:** Mezclado en central continua o discontinua con dosificación ponderal (mínimo 4 fracciones de árido) y temperatura de fabricación ≤ 165 °C. Transporte en camiones con caja tratada con antiadherente no derivado del petróleo y protegida obligatoriamente con lona protectora.
3. **Extendido y compactación:** Extendido mecánico mediante extendedora autopropulsada con nivelación automática y calefacción de juntas a temperatura de descarga ≥ 130 °C. Compactación inmediata mediante equipo mixto (compactador vibratorio de rodillo metálico y compactador de neumáticos con faldones aislantes) a la mayor temperatura posible hasta alcanzar la densidad especificada (≥ 98% de la densidad de referencia). Solape de juntas longitudinales (≥ 15 cm de desfase respecto a capas adyacentes) y transversales (≥ 5 m de desfase).
4. **Control de recepción:** Extracción de testigos para verificación de espesores, densidad *in situ*, contenido de huecos y comprobación de la sensibilidad al agua (resistencia conservada ITSR ≥ 80%).

## Medición
* **Unidad de medida:** Tonelada (t) de mezcla bituminosa AC22 BIN D efectivamente fabricada, extendida y compactada.
* **Criterio:** Peso neto justificado mediante tiques de báscula oficial de central comprobados en obra, limitado al volumen teórico derivado de las secciones del proyecto.

## Valoración
El precio unitario (€/t) incluye:
* Suministro, acopio y manipulación de áridos ofíticos, filler y ligante 50/70.
* Fabricación de la mezcla en central, energía, aditivos y control de proceso.
* Transporte desde la planta de asfaltado hasta el tajo de obra con lona de protección térmica.
* Extendido mecánico, compactado con equipos metálicos y neumáticos y ejecuciones de juntas.
* Líquidos antiadherentes autorizados y preparación de bordes/cortes verticales de juntas.
* Ensayos de laboratorio de recepción (granulometría, densidad Marshall/giratoria, huecos, ITSR y extracción de testigos).