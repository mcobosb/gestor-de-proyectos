# Árido fino para mezclas bituminosas

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Fracción fina de los áridos de la mezcla bituminosa, procedente de trituración según la prescripción del proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 91–91. Transcripción para trazabilidad.

- Árido fino. Deberá proceder de la trituración de piedra de cantera o grava natural en su totalidad.

## Ejecución

Comprobar procedencia, limpieza, granulometría y compatibilidad con la fórmula de trabajo. Acopiar por separado y dosificar de forma uniforme, corrigiendo la humedad cuando proceda, conforme al artículo 542 del PG-3.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 673–677. Transcripción para trazabilidad.

La carga de cada una de las tolvas de áridos en frío se realizará de forma que su contenido esté siempre comprendido entre el cincuenta y el cien por ciento (50% a 100%) de su capacidad, sin rebosar.
Para mezclas densas y semidensas la alimentación del árido fino, aun cuando éste fuera de un único tipo y granulometría, se efectuará dividiendo la carga entre dos (2) tolvas.
Si se utilizase material procedente del fresado o trituración de capas de mezclas bituminosas, en proporción superior al quince por ciento (> 15%) de la masa total de la mezcla, se procederá como se especifica a continuación:
- En centrales cuyo secador no sea a la vez mezclador, si la alimentación de éste fuera discontinua, para cada amasada, después de haber introducido los áridos, se pesarán e introducirán los áridos procedentes de mezclas bituminosas, y después de un tiempo de disgregación, calentado y mezcla, se agregará el ligante hidrocarbonado, y en su caso los aditivos, y se continuará la operación de mezcla durante el tiempo especificado en la fórmula de trabajo.
Si la alimentación fuese continua, los áridos procedentes de mezclas bituminosas se incorporarán junto al resto de los áridos en la zona de pesaje en caliente a la salida del secador.

## Medición y valoración

Su suministro y manipulación quedan incluidos en la mezcla bituminosa, salvo partida contractual independiente.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad.

Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
