# Árido grueso para mezclas bituminosas

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Fracción gruesa procedente de machaqueo para las mezclas del firme; el original especifica piedra ofítica y límites propios de calidad.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 87–90. Transcripción para trazabilidad.

- Árido grueso. Deberá ser de machaqueo y trituración de piedra de cantera ofítica; se compondrá de elementos limpios, sólidos y resistentes, de uniformidad razonable, exentos de polvo, suciedad, arcilla u otras materias extrañas.
- El coeficiente de desgaste medido por el ensayo de Los Ángeles será inferior o igual a 25. Para una correcta adhesividad, la pérdida de resistencia en el ensayo de inmersión-compresión no rebasará el 25%.
- El índice de lajas será inferior o igual a 30.
- Queda totalmente prohibido el empleo de árido grueso procedente de escombreras.

## Ejecución

Aprobar cantera y características por fracciones, recibir resultados de los ensayos exigidos por el artículo 542 del PG-3 y acopiar separadamente sobre superficie limpia. Evitar contaminación y segregación; verificar las propiedades específicas exigidas a la capa de rodadura.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 673–677. Transcripción para trazabilidad.

La carga de cada una de las tolvas de áridos en frío se realizará de forma que su contenido esté siempre comprendido entre el cincuenta y el cien por ciento (50% a 100%) de su capacidad, sin rebosar.
Para mezclas densas y semidensas la alimentación del árido fino, aun cuando éste fuera de un único tipo y granulometría, se efectuará dividiendo la carga entre dos (2) tolvas.
Si se utilizase material procedente del fresado o trituración de capas de mezclas bituminosas, en proporción superior al quince por ciento (> 15%) de la masa total de la mezcla, se procederá como se especifica a continuación:
- En centrales cuyo secador no sea a la vez mezclador, si la alimentación de éste fuera discontinua, para cada amasada, después de haber introducido los áridos, se pesarán e introducirán los áridos procedentes de mezclas bituminosas, y después de un tiempo de disgregación, calentado y mezcla, se agregará el ligante hidrocarbonado, y en su caso los aditivos, y se continuará la operación de mezcla durante el tiempo especificado en la fórmula de trabajo.
Si la alimentación fuese continua, los áridos procedentes de mezclas bituminosas se incorporarán junto al resto de los áridos en la zona de pesaje en caliente a la salida del secador.

## Medición y valoración

Componente incluido en el precio de fabricación y puesta en obra de la mezcla. No tiene abono adicional salvo partida de suministro expresamente aprobada.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad.

Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
