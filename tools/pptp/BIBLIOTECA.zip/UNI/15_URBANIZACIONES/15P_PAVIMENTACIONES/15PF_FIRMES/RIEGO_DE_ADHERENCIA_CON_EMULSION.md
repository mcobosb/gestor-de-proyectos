# Riego de adherencia con emulsión bituminosa

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Aplicación uniforme de emulsión para asegurar la unión entre capas del firme. El original identifica el ligante como C60B3.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 102–106. Transcripción para trazabilidad.

El ligante a emplear será una emulsión bituminosa C60B3.
Dosificación del ligante.
La dosificación del ligante a utilizar será mayor de 250g/m². Esta dosificación podrá ser modificada a la vista de los ensayos realizados en obra, previa autorización del Ingeniero de Construcción.

## Ejecución

Aplicar el artículo 531 y el artículo 214 del PG-3: limpiar y comprobar el soporte, proteger elementos adyacentes, calibrar el distribuidor y pulverizar uniformemente. Fijar y comprobar la dotación de ligante residual, respetar la rotura de la emulsión y evitar tránsito o contaminación antes de extender la capa superior.

## Medición y valoración

Medir en m² realmente ejecutados conforme al original únicamente cuando no esté incluido en el precio de la mezcla. El transporte y la aplicación forman parte del precio descrito.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 107–108. Transcripción para trazabilidad.

El ligante se abonará por m² realmente ejecutado en obra. No se abonará en transporte del ligante ni la ejecución del riego de adherencia por estar incluidos en el precio anterior.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad.

Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
