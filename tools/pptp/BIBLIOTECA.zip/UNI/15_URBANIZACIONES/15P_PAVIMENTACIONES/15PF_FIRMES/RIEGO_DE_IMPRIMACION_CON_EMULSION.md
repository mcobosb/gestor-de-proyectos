# Riego de imprimación con emulsión bituminosa

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Tratamiento de una capa granular mediante ligante adecuado para preparar su unión con la capa bituminosa. El original designa la emulsión C60BF4.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 109–113. Transcripción para trazabilidad.

El ligante a emplear será una emulsión bituminosa tipo C60BF4.
Dosificación de los materiales.
La dosificación del ligante será mayor de 500g/m². Esta dosificación podrá ser modificada a la vista de los ensayos realizados en obra, previa autorización del Ingeniero de Construcción.

## Ejecución

Aplicar los artículos 530 y 214 del PG-3: comprobar el soporte granular, retirar polvo suelto, ajustar su estado superficial y efectuar riego uniforme con dotación aprobada según absorción. Esperar la absorción y curado necesarios, tratar excesos según procedimiento aprobado y proteger la superficie hasta el extendido.

## Medición y valoración

Medir en m² según el documento, sólo si la partida de mezcla no incluye ya la imprimación. Transporte y puesta en obra están incluidos en el precio descrito.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 114–115. Transcripción para trazabilidad.

El ligante se medirá y abonará por m² realmente ejecutados. No se abonará el transporte de los materiales ni la ejecución y puesta en obra del riesgo por estar incluidos en los precios anteriores.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad.

Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
