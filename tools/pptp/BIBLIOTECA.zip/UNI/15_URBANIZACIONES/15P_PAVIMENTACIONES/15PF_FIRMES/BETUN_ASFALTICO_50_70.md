# Betún asfáltico 50/70

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Ligante hidrocarbonado de las mezclas bituminosas descritas en 3.7, de grado 50/70.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 81–86. Transcripción para trazabilidad.

Se define como mezcla bituminosa la combinación de un betún asfáltico, áridos con granulometría continua, polvo mineral y, eventualmente, aditivos, de manera que todas las partículas del árido queden recubiertas por una película homogénea de ligante, cuyo proceso de fabricación y puesta en obra deben realizarse a una temperatura muy superior a la del ambiente.
Se utilizarán la tipo AC32 BASE G, capa base de granulometría gruesa y con tamaño máximo de árido de 32mm; como capa intermedia la tipo AC22 BIN D, capa base de granulometría densa y con tamaño máximo de árido de 22mm y la AC16 SURF S, capa de rodadura semidensa y con tamaño máximo de árido de 16mm.
Condiciones que han de cumplir los materiales.
- Ligante hidrocarbonado. El ligante hidrocarbonado a emplear en la mezcla será betún asfáltico, tipo 50/70. El contenido de ligante en la mezcla será del 4,9 5%.

## Ejecución

Recibir el producto con identificación, documentación de prestaciones que corresponda y trazabilidad. Almacenar y calentar con equipos regulados evitando contaminación y sobrecalentamiento. Dosificar según la fórmula aprobada de cada mezcla; aplicar los artículos 211 y 542 del PG-3.

## Medición y valoración

El documento lo integra en el precio de la mezcla. No se crea abono independiente. Sólo se medirá como suministro separado si existe partida aprobada con unidad y criterio propios.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad.

Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
