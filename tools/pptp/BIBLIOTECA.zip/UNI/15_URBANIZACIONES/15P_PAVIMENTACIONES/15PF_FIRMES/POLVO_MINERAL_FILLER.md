# Polvo mineral o filler para mezclas bituminosas

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Fracción mineral fina recuperada o de aportación que forma parte de la mezcla bituminosa.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 92–94. Transcripción para trazabilidad.

- Filler. Procederá de machaqueo de los áridos o será de aportación como producto comercial. La densidad aparente del filler, determinada por el ensayo de sedimentación en tolueno estará comprendida entre 0,5 0,8g/cm3.
- El coeficiente de emulsibilidad será inferior a 0,6.
- La relación entre polvo mineral y ligante será 1,2.

## Ejecución

Identificar el origen, acreditar sus prestaciones y almacenar evitando humedad y contaminación. Dosificar homogéneamente según la fórmula de trabajo, controlando la proporción respecto al ligante y las prestaciones de la mezcla conforme al artículo 542 del PG-3.

## Medición y valoración

El filler de aportación está incluido expresamente en el precio de la mezcla; no procede duplicar su abono.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad.

Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
