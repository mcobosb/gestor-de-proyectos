# Bordillos prefabricados de hormigón

**Clasificación:** 15PB. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Piezas prefabricadas que delimitan calzadas, aceras y otras superficies, recibidas sobre una base de hormigón.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 179–187. Transcripción para trazabilidad.

Son piezas o elementos prefabricados que asentados sobre la subbase granular mediante un lecho de hormigón con el cual son solidarios sirven para reparar la calzada de las aceras.
Condiciones que han de cumplir los materiales.
El hormigón de asiento será HM 20 con 200 Kg/cm² de resistencia característica.
Los bordillos habrán de cumplir que su resistencia a la compresión en probeta cúbica cortada con sierra circular a los 28 días debe ser como mínimo de 350 Kg/ cm².
Los bordillos deberán ser aceptados previamente por la Dirección de obra, debiendo tener doble capa de terminación.
Se rechazarán en acopio bordillos que presenten defectos, aunque sean debidos al transporte.
No se podrán recepcionar bordillos con tolerancias dimensionales de más de un centímetro, en cualquier caso.

## Ejecución

Recepcionar piezas con geometría, acabado y prestaciones adecuados, comprobar su norma de producto aplicable, habitualmente UNE-EN 1340, y rechazar las dañadas. Replantear alineación y rasante, ejecutar base y refuerzo lateral, colocar piezas y juntas y proteger hasta su estabilidad. Mantener transiciones accesibles y drenaje.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1002–1010. Transcripción para trazabilidad.

EJECUCIÓN DE LAS OBRAS
Se recibirán sobre solera de hormigón H 150, abrigándolos a ambas caras con el mismo material. Las juntas entre piezas se ejecutarán con mortero de cemento y, según la utilización serán de dos tipos:
- Bordillos tipo A 1: La junta será de 2 cm., y se terminará resaltada abrigando las cabezas de los bordillos 1 cm., a cada lado de la misma.
- Bordillos tipo E 3, E 5: La junta será de 1 cm., y se terminará rehundida.
Compresión, absorción y resistencia a flexión. El material que compone cada partida deberá ser homogéneo y de mismo fabricante, con condiciones según albarán ajustadas a las de proyecto.
CONTROL DE LA EJECUCIÓN
Se verificarán la correcta alineación, el ajuste a rasante y la correcta ejecución de las soleras de apoyo y juntas.
La tolerancia en rasante será de 3 mm., al comprobar con regla de 3 m., y en alineación las diferencias en cualquier punto no serán superiores a 1 cm.

## Medición y valoración

Medir en m colocados y aceptados. Incluye base de hormigón y mortero de juntas conforme a 3.15.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 188–189. Transcripción para trazabilidad.

Se medirán y abonarán por ml colocado realmente, quedando incluidos en este precio tanto el hormigón de base dispuesto según planos como el mortero necesario para el rejuntado.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1162–1165. Transcripción para trazabilidad.

Se incluyen en este concepto tanto bordillos en delimitación de zonas de tráfico rodado a peatonal, como los materiales de pavimentación de zonas peatonales.

Se medirán y abonarán por metro lineal (m), colocado perfectamente según las indicaciones del presente Pliego y de los planos.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
