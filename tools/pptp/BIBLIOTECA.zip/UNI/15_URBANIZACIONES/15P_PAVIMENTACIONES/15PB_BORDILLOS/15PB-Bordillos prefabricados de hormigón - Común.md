# Bordillos prefabricados de hormigón - Común

**Clasificación:** 15PB  
**Capítulo:** Pavimentos, firmes y bordillos  
**Familia:** Elementos de delimitación  

## Descripción
Suministro, transporte, colocación y rejuntado de bordillos prefabricados de hormigón de doble capa para la delimitación física de calzadas, aceras, isletas o zonas ajardinadas, recibidos sobre solera/base de hormigón in situ y abrigados lateralmente.

## Ejecución
1. **Previos y recepción:** Replantear alineación y rasantes. Verificar que las piezas cumplan con la norma UNE-EN 1340, posean doble capa de acabado y resistencia mínima a compresión de 350 kg/cm² (35 MPa) a 28 días. Rechazar piezas fisuradas, desportilladas o con desviaciones dimensionales > 1 cm.
2. **Asiento y colocación:** Extender cimiento/solera de asiento de hormigón (HM-20/H-150 según proyecto y espesor de planos) sobre la subbase compactada. Asentar los bordillos a cordel enrasando a la rasante de proyecto. Abrigarlos o zuncharlos por ambas caras con el mismo hormigón para garantizar su traba lateral.
3. **Rejuntado y control:** Rejuntado de piezas con mortero de cemento según tipología (junta de 2 cm resaltada abrigando cabezas para tipo A1; junta de 1 cm rehundida para tipos E3/E5). Comprobar tolerancias finales: máximo 3 mm en rasante con regla de 3 m y desviación máxima de 1 cm en alineación horizontal. Mantener las condiciones de accesibilidad y continuidad de drenaje en vados.

## Medición
* **Unidad de medida:** Metro lineal (m) de bordillo prefabricado colocado, rejuntado y recibido.
* **Criterio:** Longitud neta realmente ejecutada sobre el eje de la alineación comprobada in situ.

## Valoración
El precio unitario (€/m) incluye:
* Suministro, transporte, descarga, acopio y manipulación de las piezas prefabricadas de hormigón.
* Suministro, vertido y ejecución de la solera de asiento de hormigón y el abrigo/respaldo lateral.
* Mortero de cemento para la ejecución y acabado de juntas (resaltadas o rehundidas).
* Replanteo topográfico, regla de enrase, herramientas, corte de piezas y limpieza final.