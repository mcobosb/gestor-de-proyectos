"""
# Huecos - Hormigón

**Clasificación BCCA:** `06BHH`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Hormigón**, dentro de **Huecos**.
Aplicable a las partidas cuyo código BCCA comienza por `06BHH`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06BHH00001 - FÁBRICA 6 cm ESP. CON BLOQUE HUECO HORMIGÓN

**Unidad:** m2.

Fabrica de 6 cm de espesor, con bloque hueco de hormigón de 40x20x6 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante; construida según CTE. Medida a cinta corrida.

### 06BHH00010 - FÁBRICA 9 cm ESP. CON BLOQUE HUECO HORMIGÓN

**Unidad:** m2.

Fabrica de 9 cm de espesor, con bloque hueco de hormigón de 40x20x9 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante; construida según CTE. Medida deduciendo huecos.

### 06BHH00015 - FÁBRICA 12 cm ESP. CON BLOQUE HUECO HORMIGÓN

**Unidad:** m2.

Fabrica de 12 cm de espesor, con bloque hueco de hormigón de 40x20x12 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante; construida según CTE. Medida deduciendo huecos.

### 06BHH00020 - FÁBRICA 15 cm ESP. CON BLOQUE HUECO HORMIGÓN

**Unidad:** m2.

Fabrica de 15 cm de espesor, con bloque hueco de hormigón de 40x20x15 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante; construida según CTE. Medida deduciendo huecos.

### 06BHH00030 - FÁBRICA 20 cm ESP. CON BLOQUE HUECO HORMIGÓN

**Unidad:** m2.

Fabrica de 20 cm de espesor, con bloque hueco de hormigón de 40x20x20 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante; construida según CTE. Medida deduciendo huecos.

### 06BHH00031 - FÁBRICA RESISTENTE 20 cm ESP. BLOQUE DE HORMIGÓN

**Unidad:** m2.

Fabrica resistente de 20 cm de espesor, con bloque hueco de carga de hormigón de 40x20x20 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante; construida según CTE y NCSR-02. Medida deduciendo huecos.

### 06BHH00036 - FÁBRICA RESISTENTE 20 cm ESP. BLOQUE HORMIGÓN C/V

**Unidad:** m2.

Fabrica resistente de 20 cm de espesor, con bloque hueco de carga de hormigón de 40x20x20 cm, a cara vista, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, incluso avitolado de juntas y limpieza de paramentos, con plastificante; construida según CTE y NCSR-02. Medida deduciendo huecos.

### 06BHH00050 - FÁBRICA 20 cm ESP. BLOQUE HORM. BLANCO ESTRIADO C/V

**Unidad:** m2.

Fábrica de 20 cm de espesor, de bloques huecos de hormigón decorativo blanco de 40x20x20 cm, acabado estriado, a una cara vista, recibidos con mortero M5 de cemento blanco BL II/A-L 32,5 N, con plastificante, incluso p.p. de piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH00060 - FÁBRICA 20 cm ESP. BLOQUE HORM. COLOR ESTRIADO C/V

**Unidad:** m2.

Fábrica de 20 cm de espesor, de bloques huecos de hormigón decorativo en color de 40x20x20 cm, acabado estriado, a una cara vista, recibidos con mortero M5 de cemento blanco BL II/A-L 42,5 R, con plastificante, incluso p.p. de piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH00070 - FÁBRICA 20 cm ESP. BLOQUE HORM. GRIS ESTRIADO C/V

**Unidad:** m2.

Fábrica de 20 cm de espesor, de bloques huecos de hormigón decorativo gris de 40x20x20 cm, acabado estriado, a una cara vista, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso p.p. de piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH00080 - FÁBRICA 20 cm ESP. BLOQUE HORM. BLANCO RUGOSO C/V

**Unidad:** m2.

Fábrica de 20 cm de espesor, de bloques huecos de hormigón decorativo blanco de 40x20x20 cm, acabado rugoso, a una cara vista, recibidos con mortero M5 de cemento blanco BL II/A-L 42,5 R, con plastificante, incluso p.p. de piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH00090 - FÁBRICA 20 cm ESP. BLOQUE HORM. COLOR RUGOSO C/V

**Unidad:** m2.

Fábrica de 20 cm de espesor, de bloques huecos de hormigón decorativo en color de 40x20x20 cm, acabado rugoso partido, a una cara vista, recibidos con mortero M5 de cemento blanco BL II/A-L 42,5 R, con plastificante, incluso p.p. de piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH00100 - FÁBRICA 20 cm ESP. BLOQUE HORM. GRIS RUGOSO C/V

**Unidad:** m2.

Fábrica de 20 cm de espesor, de bloques huecos de hormigón decorativo gris de 40x20x20 cm, acabado rugoso partido, a una cara vista, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso p.p. de piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH80000 - FÁBRICA ARMADA 20 cm ESP. BLOQ. HORM. 40x20x20 cm

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón de 40x20x20 cm, para revestir, recibidos con mortero M7,5 de cemento CEM II/A-L 32,5 N, armadura vertical formada por 4 redondos de acero B 500 S de 12 mm de diám. cada m, y armadura horizontal con 2 redondos de 8 mm de diám. cada hilada de bloques, incluso relleno de hormigón, vibrado y piezas especiales; según CTE. Medida deduciendo huecos.

### 06BHH80010 - FÁBRICA ARMADA C/CELOSÍA 20 cm ESP. BLOQ. HORM. 40x20x20 cm

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón de 40x20x20 cm, para revestir, recibidos con mortero M7,5 de cemento CEM II/A-L 32,5 N, armadura vertical formada por 4 redondos de acero B 500 S de 12 mm de diám., cada m, y armadura de acero galvanizado en forma de celosía con recubrimiento de resina epoxi, cada 2 hiladas, incluso relleno de hormigón, vibrado y piezas especiales; según CTE. Medida deduciendo huecos.

### 06BHH80100 - FÁBRICA ARMADA 10 cm ESP. BLOQ. HORM. GRIS 40x20x10 cm C/V

**Unidad:** m2.

Fábrica armada de 10 cm de espesor, de bloques huecos de hormigón gris de 40x20x10 cm, a una cara vista, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, rellenos de hormigón, armadura de acero B 400 S, incluso p.p. avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH80110 - FÁBRICA ARMADA 20 cm ESP. BLOQ. HORM. GRIS 40x20x20 cm C/V

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón gris de 40x20x20 cm, a una cara vista, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, rellenos de hormigón, armadura de acero B 400 S, incluso p.p. de avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH80120 - FÁBRICA ARMADA 20 cm ESP. BLOQ. HORM. GRIS 40x20x20 cm 2 C/V

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón gris de 40x20x20 cm, a dos caras vistas, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, rellenos de hormigón, armadura de acero B 400 S, incluso p.p. de avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH80200 - FÁBRICA ARM. 20 cm ESP. BLOQ. HORM. COLOR LISO 40x20x20 cm C/V

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón liso en color de 40x20x20 cm, a una cara vista, recibidos con mortero M7,5 de cemento CEM II/A-L 32,5 N, armadura triangulada de acero AHT-500 con recubrimiento de resina epoxi, cada 2 hiladas, incluso relleno de hormigón, vibrado, formación de mocheta, piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH80210 - FÁBRICA ARM. 20 cm ESP. BLOQ. HORM. BLANCO ESTR. 40x20x20 cm C/V

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón en color blanco estriado de 40x20x20 cm, a una cara vista, recibidos con mortero M7,5 de cemento CEM II/A-L 32,5 N, armadura triangulada de acero AHT-500 con recubrimiento de resina epoxi, cada 2 hiladas, incluso relleno de hormigón, vibrado, formación de mocheta, piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

### 06BHH80220 - FÁBRICA ARM. 20 cm ESP. BLOQ. HORM. BLAN. LISO 40x20x20 cm 2 C/V

**Unidad:** m2.

Fábrica armada de 20 cm de espesor, de bloques huecos de hormigón blanco de 40x20x20 cm, a dos caras vistas, recibidos con mortero M5 de cemento blanco BL II/A-L 42,5 R, rellenos de hormigón y armadura, incluso p.p. de formación de mocheta, piezas especiales, avitolado de juntas y limpieza de paramentos; según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Huecos

**Clasificación:** 06BH. **Capítulo:** albañilería. **Familia:** fábricas de bloques.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «huecos», dentro de «fábricas de bloques». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Comprobar geometría y resistencia del bloque, juntas y disposición de refuerzos y rellenos cuando estén proyectados.

Para la variante «huecos» se comprobarán expresamente bloque, mortero, rellenos y armaduras de tendel. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
