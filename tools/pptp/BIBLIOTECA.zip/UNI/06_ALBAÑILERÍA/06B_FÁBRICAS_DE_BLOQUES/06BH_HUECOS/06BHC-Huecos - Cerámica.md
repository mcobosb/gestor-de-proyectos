"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Huecos - Cerámica

**Clasificación BCCA:** `06BHC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Cerámica**, dentro de **Huecos**.
Aplicable a las partidas cuyo código BCCA comienza por `06BHC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06BHC80301 - FÁBRICA 4 cm ESP. CON BLOQUE CERÁMICO HUECO 33X15 cm

**Unidad:** m2.

Fabrica de 4 cm de espesor, con bloque ceramico hueco de 33x15x4 cm, recibido con mortero M5 de cemento CEM II/A-L 32,5 N; construido según CTE. Medida a cinta corrida.

### 06BHC80306 - FÁBRICA 8 cm ESP. CON BLOQUE CERÁMICO HUECO 33X11 cm

**Unidad:** m2.

Fabrica de 8 de espesor, con bloque cerámico hueco de 33x11x8 cm, recibido con mortero M5 de cemento CEM II/A-L 32,5 N; construido según CTE. Medida deduciendo huecos.

### 06BHC80311 - FÁBRICA 7 cm ESP. CON BLOQUE CERÁMICO HUECO 40X20 cm

**Unidad:** m2.

Fabrica de 7 cm de espesor, con bloque cerámico hueco de 40x20x7 cm, recibido con mortero M5 de cemento CEM II/A-L 32,5 N; construido según CTE. Medida deduciendo huecos.

### 06BHC80316 - FÁBRICA 12 cm ESP. CON BLOQUE CERÁMICO HUECO 40X17 cm

**Unidad:** m2.

Fabrica de 12 cm de espesor, con bloque cerámico hueco de 40x12x12 cm, recibido con mortero M5 de cemento CEM II/A-L 32,5 N; construido según CTE. Medida deduciendo huecos.

### 06BHC80321 - FÁBRICA 20 cm ESP. CON BLOQUE CERÁMICO HUECO 40X20 cm

**Unidad:** m2.

Fabrica de 20 cm de espesor, con bloque cerámico hueco de 40x20x20 cm, recibido con mortero M5 de cemento CEM II/A-L 32,5 N; construido según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Huecos

**Clasificación:** 06BH. **Capítulo:** albañilería. **Familia:** fábricas de bloques.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «huecos», dentro de «fábricas de bloques». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Comprobar geometría y resistencia del bloque, juntas y disposición de refuerzos y rellenos cuando estén proyectados.

Para la variante «huecos» se comprobarán expresamente bloque, mortero, rellenos y armaduras de tendel. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
