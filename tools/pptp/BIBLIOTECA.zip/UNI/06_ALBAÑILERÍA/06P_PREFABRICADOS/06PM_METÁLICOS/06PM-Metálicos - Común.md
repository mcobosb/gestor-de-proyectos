# Metálicos - Común

**Clasificación:** 06PM. **Capítulo:** albañilería. **Familia:** prefabricados.

## Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «metálicos», dentro de «prefabricados». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Verificar identificación, izado, apoyos y fijación de los prefabricados, sin alterar sus puntos de sujeción.

Para la variante «metálicos» se comprobarán expresamente peso, tolerancias, anclajes y procedimiento de montaje. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
