"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Hormigón - Varios

**Clasificación BCCA:** `06PHW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Hormigón**.
Aplicable a las partidas cuyo código BCCA comienza por `06PHW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06PHW80000 - IMPOSTA DE HORMIGÓN PREFABRICADO 15x24 cm

**Unidad:** m.

Imposta de hormigón prefabricado de 61x21x15 cm, con un vuelo de 10 cm, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso rejuntado. Medida la longitud ejecutada.

### 06PHW80100 - CORNISA HORMIGÓN PREFABRICADO 30X20 cm

**Unidad:** m.

Cornisa de hormigón prefabricado de 30 cm de anchura y 20 cm de vuelo, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso rejuntado. Medida la longitud ejecutada.

### 06PHW80200 - CANECILLO HORMIGÓN BLANCO 88x13 cm

**Unidad:** u.

Canecillo de hormigón blanco de 88x13x10 cm, recibido con mortero M5 de cemento blanco BL II/A-L 42,5 R, con plastificante. Medida la unidad colocada.

### 06PHW80300 - GARGOLA HORMIGÓN BLANCO 6x10 cm

**Unidad:** u.

Gárgola de hormigón polímero blanco, en piezas de 6x10 cm y una longitud de 22 cm, con mortero M5 de cemento blanco BL II/A-L 42,5 R, con plastificante. Medida la unidad colocada.

### 06PHW80400 - GARGOLA HORMIGÓN BLANCO 10x14 cm

**Unidad:** u.

Gárgola de hormigón polímero blanco, en piezas de 10x14 cm y una longitud de 22 cm, con mortero M5 de cemento blanco BL II/A-L 42,5 R, con plastificante. Medida la unidad colocada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### PREFABRICADOS - hormigón

**Clasificación:** 06PH. **Capítulo:** albañilería. **Familia:** prefabricados.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «hormigón», dentro de «prefabricados». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Verificar identificación, izado, apoyos y fijación de los prefabricados, sin alterar sus puntos de sujeción.

Para la variante «hormigón» se comprobarán expresamente peso, tolerancias, anclajes y procedimiento de montaje. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
