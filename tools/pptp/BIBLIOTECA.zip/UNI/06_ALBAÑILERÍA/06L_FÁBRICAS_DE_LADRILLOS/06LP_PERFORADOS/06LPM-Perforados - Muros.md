"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Perforados - Muros

**Clasificación BCCA:** `06LPM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Muros**, dentro de **Perforados**.
Aplicable a las partidas cuyo código BCCA comienza por `06LPM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06LPM00001 - FÁBRICA 1 PIE L/PERF. TALADRO PEQUEÑO

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro pequeño, para revestir, recibido con mortero de cemento M5 (1:6), con plastificante; construida según CTE. Medida deduciendo huecos.

### 06LPM00002 - FÁBRICA 1 PIE L/PERF. TALADRO PEQUEÑO C/V

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro pequeño, a cara vista, recibido con mortero de cemento M5 (1:6), con plastificante, incluso avitolodado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00003 - FÁBRICA 1 PIE L/PERF. TALADRO PEQUEÑO C/V MORT. BAST.

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro pequeño, a cara vista, recibido con mortero bastardo M10 (1:0,5:4) de cemento y cal, incluso avitolado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00111 - FÁBRICA 1 PIE L/PERF. TALADRO GRANDE MORT. BAST.

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, para revestir, recibido con mortero bastardo M5 M10 (1:0,5:4) de cemento y cal; construida según CTE. Medida deduciendo huecos.

### 06LPM00201 - FÁBRICA 1 PIE L/PERF. TALADRO GRANDE C/V

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a cara vista, recibido recibido con mortero de cemento M5 (1:6), con plastificante, incluso avitolodado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00211 - FÁBRICA 1 PIE L/PERF. TALADRO GRANDE C/V MORT. BAST.

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a cara vista, recibido con mortero bastardo M5 M10 (1:0,5:4) de cemento y cal, incluso avitolado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00221 - FÁBRICA 1 PIE L/PERF. TALADRO GRANDE C/V MORT. DE CAL

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a cara vista, recibido con mortero de cal M15 (1:3), incluso avitolado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00301 - FÁBRICA 1,5 PIE L/PERF. TALADRO GRANDE C/V

**Unidad:** m2.

Fábrica de un pie y medio de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a cara vista, recibido recibido con mortero de cemento M5 (1:6), con plastificante, incluso avitolodado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00306 - FÁBRICA 1,5 PIE L/PERF. TALADRO GRANDE 2 C/V

**Unidad:** m2.

Fábrica de un pie y medio de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a dos caras vistas, recibido con mortero de cemento M5 (1:6), con plastificante, incluso avitolodado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00311 - FÁBRICA 1,5 PIE L/PERF. TALADRO GRANDE C/V MORT. BAST.

**Unidad:** m2.

Fábrica de un pie y medio de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a cara vista, recibido con mortero bastardo M5 M10 (1:0,5:4) de cemento y cal, incluso avitolado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM00316 - FÁBRICA 1,5 PIE L/PERF. TALADRO GRANDE C/V MORT. DE CAL

**Unidad:** m2.

Fábrica de un pie y medio de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a cara vista, recibido con mortero de cal M15 (1:3), incluso avitolado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM80000 - FÁBRICA 1 PIE L/PERF. TALADRO PEQUEÑO 2 C/V

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro pequeño, a dos caras vistas, recibido con mortero de cemento M5 (1:6), con plastificante, incluso avitolodado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM80002 - FÁBRICA 1 PIE L/PERF. TALADRO GRANDE 2 C/V

**Unidad:** m2.

Fábrica de un pie de espesor con ladrillo perforado de 24x11,5x5 cm taladro grande, a dos caras vistas, recibido con mortero de cemento M5 (1:6), con plastificante, incluso avitolodado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM80009 - FÁBRICA 1 PIE L/PERF. DE HORMIGÓN C/V

**Unidad:** m2.

Fábrica de un pie de espesor de ladrillo de hormigón perforado de 25x12x5 cm, a cara vista, recibido con mortero de cemento blanco M5 (1:6), con plastificante, incluso avitolado de juntas; construida según CTE. Medida deduciendo huecos.

### 06LPM80050 - FÁBRICA 2 PIES L/PERFORADO 7 cm

**Unidad:** m3.

Fábrica de dos pies de espesor de ladrillo perforado tosco de 24x11,5x7 cm, para revestir, recibido con mortero de cemento M5 (1:6), con plastificante; construida según CTE. Medida deduciendo huecos.

### 06LPM80060 - FÁBRICA 2 PIES L/PERFORADO 10 cm

**Unidad:** m3.

Fábrica de dos pies de espesor de ladrillo perforado tosco de 24x11,5x10 cm, para revestir, recibido con mortero de cemento M5 (1:6), con plastificante; construida según CTE. Medida deduciendo huecos.

### 06LPM80100 - FÁBRICA ARMADA 1 PIE L/PERFORADO 10 cm

**Unidad:** m2.

Fábrica armada de un pie de espesor de ladrillo perforado tosco de 24x11,5x10 cm, para revestir, recibido con mortero bastardo M7,5 de cemento y cal, con armadura de acero galvanizado en forma de celosía cada cuatro hiladas, recubierta de resina epoxi, incluso p.p. de ganchos para la armadura; construida según CTE. Medida deduciendo huecos.

### 06LPM80110 - FÁBRICA ARMADA 1 PIE L/PERFORADO C/V

**Unidad:** m2.

Fábrica armada de un pie de espesor de ladrillo perforado de 24x11,5x5 cm, a cara vista, recibido con mortero bastardo M7,5 de cemento y cal, con armadura de acero galvanizado en forma de celosía cada ocho hiladas, recubierta de resina epoxi, incluso p.p. de ganchos para la armadura, avitolado de juntas; construida según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Perforados

**Clasificación:** 06LP. **Capítulo:** albañilería. **Familia:** fábricas de ladrillos.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «perforados», dentro de «fábricas de ladrillos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Aprobar muestra de fábrica vista; proteger las piezas frente a manchas y ejecutar juntas y vierteaguas compatibles con la exposición.

Para la variante «perforados» se comprobarán expresamente acabado visto, aparejo, mortero y protección frente al agua. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
