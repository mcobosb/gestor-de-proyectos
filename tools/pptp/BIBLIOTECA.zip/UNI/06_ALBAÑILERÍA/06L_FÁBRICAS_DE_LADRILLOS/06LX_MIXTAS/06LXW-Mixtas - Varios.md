"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Mixtas - Varios

**Clasificación BCCA:** `06LXW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Mixtas**.
Aplicable a las partidas cuyo código BCCA comienza por `06LXW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06LXW80050 - CERRAM. 2 HOJAS 1/2 PIE LAD. H/D + TAB. L. H/D 7 cm

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo cerámico hueco doble de 24x11,5x7 cm, cámara de aíre de 5 cm, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x7 cm, para revestir, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80060 - CERRAM. 2 HOJAS 1/2 PIE LAD. H/D + TAB. L. H/D 9 cm

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo cerámico hueco doble de 24x11,5x7 cm, cámara de aíre de 5, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x9 cm, para revestir, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80100 - CERRAM. 2 HOJAS 1/2 PIE PERF. + TAB. LAD. H/D 7 cm

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo perforado tosco de 24x11,5x7 cm, cámara de aíre de 5 cm, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x7 cm, para revestir, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80110 - CERRAM. 2 HOJAS 1 PIE PERF. + TAB. LAD. H/D 7 cm

**Unidad:** m2.

Cerramiento formado por fábrica de un pie de espesor de ladrillo perforado tosco de 24x11,5x7 cm, cámara de aíre de 5 cm, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x7 cm, para revestir, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80120 - CERRAM. 2 HOJAS 1/2 PIE LAD. PERF. C/V. + TAB. LAD. H/D 7 cm

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo perforado 24x11,5x5 cm, a cara vista, cámara de aíre de 5 cm, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x7 cm, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80130 - CERRAM. 2 HOJAS 1/2 PIE LAD. PERF. C/V. + TAB. LAD. H/D 9 cm

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo perforado 24x11,5x5 cm, a cara vista, cámara de aíre de 5 cm, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x9 cm, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80140 - CERRAM. 2 HOJAS 1/2 PIE LAD. PERF. C/V + 1/2 PIE PERF.

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo perforado 24x11,5x5 cm, a cara vista, cámara de aíre de 5 cm, trasdósado con fábrica de medio pie de espesor de ladrillo perforado tosco de 24x11,5x7 cm, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80150 - CERRAM. 2 HOJAS 1/2 PIE LAD. PRENS. C/V + 1/2 PIE PERF.

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo prensado aplantillado 24x12x4 cm, a cara vista, cámara de aíre de 5 cm, trasdósado con fábrica de medio pie de espesor de ladrillo perforado tosco de 24x11,5x7 cm, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80155 - CERRAM. 2 HOJAS 1/2 PIE LAD. PRENS. C/V + TAB. LAD. H/D 7 cm

**Unidad:** m2.

Cerramiento formado por fábrica de medio pie de espesor de ladrillo prensado aplantillado 24x12x4 cm, a cara vista, cámara de aíre de 5 cm, trasdósado con tabicón de ladrillo cerámico hueco doble de 24x11,5x7 cm, recibidos con mortero M5 de cemento CEM II/A-L 32,5 N, con plastificante, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M5, rejuntado; construida según CTE. Medido deduciendo huecos.

### 06LXW80250 - CERRAM. 2 HOJAS 1/2 PIE LAD. PERF. C/ARMADURA

**Unidad:** m2.

Muro capuchino formado por doble fábrica de medio pie de espesor de ladrillo perforado tosco de 24x11,5x7 cm, cámara de aíre de 5 cm, para revestir, recibidos con mortero M7,5 de cemento CEM II/A-L 32,5 N, con plastificante, con armadura de acero galvanizado en forma de celosía cada seis hiladas, recubierta de resina epoxi, incluso enfoscado interior sin maestrear ni fratasar con mortero de cemento M7,5, rejuntado; construida según CTE. Medido deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Mixtas

**Clasificación:** 06LX. **Capítulo:** albañilería. **Familia:** fábricas de ladrillos.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «mixtas», dentro de «fábricas de ladrillos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Aprobar muestra de fábrica vista; proteger las piezas frente a manchas y ejecutar juntas y vierteaguas compatibles con la exposición.

Para la variante «mixtas» se comprobarán expresamente acabado visto, aparejo, mortero y protección frente al agua. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
