"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Macizos - Varios

**Clasificación BCCA:** `06LMW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Macizos**.
Aplicable a las partidas cuyo código BCCA comienza por `06LMW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Fábrica de ladrillo cerámico

**Clasificación:** 06LM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Obra de fábrica de ladrillo con mortero y aparejo previstos en planos.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 914–914. Transcripción para trazabilidad.
"""

#### Ejecución

Recibir piezas y mortero adecuados al uso, replantear, preparar apoyo y ajustar la humectación a la absorción y al fabricante, sin saturar indiscriminadamente cualquier pieza. Ejecutar juntas llenas y trabazón, comprobar geometría y proteger frente a heladas o desecación. Para fábrica estructural de edificación, aplicar CTE DB-SE-F; para obra civil, la especificación y cálculo propios del proyecto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 915–921. Transcripción para trazabilidad.
"""

Los ladrillos se colocarán según el aparejo previsto en los planos o en su caso designe el Ingeniero Técnico Director de las obras. Antes de su colocación deberán ser saturados de humedad, aunque bien escurridos del exceso de agua, con objeto de evitar el deslavamiento del mortero. Deberán demolerse toda la fábrica en la que el ladrillo hubiese sido insuficientemente humedecido a juicio del Ingeniero Técnico Director de las obras.
Los tendeles no deberán exceder a los diez (10) milímetros, ni las juntas de nueve (9) milímetros. Para la colocación, una vez limpias y humedecidas las superficies sobre las que han de descansar, se echará el mortero en cantidad suficiente para que, comprimiendo fuertemente sobre el ladrillo y  apretando contra los inmediatos queden los espesores de juntas deseados y el mortero refluya por todas partes. En los parámetros que hayan de revocarse, las juntas quedarán sin rellenar a tope, para facilitar la adherencia al revoco.
La subida de fábrica se hará horizontalmente. Después de una interrupción y al reanudarse el trabajo, se regarán abundantemente la fábrica y todo el ladrillo que no hubiere quedado debidamente colocado. Los parámetros se harán con los cuidados y precauciones indispensables, para cualquier elemento se encuentre en el plano, superficie y perfil prescritos. En las superficies curvas las juntas serán normales a los parámetros.

No se efectuarán fábricas de ladrillo cuando la temperatura ambiente sea de seis grados centígrados (6º C) con tendencia a decrecer.
En tiempo caluroso, la fábrica de ladrillo se rociará frecuentemente con agua, para evitar la desecación del mortero.

#### Medición y valoración

Por m³ según planos conforme a 5.14, con materiales, equipo y mano de obra incluidos, salvo que forme parte de una arqueta completa.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1151–1153. Transcripción para trazabilidad.
"""

Las obras de fábrica de ladrillo se medirán en metros cúbicos (mi) y siempre de acuerdo con las dimensiones indicadas en los planos o las modificaciones ordenadas por el Director de la Obra.
En ambos casos se abonará a los precios respectivos del presupuesto, en los que se encuentran incluidos los materiales, equipo y mano de obra necesarios para la completa terminación de la unidad.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
