"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Huecos - Muros

**Clasificación BCCA:** `06LHM`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Muros**, dentro de **Huecos**.
Aplicable a las partidas cuyo código BCCA comienza por `06LHM`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06LHM00001 - FÁBRICA 1 PIE LADRILLO GAFA

**Unidad:** m2.

Fabrica de un pie de espesor, con ladrillo gafa, recibido con mortero M5 (1:6), con plastificante; construida según CTE. Medida deduciendo huecos.

### 06LHM00005 - FÁBRICA 1 PIE LADRILLO H/D

**Unidad:** m2.

Fabrica de un pie de espesor, con ladrillo cerámico hueco doble de 24x11,5x9 cm, recibido con mortero M5 (1:6), con plastificante; construida según CTE. Medida deduciendo huecos.

### 06LHM80000 - FÁBRICA 1 PIE LADRILLO H/D C/MORT. BAST.

**Unidad:** m2.

Fábrica de medio pie de espesor de ladrillo cerámico hueco doble de 24x11,5x9 cm, recibido con mortero de bastardo M10 (1:0,5:4) de cemento y cal; construida según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Huecos

**Clasificación:** 06LH. **Capítulo:** albañilería. **Familia:** fábricas de ladrillos.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «huecos», dentro de «fábricas de ladrillos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Aprobar muestra de fábrica vista; proteger las piezas frente a manchas y ejecutar juntas y vierteaguas compatibles con la exposición.

Para la variante «huecos» se comprobarán expresamente acabado visto, aparejo, mortero y protección frente al agua. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
