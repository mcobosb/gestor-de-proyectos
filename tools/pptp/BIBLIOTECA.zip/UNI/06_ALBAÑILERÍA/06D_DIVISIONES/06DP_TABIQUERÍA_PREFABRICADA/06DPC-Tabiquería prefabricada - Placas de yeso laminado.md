"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Tabiquería prefabricada - Placas de yeso laminado

**Clasificación BCCA:** `06DPC`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Placas de yeso laminado**, dentro de **Tabiquería prefabricada**.
Aplicable a las partidas cuyo código BCCA comienza por `06DPC`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06DPC80370 - TABIQUE SIMPLE PL. YESO LAMINADO C/ALMA CEL. 10+30+10 (50 mm)

**Unidad:** m2.

Tabique formado por dos placas de yeso laminado de 10 mm de espesor sobre alma celular de 30 mm, y espesor final de 50 mm, atornillado a entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80400 - TABIQUE SIMPLE PL. YESO LAMINADO 13+46+13 (72 mm)

**Unidad:** m2.

Tabique simple con placa de yeso laminado de 13 mm de espesor y espesor final de 72 mm, cubriendo la altura total de suelo a techo, atornillado a entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80410 - TABIQUE SIMPLE PL. YESO LAMINADO 13+70+13 (96 mm)

**Unidad:** m2.

Tabique simple con placa de yeso laminado de 13 mm de espesor y espesor final de 96 mm, cubriendo la altura total de suelo a techo, atornillado a entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80415 - TABIQUE MÚLTIPLE PL. YESO LAMINADO 13+13+46+13+13 (98 mm)

**Unidad:** m2.

Tabique múltiple con dos placas de yeso laminado de 13 mm de espesor por cada cara y espesor final de 98 mm, cubriendo la altura total de suelo a techo, atornillado a entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80420 - TABIQUE MÚLTIPLE PL. YESO LAMINADO 15+15+70+15+15 (130mm)

**Unidad:** m2.

Tabique múltiple con dos placas de yeso laminado de 15 mm de espesor por cada cara y espesor final de 130 mm, cubriendo la altura total de suelo a techo, atornillado a entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80520 - TABIQUE MÚLTIPLE PL. YESO LAMINADO 13+13+46+13+13 WA

**Unidad:** m2.

Tabique de y eso formado por una estructura galv anizada de 46 mm. y 2 placa 13 mm. por cada lado de la estructura, i/tratamiento de huecos, replanteo auxiliar, nivelación, ejecución de ángulos, repaso de juntas con cinta, recibido de cercos, paso de instalaciones y limpieza, totalmente terminado y listo para pintar, medido deduciendo huecos.Resistente al agua.

### 06DPC80521 - TABIQUE MÚLTIPLE PL. YESO LAMINADO 13+13WA+46+13+13WA (98 mm)

**Unidad:** m2.

Tabique múltiple con dos placas de yeso laminado de 13 mm de espesor por cada cara y espesor final de 98 mm, cubriendo la altura total de suelo a techo, atornillado a entramado de acero galv anizado con una separación de montantes de 60 cm, incluso replanteo, entramado auxiliar, nivelación, ejecución de ángulos, pasos de instalaciones, recibido de estas, colocación de cercos, repaso de juntas y limpieza; construido según especificaciones del fabricante de las placas. Medido a cinta corrida.

### 06DPC80522 - TABIQUE MÚLTIPLE PL. YESO LAMINADO 15+15 RF+46+15+15 RF

**Unidad:** m2.

Tabique de y eso formado por una estructura galv anizada de 46 mm. y 2 placa 15 mm. por cada lado de la estructura, i/tratamiento de huecos, replanteo auxiliar, nivelación, ejecución de ángulos, repaso de juntas con cinta, recibido de cercos, paso de instalaciones y limpieza, totalmente terminado y listo para pintar, medido deduciendo huecos.Resistente al fuego.

### 06DPC80540 - TABIQUE MÚLTIPLE PL. YESO LAMINADO 15+15+70+15+15 (130 mm) RF

**Unidad:** m2.

Tabique múltiple con dos placas de yeso laminado de 15 mm de espesor por cada cara y espesor final de 150 mm, resistentes al fuego (RF), cubriendo la altura total de suelo a techo, atornillado a entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80600 - TABIQUE DOBLE ESTRUCT. PL. YESO LAM. (13x2+46x2+13x2) 144 mm

**Unidad:** m2.

Tabique de doble estructura formado por con dos placas de yeso laminado de 13 mm de espesor por cada cara y espesor final de 144 mm, cubriendo la altura total de suelo a techo, atornillado a doble entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

### 06DPC80610 - TABIQUE DOBLE ESTRUCT. PL. YESO LAM. (15x2+70x2+15x2) 200 mm

**Unidad:** m2.

Tabique de doble estructura formado por con dos placas de yeso laminado de 15 mm de espesor por cada cara y espesor final de 200 mm, cubriendo la altura total de suelo a techo, atornillado a doble entramado de acero galvanizado con una separación de montantes de 60 cm, incluso nivelación, ejecución de ángulos, pasos de instalaciones y recibido de cajas, encintado y repaso de juntas; construido según especificaciones del fabricante de las placas. Medido deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Tabiquería prefabricada

**Clasificación:** 06DP. **Capítulo:** albañilería. **Familia:** divisiones.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «tabiquería prefabricada», dentro de «divisiones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Coordinar la partición con estructura e instalaciones y resolver juntas perimetrales, huecos y refuerzos de fijaciones.

Para la variante «tabiquería prefabricada» se comprobarán expresamente tipo de partición, altura, encuentros y prestaciones acústicas y de fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
