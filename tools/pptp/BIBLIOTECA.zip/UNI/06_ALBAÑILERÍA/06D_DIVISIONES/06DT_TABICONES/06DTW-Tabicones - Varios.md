"""
# Tabicones - Varios

**Clasificación BCCA:** `06DTW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Tabicones**.
Aplicable a las partidas cuyo código BCCA comienza por `06DTW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06DTW80120 - TABICÓN LAD. H/D 7 cm GRAN FORMATO TRASDOS. PL. YESO 13 mm

**Unidad:** m2.

Tabicón de ladrillo cerámico hueco doble gran formato de 70x50,5x6,8 cm, tomado con pasta de agarre, trasdósado con una placa de yeso laminado de 13 mm de espesor, recibido con pasta de agarre en toda la superficie, incluso nivelación, encintado y repaso de juntas. Medido deduciendo huecos.

### 06DTW80160 - TABICÓN LAD. H/D 7 cm GRAN FORMATO TRASDOS. 2 PL. YESO 13 mm

**Unidad:** m2.

Tabicón de ladrillo cerámico hueco doble gran formato de 70x50,5x6,8 cm, tomado con pasta de agarre, trasdósado a doble cara con placas de yeso laminado de 13 mm de espesor, recibido con pasta de agarre en toda la superficie, incluso nivelación, encintado y repaso de juntas. Medido deduciendo huecos.

### 06DTW80170 - TABICÓN LAD. H/D 10 cm GRAN FORMATO TRASDOS. PL. YESO 13 mm

**Unidad:** m2.

Tabicón de ladrillo cerámico hueco doble gran formato de 70x40x9,8 cm, tomado con pasta de agarre, trasdósado con una placa de yeso laminado de 13 mm de espesor, recibido con pasta de agarre en toda la superficie, incluso nivelación, encintado y repaso de juntas. Medido deduciendo huecos.

### 06DTW80500 - DOBLE TABICÓN LAD. H/D 7 cm C/AISLAM. ACUST. 48,5 dBA

**Unidad:** m2.

Doble tabicón de ladrillo hueco doble de 24x11,5x7 cm, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, con panel intermedio de lana mineral de 25 mm de espesor, adherido a una cara con cemento cola, guarnecidas las caras exteriores de yeso negro YG de 12 mm de espesor, incluso nivelación, encintado y repaso de juntas; para un aislamiento acústico a ruido aéreo de 48,5 dBA. Medido deduciendo huecos.

### 06DTW80600 - DOBLE TABICÓN LAD. H/D GRAN FORMATO C/AISLAM. ACÚST. 52,8 dBA

**Unidad:** m2.

Doble tabicón de ladrillo hueco doble gran formato de 70x50,5x6,8 cm, recibido con pasta de agarre, con panel intermedio de lana mineral de 15 mm de espesor, con placas de yeso laminado YP de 13 mm de espesor adheridos a las dos caras exteriores, recibidas con pasta de agarre extendida en toda la superficie, incluso nivelación, encintado y repaso de juntas; para conseguir un aislamiento acústico a ruido aéreo de 52,8 dBA. Medido deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Tabicones

**Clasificación:** 06DT. **Capítulo:** albañilería. **Familia:** divisiones.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «tabicones», dentro de «divisiones». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Coordinar la partición con estructura e instalaciones y resolver juntas perimetrales, huecos y refuerzos de fijaciones.

Para la variante «tabicones» se comprobarán expresamente tipo de partición, altura, encuentros y prestaciones acústicas y de fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
