"""
# Perforados - Perforados

**Clasificación BCCA:** `06APP`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Perforados**, dentro de **Perforados**.
Aplicable a las partidas cuyo código BCCA comienza por `06APP`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06APP80000 - ARCO 1/2 PUNTO 1 PIE ESP. x 1 PIE ANCH. LAD. PERF. REVESTIR

**Unidad:** m.

Arco 1/2 punto de 1 pie de espesor por 1 pie de anchura, de ladrillo perforado de 24x11,5x5 cm, para revestir, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, incluso p.p. de cimbrado, descimbrado y apeos; según CTE. Medida la longitud en verdadera magnitud por el intradós.

### 06APP80020 - ARCO 1/2 PUNTO 1 PIE ESP. x 1 PIE ANCH. LAD. PERF. C/V

**Unidad:** m.

Arco de 1/2 punto de 1 pie de espesor por 1 pie de anchura, de ladrillo perforado de 24x11,5x5 cm, a cara vista, recibido con mortero bastardo M5 de cemento CEM II/A-L 32,5 N, incluso p.p. de cimbras, apeos, avitolado de juntas y limpieza de paramentos; según CTE. Medida la longitud en verdadera magnitud por el intradós.

### 06APP80040 - ARCO ADINTELADO DE 1 PIE DE ESP. x 1 ROSCA C/V

**Unidad:** m.

Arco adintelado de 1 pié de espesor por una rosca de 1/2 pie de anchura, con ladrillo perforado de 24x11,5x5 cm, a cara vista , recibido con mortero M5 de cemento CEM II/A-L 32,5 N, incluso p.p. de cimbrado, descimbrado, apeos, avitolado de juntas y limpieza de paramentos; según CTE. Medida la longitud en verdadera magnitud por el intradós.

### 06APP80050 - ARCO ADINTELADO DE 1 PIE DE ESP. x 2 ROSCAS C/V

**Unidad:** m.

Arco adintelado de 1 pié de espesor por dos roscas de 1 pie de anchura, con ladrillo perforado de 24x11,5x5 cm, a cara vista, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, incluso p.p. de cimbrado, descimbrado, apeos, avitolado de juntas y limpieza de paramentos; según CTE. Medida la longitud en verdadera magnitud por el intradós.

### 06APP80100 - ARCO 1/2 PUNTO 1 PIE ESP. x 1/2 PIE ANCH. A SARDINEL C/V

**Unidad:** m.

Arco de 1/2 punto de 1 pie de espesor por 1/2 pie de anchura, con ladrillo perforado de 24x11,5x5 cm colocado a sardinel, a cara vista, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, incluso p.p. de cimbrado, descimbrado, apeos, avitolado de juntas y limpieza de paramentos; según CTE. Medida la longitud en verdadera magnitud por el intradós.

### 06APP80120 - ARCO 1/2 PUNTO 1 PIE ESP. x 1 PIE ANCH. A SARDINEL C/V

**Unidad:** m.

Arco de 1/2 punto de 1 pie de espesor por 1 pie de anchura, con ladrillo perforado de 24x11,5x5 cm colocado a sardinel, a cara vista, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, incluso p.p. de cimbrado, descimbrado, apeos, avitolado de juntas y limpieza de paramentos; según CTE. Medida la longitud en verdadera magnitud por el intradós.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Perforados

**Clasificación:** 06AP. **Capítulo:** albañilería. **Familia:** arcos y bóvedas de ladrillo.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «perforados», dentro de «arcos y bóvedas de ladrillo». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Confirmar que el ladrillo y el mortero son aptos para fábrica revestida y para la función resistente prevista.

Para la variante «perforados» se comprobarán expresamente pieza, mortero, revestimiento y prestaciones de la fábrica. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
