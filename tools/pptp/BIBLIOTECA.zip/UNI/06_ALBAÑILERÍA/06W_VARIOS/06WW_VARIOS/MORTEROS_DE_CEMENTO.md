# Morteros de cemento

**Clasificación:** 06WW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Mezclas de cemento, áridos y agua para fábricas, revestimientos y juntas según su uso y las dosificaciones o clases prescritas.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1059–1060. Transcripción para trazabilidad.

Deberán emplearse todos los tipos de morteros que figuran el los Cuadros de Precios y Presupuestos Parciales del Proyecto, con las dosificaciones que en dichos documentos se indican, las cuales podrán ser modificadas en forma adecuada por el Director de la obra si se producen circunstancias que lo aconsejen, sin que el Contratista tenga derecho a reclamar modificación en el precio de la unidad de obra correspondiente.

## Ejecución

Seleccionar mortero compatible con soporte y exposición, verificar documentación del producto y cemento y dosificar de manera controlada. Amasar homogéneamente con agua adecuada, utilizar dentro del tiempo útil del sistema y desechar producto iniciado el fraguado. No rebatir para recuperar consistencia ni aplicar una receta de volumen sin comprobar la prestación exigida.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1061–1062. Transcripción para trazabilidad.

La mezcla podrá realizarse con medios mecánicos o a mano, en este caso sobre un piso impermeable. El amasado del mortero se hará de modo que resulte una mezcla homogénea y con la rapidez necesaria para que no tenga lugar un principio de fraguado antes de su empleo. La cantidad de agua será la necesaria para obtener una consistencia jugosa, sin que se forme en la superficie una capa de agua de espesor apreciable cuando se introduzca en una vasija y se sacuda ligeramente. Solamente se fabricará el mortero preciso para uso inmediato, desechándose todo aquel que haya empezado a fraguar y el que no haya sido empleado dentro de los cuarenta y cinco (45) minutos que sigan a su amasado. Se rechazarán asimismo, los morteros rebatidos.
Los morteros que se confeccionen para enlucido tendrán una consistencia menos fluida que los restantes, principalmente cuando las superficies en que hayan de ser empleados sean verticales o poco rugosas, sin que llegue a agrietarse al ser aplicado lanzándolo enérgicamente contra las paredes.

## Medición y valoración

El original los integra en las unidades de fábrica, revestimiento o junta correspondientes. Sólo abonar suministro independiente si una partida lo define con su unidad y alcance.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1151–1156. Transcripción para trazabilidad.

Las obras de fábrica de ladrillo se medirán en metros cúbicos (mi) y siempre de acuerdo con las dimensiones indicadas en los planos o las modificaciones ordenadas por el Director de la Obra.
En ambos casos se abonará a los precios respectivos del presupuesto, en los que se encuentran incluidos los materiales, equipo y mano de obra necesarios para la completa terminación de la unidad.

Los enlucidos de las obras de fábrica, ya sea en hormigón o ladrillo se medirán por metro cuadrado (m2) realmente ejecutado.
El abono se efectuará aplicando a estas mediciones los precios que se indican en el presupuesto, en los que se incluyen los materiales y la colocación.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 188–189. Transcripción para trazabilidad.

Se medirán y abonarán por ml colocado realmente, quedando incluidos en este precio tanto el hormigón de base dispuesto según planos como el mortero necesario para el rejuntado.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
