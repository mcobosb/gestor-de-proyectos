"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Varios

**Clasificación BCCA:** `06EWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `06EWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06EWW00010 - ALFÉIZAR CHAPA  ALUMINO CON ALMA COMPOSITE DE 4 MM ESPESOR

**Unidad:** ml.

Alféizar fabricado con plancha conformada de panel composite de aluminio de 4 mm de espesor total, formada por doble lámina de aluminio lacadas al horno (exterior e interior) de 0.5 mm de espesor según norma EN 485-4:1993, con núcleo intermedio de polietileno con una elevada proporción de carga mineral y un peso total de aprox. 8,02 Kg/m2. Aluminio cara exterior aleación 5005 según UNE-EN 485-2 acabado lacado color a elegir por la DF, terminación (70% Fluoruro de Polivinilideno, 30% resina acrílica) con film plástico de protección de 100 µ.  Mecanizado mediante 3 pliegues previo fresado de 25 mm de ancho, que conformen un tubo rígido y forme goterón en el borde exterior, con pliegue en borde para rigidizar el conjunto, separado 30 mm del acabado final del SATE en el borde de fachada, colocado con una pendiente mínima de 17% (10º) según CTE. Las piezas mecanizadas se fijarán al soporte existente mediante la utilización de adhesivo para metal según las especificaciones del fabricante del adhesivo, previa limpieza de la superficie para quitar la suciedad y a continuación aplicar el “PRIMER” para seguidamente añadir el adhesivo mediante cordón, junto con la cinta de doble cara, cuya función es mantener el espesor necesario del adhesivo para poder absorber las posibles dilataciones, al igual que sujetar la placa mientras se produce el secado de dicho adhesivo. Incluso encuentro con paramentos y ventana con sellador compatible elástico y adhesivo multiuso de poliuretano, incluso limpieza y resanado de alféizar existente con mortero de reparación con ligantes de resinas sintéticas.  Construido según proyecto de ejecución, indicaciones de la D.F. y según CTE. Medido según la longitud realmente ejecutada.

### 06EWW00020 - CIERRE DE CÁMARA FACHADA VENTILADA HORMIGÓN POLÍMERO

**Unidad:** m.

Cierre de cámara de fachada ventilada, con placas de hormigón polímero y sistema de fijación oculto, sistema horizontal, con DIT, compuesta por: hoja exterior con placas de hormigón polímero, núcleo fabricado por molde mediante mezcla de áridos de basalto, sílice y cuarzo con resinas de poliester, capa superficial de resinas termoestables, idóneas para uso exterior resistentes a los rayos UV y resto de agentes atmosféricos, con acabado superficial de Gel-Coat, textura y color a elegir por la DF, ranuradas en toda su longitud del canto superior e inferior, preparadas para su colocación sobre los perfiles-guía; subestructuraperfil  de apoyo continuo en "L" y angular  de 50 x 50 x 3 mm. para soporte del perfil de apoyo; toda la subestructura será en aluminio de aleación 6063 y tratamiento T-5; Remaches, material  adhesivo y tornillería necesaria autorroscante INOX tipo A2. Incluso replanteo, piezas especiales y formación de encuentros y remates; según CTE. Medida la longitud ejecutada.

### 06EWW00030 - REJILLA ANTIRROEDORES FACHADA VENTILADA

**Unidad:** m.

Rejilla metálica perforada de arranque de fachada ventilada, incluso angular de 50x50x3 mm y tornillería de acero inoxidable necesaria para su soporte. Medida la longitud ejecutada.

### 06EWW00040 - REJILLA LACADA ANTIRROEDORES FACHADA VENTILADA

**Unidad:** m.

Rejilla metálica perforada y lacada de arranque de fachada ventilada, incluso angular de 50x50x3 mm y tornillería de acero inoxidable necesaria para su soporte. Medida la longitud ejecutada.

### 06EWW00050 - CORTE EN PENDIENTE FACHADA VENTILADA

**Unidad:** m.

Corte para la formación de arranque/terminación de la fachada ventilada en pendiente. Medida la longitud ejecutada.

### 06EWW00060 - SATE EPS 80mm ACABADO ACRÍLICO FRATASADO REFORZADO EN FACHADAS

**Unidad:** m2.

Sistema de aislamiento térmico por el exterior en rehabilitación de fachadas, (con clasificación Categoría I en planta baja y Categoría III en resto de plantas),  según ETAG 004, reforzado con doble malla y acabado con revestimiento acrílico, formado por: limpieza de paramentos de fachada realizada mediante agua a presión y/o cepillado mecánico para posterior anclaje de mortero de base; preparación del soporte, paneles rígidos aislantes de poliestireno expandido EPS de 80 mm de espesor con conductividad térmica de 0.037 w/mK de medidas 1000x500 mm por placa, según UNE-EN 13499;  colocada a contrajunta adheridas al soporte con mortero polimérico monocomponente (anclaje químico base de doble encolado con llana dentada, con el espesor necesario para el correcto aplomado de la superficie; refuerzo de anclaje con espigas de fijación de polipropileno con clavo expansionante (anclaje mecánico) a razón de 8 ud/m2; refuerzos de esquinas mediante perfil cantonera de PVC con malla de fibra de vidrio, así como perfiles en uniones con ventanas y huecos; protección superficial de los paneles mediante tres capas de 3 mm de espesor cada una con mortero de 9 mm de espesor total mínimo; armado con doble malla de fibra de vidrio alcalirresistente de 160 gr/m2 embutida sobre la primera y la segunda capa sobre el mortero fresco, aplicando la segunda y tercera capa de mortero una vez haya secado la anterior; capa de imprimación de fondo aplicado a brocha o rodillo; revestimiento final con mortero acrílico a base de resinas al siloxano de elevada adherencia micro o equivalente con espesor mínimo de 1 mm y tamaño máximo  de 0,8 mm, aplicado con llana y acabado fratasado, incluso forrado de dinteles y mochetas de huecos con el mismo material con espesor de aislamiento de 20 mm. Color RAL a elegir por la Dirección Facultativa. Incluso p/p de accesorios, refuerzos de malla en esquinas de huecos para evitar fisuraciones, tratamiento  de ventanas, puertas y otros huecos en fachada, perfiles de coronación el la línea superior, perfiles de goterón en huecos, sustitución de rejillas de ventilación de gas, pequeño material, preparación de la superficie del soporte, colocación de perfiles de arranque, formación de juntas, rincones, maestras, aristas, mochetas, jambas, dinteles, remates y sellado en los encuentros con paramentos. Así como la retirada y posterior recolocación o modificación de cualquier elemento anclado a fachadas de actuación, tales como rejas de seguridad, equipos de aire acondicionado, tendederos, toldos, luminarias, instalaciones de sevicios y suministros, o cualquier otro elemento no enumerado preexistente en fachadas. Construído según recomendaciones y fichas técnicas del fabricante, proyecto de ejecución e indicaciones de la D.F;
Se incluye panel termoaislante de espuma rígida de poliestireno extruido (XPS) sin piel y de conductividad térmica 0,034 W/m·K, como material aislante para la zona del zócalo en sistemas de aislamiento térmico por el exterior Weber therm.
 Medida la superficie ejecutada, deduciendo huecos mayores de 2 m2.

### 06EWW00070 - SATE EPS 80mm ACABADO ACRÍLICO FRATASADO REFORZADO EN FACHADAS

**Unidad:** m2.

Sistema de aislamiento térmico por el exterior en rehabilitación de fachadas, (con clasificación Categoría I en planta baja y Categoría III en resto de plantas),  reforzado con doble malla y acabado con revestimiento acrílico, formado por: limpieza de paramentos de fachada realizada mediante agua a presión y/o cepillado mecánico para posterior anclaje de mortero de base; preparación del soporte, paneles rígidos aislantes de poliestireno expandido EPS con de 80 mm de espesor con conductividad térmica de 0.032 w/mK de medidas 1000x500 mm por placa, según UNE-EN 13499;  colocada a contrajunta adheridas al soporte con mortero polimérico monocomponente (anclaje químico) a base de doble encolado con llana dentada, con el espesor necesario para el correcto aplomado de la superficie; refuerzo de anclaje con espigas de fijación de polipropileno con clavo expansionante (anclaje mecánico) a razón de 8 ud/m2; refuerzos de esquinas mediante perfil cantonera de PVC con malla de fibra de vidrio, así como perfiles en uniones con ventanas y huecos; protección superficial de los paneles mediante tres capas de 3 mm de espesor cada una con mortero de 9 mm de espesor total mínimo; armado con doble malla de fibra de vidrio alcalirresistente de 160 gr/m2 embutida sobre la primera y la segunda capa sobre el mortero fresco, aplicando la segunda y tercera capa de mortero una vez haya secado la anterior; capa de imprimación de fondo aplicado a brocha o rodillo; revestimiento final con mortero acrílico a base de resinas al siloxano de elevada adherencia con espesor mínimo de 1 mm y tamaño máximo  de 0,8 mm, aplicado con llana y acabado fratasado, incluso forrado de dinteles y mochetas de huecos con el mismo material con espesor de aislamiento de 20 mm. Color RAL a elegir por la Dirección Facultativa. Incluso p/p de accesorios, refuerzos de malla en esquinas de huecos para evitar fisuraciones, tratamiento  de ventanas, puertas y otros huecos en fachada, perfiles de coronación el la línea superior, perfiles de goterón en huecos, sustitución de rejillas de ventilación de gas, pequeño material, preparación de la superficie del soporte, colocación de perfiles de arranque, formación de juntas, rincones, maestras, aristas, mochetas, jambas, dinteles, remates y sellado en los encuentros con paramentos. Así como la retirada y posterior recolocación o modificación de cualquier elemento anclado a fachadas de actuación, tales como rejas de seguridad, equipos de aire acondicionado, tendederos, toldos, luminarias, instalaciones de sevicios y suministros, o cualquier otro elemento no enumerado preexistente en fachadas. Construído según recomendaciones y fichas técnicas del fabricante, proyecto de ejecución e indicaciones de la D.F;
Se incluye panel termoaislante de espuma rígida de poliestireno extruido (XPS) sin piel y de conductividad térmica 0,034 W/m·K, como material aislante para la zona del zócalo en sistemas de aislamiento térmico por el exterior Weber therm.
 Medida la superficie ejecutada, deduciendo huecos mayores de 2 m2.

### 06EWW00080 - SATE EPS 20mm ACABADO ACRÍLICO FRATASADO EN TECHOS Y VOLADIZOS

**Unidad:** m2.

Sistema de aislamiento térmico por el exterior en rehabilitación de techos y voladizos, acabado con revestimiento acrílico, formado por: limpieza de paramentos de fachada realizada mediante agua a presión y/o cepillado mecánico para posterior anclaje de mortero de base, perfil perimetral con goterón en bordes vistos; preparación del soporte, paneles rígidos aislantes de poliestireno expandido EPS de 20 mm de espesor con conductividad térmica de 0.037 w/mK de medidas 1000x500 mm por placa, según UNE-EN 13499; colocada a contrajunta adheridas al soporte con mortero polimérico monocomponente (anclaje químico) tipo Weber therm base o equivalente a base de doble encolado con llana dentada, con el espesor necesario para el correcto aplomado de la superficie; refuerzo de anclaje con espigas de fijación de polipropileno con clavo expansionante (anclaje mecánico) a razón de 9 ud/m2; refuerzos de esquinas mediante perfil cantonera de PVC con malla de fibra de vidrio, protección superficial de los paneles mediante dos capas de 3 mm de espesor cada una con mortero de 6 mm de espesor total mínimo; armado de la primera capa embutiendo sobre el mortero fresco una malla de fibra de vidrio alcalirresistente de 160 gr/m2, aplicando la segunda capa de mortero una vez haya secado la primera; capa de imprimación de aplicado a brocha o rodillo; revestimiento final con mortero acrílico a base de resinas al siloxano de elevada adherencia con espesor mínimo de 1 mm aplicado con llana y acabado fratasado. Color RAL a elegir por la Dirección Facultativa. Incluso p/p de accesorios, perfiles especiales, pequeño material, preparación de la superficie del soporte, colocación de perfiles de arranque, formación de juntas, rincones, maestras, aristas, remates en los encuentros con paramentos. Así como la retirada y posterior recolocación o modificación de cualquier elemento anclado a la superficie, tales como elementos de cerrajería, maquinas de aire acondicionado, luminarias, instalaciones de sevicios y suministros, o cualquier otro elemento no enumerado preexistente en la superficie de actuación. Construído según recomendaciones y fichas técnicas del fabricante, proyecto de ejecución e indicaciones de la D.F. Medida la superficie ejecutada, deduciendo huecos mayores de 2 m2.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### CERRAMIENTOS ESPECIALES - varios

**Clasificación:** 06EW. **Capítulo:** albañilería. **Familia:** cerramientos especiales.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Comprobar continuidad del cerramiento y sus capas, anclajes y control de agua y vapor; no obstruir cámaras ventiladas.

Para la variante «varios» se comprobarán expresamente sistema de fachada, acciones de viento, cámara y fijaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
