"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Muros bioclimáticos - Muros trombe

**Clasificación BCCA:** `06EBT`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Muros trombe**, dentro de **Muros bioclimáticos**.
Aplicable a las partidas cuyo código BCCA comienza por `06EBT`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06EBT80000 - MURO TROMBE C/FABR. DE LADRILLO

**Unidad:** m2.

Muro trombe constituido por fábrica de ladrillo cara vista de 25x11,5x5 cm de un pie de espesor, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, dejando huecos para ventilación en zona superior e inferior de muro, colocación de rejillas, estructura fija de aluminio anonizado en color natural con un 20% en superficies practicables compuesta por bastidor de 80x40 mm anclado a la fábrica, cámara de aire de 20 cm, luna de vidrio templado de 6 mm de espesor sellada con silicona en unión con perfilería, incluso nivelación y rejuntado; según CTE. Medida deduciendo huecos.

### 06EBT80100 - MURO TROMBE C/MURO DE HORMIGÓN

**Unidad:** m2.

Muro trombe constituido por muro de hormigón armado HA-25/P/20/IIa, consistencia plástica y tamaño máximo del árido 20 mm, de 25 cm de espesor, con una cuantía de 60 kg/m3, encofrado y desencofrado a dos caras, vibrado y curado, dejando huecos para ventilación en zona superior e inferior de muro, colocación de rejillas, estructura fija de aluminio anonizado en color natural con un 20% en superficies practicables compuesta por bastidor de 80x40 mm anclado al muro, cámara de aire de 20 cm, luna de vidrio templado de 8 mm de espesor sellada con silicona en unión con perfilería. Medida deduciendo huecos.

### 06EBT80200 - MURO TROMBE C/FABR. DE LADRILLO Y PROTEC. SOLAR

**Unidad:** m2.

Muro trombe constituido por fábrica de ladrillo tosco de 24x11,5x7 cm de un pie de espesor, recibido con mortero M5 de cemento CEM II/A-L 32,5 N, dejando huecos para ventilación en zona superior e inferior de muro, colocación de rejillas, enfoscado exterior, acabado con imprimación y dos manos de pintura negra previa limpieza del paramento, estructura fija de aluminio anonizado en color natural con un 20% en superficies practicables compuesta por bastidor de 80x40 mm anclado a la fábrica, cámara de aire de 20 cm, luna de vidrio templado de 6 mm de espesor sellada con silicona en unión con perfilería, entramado protector solar anclado a forjados con celosía de lamas orientables de 145 mm de PVC con sistema de bloqueo, montada sobre estructura de aluminio anodizado fijada mediante tornillos, incluso nivelación y rejuntado; según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Muros bioclimáticos

**Clasificación:** 06EB. **Capítulo:** albañilería. **Familia:** cerramientos especiales.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «muros bioclimáticos», dentro de «cerramientos especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Comprobar continuidad del cerramiento y sus capas, anclajes y control de agua y vapor; no obstruir cámaras ventiladas.

Para la variante «muros bioclimáticos» se comprobarán expresamente sistema de fachada, acciones de viento, cámara y fijaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
