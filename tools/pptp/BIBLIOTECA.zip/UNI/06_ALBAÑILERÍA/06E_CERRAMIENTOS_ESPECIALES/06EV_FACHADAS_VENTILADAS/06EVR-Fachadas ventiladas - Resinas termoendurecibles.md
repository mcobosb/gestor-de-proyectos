"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Fachadas ventiladas - Resinas termoendurecibles

**Clasificación BCCA:** `06EVR`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Resinas termoendurecibles**, dentro de **Fachadas ventiladas**.
Aplicable a las partidas cuyo código BCCA comienza por `06EVR`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06EVR80380 - FACHADA VENTILADA CON RESINAS TERMOENDURECIBLES

**Unidad:** m2.

Fachada ventilada compuesta por, hoja interior de fábrica de medio pie de espesor con ladrillo perforado fonorresistente de 24x11x10 cm, para revestir, apoyada en el forjado, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, con mortero adhesivo hidrófugo proyectado en su cara exterior, hoja exterior con placas de resinas termoendurecibles de 60x100 cm y 8 mm de espesor, acabado textura satinada en color, colocada con modulación horizontal, juntas verticales de 4 mm y horizontales de 8 mm, montadas sobre perfiles de aluminio tipo T guíados de 85x75x3 mm, y tipo L de las mismas dimensiones en material aluminio en las cercanías de esquinas y huecos, recibiendo cada T dos piezas cerámicas, apoyos a forjados y hoja interior consistentes en mensulas de regulación de sustentación y retención con escuadras de 4 mm de espesor en aluminio, clips de sujeción en acero inoxidable, perfiles de junta en material EPDM entre piezas cerámicas, anclajes y tornillería en acero inoxidable o bicromatado, incluso replanteo, formación de encuentros y remates, y piezas especiales; según CTE. Medida deduciendo huecos.

### 06EVR80380N - FACHADA VENTILADA CON PLACAS DE HORMIGÓN POLÍMERO MONOCROMO GC S.HORIZONTAL

**Unidad:** m2.

Fachada ventilada, con placas de hormigón polímero y sistema de fijación oculto, sistema horizontal, con DIT, compuesta por: hoja exterior con placas de hormigón polímero, núcleo fabricado por molde mediante mezcla de áridos de basalto, sílice y cuarzo con resinas de poliester, capa superficial de resinas termoestables, idóneas para uso exterior resistentes a los rayos UV y resto de agentes atmosféricos, con acabado superficial de Gel-Coat, de 500 x 900 mm y 14 mm de espesor, textura y color monocromo a elegir por la DF, ranuradas en toda su longitud del canto superior e inferior, preparadas para su colocación sobre los perfiles-guía; subestructura primaria: Montantes en "T", y anclajes sencillos y dobles en "L" para puntos fijos y deslizantes del montante, vuelo máximo de 150mm; subestructura secundaria: Perfiles de arranque y perfiles guía de junta corriente de 3 mm. de 3,6 metros de longitud; formación de esquina con perfil en “Y” según planos de detalle;  toda la subestructura será en aluminio de aleación 6063 y tratamiento T-5; separadores de polyamida para juntas verticales de 3 mm; tornillería necesaria autorroscante INOX tipo A2. Incluso replanteo, piezas especiales y formación de encuentros y remates; según CTE. Medida deduciendo huecos.

### 06EVR80381N - FACHADA VENTILADA CON PLACAS DE HORMIGÓN POLÍMERO

**Unidad:** m2.

Fachada ventilada, o equivalente, con placas de hormigón polímero y sistema de fijación oculto, sistema horizontal, con DIT, compuesta por: hoja exterior con placas de hormigón polímero, núcleo fabricado por molde mediante mezcla de áridos de basalto, sílice y cuarzo con resinas de poliester, capa superficial de resinas termoestables, idóneas para uso exterior resistentes a los rayos UV y resto de agentes atmosféricos, con acabado superficial de Gel-Coat, de 500 x 900 mm y 14 mm de espesor, textura y color porfido a elegir por la DF, ranuradas en toda su longitud del canto superior e inferior, preparadas para su colocación sobre los perfiles-guía; subestructura primaria: Montantes en "T", y anclajes sencillos y dobles en "L" para puntos fijos y deslizantes del montante, vuelo máximo de 150mm; subestructura secundaria: Perfiles de arranque y perfiles guía de junta corriente de 3 mm. de 3,6 metros de longitud; formación de esquina con perfil en “Y” según planos de detalle;  toda la subestructura será en aluminio de aleación 6063 y tratamiento T-5; separadores de polyamida para juntas verticales de 3 mm; tornillería necesaria autorroscante INOX tipo A2. Incluso replanteo, piezas especiales y formación de encuentros y remates; según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Fachadas ventiladas

**Clasificación:** 06EV. **Capítulo:** albañilería. **Familia:** cerramientos especiales.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «fachadas ventiladas», dentro de «cerramientos especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Comprobar continuidad del cerramiento y sus capas, anclajes y control de agua y vapor; no obstruir cámaras ventiladas. Comprobar subestructura, anclajes, cámara y barreras de fuego previstas; permitir dilatación y drenaje sin fijaciones improvisadas.

Para la variante «fachadas ventiladas» se comprobarán expresamente sistema de fachada, acciones de viento, cámara y fijaciones; acciones de viento, anclajes, cámara y comportamiento al fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
