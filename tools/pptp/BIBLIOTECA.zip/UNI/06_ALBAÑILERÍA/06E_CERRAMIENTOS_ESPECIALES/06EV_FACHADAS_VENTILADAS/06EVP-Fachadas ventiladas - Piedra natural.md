"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Fachadas ventiladas - Piedra natural

**Clasificación BCCA:** `06EVP`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Piedra natural**, dentro de **Fachadas ventiladas**.
Aplicable a las partidas cuyo código BCCA comienza por `06EVP`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06EVP80320 - FACHADA VENTILADA PIEZAS DE MÁRMOL CREMA 30x30x2 cm

**Unidad:** m2.

Fachada ventilada compuesta por, hoja interior de fábrica de medio pie de espesor con ladrillo perforado fonorresistente 24x11,5x10 cm, para revestir, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, hoja exterior pasante de 2 cm de espesor con piezas de mármol crema marfil de 60x40x2 cm, acabado pulido, sujetas con cuatro pletinas ocultas de acero inoxidable por pieza, de 3 mm de espesor y 30 mm de ancho, anclados con mortero M5 de cemento blanco BL II/A-L 42,5 R, incluso p.p. de elementos metálicos de sujeción al forjado y conectores de las hojas, ejecución de encuentros, piezas especiales y rejuntado; según CTE. Medida deduciendo huecos.

### 06EVP80340 - FACHADA VENTILADA PIEZAS DE GRANITO ROSA PORRIÑO 60x40x2 cm

**Unidad:** m2.

Fachada ventilada compuesta por, hoja interior de fábrica de medio pie de espesor con ladrillo perforado fonorresistente de 24x11,5x10 cm, para revestir, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, hoja exterior pasante de 2 cm de espesor con piezas de granito rosa de 60x40x2 cm, acabado pulido, sujetas con cuatro pletinas ocultas de acero inoxidable por pieza, de 3 mm de espesor y 30 mm de ancho, anclados con mortero M5 de cemento blanco BL II/A-L 42,5 R, incluso p.p. de elementos metálicos de sujeción al forjado y conectores de las hojas, ejecución de encuentros, piezas especiales y rejuntado; según CTE. Medida deduciendo huecos.

### 06EVP80360 - FACHADA VENTILADA ARENISCA APOMAZADA 60x40x2 cm

**Unidad:** m2.

Fachada ventilada compuesta por, hoja interior de fábrica de medio pie de espesor con ladrillo perforado fonorresistente de 24x11,5x10 cm, para revestir, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, hoja exterior pasante de 2 cm de espesor con piezas de arenisca de 60x40x2 cm, acabado apomazado, sujetas con cuatro anclajes vistos en acero inoxidable longitudinales y continuos en forma de T, anclados con mortero M5 de cemento blanco BL II/A-L 42,5 R, incluso p.p. de elementos metálicos de sujeción al forjado y conectores de las hojas, ejecución de encuentros, piezas especiales y rejuntado; según CTE. Medida deduciendo huecos.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Fachadas ventiladas

**Clasificación:** 06EV. **Capítulo:** albañilería. **Familia:** cerramientos especiales.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «fachadas ventiladas», dentro de «cerramientos especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Comprobar continuidad del cerramiento y sus capas, anclajes y control de agua y vapor; no obstruir cámaras ventiladas. Comprobar subestructura, anclajes, cámara y barreras de fuego previstas; permitir dilatación y drenaje sin fijaciones improvisadas.

Para la variante «fachadas ventiladas» se comprobarán expresamente sistema de fachada, acciones de viento, cámara y fijaciones; acciones de viento, anclajes, cámara y comportamiento al fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
