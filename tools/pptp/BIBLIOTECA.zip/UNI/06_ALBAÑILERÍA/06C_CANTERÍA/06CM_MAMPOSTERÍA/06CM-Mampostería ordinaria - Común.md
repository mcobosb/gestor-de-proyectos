# Mampostería ordinaria - Común

**Clasificación:** 06CM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Descripción

Fábrica de piedra natural trabada con mortero, con geometría y función definidas en el proyecto.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1011–1011. Transcripción para trazabilidad.

## Ejecución

Aprobar piedra y mortero, preparar apoyo y disponer piezas estables con trabazón transversal y juntas llenas. Evitar continuidad de juntas, comprobar alineación y disponer drenaje cuando retenga tierras. Las dimensiones, capacidad y cimentación deben estar justificadas; no deducir estabilidad sólo de la cantidad de tizones.

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1012–1017. Transcripción para trazabilidad.

Las piedras se trabajarán con el fin de quitarles todas las partes delgadas o débiles, así como las irregularidades de las caras que puedan dificultar la adherencia entre el mortero y la piedra, o el encaje de las piedras entre sí.
Las caras vistas de los mampuestos se prepararán únicamente a labra tosca, con martillo, pudiéndose emplear mampuestos de todas las dimensiones, con las limitaciones anteriormente indicadas.
Las tolerancias de desvío en las caras de asiento, respecto a un plano, y en juntas respecto a la línea recta, serán inferiores a 1,5 cm.
La capacidad de absorción de agua de las piedras será inferior al 3% de su peso.
Se colocarán mampuestos de suficiente tizón para atravesarlo en todo su espesor, de forma que exista al menos una de estas piezas por metro cuadrado.
El Contratista vendrá obligado a dejar en la fábrica mechinales u orificios, regularmente dispuestos, para facilitar la evacuación de agua de trasdós de la misma, a razón de uno por cada cuatro metros de paramento.

## Medición y valoración

El original no fija criterio económico específico. Se propone m³ netos de fábrica terminada, con piedra, mortero, colocación y auxiliares, sujeto a aprobación y a que no esté incluida en otra unidad.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
