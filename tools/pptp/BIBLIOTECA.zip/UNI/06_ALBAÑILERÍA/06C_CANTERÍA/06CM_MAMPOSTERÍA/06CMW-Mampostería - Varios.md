"""
# Mampostería - Varios

**Clasificación BCCA:** `06CMW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Mampostería**.
Aplicable a las partidas cuyo código BCCA comienza por `06CMW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Mampostería ordinaria

**Clasificación:** 06CM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

"""
#### Descripción

Fábrica de piedra natural trabada con mortero, con geometría y función definidas en el proyecto.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1011–1011. Transcripción para trazabilidad.
"""

#### Ejecución

Aprobar piedra y mortero, preparar apoyo y disponer piezas estables con trabazón transversal y juntas llenas. Evitar continuidad de juntas, comprobar alineación y disponer drenaje cuando retenga tierras. Las dimensiones, capacidad y cimentación deben estar justificadas; no deducir estabilidad sólo de la cantidad de tizones.

"""
Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1012–1017. Transcripción para trazabilidad.
"""

Las piedras se trabajarán con el fin de quitarles todas las partes delgadas o débiles, así como las irregularidades de las caras que puedan dificultar la adherencia entre el mortero y la piedra, o el encaje de las piedras entre sí.
Las caras vistas de los mampuestos se prepararán únicamente a labra tosca, con martillo, pudiéndose emplear mampuestos de todas las dimensiones, con las limitaciones anteriormente indicadas.
Las tolerancias de desvío en las caras de asiento, respecto a un plano, y en juntas respecto a la línea recta, serán inferiores a 1,5 cm.
La capacidad de absorción de agua de las piedras será inferior al 3% de su peso.
Se colocarán mampuestos de suficiente tizón para atravesarlo en todo su espesor, de forma que exista al menos una de estas piezas por metro cuadrado.
El Contratista vendrá obligado a dejar en la fábrica mechinales u orificios, regularmente dispuestos, para facilitar la evacuación de agua de trasdós de la misma, a razón de uno por cada cuatro metros de paramento.

#### Medición y valoración

El original no fija criterio económico específico. Se propone m³ netos de fábrica terminada, con piedra, mortero, colocación y auxiliares, sujeto a aprobación y a que no esté incluida en otra unidad.

La valoración se efectuará según la unidad y el precio del cuadro de precios aprobado. No se abonarán por separado trabajos incluidos en la unidad ni se crearán precios nuevos.
