"""
# Varios - Varios

**Clasificación BCCA:** `06CWW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Varios**.
Aplicable a las partidas cuyo código BCCA comienza por `06CWW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 06CWW80000 - DINTEL DE PIEDRA CALIZA LABRADA ABUJARDADA 10x30 cm

**Unidad:** m.

Dintel con piedra caliza labrada, de sección 10x30 cm, con acabado abujardado en las caras vistas, recibida con mortero M5 (1:6) de cemento CEM II/A-L 32,5 N, incluso matado de cantos vistos, rejuntado y limpieza. Medida la longitud ejecutada por la arista interior del hueco.

### 06CWW80050 - DINTEL DE PIEDRA GRANÍTICA LABRADA ABUJARDADA 10x30 cm

**Unidad:** m.

Dintel con piedra granítica labrada, de sección 10x30 cm, con acabado abujardado en las caras vistas, recibida con mortero M5 (1:6) de cemento CEM II/A-L 32,5 N, incluso matado de cantos vistos, rejuntado y limpieza. Medida la longitud ejecutada por la arista interior del hueco.

### 06CWW81000 - MOCHETA DE PIEDRA CALIZA LABRADA ABUJARDADA 10x30 cm

**Unidad:** m.

Mocheta de 30 cm de anchura con piedra caliza labrada, de sección 10x30 cm, con acabado abujardado en las caras vistas, recibida con mortero M5 (1:6) de cemento CEM II/A-L 32,5 N, incluso matado de cantos vistos, rejuntado y limpieza. Medida la longitud ejecutada por la arista interior del hueco.

### 06CWW81050 - MOCHETA DE PIEDRA GRANÍTICA LABRADA ABUJARDADA 10x30 cm

**Unidad:** m.

Mocheta de 30 cm de anchura con piedra granítica labrada, de sección 10x30 cm, con acabado abujardado en las caras vistas, recibida con mortero M5 (1:6) de cemento CEM II/A-L 32,5 N, incluso matado de cantos vistos, rejuntado y limpieza. Medida la longitud ejecutada por la arista interior del hueco.

### 06CWW82000 - CORNISA DE PIEDRA CALIZA LABRADA DE SECCIÓN CAPAZ 25x25 cm

**Unidad:** m.

Cornisa con piedra caliza labrada, de sección capaz 25x25 cm, moldurada con forma de pecho de paloma o similar, con acabado abujardado en las cara vistas, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, incluso rejuntado y limpieza. Medida la longitud ejecutada.

### 06CWW82100 - CORNISA DE PIEDRA GRANÍTICA LABRADA DE SECCIÓN CAPAZ 25x25 cm

**Unidad:** m.

Cornisa con piedra granítica labrada, de sección capaz 25x25 cm, moldurada con forma de pecho de paloma o similar, con acabado abujardado en las cara vistas, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, incluso rejuntado y limpieza. Medida la longitud ejecutada.

### 06CWW83000 - IMPOSTA CON PIEDRA CALIZA LABRADA 15x40 cm

**Unidad:** m.

Imposta con piedra caliza labrada, de sección 40x15 cm, con acabado moldurado en las cara vista, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, incluso rejuntado y limpieza. Medida la longitud ejecutada.

### 06CWW83100 - IMPOSTA CON PIEDRA GRANÍTICA LABRADA 5x40 cm

**Unidad:** m.

Imposta con piedra granítica labrada, de sección 40x15 cm, con acabado moldurado en las cara vista, recibida con mortero M5 de cemento CEM II/A-L 32,5 N, incluso rejuntado y limpieza. Medida la longitud ejecutada.

### 06CWW84000 - VIERTEAGUAS DE PIEDRA GRANÍTICA 30x3 cm

**Unidad:** m.

Vierteaguas de piedra granítica labrada de 30 cm de anchura y 3 cm de espesor, con goterón y acabado apomazado en las caras vistas, recibido con mortero bastardo M10 (1:0,5:4), incluso matado de cantos vistos, rejuntado con lechada de cemento blanco BL II/A-L 42,5 R, p.p. de sellado de juntas con paramentos y limpieza. Medido según la anchura libre del hueco.

### 06CWW84100 - VIERTEAGUAS DE PIEDRA CALIZA 30x3 cm

**Unidad:** m.

Vierteaguas de piedra caliza labrada de 30 cm de ancho y 3 cm de espesor, con goterón y acabado apomazado en las caras vistas, recibido con mortero bastardo M10 (1:0,5:4), incluso matado de cantos vistos, rejuntado con lechada de cemento blanco BL II/A-L 42,5 R, p.p. de sellado de juntas con paramentos y limpieza. Medido según la anchura libre del hueco.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### CANTERÍA - varios

**Clasificación:** 06CW. **Capítulo:** albañilería. **Familia:** cantería.

"""
#### Descripción

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

Seleccionar piezas de piedra y aparejo; resolver trabazón, juntas, apoyos y anclajes sin concentrar cargas en aristas.

Para la variante «varios» se comprobarán expresamente roca, geometría, mortero, aparejo y función resistente. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
