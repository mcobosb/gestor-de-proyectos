# varios

**Clasificación:** 11AW. **Capítulo:** carpintería y elementos de seguridad y protección. **Familia:** acero.

## Descripción

Carpinterías, cierres y elementos de protección con dimensiones, herrajes, anclajes y prestaciones definidos para su emplazamiento.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Comprobar huecos y apoyos; replantear, anclar y sellar con productos compatibles. Ajustar hojas y herrajes y proteger acabados. No fijar elementos de seguridad a soportes sin capacidad resistente comprobada.

Comprobar protección anticorrosiva del acero y compatibilidad de herrajes y sellantes, incluidos puntos de corte y soldadura.

Para la variante «varios» se comprobarán expresamente perfiles, uniones, galvanizado o pintura y uso. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar apertura, cierre, holguras, anclajes y sellados; verificar prestaciones de seguridad, accesibilidad, viento, agua, aire y fuego según el uso.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

ud de conjunto completo o m² de carpintería tipificada; barandillas, rejas o cerramientos en m, m² o ud según presupuesto. Definir vidrio, herrajes, sellado y acabados incluidos antes de medir.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
