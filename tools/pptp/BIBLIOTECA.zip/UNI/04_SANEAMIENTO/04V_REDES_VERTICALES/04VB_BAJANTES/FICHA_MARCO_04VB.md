# bajantes

**Clasificación:** 04VB. **Capítulo:** saneamiento. **Familia:** redes verticales.

## Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «bajantes», dentro de «redes verticales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

## Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar soportes de bajantes, ventilación, encuentros de plantas y sellado de pasos de sectores cuando proceda.

Para la variante «bajantes» se comprobarán expresamente caudales, material, soportes, ventilación y protección de pasos. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

## Medición y valoración

m de trazado realmente instalado y aceptado, diferenciado por material, diámetro o sección y condiciones de montaje. El presupuesto definirá longitud en eje, accesorios, soportes y conexiones incluidos; separar equipos y obra civil sólo si no se incluyen en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
