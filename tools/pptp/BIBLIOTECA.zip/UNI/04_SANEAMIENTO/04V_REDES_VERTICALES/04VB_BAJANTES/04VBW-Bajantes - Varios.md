"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Bajantes - Varios

**Clasificación BCCA:** `04VBW`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Varios**, dentro de **Bajantes**.
Aplicable a las partidas cuyo código BCCA comienza por `04VBW`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

El BC3 de origen define esta clasificación pero no contiene partidas desarrolladas bajo este código. La ficha identifica su alcance; deben completarse sus prescripciones antes de usarla como condición contractual.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Bajantes

**Clasificación:** 04VB. **Capítulo:** saneamiento. **Familia:** redes verticales.

"""
#### Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «bajantes», dentro de «redes verticales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar soportes de bajantes, ventilación, encuentros de plantas y sellado de pasos de sectores cuando proceda.

Para la variante «bajantes» se comprobarán expresamente caudales, material, soportes, ventilación y protección de pasos. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

m de trazado realmente instalado y aceptado, diferenciado por material, diámetro o sección y condiciones de montaje. El presupuesto definirá longitud en eje, accesorios, soportes y conexiones incluidos; separar equipos y obra civil sólo si no se incluyen en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
