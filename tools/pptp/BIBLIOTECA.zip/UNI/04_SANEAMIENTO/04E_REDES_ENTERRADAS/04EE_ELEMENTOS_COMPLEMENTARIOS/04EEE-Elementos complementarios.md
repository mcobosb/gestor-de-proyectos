"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca incluida en el software v1.6.0 | Fecha: 10/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
# Elementos complementarios

**Clasificación BCCA:** `04EEE`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Elementos complementarios**, dentro de **Elementos complementarios**.
Aplicable a las partidas cuyo código BCCA comienza por `04EEE`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 04EEE00101 - SUMIDERO SIFÓNICO HIERRO FUND. SAL. HORIZ. DIÁM. 140 mm

**Unidad:** u.

Sumidero sifónico de salida horizontal de 140 mm de diámetro, con rejilla de hierro fundido, incluso pequeño material de recibido; construido según CTE. Medida la cantidad ejecutada.

### 04EEE00102 - SUMIDERO SIFÓNICO PVC SALIDA DE DIÁM. 110 mm

**Unidad:** u.

Sumidero sifónico de PVC con salida de 110 mm de diámetro, con rejilla plana de PVC, incluso pequeño material de recibido y colocación; construido según CTE. Medida la cantidad ejecutada.

### 04EEE90001 - SEPARADOR DE GRASAS Y FANGOS 1x1 m Y PROF. 1,50 m.

**Unidad:** u.

Separador de grasas y fangos de 1x1 m y 1,50 m de profundidad, formado por solera de hormigón HM-20 de 20 cm de espesor, fábrica de ladrillo perforado por tabla de 1 pie, enfoscada y bruñida por el interior y tapa de hormigón armado con cerco de perfil laminado L 50.5, incluso excavación en tierras y relleno; construido según CTE y Ordenanza Municipal. Medida la cantidad ejecutada.

### 04EEE90051 - ARQUETA DE BOMBEO DE 63X63 cm Y PROFUNDIDAD 1,20 m.

**Unidad:** u.

Arqueta de bombeo de 63x63 cm y 1,20 m de profundidad, formada por solera de hormigón HM-20 de15 cm de espesor, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior, bancada formada por dado de hormigón, tapa de hormigón armado con cerco de perfil laminado y L 50.5, conexión de tubos de alcantarillado, incluso excavación en tierras y relleno; construido según CTE y Ordenanza Municipal. Medida la cantidad ejecutada.

### 04EEE90056 - ARQUETA DE BOMBEO 1x1 m Y PROFUNDIDAD 1,80 m.

**Unidad:** u.

Arqueta de bombeo de 1x1 m y 1,80 de profundidad, formada por solera de hormigón HM-20 de 15 cm de espesor fábrica de ladrillo perforado por tabla de 1 pie, enfoscada y bruñida por el interior, bancada formada por dado de hormigón tapa de hormigón armado con cerco de perfil laminado L 50.5, conexión de tubos de alcantarillado, incluso excavación entierras y relleno; construido según CTE y Ordenanza Municipal. Medida la cantidad ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Elementos complementarios

**Clasificación:** 04EE. **Capítulo:** saneamiento. **Familia:** redes enterradas.

"""
#### Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «elementos complementarios», dentro de «redes enterradas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar cama, pendiente, uniones y relleno lateral antes de cubrir; inspeccionar pozos y pruebas por tramos.

Para la variante «elementos complementarios» se comprobarán expresamente cargas de tráfico, sección de zanja y ensayo de estanqueidad. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

Conducciones: m de longitud instalada con regla expresa para accesorios. Arquetas, pozos, sumideros y acometidas: ud tipificada o la base prevista en presupuesto. Separar excavación, relleno y reposición sólo cuando no estén incluidos.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
