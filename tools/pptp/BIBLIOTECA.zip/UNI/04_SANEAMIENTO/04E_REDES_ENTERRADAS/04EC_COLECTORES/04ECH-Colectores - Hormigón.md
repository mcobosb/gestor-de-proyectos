"""
# Colectores - Hormigón

**Clasificación BCCA:** `04ECH`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Hormigón**, dentro de **Colectores**.
Aplicable a las partidas cuyo código BCCA comienza por `04ECH`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 04ECH90001 - COLECTOR ENTERR. HORM. DIÁM. 150 mm CON RECALCE, EN TIERRAS

**Unidad:** m.

Colector enterrado de hormigón, de 150 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm de espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90002 - COLECTOR ENTERR. HORM. DIÁM. 200 mm CON RECALCE, EN TIERRAS

**Unidad:** m.

Colector enterrado de hormigón, de 200 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm de espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90003 - COLECTOR ENTERR. HORM. DIÁM. 250 mm CON RECALCE, EN TIERRAS

**Unidad:** m.

Colector enterrado de hormigón de 250 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm de espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90004 - COLECTOR ENTERR. HORM. DIÁM. 300 mm CON RECALCE, EN TIERRAS

**Unidad:** m.

Colector enterrado de hormigón, de 300 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm de espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en tierras y relleno; construido CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90005 - COLECTOR ENTERRADO, HORMIGÓN, DIÁM. 150 mm CON REFUERZO

**Unidad:** m.

Colector enterrado de hormigón, de 150 mm de diámetro nominal, colocado sobre solera de 10 cm de espesor y con refuerzo de hormigón HM-20, incluso p.p. de cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90006 - COLECTOR ENTERRADO, HORMIGÓN, DIÁM. 200 mm CON REFUERZO

**Unidad:** m.

Colector enterrado de hormigón, de 200 mm de diámetro nominal, colocado sobre solera de 10 cm de espesor y con refuerzo de hormigón HM-20, incluso p.p. de cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90007 - COLECTOR ENTERRADO, HORMIGÓN, DIÁM. 250 mm CON REFUERZO

**Unidad:** m.

Colector enterrado de hormigón, de 250 mm de diámetro nominal, colocado sobre solera de 10 cm de espesor y con refuerzo de hormigón HM-20, incluso p.p. de cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90008 - COLECTOR ENTERRADO, HORMIGÓN, DIÁM. 300 mm CON REFUERZO

**Unidad:** m.

Colector enterrado de hormigón, de 300 mm de diámetro nominal, colocado sobre solera de 10 cm de espesor y con refuerzo de hormigón HM-20, incluso p.p. de cinta de señalización, apisonado, excavación en tierras y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90010 - DRENAJE CON TUBO DE HORMIGÓN POROSO, DIÁM. 150 mm

**Unidad:** m.

Drenaje con tubo de hormigón poroso, de 150 mm de diámetro nominal, colocado sobre lecho de hormigón y bajo relleno de gravas, incluso excavación en tierras y relleno filtrante con grava gruesa; construido según CTE. Medida la longitud ejecutada.

### 04ECH90052 - COLECTOR ENTERR. HORMIG. DIÁM. 200 mm CON RECALCE, EN ROCA

**Unidad:** m.

Colector enterrado de hormigón, de 200 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en roca y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90053 - COLECTOR ENTERR. HORMIG. DIÁM. 250 mm CON RECALCE, EN ROCA

**Unidad:** m.

Colector enterrado de hormigón, de 250 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm de espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en roca y relleno; construido según CTE. Medida la longitud entre ejes de arquetas.

### 04ECH90054 - COLECTOR ENTERR. HORMIG. DIÁM. 300 mm CON RECALCE, EN ROCA

**Unidad:** m.

Colector enterrado de hormigón, de 300 mm de diámetro nominal, colocado sobre solera de hormigón HM-20 de 10 cm de espesor y recalce de hormigón HM-20 hasta eje horizontal, incluso p.p. de corchetes de hormigón, cinta de señalización, apisonado, excavación en roca; construido según CTE. Medida la longitud entre ejes de arquetas.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Colectores

**Clasificación:** 04EC. **Capítulo:** saneamiento. **Familia:** redes enterradas.

"""
#### Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «colectores», dentro de «redes enterradas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar cama, pendiente, uniones y relleno lateral antes de cubrir; inspeccionar pozos y pruebas por tramos.

Para la variante «colectores» se comprobarán expresamente cargas de tráfico, sección de zanja y ensayo de estanqueidad. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

m de trazado realmente instalado y aceptado, diferenciado por material, diámetro o sección y condiciones de montaje. El presupuesto definirá longitud en eje, accesorios, soportes y conexiones incluidos; separar equipos y obra civil sólo si no se incluyen en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
