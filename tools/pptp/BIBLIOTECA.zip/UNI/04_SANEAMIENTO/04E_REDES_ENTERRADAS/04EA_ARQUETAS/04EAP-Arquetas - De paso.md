"""
# Arquetas - De paso

**Clasificación BCCA:** `04EAP`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **De paso**, dentro de **Arquetas**.
Aplicable a las partidas cuyo código BCCA comienza por `04EAP`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 04EAP90001 - ARQUETA DE PASO DE 51X51 cm 1 m PROF. EXC. EN TIERRAS.

**Unidad:** u.

Arqueta de paso de 51x51 cm y 1 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior, tapa de hormigón armado, con cerco de perfil laminado L 50.5 y conexión de tubos de entrada y salida, incluso excavación en tierras y relleno; construido según CTE. Medida la cantidad ejecutada.

### 04EAP90002 - ARQUETA DE PASO DE 63X63 cm 1 m PROF. EXC. EN TIERRAS.

**Unidad:** u.

Arqueta de paso de 63x63 cm y 1 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior; tapa de hormigón armado con cerco de perfil laminado l50:5 y conexión de tubos de entrada y salida, incluso excavación en tierras y relleno; construido según CTE. Medida la cantidad ejecutada.

### 04EAP90011 - ARQUETA DE PASO DE 51X51 cm 1 m PROF. EXC. EN ROCA.

**Unidad:** u.

Arqueta de paso de 51x51 cm y 1 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior, tapa de hormigón armado, con cerco de perfil laminado L 50.5 y conexión de tubos de entrada y salida, incluso excavación en roca y relleno; construida según CTE. Medida la cantidad ejecutada.

### 04EAP90021 - ARQUETA DE PASO DE 63X63 cm 1 m PROF. EXC. EN ROCA.

**Unidad:** u.

Arqueta de paso de 63x63 cm y 1 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior; tapa de hormigón armado con cerco de perfil laminado L 50.5 y conexión de tubos de entrada y salida, incluso excavación en roca y relleno; construida según CTE. Medida la cantidad ejecutada.

### 04EAP90100 - ARQUETA DE PASO DE 51X51 cm 0,70 m PROF. EXC. EN TIERRAS.

**Unidad:** u.

Arqueta de paso de 51x51 cm y 0,70 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior, tapa de hormigón armado, con cerco de perfil laminado L 50.5 y conexión de tubos de entrada y salida, incluso excavación en tierra y relleno; construido según CTE. Medida la cantidad ejecutada.

### 04EAP90110 - ARQUETA DE PASO DE 51X51 cm 0,70 m PROF. EXC. EN ROCA.

**Unidad:** u.

Arqueta de paso de 51x51 cm y 0,70 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior, tapa de hormigón armado, con cerco de perfil laminado L 50.5 y conexión de tubos de entrada y salida, incluso excavación en roca y relleno; construida según CTE. Medida la cantidad ejecutada.

### 04EAP90200 - ARQUETA DE PASO DE 63X63 cm 0,70 m PROF. EXC. EN TIERRAS.

**Unidad:** u.

Arqueta de paso de 63x63 cm y 0,70 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior; tapa de hormigón armado con cerco de perfil laminado l50:5 y conexión de tubos de entrada y salida, incluso excavación en tierras y relleno; construido según CTE. Medida la cantidad ejecutada.

### 04EAP90210 - ARQUETA DE PASO DE 63X63 cm 0,70 m PROF. EXC. EN ROCA.

**Unidad:** u.

Arqueta de paso de 63x63 cm y 0,70 m de profundidad media, formada por solera de hormigón HM-20 de 15 cm de espesor con formación de pendientes, fábrica de ladrillo perforado por tabla de 1/2 pie, enfoscada y bruñida por el interior; tapa de hormigón armado con cerco de perfil laminado L 50.5 y conexión de tubos de entrada y salida, incluso excavación en roca y relleno; construida según CTE. Medida la cantidad ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Arquetas

**Clasificación:** 04EA. **Capítulo:** saneamiento. **Familia:** redes enterradas.

"""
#### Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «arquetas», dentro de «redes enterradas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar cama, pendiente, uniones y relleno lateral antes de cubrir; inspeccionar pozos y pruebas por tramos.

Para la variante «arquetas» se comprobarán expresamente cargas de tráfico, sección de zanja y ensayo de estanqueidad. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

ud de elemento completo de tipología, dimensiones y prestaciones definidas, instalado y con la recepción exigida. Precisar conexiones, anclajes, pruebas y obra civil incluidos, evitando certificar de nuevo componentes del conjunto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
