"""
# Colectores - P.V.C.

**Clasificación BCCA:** `04CCP`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **P.V.C.**, dentro de **Colectores**.
Aplicable a las partidas cuyo código BCCA comienza por `04CCP`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 04CCP00001 - COLECTOR COLGADO DE PVC DIÁM. 160 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 160 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo, pequeño material y ayudas de albañilería; construido según CTE. Medida la longitud ejecutada.

### 04CCP00002 - COLECTOR COLGADO DE PVC DIÁM. 200 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 200 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo, pequeño material y ayudas de albañilería; construido según CTE. Medida la longitud ejecutada.

### 04CCP00003 - COLECTOR COLGADO DE PVC DIÁM. 110 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 110 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo, pequeño material y ayudas de albañilería; construido según CTE. Medida la longitud ejecutada.

### 04CCP00004 - COLECTOR COLGADO DE PVC DIÁM. 125 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 125 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo,pequeño material y ayudas de albañilería; construido según CTE. Medida la longitud ejecutada.

### 04CCP00011 - COLECTOR COLGADO DE PVC DIÁM. 90 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 90 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo, pequeño material y ayudas de albañilería; construido según CTE. Medida la longitud ejecutada.

### 04CCP00021 - COLECTOR COLGADO DE PVC DIÁM. 250 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 250 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo, pequeño material y ayudas de albañilería; construida según CTE. Medida la longitud ejecutada.

### 04CCP00031 - COLECTOR COLGADO DE PVC DIÁM. 315 mm

**Unidad:** m.

Colector colgado de PVC, presión 4 kg/cm2, de 315 mm de diámetro nominal, incluso p.p. de piezas especiales, abrazaderas, contratubo, pequeño material y ayudas de albañilería; construido según CTE. Medida la longitud ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Colectores

**Clasificación:** 04CC. **Capítulo:** saneamiento. **Familia:** redes colgadas.

"""
#### Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «colectores», dentro de «redes colgadas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar soportación de la red colgada, dilataciones, pendiente y accesibilidad; no transmitir al tubo cargas de otros sistemas.

Para la variante «colectores» se comprobarán expresamente separación y capacidad de soportes, juntas y registros. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

m de trazado realmente instalado y aceptado, diferenciado por material, diámetro o sección y condiciones de montaje. El presupuesto definirá longitud en eje, accesorios, soportes y conexiones incluidos; separar equipos y obra civil sólo si no se incluyen en el precio.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
