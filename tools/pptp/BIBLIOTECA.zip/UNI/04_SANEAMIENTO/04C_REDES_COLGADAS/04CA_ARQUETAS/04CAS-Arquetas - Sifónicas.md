"""
# Arquetas - Sifónicas

**Clasificación BCCA:** `04CAS`.
**Fuente:** BCCA 2023, revisión V02, clasificación y descripciones BC3.

## Alcance específico

Esta ficha corresponde exclusivamente a **Sifónicas**, dentro de **Arquetas**.
Aplicable a las partidas cuyo código BCCA comienza por `04CAS`. No extiende su alcance a las variantes con una tercera letra distinta.

## Unidades de referencia BCCA

### 04CAS00001 - ARQUETA SIFÓNICA COLGADA DE POLIÉSTER DE 60X60 cm

**Unidad:** u.

Arqueta sifónica colgada de fibra de poliéster reforzada de 60x60 cm y 1 m de profundidad, incluso conexiones con colectores de entrada y salida, elementos metálicos de cuelgue, accesorios y ayudas de albañilería; construida según Ordenanza Municipal. Medida la cantidad ejecutada.

### 04CAS00002 - ARQUETA SIFÓNICA COLGADA DE POLIÉSTER DE 1x1 m

**Unidad:** u.

Arqueta sifónica colgada de fibra de poliéster reforzada de 1x1 m y 1 m de profundidad, incluso conexiones con colectores de entrada y salida, elementos metálicos de cuelgue, accesorios y ayudas de albañilería; construida según Ordenanza Municipal. Medida la cantidad ejecutada.

## Aplicación, medición y valoración

Seleccionar la unidad concreta del presupuesto y comprobar sus características, inclusiones, exclusiones y criterio de medición. Las descripciones anteriores son referencias alternativas del BCCA, no prestaciones acumulables ni una orden de ejecutar todas las variantes.

La ejecución, los controles y la recepción deben ajustarse a la documentación contractual, a las condiciones comunes aplicables y a la normativa vigente. Esta clasificación no sustituye la revisión técnica del pliego.

## Prescripciones integradas de la familia

Estas condiciones se aplican exclusivamente al material y a la operación de esta ficha, en lo compatible con la partida aprobada. Las condiciones de variantes distintas son alternativas, no acumulables. Si una prescripción general contradice las inclusiones, exclusiones o la medición de la unidad concreta, debe revisarse antes de incorporar la ficha al contrato.

### Arquetas

**Clasificación:** 04CA. **Capítulo:** saneamiento. **Familia:** redes colgadas.

"""
#### Descripción

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «arquetas», dentro de «redes colgadas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

La unidad comprende exclusivamente los trabajos y elementos propios de esta partida, dentro de los límites y condiciones de la documentación contractual; no incluye variantes ni trabajos ajenos a su alcance.

#### Ejecución

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

Comprobar soportación de la red colgada, dilataciones, pendiente y accesibilidad; no transmitir al tubo cargas de otros sistemas.

Para la variante «arquetas» se comprobarán expresamente separación y capacidad de soportes, juntas y registros. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

La dirección facultativa comprobará la ejecución, registrará las incidencias y exigirá la resolución documentada de las no conformidades antes de aceptar los trabajos.

#### Medición y valoración

ud de elemento completo de tipología, dimensiones y prestaciones definidas, instalado y con la recepción exigida. Precisar conexiones, anclajes, pruebas y obra civil incluidos, evitando certificar de nuevo componentes del conjunto.

La medición se ajustará a la unidad, los límites y las inclusiones del cuadro de precios aprobado; se computarán los trabajos comprobados y aceptados, sin duplicar operaciones o medios auxiliares incluidos en otras unidades.

El abono se realizará conforme al precio y al alcance del cuadro de precios aprobado, sin duplicar transportes, gestión de residuos, medios auxiliares ni ensayos incluidos en otras unidades.
