# cortinas

**Clasificación:** 14WC. **Capítulo:** equipamiento. **Familia:** varios.

## Definición

Equipamiento y mobiliario definido por sus prestaciones, dimensiones, uso y condiciones de instalación.

El objeto de esta ficha es «cortinas», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán modelo o prestaciones equivalentes, dimensiones, cargas, acabados, servicios y condiciones de accesibilidad. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Comprobar accesos, ubicación y compatibilidad con los servicios. Montar, nivelar y anclar conforme al diseño, sin obstaculizar recorridos accesibles ni evacuación. Ajustar componentes y entregar instrucciones y garantías.

### Condiciones de esta clasificación

Comprobar accesibilidad, fijaciones y mantenimiento de elementos decorativos y de señalización.

Para la variante «cortinas» se comprobarán expresamente elemento concreto, emplazamiento y prestaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Verificar estabilidad, fijación, funcionamiento, acabado, ausencia de aristas peligrosas y documentación del equipo.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

ud de equipo o conjunto completo tipificado; superficies de decoración en m² y elementos continuos en m si lo establece la partida. Relacionar accesorios, montaje y conexiones incluidos.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
