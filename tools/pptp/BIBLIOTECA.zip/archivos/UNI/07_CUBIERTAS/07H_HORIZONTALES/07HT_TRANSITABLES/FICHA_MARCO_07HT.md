# transitables

**Clasificación:** 07HT. **Capítulo:** cubiertas. **Familia:** horizontales.

## Definición

Sistemas de cubierta y sus capas, encuentros y elementos de iluminación, definidos como una solución compatible de protección frente al agua y al ambiente.

El objeto de esta ficha es «transitables», dentro de «horizontales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán composición y pendientes, soporte, evacuación, comportamiento térmico y de fuego, fijaciones y prueba de recepción. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Verificar el soporte y las pendientes. Colocar las capas en el orden del sistema aprobado, resolver sumideros, juntas, petos y penetraciones y proteger la impermeabilización antes de recibir las capas superiores. Mantener la seguridad frente a caídas.

### Condiciones de esta clasificación

Comprobar pendientes, capas separadoras y continuidad de la impermeabilización en una cubierta horizontal.

Para la variante «transitables» se comprobarán expresamente uso transitable o no, capas, pendientes y sistema impermeable. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Inspeccionar continuidad, fijaciones y encuentros y efectuar la prueba de estanqueidad prevista, con carga y evacuación compatibles con la estructura.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m² de cubierta con criterio expreso de superficie en proyección o desarrollada; remates y juntas en m y lucernarios en ud o m² tipificado. Precisar las capas incluidas para evitar medir dos veces aislamiento o impermeabilización.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
