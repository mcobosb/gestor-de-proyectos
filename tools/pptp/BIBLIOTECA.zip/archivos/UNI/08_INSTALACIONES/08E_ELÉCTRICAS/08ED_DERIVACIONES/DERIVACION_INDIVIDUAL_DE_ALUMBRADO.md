# Derivación individual de alumbrado

**Clasificación:** 08ED. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Comprobar la designación antigua Cu 750 V, el esquema de enlace y los dispositivos de control efectivamente exigidos.

## Definición

### Criterio de la ficha y complemento técnico

Enlace entre los equipos de medida y el cuadro del suministro de alumbrado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 345–345. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Desde cada uno de los contadores hasta el cuadro de protección, situado en la misma hornacina, se instalarán conductores del tipo Cu 750 v de secciones según proceda, en el interior de tubos según ITC Bt 21, cumpliendo las normas UNE EN50086 2 1, siempre a través de la correspondiente caja para I.C.P antes de su conexión en el cuadro.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Dimensionar conforme a ITC-BT-15 y a la instalación, seleccionar conductores y canalizaciones adecuados y ejecutar sin empalmes no permitidos. Identificar circuitos y realizar verificaciones de continuidad, aislamiento y protecciones antes de la conexión.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 346–347. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

EJECUCIÓN DE OBRA
La instalación interior se hará según norma del Ayuntamiento, cumpliendo con el R.B.T. y la empresa suministradora.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Se integra en la ud conjunta de módulos y derivación de 3.17.2, salvo partida independiente aprobada. No duplicar el abono al utilizar las dos fichas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 348–349. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
El modulo de contadores y derivación individual se medirá como Uds. De obra completamente terminada, realmente ejecutada, se incluirá la hornacina donde va colocada estos elementos.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
