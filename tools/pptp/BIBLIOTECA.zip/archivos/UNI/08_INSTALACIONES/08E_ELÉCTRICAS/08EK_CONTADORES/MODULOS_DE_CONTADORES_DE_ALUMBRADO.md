# Módulos de contadores de alumbrado

**Clasificación:** 08EK. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Las menciones a Sevillana, tarifa nocturna y grados IP de tres cifras son históricas. Confirmar los equipos y grados de protección con la normativa y distribuidora actuales.

## Definición

### Criterio de la ficha y complemento técnico

Envolventes y equipos de medida del suministro de alumbrado exterior.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 341–344. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MODULOS DE CONTADORES Y DERIVACIÓN INDIVIDUAL
DESCRIPCIÓN
Los equipos de medida estarán situados en hornacinas y compuestos por contador trifásico de activa con discriminación horaria y reloj, permisible para la contratación de tarifa nocturna, estos elementos serán a instalar por la Cía. Suministradora en régimen de alquiler. Todo ello, dispuesto en el interior de módulos homologados por la S.A. Sevillana de Electricidad, construidos en material aislante clase A, resistente a los álcalis, auto extinguibles y precintables, con un IP 403 para la caja, las tapas serán de poliéster y dispondrán de dos ventanas trasparentes situadas delante de los diales de los contadores y relojes, y con un IP cuya tercera cifra no sea menor de 7.
Los conjuntos estarán situados de forma tal que los diales de los contadores queden a una altura comprendida entre 0,50 y 1,80 metros, de forma que se facilite la lectura de los mismos. Dispondrán de ventilación para evitar condensaciones. En su interior alojará tres cortacircuitos ZR 2 con sus correspondientes cartuchos de los valores nominales indicados en los esquemas.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aplicar ITC-BT-16 y las condiciones aprobadas de la distribuidora. Verificar accesibilidad de lectura y mantenimiento, protección, ventilación, precintado y segregación de circuitos. Instalar y comprobar por personal habilitado, sin atribuir al contratista equipos en alquiler que corresponda aportar a la distribuidora.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 345–347. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Desde cada uno de los contadores hasta el cuadro de protección, situado en la misma hornacina, se instalarán conductores del tipo Cu 750 v de secciones según proceda, en el interior de tubos según ITC Bt 21, cumpliendo las normas UNE EN50086 2 1, siempre a través de la correspondiente caja para I.C.P antes de su conexión en el cuadro.
EJECUCIÓN DE OBRA
La instalación interior se hará según norma del Ayuntamiento, cumpliendo con el R.B.T. y la empresa suministradora.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original mide conjuntamente módulos y derivación individual por ud completa con hornacina. Mantener esa unidad agrupada salvo que el presupuesto los separe; esta ficha y la de derivación no crean dos abonos.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 348–349. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
El modulo de contadores y derivación individual se medirá como Uds. De obra completamente terminada, realmente ejecutada, se incluirá la hornacina donde va colocada estos elementos.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
