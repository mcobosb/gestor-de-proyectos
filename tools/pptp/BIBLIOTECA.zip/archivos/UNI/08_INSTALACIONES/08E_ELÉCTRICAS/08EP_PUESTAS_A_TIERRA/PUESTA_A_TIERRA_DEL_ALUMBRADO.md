# Puesta a tierra del alumbrado

**Clasificación:** 08EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Ficha complementaria de una obligación reglamentaria explícitamente citada en los equipos; no crea una nueva partida.

## Definición

### Criterio de la ficha y complemento técnico

Red de protección de las masas metálicas del alumbrado, exigida por las prescripciones de cuadros y soportes y por el REBT.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 353–353. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Las partes metálicas del cuadro irán conectada a tierra.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 385–385. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Los soportes que lo requieran, deberán poseer una abertura de dimensiones adecuadas al equipo eléctrico para acceder a los elementos de protección y maniobra; la parte inferior de dicha abertura estará situada, como mínimo, a 0,30 m de la rasante y estará dotada de puerta o trampilla con grado de protección IP44 según UNE 20324 (EN 60529) e IK 10 según UNE EN 50102. La puerta solamente se podrá abrir mediante el empleo de útiles especiales y dispondrán de un borne a tierra cuando sea metálico.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Diseñar y ejecutar la red de tierra y las conexiones equipotenciales conforme a ITC-BT-09 y 18, con materiales y uniones protegidos frente a corrosión. Conectar masas, verificar continuidad y medir resistencia y coordinación con las protecciones antes de la puesta en servicio. No sustituir el cálculo y las medidas por un único valor genérico.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original no define abono separado. Incluir en las unidades correspondientes si así lo prevén sus precios; sólo medir electrodos y conductores por separado cuando existan partidas aprobadas.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
