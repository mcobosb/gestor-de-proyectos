# captadores

**Clasificación:** 08OO. **Capítulo:** instalaciones. **Familia:** energía fotovoltaica.

## Definición

Componentes de instalaciones y equipos, sus soportes y conexiones, integrados en el sistema definido por el proyecto y su reglamentación sectorial.

El objeto de esta ficha es «captadores», dentro de «energía fotovoltaica». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán función, capacidad, dimensiones, alimentación, protecciones, interfaces, reglamentación sectorial y pruebas de puesta en servicio. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Comprobar el diseño, la compatibilidad de equipos y la coordinación con otras redes. Montar con personal y empresa habilitados cuando sea exigible, dejando accesos de mantenimiento. Realizar las pruebas y la puesta en servicio reglamentarias antes de entregar la instalación.

### Condiciones de esta clasificación

Verificar orientación, soporte, cableado y protecciones de corriente continua y alterna; comprobar monitorización y puesta en servicio.

Para la variante «captadores» se comprobarán expresamente potencia, cargas de viento, esquema eléctrico y condiciones de conexión. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Registrar identificación de equipos, controles previos al cierre, ajustes, pruebas funcionales y documentación de puesta en servicio y mantenimiento.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

ud de elemento completo de tipología, dimensiones y prestaciones definidas, instalado y con la recepción exigida. Precisar conexiones, anclajes, pruebas y obra civil incluidos, evitando certificar de nuevo componentes del conjunto.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
