# Índice de fichas de materiales y unidades de obra

Fuentes: [PPTP.md](../../PPTP.md) para las **104 fichas originales** y [catálogo UNI](../../00_capitulos_subcapitulos.xlsx) para las **580 fichas marco nuevas**. Total: **684 fichas**. Cobertura: **637 carpetas finales**, todas con al menos una ficha directa. Organización: carpetas existentes de archivos/UNI, sin añadir niveles. El PPTP se conserva sin modificaciones; las fichas mantienen su contenido técnico con la limpieza de metadatos y encabezados descrita a continuación.

## Catálogo para software y paquete ZIP

- [catalogo.json](catalogo.json) contiene el inventario de fichas, sus códigos y niveles UNI, títulos, rutas relativas, tipo, encabezados y huellas SHA-256. El contenido técnico se obtiene leyendo cada archivo Markdown.
- Las fichas de tipo `marco` se distinguen de las de tipo `pptp`. Los códigos con varias fichas incluyen sus identificadores relacionados; no se debe seleccionar una variante automáticamente sólo por compartir código.
- `seleccion.criterios: null` significa que no hay reglas específicas de material, operación o uso codificadas. La selección requiere confirmación frente a las partidas del proyecto, incluso para códigos con una sola ficha.
- El software debe deduplicar por `id` y asignar la numeración al ensamblar los encabezados en el documento del proyecto. El índice no se incorpora como contenido técnico.
- [BIBLIOTECA_UNI.zip](../BIBLIOTECA_UNI.zip) incluye las fichas, este índice y el catálogo dentro de `archivos/UNI`, además de los documentos fuente disponibles en la raíz del paquete. Se conserva esa estructura para mantener las rutas de los enlaces; extraer el ZIP completo.
- El catálogo registra en `referencias_locales_no_disponibles` los documentos enlazados que ya faltaban en la biblioteca de origen. El empaquetado no reconstruye esos documentos ni acredita la vigencia de las referencias externas.

## Alcance de la ampliación por catálogo

- Se han cubierto únicamente las carpetas finales sin ficha; los capítulos y subcapítulos intermedios siguen siendo agrupaciones, no partidas artificiales. Una clasificación puede contener varias unidades y las fichas originales no implican cobertura de todas sus variantes.
- Las fichas marco nuevas son redacción orientativa por familia y clasificación, no extractos del PPTP ni soluciones calculadas. Contienen Definición, Ejecución en obra y Medición y abono, con los datos que debe definir el proyecto.
- Las categorías «varios» requieren identificar el elemento concreto antes de usarlas. El título del catálogo no basta para prescribir un material, procedimiento, rendimiento o precio.
- La preselección normativa se consulta en [02_DisposicionesTecnicasLegalesAplicables.md](../../02_DisposicionesTecnicasLegalesAplicables.md); se ha retirado de las fichas marco el bloque «Referencias candidatas para revisión». Las referencias de aplicación de las fichas originales se conservan.
- Los criterios de medición de las nuevas fichas son propuestas sujetas al presupuesto y al contrato. No fijan por sí mismos unidades de abono, inclusiones ni precios.
- Se han retirado los bloques de Origen, Estado y Datos pendientes de las fichas. Sus títulos y apartados no llevan numeración y utilizan únicamente los niveles #, ## y ###; los códigos UNI se conservan como metadatos de clasificación y en las tablas del índice.
- La tabla original conserva sus avisos particulares. La segunda tabla identifica todas las fichas marco nuevas y sus datos pendientes; para una búsqueda completa deben consultarse ambas.

## Criterios de las fichas originales y precauciones comunes

- Se han reunido las prescripciones de definición, ejecución y valoración dispersas en los capítulos 3, 4 y 5. Las variantes expresamente descritas y los materiales con requisitos propios tienen ficha independiente.
- Los medios, herramientas y componentes sin prescripción propia (tornillos, maquinaria, agua de curado, etc.) se mantienen en la unidad que los utiliza; no se convierten artificialmente en partidas nuevas.
- Cada ficha contiene un título de nivel 1 y las secciones de nivel 2 Definición, Ejecución en obra y Medición y abono. La transcripción de origen y los complementos técnicos se distinguen expresamente.
- Las transcripciones permiten localizar el texto original; no convalidan erratas, normas antiguas, tablas mal copiadas ni prescripciones incompatibles con disposiciones obligatorias. Los avisos específicos indican los conflictos detectados.
- Los complementos de ejecución son síntesis técnicas apoyadas en las fuentes oficiales enlazadas; no son cálculos de proyecto ni transcripciones de normas UNE. Se debe comprobar la edición aplicable de estas últimas y las condiciones del titular de cada red.
- El PG-3 se utiliza como referencia técnica por remisión del pliego. No se presume que toda disposición de carreteras sea automáticamente obligatoria en cualquier urbanización. El CTE y los reglamentos de instalaciones se aplican dentro de su ámbito.
- La normativa técnica no resuelve por sí sola el abono contractual. Donde falta un criterio económico se propone uno expresamente sujeto a aprobación y se evita cualquier doble medición.
- No se han inventado clases de exposición, recubrimientos numéricos, dimensiones, presiones de ensayo, especies vegetales ni precios que requieren datos del proyecto.
- Consulta normativa realizada el 05/11/2026. Las referencias enlazadas no constituyen una certificación exhaustiva de vigencia de toda la normativa nacional, autonómica, local o de los operadores.

## Fichas originales procedentes del PPTP

| Código | Ficha | Revisión específica |
|---|---|---|
| 01TR | [Reposición y desvío de servicios afectados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TR_ACTUACI%C3%93N_SOBRE_REDES/REPOSICION_DE_SERVICIOS_AFECTADOS.md) | Distinguir reposición prevista de reparación de daños. La clasificación general no reemplaza los requisitos del servicio concreto. |
| 01TV | [Desbroce y limpieza del terreno](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TV_VEGETACI%C3%93N/DESBROCE_Y_LIMPIEZA_DEL_TERRENO.md) | 3.3 fija profundidades de 1 m y 4.5 menciona 50 cm; además aparece la errata «terraplenes con altura inferior a 1 cm». No se corrigen por conjetura: contrastar con perfiles, terreno y PG-3. |
| 01UA | [Demolición de conducciones de saneamiento](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/DEMOLICION_DE_CONDUCCIONES_DE_SANEAMIENTO.md) | La identificación de posibles tubos de fibrocemento con amianto debe preceder a cualquier demolición; esta ficha no habilita su manipulación. |
| 01UA | [Demolición de pozos de saneamiento](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UA_ALCANTARILLADO/DEMOLICION_DE_POZOS_DE_SANEAMIENTO.md) | No confundir esta medición de demolición por altura con la de construcción de pozos. |
| 01UE | [Demolición de arquetas eléctricas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UE_ELECTRICIDAD/DEMOLICION_DE_ARQUETAS_ELECTRICAS.md) | La ejecución requiere coordinación previa con el titular y medidas frente al riesgo eléctrico. |
| 01UE | [Reposición de líneas eléctricas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UE_ELECTRICIDAD/REPOSICION_DE_LINEAS_ELECTRICAS.md) | El REBT sólo cubre baja tensión. Si la línea es de media o alta tensión deberá aplicarse su reglamentación específica; el original no identifica su tensión. |
| 01UP | [Demolición de aceras y pavimentos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/DEMOLICION_DE_ACERAS_Y_PAVIMENTOS.md) | Comprobar el espesor de cada partida y la inclusión del transporte frente a 5.8. |
| 01UT | [Reposición de servicios telefónicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UT_TEL%C3%89FONO/REPOSICION_DE_SERVICIOS_TELEFONICOS.md) | — |
| 01WW | [Demoliciones de construcciones y obras de fábrica](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WW_VARIOS/DEMOLICIONES_DE_CONSTRUCCIONES_Y_OBRAS_DE_FABRICA.md) | El apartado 5.8 contempla transporte a vertedero separado, mientras 3.2 lo incluye. Resolver el alcance con el presupuesto antes de certificar. |
| 02AE | [Excavación para formación de explanada y cajeo](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AE_EXPLANACIONES/EXCAVACION_PARA_FORMACION_DE_EXPLANADA_Y_CAJEO.md) | 3.4 y 5.4 incluyen transporte; 5.5 lo excluye y 5.8 lo abona aparte. Resolver la contradicción sin duplicar la certificación. |
| 02AE | [Refino de la explanada](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AE_EXPLANACIONES/REFINO_DE_LA_EXPLANADA.md) | La frase sobre refino aparece también al final de 5.8, bajo transporte a vertedero; debe revisarse su ubicación contractual para no duplicar costes. |
| 02AT | [Terraplenes](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AT_TERRAPLENES/TERRAPLENES.md) | Verificar la clasificación de los suelos y las exigencias de cada zona del terraplén con el PG-3 incorporado al proyecto. |
| 02AV | [Excavación sin clasificar para cimientos y emplazamientos](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AV_VACIADOS/EXCAVACION_PARA_CIMIENTOS_Y_EMPLAZAMIENTOS.md) | El terreno, la cota y la solución de cimentación requieren comprobación geotécnica y estructural antes de hormigonar. |
| 02RR | [Relleno de trasdós con material seleccionado](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/RELLENO_DE_TRASDOS_CON_MATERIAL_SELECCIONADO.md) | No adoptar el 85 % de Proctor de 4.9 como aceptación automática; precisar ensayo, densidad y limitaciones de equipos con el cálculo del muro. |
| 02RR | [Relleno filtrante de trasdós](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/RELLENO_FILTRANTE_DE_TRASDOS.md) | No se ha inventado granulometría ni geotextil: requieren el diseño del drenaje y las características del terreno. |
| 02RR | [Relleno localizado con material filtrante](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/RELLENO_LOCALIZADO_CON_MATERIAL_FILTRANTE.md) | El original no aporta criterios de filtro; deben establecerse con los suelos y el drenaje proyectados, no mediante una granulometría arbitraria. |
| 02RR | [Relleno localizado con material seleccionado](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/RELLENO_LOCALIZADO_CON_MATERIAL_SELECCIONADO.md) | 4.9 menciona el 85 % del ensayo Proctor sin precisar su modalidad, frente a otras exigencias del documento. Debe fijarse el criterio de aceptación para la ubicación concreta; no adoptar ese mínimo genérico. |
| 02RR | [Relleno y compactación de zanjas](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RR_RELLENOS/RELLENO_Y_COMPACTACION_DE_ZANJAS.md) | El original mezcla 98 % Proctor Modificado, más del 95 % Proctor Modificado y 95 % Proctor Normal, y distintos espesores de tongada. Resolver por zona y servicio antes de ejecutar; no tratarlos como equivalentes. |
| 02TM | [Transporte interior de productos reutilizables](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TM_MEDIOS_MEC%C3%81NICOS/TRANSPORTE_INTERIOR_DE_PRODUCTOS_REUTILIZABLES.md) | La reutilización debe ser técnicamente apta y legalmente admisible; no se presume por estar el material dentro de la obra. |
| 02ZM | [Excavación en zanjas y pozos para tuberías](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZM_MEDIOS_MEC%C3%81NICOS/EXCAVACION_EN_ZANJAS_PARA_TUBERIAS.md) | El original cita entibación a más de 2 m y, en abastecimiento, a más de 1,50 m. Ninguno permite dejar sin protección excavaciones menos profundas que presenten riesgo. |
| 03HM | [Hormigón en masa de 20 MPa](03_CIMENTACIONES/03H_HORMIGONES/03HM_EN_MASA/HORMIGON_EN_MASA_DE_20_MPA.md) | La clase resistente de 20 MPa no exime de comprobar durabilidad ni autoriza su uso en elementos armados. |
| 03HW | [Hormigón de 12,5 MPa: referencia del original a revisar](03_CIMENTACIONES/03H_HORMIGONES/03HW_VARIOS/HORMIGON_DE_12_5_MPA_REFERENCIA_A_REVISAR.md) | Requiere revisión de función y producto antes de utilizarse; la mera denominación «limpieza» no valida cualquier dosificación. |
| 03HW | [Hormigón de 15 MPa: referencia del original a revisar](03_CIMENTACIONES/03H_HORMIGONES/03HW_VARIOS/HORMIGON_DE_15_MPA_REFERENCIA_A_REVISAR.md) | El original asocia 15 MPa a cimentación de cerramientos y otros elementos potencialmente estructurales. Esas aplicaciones requieren revisión y no pueden ejecutarse con esta resistencia por remisión al texto. |
| 03HW | [Hormigón de 6 MPa: referencia del original a revisar](03_CIMENTACIONES/03H_HORMIGONES/03HW_VARIOS/HORMIGON_DE_6_MPA_REFERENCIA_A_REVISAR.md) | No hay datos suficientes para validar el material ni su idoneidad geotécnica; la referencia de 6 MPa no constituye una prescripción ejecutable de sustitución de terreno. |
| 05HA | [Armaduras de acero corrugado para hormigón](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HA_ARMADURAS/ARMADURAS_DE_ACERO_CORRUGADO.md) | 3.23 incluye mermas, despuntes y solapes; 5.13 admite hasta un 5 % adicional. No aplicar ambos criterios acumulativamente. Los 5.100 kg/cm² no identifican por sí solos una clase de acero aprobada. |
| 05HE | [Encofrado curvo de paramentos verticales](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/ENCOFRADO_CURVO_VERTICAL.md) | — |
| 05HE | [Encofrado plano de paramentos verticales e inclinados](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/ENCOFRADO_PLANO_VERTICAL_E_INCLINADO.md) | Comprobar la inclusión del encofrado en los precios de hormigón según 5.12. |
| 05HE | [Encofrados y cimbras de tableros, dinteles y bóvedas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HE_ENCOFRADOS/ENCOFRADOS_Y_CIMBRAS_DE_TABLEROS_DINTELES_Y_BOVEDAS.md) | El abono incluido no elimina la necesidad de justificar estructuralmente cimbras y apeos. |
| 05HH | [Hormigón de 25 MPa para arquetas y pozos armados](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/HORMIGON_DE_25_MPA_PARA_ARQUETAS_Y_POZOS.md) | 25 MPa es un mínimo resistente de hormigón armado, pero una exposición determinada puede exigir prestaciones y dosificación más estrictas. |
| 05HH | [Hormigón de 30 MPa para losas de aparcamiento y rigolas](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/HORMIGON_DE_30_MPA_PARA_LOSAS_Y_RIGOLAS.md) | Los 30 MPa no constituyen una designación completa ni fijan espesor o armado. |
| 05HH | [Hormigón de 35 MPa para elementos prefabricados](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/HORMIGON_DE_35_MPA_PARA_PREFABRICADOS.md) | 3.12 menciona HA-25 para prefabricados y 4.13.2 prescribe 35 MPa. Confirmar con planos, cálculo y producto; no certificar equivalencia entre ambos. |
| 05HH | [Hormigones: materiales, ejecución y control](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HH_PARA_ARMAR/HORMIGONES_PRESCRIPCIONES_GENERALES.md) | Las tablas transcritas de exposición y dosificación no se han validado como tablas del Código y no deben usarse para dimensionar. El original contiene el marcador «Falta el recubrimiento nominal», resistencias históricas inferiores a las estructurales y curados de 5 y 15 días. Aplicar el Código y el diseño aprobado; no trasladar esas tablas ni cifras incompatibles como requisitos válidos. |
| 06CM | [Mampostería ordinaria](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CM_MAMPOSTER%C3%8DA/MAMPOSTERIA_ORDINARIA.md) | La aplicación del CTE depende de que se trate de edificación. Los mechinales y el drenaje deben adecuarse al diseño, no únicamente a una regla genérica de número por superficie. |
| 06LM | [Fábrica de ladrillo cerámico](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LM_MACIZOS/FABRICA_DE_LADRILLO_CERAMICO.md) | Las exigencias de humectación deben ser compatibles con el producto. No medir separadamente fábrica ya incluida en una arqueta o pozo. |
| 06WW | [Cemento para hormigones y morteros](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WW_VARIOS/CEMENTO_PARA_HORMIGONES_Y_MORTEROS.md) | La afirmación del original que vincula «endurecimiento rápido» a a/c ≤ 0,50 no es un criterio válido de clasificación del cemento. Confirmar la designación completa y la agresividad real. |
| 06WW | [Morteros de cemento](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WW_VARIOS/MORTEROS_DE_CEMENTO.md) | La clase y el uso se deben precisar; las normas de mortero de fábrica y revestimiento no son intercambiables. Los 45 minutos del original se conservarán sólo si son compatibles con el sistema aprobado. |
| 08ED | [Derivación individual de alumbrado](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ED_DERIVACIONES/DERIVACION_INDIVIDUAL_DE_ALUMBRADO.md) | Comprobar la designación antigua Cu 750 V, el esquema de enlace y los dispositivos de control efectivamente exigidos. |
| 08EK | [Módulos de contadores de alumbrado](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EK_CONTADORES/MODULOS_DE_CONTADORES_DE_ALUMBRADO.md) | Las menciones a Sevillana, tarifa nocturna y grados IP de tres cifras son históricas. Confirmar los equipos y grados de protección con la normativa y distribuidora actuales. |
| 08EP | [Puesta a tierra del alumbrado](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EP_PUESTAS_A_TIERRA/PUESTA_A_TIERRA_DEL_ALUMBRADO.md) | Ficha complementaria de una obligación reglamentaria explícitamente citada en los equipos; no crea una nueva partida. |
| 10CL | [Enfoscados y enlucidos de cemento](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CL_ENLUCIDOS/ENFOSCADOS_Y_ENLUCIDOS_DE_CEMENTO.md) | El original ordena enlucir hormigón «todavía fresco». Debe verificarse la compatibilidad y preparación del soporte del sistema elegido antes de aplicar esa instrucción. |
| 15AC | [Tubería de hormigón para saneamiento y drenaje](15_URBANIZACIONES/15A_ALCANTARILLADO/15AC_CANALIZACIONES/TUBERIA_DE_HORMIGON_PARA_SANEAMIENTO_Y_DRENAJE.md) | Comprobar la antigua referencia UNE 127010 y la «clase 180». Los requisitos de tubería a presión presentes en 4.16 no se aplican indiscriminadamente al saneamiento por gravedad. |
| 15AP | [Arquetas de saneamiento](15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/ARQUETAS_DE_SANEAMIENTO.md) | 3.12 incluye cerco y tapa salvo presupuesto contrario; 5.17 los contempla por unidad. La referencia NTE/ISS no sustituye los requisitos de producto, estanqueidad y proyecto aplicables. |
| 15AP | [Pozos de registro de saneamiento](15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/POZOS_DE_REGISTRO_DE_SANEAMIENTO.md) | La frase «por ml ... independientemente de altura total» requiere aclaración. Revisar también el conflicto entre HA-25 de 3.12 y 35 MPa para pozos prefabricados de 4.13.2. |
| 15AP | [Tapas, marcos y rejillas de fundición](15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/TAPAS_MARCOS_Y_REJILLAS_DE_FUNDICION.md) | Las normas antiguas y pesos mínimos de tapas del original no sustituyen la clase de producto. D400 se cita para calzada; no debe extenderse sin comprobar grupos y ubicación a cualquier registro. |
| 15AS | [Imbornales y sumideros](15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/IMBORNALES_Y_SUMIDEROS.md) | La resistencia del cuerpo y del asiento debe ajustarse al proyecto; no adoptar el hormigón de 15 MPa mencionado genéricamente en 4.13 para un elemento estructural. |
| 15CP | [Marcas transversales, cebreados y símbolos](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CP_PINTURAS/MARCAS_TRANSVERSALES_CEBREADOS_Y_SIMBOLOS.md) | La cifra de 3.000 g/m² atribuida a microesferas puede ser un error de transcripción. No corregirla por intuición ni usarla para ejecutar: contrastar el sistema aprobado y la partida. |
| 15CP | [Marcas viales longitudinales](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CP_PINTURAS/MARCAS_VIALES_LONGITUDINALES.md) | La expresión «acrílica termoplástica en disolución» necesita identificar el sistema concreto; no confundir pintura de aplicación en frío con termoplástico de aplicación en caliente. |
| 15CP | [Pinturas y microesferas para señalización horizontal](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CP_PINTURAS/PINTURAS_Y_MICROESFERAS_PARA_SENALIZACION.md) | Confirmar las designaciones y dotaciones ambiguas del original antes de aprobar el producto. |
| 15CR | [Señales y carteles verticales retrorreflectantes](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CR_R%C3%93TULOS_Y_PLACAS/SENALES_Y_CARTELES_VERTICALES_RETRORREFLECTANTES.md) | La «reflectancia nivel 3ª» no define inequívocamente una clase de producto actual. Verificar también los símbolos y catálogo vigentes con la autoridad de tráfico, sin perpetuar señales obsoletas. |
| 15EA | [Acometidas eléctricas de alumbrado](15_URBANIZACIONES/15E_ELECTRICIDAD/15EA_ACOMETIDAS/ACOMETIDAS_ELECTRICAS_DE_ALUMBRADO.md) | Las prescripciones particulares de la distribuidora deben ser las aplicables y aprobadas, no las de una compañía citada históricamente. |
| 15EE | [Arquetas de alumbrado](15_URBANIZACIONES/15E_ELECTRICIDAD/15EE_REDES_ENTERRADAS/ARQUETAS_DE_ALUMBRADO.md) | Aprobar la clase resistente de la tapa según su ubicación; no basta con especificar únicamente que es de fundición. |
| 15EE | [Canalizaciones subterráneas de alumbrado](15_URBANIZACIONES/15E_ELECTRICIDAD/15EE_REDES_ENTERRADAS/CANALIZACIONES_SUBTERRANEAS_DE_ALUMBRADO.md) | El diámetro «110 m» es una errata dimensional evidente, pero el valor correcto debe confirmarse en planos; no se ha convertido por conjetura en 110 mm. Revisar la referencia antigua UNE-EN 50086. |
| 15EP | [Conductores eléctricos de alumbrado](15_URBANIZACIONES/15E_ELECTRICIDAD/15EP_ALUMBRADO_P%C3%9ABLICO/CONDUCTORES_ELECTRICOS_DE_ALUMBRADO.md) | Las tablas y factores antiguos del original deben contrastarse con el cálculo reglamentario. El cableado de conexión incluido en la luminaria no se abonará de nuevo. |
| 15EP | [Cuadro de protección, medida y control de alumbrado](15_URBANIZACIONES/15E_ELECTRICIDAD/15EP_ALUMBRADO_P%C3%9ABLICO/CUADRO_DE_PROTECCION_MEDIDA_Y_CONTROL.md) | La altura de acceso «entre 2 y 1,3 m» del original no reproduce ITC-BT-09, que indica entre 2 y 0,3 m. Resolver el detalle accesible y seguro del proyecto. |
| 15EP | [Luminarias, lámparas y proyectores](15_URBANIZACIONES/15E_ELECTRICIDAD/15EP_ALUMBRADO_P%C3%9ABLICO/LUMINARIAS_LAMPARAS_Y_PROYECTORES.md) | La altura mínima genérica de 6 m, IPX3 y la suspensión por cable no definen todas las luminarias posibles. Ajustar cada tipo al proyecto y al régimen reglamentario correspondiente. |
| 15EP | [Soportes, báculos y columnas de alumbrado](15_URBANIZACIONES/15E_ELECTRICIDAD/15EP_ALUMBRADO_P%C3%9ABLICO/SOPORTES_BACULOS_Y_COLUMNAS_DE_ALUMBRADO.md) | Revisar las referencias históricas RD 2642/85, RD 401/89 y la orden de 1989 frente al régimen de producto aplicable, habitualmente serie UNE-EN 40 según material y soporte. |
| 15JA | [Plantación de árboles](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JA_ARBOLES/PLANTACION_DE_ARBOLES.md) | No se asignan especies ni dimensiones ausentes. Las fechas fijas de plantación y el «tirón» final del original deben revisarse según especie, clima y sistema para evitar daños. |
| 15JP | [Plantación de arbustos](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JP_PLANTAS_DE_JARD%C3%8DN/PLANTACION_DE_ARBUSTOS.md) | La cantidad genérica de estiércol del original no se debe aplicar a toda especie sin comprobar suelo, enmienda y volumen del hoyo. |
| 15JT | [Siembras y resiembras](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JT_TAPIZANTES/SIEMBRAS_Y_RESIEMBRAS.md) | El original menciona siembras pero no define mezcla, dosis ni criterio de aceptación. Son decisiones de proyecto pendientes, no datos que pueda suplir una norma general. |
| 15JW | [Enmiendas orgánicas: estiércol, compost y turba](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JW_VARIOS/ENMIENDAS_ORGANICAS_ESTIERCOL_COMPOST_Y_TURBA.md) | Esta ficha no valida cualquier compost o estiércol ni supone que un residuo pueda aplicarse al suelo sin cumplir su régimen específico. |
| 15JW | [Manto de tierra vegetal fertilizada](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JW_VARIOS/MANTO_DE_TIERRA_VEGETAL_FERTILIZADA.md) | No se fija espesor ni fertilización por conjetura. El envío indiscriminado de sobrantes a escombrera debe ajustarse a reutilización y gestión autorizada según su naturaleza. |
| 15PB | [Bordillos prefabricados de hormigón](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PB_BORDILLOS/BORDILLOS_PREFABRICADOS_DE_HORMIGON.md) | 3.15 exige HM-20 y 4.17.3 cita H-150 para el asiento. Aclarar la partida y el hormigón aprobado; no asumir equivalencia de estas designaciones. |
| 15PC | [Mezcla bituminosa AC16 SURF S](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/MEZCLA_BITUMINOSA_AC16_SURF_S.md) | Los valores de control de rodadura no pueden extraerse de la frase incompleta sobre ITSR ni de tablas ausentes en 4.12. Confirmar con el artículo 542 y la fórmula de trabajo. |
| 15PC | [Mezcla bituminosa AC22 BIN D](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/MEZCLA_BITUMINOSA_AC22_BIN_D.md) | El original llama «capa base» a la AC22 BIN D al describir la capa intermedia. Además, 4.12 tiene tablas ausentes y frases truncadas; deben sustituirse como criterio de control por el artículo 542 aplicable y la fórmula aprobada. |
| 15PC | [Mezcla bituminosa AC32 BASE G](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/MEZCLA_BITUMINOSA_AC32_BASE_G.md) | El texto de 4.12 contiene frases truncadas, referencias de ensayo deformadas y marcadores de tablas ausentes. No usar esos fragmentos como criterio de aceptación; la fórmula de trabajo debe completar los valores aplicables. Comprobar también si los riegos se incluyen o se abonan aparte. |
| 15PF | [Arena y grava para camas de asiento y protección](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/ARENA_Y_GRAVA_PARA_CAMAS_Y_RELLENOS.md) | Los espesores del original varían según servicio. Aplicar el detalle aprobado, no un espesor común a todas las camas. |
| 15PF | [Árido fino para mezclas bituminosas](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/ARIDO_FINO_PARA_MEZCLAS_BITUMINOSAS.md) | — |
| 15PF | [Árido grueso para mezclas bituminosas](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/ARIDO_GRUESO_PARA_MEZCLAS_BITUMINOSAS.md) | Los métodos de adhesividad y parámetros antiguos del original deben contrastarse con el artículo 542 aplicable. |
| 15PF | [Betún asfáltico 50/70](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/BETUN_ASFALTICO_50_70.md) | El contenido de ligante «4,9 5%» está mal transcrito; no es una dosificación inequívoca y debe fijarse mediante fórmula de trabajo. |
| 15PF | [Polvo mineral o filler para mezclas bituminosas](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/POLVO_MINERAL_FILLER.md) | Los intervalos y ensayos antiguos del original no sustituyen la caracterización del producto conforme al artículo 542 y su documentación aplicable. |
| 15PF | [Riego de adherencia con emulsión bituminosa](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/RIEGO_DE_ADHERENCIA_CON_EMULSION.md) | Confirmar la designación completa y aptitud de C60B3 y si los 250 g/m² se refieren a emulsión o a ligante residual; no son magnitudes intercambiables. Resolver la inclusión del riego en la mezcla. |
| 15PF | [Riego de imprimación con emulsión bituminosa](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/RIEGO_DE_IMPRIMACION_CON_EMULSION.md) | Confirmar que la emulsión prescrita es adecuada para imprimación y aclarar si los 500 g/m² son de emulsión o de ligante residual. No fijar una dotación sólo por el umbral ambiguo del original. |
| 15PF | [Zahorra artificial para bases y subbases](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PF_FIRMES/ZAHORRA_ARTIFICIAL.md) | Las designaciones ZA(40) y ZA(25) del original deben contrastarse con el artículo 510 y la sección de firme aplicables; no se sustituyen automáticamente por otros husos. |
| 15PP | [Pavimento de aceras con losas de hormigón](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PP_PAVIMENTOS/PAVIMENTO_DE_ACERAS_CON_LOSAS_DE_HORMIGON.md) | 3.19 describe losas pero en el abono habla de adoquines. 4.17.2 admite pendientes de hasta el 3 %, incompatibles con el límite transversal del itinerario peatonal accesible. Precisar producto y sección sin trasladar ese 3 %. |
| 15PP | [Pavimento de adoquines de hormigón](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PP_PAVIMENTOS/PAVIMENTO_DE_ADOQUINES_DE_HORMIGON.md) | El intervalo de pendiente transversal del 1,5–3 % del original debe limitarse al máximo del 2 % en itinerarios peatonales accesibles conforme a TMA/851/2021. |
| 15PP | [Pavimento de hormigón impreso](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PP_PAVIMENTOS/PAVIMENTO_DE_HORMIGON_IMPRESO.md) | La remisión a EH-91 es obsoleta. El soporte, espesor, armadura y recubrimientos requieren diseño; el acabado o sellado no debe reducir la resistencia al deslizamiento exigida. |
| 15PW | [Cruces de viales para servicios](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PW_VARIOS/CRUCES_DE_VIALES_PARA_SERVICIOS.md) | No trasladar a todos los servicios el detalle de protección de una red concreta; aprobar el correspondiente a cada cruce. |
| 15SA | [Acometidas y ramales de polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SA_ACOMETIDAS/ACOMETIDAS_Y_RAMALES_DE_POLIETILENO.md) | Las referencias UNE 53-131 y 53-133 y la exclusividad de PE de baja densidad son antiguas; el tipo de tubo y la unión se deben confirmar con el titular de la red, no por una equivalencia supuesta. |
| 15SB | [Bocas de riego](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SB_BOCAS_DE_RIEGO/BOCAS_DE_RIEGO.md) | Sólo aparece expresamente en la relación de abono; sus características deben definirse en planos o en una especificación aprobada. |
| 15SC | [Tubería de fundición dúctil para abastecimiento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/TUBERIA_DE_FUNDICION_DUCTIL_PARA_AGUA.md) | El original fija tramos de ensayo de 100 m y también de 500 m y utiliza una fórmula de caída de presión dudosa. Aprobar un procedimiento de prueba coherente con la conducción; no aplicar esas cifras contradictorias automáticamente. Revisar asimismo los recubrimientos distintos de 3.16 y 4.16. |
| 15SC | [Tubería de polietileno PE100 para abastecimiento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SC_CONDUCCIONES/TUBERIA_DE_POLIETILENO_PE100_PARA_AGUA.md) | La referencia UNE 53966 y la obligación genérica de marca AENOR necesitan revisión. No sustituir la prueba específica de PE por la fórmula antigua del original. |
| 15SH | [Hidrantes contra incendios](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SH_HIDRANTES/HIDRANTES_CONTRA_INCENDIOS.md) | El original no fija tipo, caudal ni presión disponible; deben comprobarse con el cálculo y la reglamentación de incendios aplicable. |
| 15SP | [Codos, conos y reducciones de abastecimiento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/CODOS_Y_REDUCCIONES_DE_ABASTECIMIENTO.md) | El dimensionamiento del anclaje requiere presiones y terreno de apoyo; no puede deducirse únicamente del diámetro. |
| 15SP | [Dados y macizos de anclaje de tuberías](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/DADOS_Y_MACIZOS_DE_ANCLAJE.md) | La resistencia de 175 kg/cm² citada para anclajes en 3.16 es inferior al mínimo de hormigón estructural en masa del Código Estructural. Debe revisarse la clase; no utilizarla automáticamente. |
| 15SP | [Manguitos electrosoldables para tuberías de PE](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/MANGUITOS_ELECTROSOLDABLES_PARA_PE.md) | No confundir los manguitos electrosoldables de PE con otros accesorios «retráctiles» citados en el original; confirmar el sistema concreto. |
| 15SP | [Piezas en T y derivaciones de abastecimiento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/PIEZAS_EN_T_Y_DERIVACIONES.md) | — |
| 15SP | [Soldadura a tope de tuberías de polietileno](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/SOLDADURA_A_TOPE_DE_TUBERIAS_DE_PE.md) | El original restringe algunas uniones para diámetros inferiores a 110 mm. Confirmar la solución aprobada con el servicio de aguas antes de sustituirla por soldadura. |
| 15SP | [Uniones mecánicas y embridadas de conducciones](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SP_PIEZAS_ESPECIALES/UNIONES_MECANICAS_Y_EMBRIDADAS.md) | — |
| 15SV | [Válvulas de compuerta](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/VALVULAS_DE_COMPUERTA.md) | Las referencias ISO/UNE, presiones expresadas en kg/cm² y el espesor de revestimiento incompleto del original requieren contrastarse con la ficha aprobada del producto. No fijar una presión de ensayo sólo por multiplicación de PN. |
| 15SV | [Válvulas de mariposa](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/VALVULAS_DE_MARIPOSA.md) | El original sólo cita su uso y alojamiento; diámetro, presión y accionamiento deben proceder del proyecto y del titular, no se han inventado. |
| 15SV | [Válvulas de retención](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/VALVULAS_DE_RETENCION.md) | La selección de tipo y la limitación de velocidad del original no sustituyen el estudio de golpes de ariete ni permiten adoptar un modelo comercial sin comprobarlo. |
| 15SV | [Válvulas reguladoras de presión o caudal](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SV_V%C3%81LVULAS/VALVULAS_REGULADORAS_DE_PRESION_O_CAUDAL.md) | No se especifican modelo, consignas ni esquema hidráulico en el original. Su definición requiere datos de proyecto. |
| 15SW | [Arquetas de abastecimiento y valvulería](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SW_VARIOS/ARQUETAS_DE_ABASTECIMIENTO_Y_VALVULERIA.md) | La solera de 100 kg/cm² del original no puede adoptarse como hormigón estructural sin comprobar su función. Revisar también las antiguas normas de tapas y la inclusión económica de éstas. |
| 15SY | [Ventosas de abastecimiento](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SY_VENTOSAS/VENTOSAS_DE_ABASTECIMIENTO.md) | El original no aporta capacidad ni puntos de instalación de ventosas; deben definirse con el perfil hidráulico. |
| 15TC | [Canalizaciones de telecomunicaciones](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TC_CANALIZACIONES/CANALIZACIONES_DE_TELECOMUNICACIONES.md) | El original combina PVC corrugado y encolado, sin identificar un sistema compatible. Confirmar el producto y sus uniones con el fabricante y el titular; no exigir homologación exclusiva de una marca u operador sin justificación contractual. |
| 15TR | [Arquetas y cámaras de telecomunicaciones](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TR_REGISTROS/ARQUETAS_Y_CAMARAS_DE_TELECOMUNICACIONES.md) | El documento no concreta dimensiones ni clases de tapas para cada registro; deben proceder del diseño aprobado. |
| 15WM | [Geotextiles de filtro y separación](15_URBANIZACIONES/15W_VARIOS/15WM_MUROS_DE_CONTENCI%C3%93N/GEOTEXTILES_DE_FILTRO_Y_SEPARACION.md) | No se prescribe gramaje ni un producto genérico por el solo nombre geotextil. Su necesidad y dimensionamiento requieren definición del proyecto. |
| 15WM | [Muros de escollera](15_URBANIZACIONES/15W_VARIOS/15WM_MUROS_DE_CONTENCI%C3%93N/MUROS_DE_ESCOLLERA.md) | El tipo de roca está sin definir («granito, caliza, etc.»), y los controles carecen de frecuencia. El proyecto debe concretarlos; los valores de peso y tolerancia del texto no sustituyen la justificación de estabilidad ni las especificaciones de escollera aplicables. |
| 15WM | [Piedra para escollera](15_URBANIZACIONES/15W_VARIOS/15WM_MUROS_DE_CONTENCI%C3%93N/PIEDRA_PARA_ESCOLLERA.md) | El original deja pendiente el tipo de roca. No se atribuye obligatoriedad normativa a los umbrales de 80 MPa o 2 % de absorción: son datos del texto que debe confirmar el proyecto. |
| 17WW | [Transporte y entrega de residuos a gestor autorizado](17_GESTI%C3%93N_DE_RESIDUOS/17W_VARIOS/17WW_VARIOS/TRANSPORTE_Y_ENTREGA_DE_RESIDUOS_A_GESTOR.md) | Conflicto con las numerosas unidades que incluyen transporte a cualquier distancia. Además, la última frase de 5.8 sobre refino de explanada parece desubicada. Resolver el alcance con el presupuesto y el plan de residuos. |
| 18U | [Pruebas y ensayos de recepción](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/PRUEBAS_Y_ENSAYOS_DE_RECEPCION.md) | 5.29 atribuye todos los gastos al contratista y a continuación los limita al 1 % del presupuesto. El contrato debe aclarar el alcance; esta ficha no decide cuál prevalece. |
| 19SC | [Medidas de seguridad y salud](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SC_COLECTIVA/MEDIDAS_DE_SEGURIDAD_Y_SALUD.md) | 5.21 no proporciona por sí solo un método de medición. Debe contrastarse con el presupuesto de seguridad y el plan aprobado. |
| 19SS | [Señalización provisional, balizamiento y desvíos de tráfico](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SS_SE%C3%91ALIZACIONES_Y_ACOTAMIENTOS/SENALIZACION_PROVISIONAL_Y_DESVIOS_DE_TRAFICO.md) | La imputación económica no exime de definir y mantener las medidas necesarias. |
| 19SW | [Medios auxiliares de ejecución](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SW_VARIOS/MEDIOS_AUXILIARES_DE_EJECUCION.md) | No confundir medios auxiliares incluidos con supresión de partidas de seguridad obligatorias. |

## Fichas marco añadidas por clasificación

Fichas nuevas: **580**. Todas están **pendientes de particularización**. Los datos siguientes se desarrollan en cada ficha junto con su procedimiento, controles y propuesta de medición.

| Código | Ficha marco | Datos pendientes de proyecto |
|---|---|---|
| 01AA | [arcos y bóvedas de ladrillo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/FICHA_MARCO_01AA.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01AB | [fábricas de bloque](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AB_F%C3%81BRICAS_DE_BLOQUE/FICHA_MARCO_01AB.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01AC | [cantería](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AC_CANTER%C3%8DA/FICHA_MARCO_01AC.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01AD | [distribuciones de ladrillo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AD_DISTRIBUCIONES_DE_LADRILLO/FICHA_MARCO_01AD.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01AL | [paredes de ladrillo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AL_PAREDES_DE_LADRILLO/FICHA_MARCO_01AL.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01AP | [prefabricados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AP_PREFABRICADOS/FICHA_MARCO_01AP.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01AW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01A_ALBA%C3%91ILER%C3%8DA/01AW_VARIOS/FICHA_MARCO_01AW.md) | función resistente de la fábrica, aparejo y elementos que permanecen. |
| 01CA | [hormigón armado](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CA_HORMIG%C3%93N_ARMADO/FICHA_MARCO_01CA.md) | profundidad, continuidad y conexiones de la cimentación existente. |
| 01CM | [hormigón en masa](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CM_HORMIG%C3%93N_EN_MASA/FICHA_MARCO_01CM.md) | profundidad, continuidad y conexiones de la cimentación existente. |
| 01CW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01C_CIMENTACIONES/01CW_VARIOS/FICHA_MARCO_01CW.md) | profundidad, continuidad y conexiones de la cimentación existente. |
| 01EB | [a brazo](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EB_A_BRAZO/FICHA_MARCO_01EB.md) | procedimiento de demolición, perímetro de protección y secuencia autorizada. |
| 01EE | [explosivos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EE_EXPLOSIVOS/FICHA_MARCO_01EE.md) | procedimiento de demolición, perímetro de protección y secuencia autorizada; viabilidad legal y técnica, autorización y proyecto específico. |
| 01EM | [mecánicos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EM_MEC%C3%81NICOS/FICHA_MARCO_01EM.md) | procedimiento de demolición, perímetro de protección y secuencia autorizada. |
| 01EW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01E_EDIFICACIONES/01EW_VARIOS/FICHA_MARCO_01EW.md) | procedimiento de demolición, perímetro de protección y secuencia autorizada. |
| 01IC | [climatización](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IC_CLIMATIZACI%C3%93N/FICHA_MARCO_01IC.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IE | [eléctricas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IE_EL%C3%89CTRICAS/FICHA_MARCO_01IE.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IF | [fontanería](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IF_FONTANER%C3%8DA/FICHA_MARCO_01IF.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IL | [gases y licuados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IL_GASES_Y_LICUADOS/FICHA_MARCO_01IL.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IM | [electro mecánicas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IM_ELECTRO_MEC%C3%81NICAS/FICHA_MARCO_01IM.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IP | [protecciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IP_PROTECCIONES/FICHA_MARCO_01IP.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IS | [salubridad](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IS_SALUBRIDAD/FICHA_MARCO_01IS.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IV | [audiovisuales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IV_AUDIOVISUALES/FICHA_MARCO_01IV.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01IW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01I_INSTALACIONES/01IW_VARIOS/FICHA_MARCO_01IW.md) | servicio, energía o fluido, puntos de aislamiento y continuidad de suministro. |
| 01KA | [acero](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KA_ACERO/FICHA_MARCO_01KA.md) | dimensiones, peso, anclajes, recuperación y cierre provisional del hueco. |
| 01KL | [aleaciones ligeras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KL_ALEACIONES_LIGERAS/FICHA_MARCO_01KL.md) | dimensiones, peso, anclajes, recuperación y cierre provisional del hueco. |
| 01KM | [madera](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KM_MADERA/FICHA_MARCO_01KM.md) | dimensiones, peso, anclajes, recuperación y cierre provisional del hueco. |
| 01KS | [seguridad y protección](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KS_SEGURIDAD_Y_PROTECCI%C3%93N/FICHA_MARCO_01KS.md) | dimensiones, peso, anclajes, recuperación y cierre provisional del hueco. |
| 01KW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/01KW_VARIOS/FICHA_MARCO_01KW.md) | dimensiones, peso, anclajes, recuperación y cierre provisional del hueco. |
| 01QH | [horizontales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QH_HORIZONTALES/FICHA_MARCO_01QH.md) | composición de cubierta, accesos, protecciones y cierre provisional. |
| 01QI | [inclinadas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QI_INCLINADAS/FICHA_MARCO_01QI.md) | composición de cubierta, accesos, protecciones y cierre provisional. |
| 01QW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01Q_CUBIERTAS/01QW_VARIOS/FICHA_MARCO_01QW.md) | composición de cubierta, accesos, protecciones y cierre provisional. |
| 01RA | [aplacados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RA_APLACADOS/FICHA_MARCO_01RA.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01RC | [continuos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RC_CONTINUOS/FICHA_MARCO_01RC.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01RL | [ligeros](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RL_LIGEROS/FICHA_MARCO_01RL.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01RP | [peldaños](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RP_PELDA%C3%91OS/FICHA_MARCO_01RP.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01RS | [suelos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RS_SUELOS/FICHA_MARCO_01RS.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01RT | [techos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RT_TECHOS/FICHA_MARCO_01RT.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01RW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01R_REVESTIMIENTOS/01RW_VARIOS/FICHA_MARCO_01RW.md) | capas que se eliminan, soporte y tratamiento de bordes. |
| 01SC | [redes colgadas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SC_REDES_COLGADAS/FICHA_MARCO_01SC.md) | tipo de red, aislamiento, estado sanitario y sistema provisional. |
| 01SE | [redes enterradas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SE_REDES_ENTERRADAS/FICHA_MARCO_01SE.md) | tipo de red, aislamiento, estado sanitario y sistema provisional. |
| 01SV | [redes verticales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SV_REDES_VERTICALES/FICHA_MARCO_01SV.md) | tipo de red, aislamiento, estado sanitario y sistema provisional. |
| 01SW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01S_SANEAMIENTO/01SW_VARIOS/FICHA_MARCO_01SW.md) | tipo de red, aislamiento, estado sanitario y sistema provisional. |
| 01TA | [apeos y apuntalamientos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TA_APEOS_Y_APUNTALAMIENTOS/FICHA_MARCO_01TA.md) | alcance temporal, interfaces y condiciones de reposición; cargas provisionales, apoyos y fases de descarga. |
| 01TC | [accesibilidad](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TC_ACCESIBILIDAD/FICHA_MARCO_01TC.md) | alcance temporal, interfaces y condiciones de reposición; anchos, pendientes, cruces y cambios temporales del itinerario. |
| 01TL | [limpiezas y retiradas](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TL_LIMPIEZAS_Y_RETIRADAS/FICHA_MARCO_01TL.md) | alcance temporal, interfaces y condiciones de reposición. |
| 01TM | [medidas especiales](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TM_MEDIDAS_ESPECIALES/FICHA_MARCO_01TM.md) | alcance temporal, interfaces y condiciones de reposición; medida concreta y autorización técnica. |
| 01TS | [señalizaciones prevenciones y protecciones](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TS_SE%C3%91ALIZACIONES_PREVENCIONES_Y_PROTECCIONES/FICHA_MARCO_01TS.md) | alcance temporal, interfaces y condiciones de reposición. |
| 01TW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01T_TRABAJOS_PREVIOS/01TW_VARIOS/FICHA_MARCO_01TW.md) | alcance temporal, interfaces y condiciones de reposición. |
| 01UC | [indicadores de circulación](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UC_INDICADORES_DE_CIRCULACI%C3%93N/FICHA_MARCO_01UC.md) | titular, permisos, desvíos y servicio provisional. |
| 01UG | [gases y licuados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UG_GASES_Y_LICUADOS/FICHA_MARCO_01UG.md) | titular, permisos, desvíos y servicio provisional. |
| 01UJ | [jardinería](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UJ_JARDINER%C3%8DA/FICHA_MARCO_01UJ.md) | titular, permisos, desvíos y servicio provisional. |
| 01UM | [movimiento de tierras](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UM_MOVIMIENTO_DE_TIERRAS/FICHA_MARCO_01UM.md) | titular, permisos, desvíos y servicio provisional. |
| 01US | [suministro de agua](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01US_SUMINISTRO_DE_AGUA/FICHA_MARCO_01US.md) | titular, permisos, desvíos y servicio provisional. |
| 01UU | [amueblamiento urbano](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UU_AMUEBLAMIENTO_URBANO/FICHA_MARCO_01UU.md) | titular, permisos, desvíos y servicio provisional. |
| 01UW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UW_VARIOS/FICHA_MARCO_01UW.md) | titular, permisos, desvíos y servicio provisional. |
| 01WA | [aislamientos](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WA_AISLAMIENTOS/FICHA_MARCO_01WA.md) | elemento concreto, composición y procedimiento. |
| 01WD | [decoración](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WD_DECORACI%C3%93N/FICHA_MARCO_01WD.md) | elemento concreto, composición y procedimiento. |
| 01WV | [vidrios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01W_VARIOS/01WV_VIDRIOS/FICHA_MARCO_01WV.md) | elemento concreto, composición y procedimiento. |
| 01XA | [acero](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XA_ACERO/FICHA_MARCO_01XA.md) | esquema resistente, cargas, uniones y plan de desmontaje. |
| 01XF | [forjados](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XF_FORJADOS/FICHA_MARCO_01XF.md) | esquema resistente, cargas, uniones y plan de desmontaje. |
| 01XH | [hormigón armado](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XH_HORMIG%C3%93N_ARMADO/FICHA_MARCO_01XH.md) | esquema resistente, cargas, uniones y plan de desmontaje. |
| 01XM | [madera](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XM_MADERA/FICHA_MARCO_01XM.md) | esquema resistente, cargas, uniones y plan de desmontaje. |
| 01XW | [varios](01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01X_ESTRUCTURAS/01XW_VARIOS/FICHA_MARCO_01XW.md) | esquema resistente, cargas, uniones y plan de desmontaje. |
| 02AC | [apertura de cajas](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AC_APERTURA_DE_CAJAS/FICHA_MARCO_02AC.md) | perfil de terreno y proyecto, taludes y destino de los productos. |
| 02AD | [desmontes](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AD_DESMONTES/FICHA_MARCO_02AD.md) | perfil de terreno y proyecto, taludes y destino de los productos. |
| 02AW | [varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02A_A_CIELO_ABIERTO/02AW_VARIOS/FICHA_MARCO_02AW.md) | perfil de terreno y proyecto, taludes y destino de los productos. |
| 02PB | [a brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PB_A_BRAZO/FICHA_MARCO_02PB.md) | profundidad, sección, sostenimiento y ventilación. |
| 02PM | [medios mecánicos](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PM_MEDIOS_MEC%C3%81NICOS/FICHA_MARCO_02PM.md) | profundidad, sección, sostenimiento y ventilación. |
| 02PW | [varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02P_POZOS/02PW_VARIOS/FICHA_MARCO_02PW.md) | profundidad, sección, sostenimiento y ventilación. |
| 02RC | [compactaciones](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RC_COMPACTACIONES/FICHA_MARCO_02RC.md) | tipo de suelo, espesor de tongada, humedad y densidad exigida. |
| 02RW | [varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02R_RELLENOS_Y_COMPACTACIONES/02RW_VARIOS/FICHA_MARCO_02RW.md) | tipo de suelo, espesor de tongada, humedad y densidad exigida. |
| 02TB | [a brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TB_A_BRAZO/FICHA_MARCO_02TB.md) | naturaleza del producto, distancia y criterio de carga y descarga. |
| 02TW | [varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02T_TRANSPORTES/02TW_VARIOS/FICHA_MARCO_02TW.md) | naturaleza del producto, distancia y criterio de carga y descarga. |
| 02WA | [agotamientos](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WA_AGOTAMIENTOS/FICHA_MARCO_02WA.md) | sistema específico, cálculo provisional, agua y afecciones; caudal, nivel de agua, control de asientos y autorización de vertido. |
| 02WE | [entibaciones](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WE_ENTIBACIONES/FICHA_MARCO_02WE.md) | sistema específico, cálculo provisional, agua y afecciones; empujes, sobrecargas, deformaciones y retirada. |
| 02WG | [galerías](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WG_GALER%C3%8DAS/FICHA_MARCO_02WG.md) | sistema específico, cálculo provisional, agua y afecciones; sección, terreno, sostenimiento y emergencia. |
| 02WS | [sistemas especiales](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WS_SISTEMAS_ESPECIALES/FICHA_MARCO_02WS.md) | sistema específico, cálculo provisional, agua y afecciones. |
| 02WW | [varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WW_VARIOS/FICHA_MARCO_02WW.md) | sistema específico, cálculo provisional, agua y afecciones. |
| 02WX | [mixtas](02_ACONDICIONAMIENTO_DE_TERRENOS/02W_VARIOS/02WX_MIXTAS/FICHA_MARCO_02WX.md) | sistema específico, cálculo provisional, agua y afecciones. |
| 02ZB | [a brazo](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZB_A_BRAZO/FICHA_MARCO_02ZB.md) | ancho, profundidad, cama y distancias a servicios. |
| 02ZW | [varios](02_ACONDICIONAMIENTO_DE_TERRENOS/02Z_ZANJAS/02ZW_VARIOS/FICHA_MARCO_02ZW.md) | ancho, profundidad, cama y distancias a servicios. |
| 03AC | [barras corrugadas](03_CIMENTACIONES/03A_ARMADURAS/03AC_BARRAS_CORRUGADAS/FICHA_MARCO_03AC.md) | tipo de acero, despiece, anclajes, solapes y recubrimiento. |
| 03AL | [barras lisas](03_CIMENTACIONES/03A_ARMADURAS/03AL_BARRAS_LISAS/FICHA_MARCO_03AL.md) | tipo de acero, despiece, anclajes, solapes y recubrimiento. |
| 03AM | [mallas electrosoldadas](03_CIMENTACIONES/03A_ARMADURAS/03AM_MALLAS_ELECTROSOLDADAS/FICHA_MARCO_03AM.md) | tipo de acero, despiece, anclajes, solapes y recubrimiento. |
| 03AW | [varios](03_CIMENTACIONES/03A_ARMADURAS/03AW_VARIOS/FICHA_MARCO_03AW.md) | tipo de acero, despiece, anclajes, solapes y recubrimiento. |
| 03CC | [consolidaciones](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CC_CONSOLIDACIONES/FICHA_MARCO_03CC.md) | terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga. |
| 03CM | [muros pantalla](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CM_MUROS_PANTALLA/FICHA_MARCO_03CM.md) | terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; paneles, juntas, fluido de sostenimiento y tolerancias. |
| 03CP | [pilotes](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CP_PILOTES/FICHA_MARCO_03CP.md) | terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; tipología, capacidad, longitud y pruebas. |
| 03CT | [micropilotes](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CT_MICROPILOTES/FICHA_MARCO_03CT.md) | terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga; diámetro, longitud, armadura, lechada y criterios de inyección. |
| 03CW | [varios](03_CIMENTACIONES/03C_CIMENTACIONES_ESPECIALES/03CW_VARIOS/FICHA_MARCO_03CW.md) | terreno, tecnología, tolerancias, parámetros de ejecución y pruebas de integridad o carga. |
| 03EP | [perdidos](03_CIMENTACIONES/03E_ENCOFRADOS/03EP_PERDIDOS/FICHA_MARCO_03EP.md) | presiones de hormigonado, apoyos, acabado y plazo de retirada. |
| 03ER | [recuperables](03_CIMENTACIONES/03E_ENCOFRADOS/03ER_RECUPERABLES/FICHA_MARCO_03ER.md) | presiones de hormigonado, apoyos, acabado y plazo de retirada. |
| 03EW | [varios](03_CIMENTACIONES/03E_ENCOFRADOS/03EW_VARIOS/FICHA_MARCO_03EW.md) | presiones de hormigonado, apoyos, acabado y plazo de retirada. |
| 03HA | [para armar](03_CIMENTACIONES/03H_HORMIGONES/03HA_PARA_ARMAR/FICHA_MARCO_03HA.md) | clase resistente, exposición, consistencia y plan de hormigonado. |
| 03HR | [armados](03_CIMENTACIONES/03H_HORMIGONES/03HR_ARMADOS/FICHA_MARCO_03HR.md) | clase resistente, exposición, consistencia y plan de hormigonado. |
| 03WS | [sub bases](03_CIMENTACIONES/03W_VARIOS/03WS_SUB_BASES/FICHA_MARCO_03WS.md) | material, función y geometría de la capa auxiliar. |
| 03WW | [varios](03_CIMENTACIONES/03W_VARIOS/03WW_VARIOS/FICHA_MARCO_03WW.md) | material, función y geometría de la capa auxiliar. |
| 04CA | [arquetas](04_SANEAMIENTO/04C_REDES_COLGADAS/04CA_ARQUETAS/FICHA_MARCO_04CA.md) | separación y capacidad de soportes, juntas y registros. |
| 04CC | [colectores](04_SANEAMIENTO/04C_REDES_COLGADAS/04CC_COLECTORES/FICHA_MARCO_04CC.md) | separación y capacidad de soportes, juntas y registros. |
| 04CE | [elementos complementarios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CE_ELEMENTOS_COMPLEMENTARIOS/FICHA_MARCO_04CE.md) | separación y capacidad de soportes, juntas y registros. |
| 04CW | [varios](04_SANEAMIENTO/04C_REDES_COLGADAS/04CW_VARIOS/FICHA_MARCO_04CW.md) | separación y capacidad de soportes, juntas y registros. |
| 04EA | [arquetas](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EA_ARQUETAS/FICHA_MARCO_04EA.md) | cargas de tráfico, sección de zanja y ensayo de estanqueidad. |
| 04EC | [colectores](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EC_COLECTORES/FICHA_MARCO_04EC.md) | cargas de tráfico, sección de zanja y ensayo de estanqueidad. |
| 04EE | [elementos complementarios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EE_ELEMENTOS_COMPLEMENTARIOS/FICHA_MARCO_04EE.md) | cargas de tráfico, sección de zanja y ensayo de estanqueidad. |
| 04EP | [pozos](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EP_POZOS/FICHA_MARCO_04EP.md) | cargas de tráfico, sección de zanja y ensayo de estanqueidad. |
| 04EW | [varios](04_SANEAMIENTO/04E_REDES_ENTERRADAS/04EW_VARIOS/FICHA_MARCO_04EW.md) | cargas de tráfico, sección de zanja y ensayo de estanqueidad. |
| 04VB | [bajantes](04_SANEAMIENTO/04V_REDES_VERTICALES/04VB_BAJANTES/FICHA_MARCO_04VB.md) | caudales, material, soportes, ventilación y protección de pasos. |
| 04VC | [cazoletas](04_SANEAMIENTO/04V_REDES_VERTICALES/04VC_CAZOLETAS/FICHA_MARCO_04VC.md) | caudales, material, soportes, ventilación y protección de pasos. |
| 04VE | [elementos complementarios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VE_ELEMENTOS_COMPLEMENTARIOS/FICHA_MARCO_04VE.md) | caudales, material, soportes, ventilación y protección de pasos. |
| 04VW | [varios](04_SANEAMIENTO/04V_REDES_VERTICALES/04VW_VARIOS/FICHA_MARCO_04VW.md) | caudales, material, soportes, ventilación y protección de pasos. |
| 04WA | [acometidas](04_SANEAMIENTO/04W_VARIOS/04WA_ACOMETIDAS/FICHA_MARCO_04WA.md) | punto de vertido, permiso y detalle de acometida. |
| 04WW | [varios](04_SANEAMIENTO/04W_VARIOS/04WW_VARIOS/FICHA_MARCO_04WW.md) | punto de vertido, permiso y detalle de acometida. |
| 05AC | [laminados en caliente](05_ESTRUCTURAS/05A_ACERO/05AC_LAMINADOS_EN_CALIENTE/FICHA_MARCO_05AC.md) | clase de acero, ejecución, soldaduras, tornillos y protección anticorrosiva y de fuego. |
| 05AF | [laminados en frío](05_ESTRUCTURAS/05A_ACERO/05AF_LAMINADOS_EN_FR%C3%8DO/FICHA_MARCO_05AF.md) | clase de acero, ejecución, soldaduras, tornillos y protección anticorrosiva y de fuego. |
| 05AW | [varios](05_ESTRUCTURAS/05A_ACERO/05AW_VARIOS/FICHA_MARCO_05AW.md) | clase de acero, ejecución, soldaduras, tornillos y protección anticorrosiva y de fuego. |
| 05FB | [bidireccionales](05_ESTRUCTURAS/05F_FORJADOS/05FB_BIDIRECCIONALES/FICHA_MARCO_05FB.md) | tipología, canto, luces, cargas de ejecución y desapuntalamiento. |
| 05FM | [madera](05_ESTRUCTURAS/05F_FORJADOS/05FM_MADERA/FICHA_MARCO_05FM.md) | tipología, canto, luces, cargas de ejecución y desapuntalamiento. |
| 05FU | [unidireccionales](05_ESTRUCTURAS/05F_FORJADOS/05FU_UNIDIRECCIONALES/FICHA_MARCO_05FU.md) | tipología, canto, luces, cargas de ejecución y desapuntalamiento. |
| 05FW | [varios](05_ESTRUCTURAS/05F_FORJADOS/05FW_VARIOS/FICHA_MARCO_05FW.md) | tipología, canto, luces, cargas de ejecución y desapuntalamiento. |
| 05HR | [armados](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HR_ARMADOS/FICHA_MARCO_05HR.md) | resistencia, exposición, recubrimientos y secuencia de hormigonado. |
| 05HW | [varios](05_ESTRUCTURAS/05H_HORMIG%C3%93N/05HW_VARIOS/FICHA_MARCO_05HW.md) | resistencia, exposición, recubrimientos y secuencia de hormigonado. |
| 05ML | [laminadas](05_ESTRUCTURAS/05M_MADERA/05ML_LAMINADAS/FICHA_MARCO_05ML.md) | clase de servicio, durabilidad, uniones y resistencia al fuego. |
| 05MT | [tradicionales](05_ESTRUCTURAS/05M_MADERA/05MT_TRADICIONALES/FICHA_MARCO_05MT.md) | clase de servicio, durabilidad, uniones y resistencia al fuego. |
| 05MW | [varios](05_ESTRUCTURAS/05M_MADERA/05MW_VARIOS/FICHA_MARCO_05MW.md) | clase de servicio, durabilidad, uniones y resistencia al fuego. |
| 05WC | [estructuras completas](05_ESTRUCTURAS/05W_VARIOS/05WC_ESTRUCTURAS_COMPLETAS/FICHA_MARCO_05WC.md) | sistema, materiales, fases, puntos de control y prestaciones. |
| 05WE | [estructuras especiales](05_ESTRUCTURAS/05W_VARIOS/05WE_ESTRUCTURAS_ESPECIALES/FICHA_MARCO_05WE.md) | sistema, materiales, fases, puntos de control y prestaciones. |
| 05WT | [tratamientos](05_ESTRUCTURAS/05W_VARIOS/05WT_TRATAMIENTOS/FICHA_MARCO_05WT.md) | sistema, materiales, fases, puntos de control y prestaciones; sistema de tratamiento, preparación y espesor o retención. |
| 05WW | [varios](05_ESTRUCTURAS/05W_VARIOS/05WW_VARIOS/FICHA_MARCO_05WW.md) | sistema, materiales, fases, puntos de control y prestaciones. |
| 06AE | [especiales](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AE_ESPECIALES/FICHA_MARCO_06AE.md) | pieza, mortero, revestimiento y prestaciones de la fábrica. |
| 06AH | [huecos](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AH_HUECOS/FICHA_MARCO_06AH.md) | pieza, mortero, revestimiento y prestaciones de la fábrica. |
| 06AM | [macizos](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AM_MACIZOS/FICHA_MARCO_06AM.md) | pieza, mortero, revestimiento y prestaciones de la fábrica. |
| 06AP | [perforados](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AP_PERFORADOS/FICHA_MARCO_06AP.md) | pieza, mortero, revestimiento y prestaciones de la fábrica. |
| 06AW | [varios](06_ALBA%C3%91ILER%C3%8DA/06A_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/06AW_VARIOS/FICHA_MARCO_06AW.md) | pieza, mortero, revestimiento y prestaciones de la fábrica. |
| 06BH | [huecos](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BH_HUECOS/FICHA_MARCO_06BH.md) | bloque, mortero, rellenos y armaduras de tendel. |
| 06BM | [macizos](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BM_MACIZOS/FICHA_MARCO_06BM.md) | bloque, mortero, rellenos y armaduras de tendel. |
| 06BW | [varios](06_ALBA%C3%91ILER%C3%8DA/06B_F%C3%81BRICAS_DE_BLOQUES/06BW_VARIOS/FICHA_MARCO_06BW.md) | bloque, mortero, rellenos y armaduras de tendel. |
| 06CA | [arcos y bóvedas](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CA_ARCOS_Y_B%C3%93VEDAS/FICHA_MARCO_06CA.md) | roca, geometría, mortero, aparejo y función resistente; geometría, empujes, cimbra y orden de descimbrado. |
| 06CS | [sillería](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CS_SILLER%C3%8DA/FICHA_MARCO_06CS.md) | roca, geometría, mortero, aparejo y función resistente. |
| 06CW | [varios](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CW_VARIOS/FICHA_MARCO_06CW.md) | roca, geometría, mortero, aparejo y función resistente. |
| 06CX | [mixtas](06_ALBA%C3%91ILER%C3%8DA/06C_CANTER%C3%8DA/06CX_MIXTAS/FICHA_MARCO_06CX.md) | roca, geometría, mortero, aparejo y función resistente. |
| 06DP | [tabiquería prefabricada](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DP_TABIQUER%C3%8DA_PREFABRICADA/FICHA_MARCO_06DP.md) | tipo de partición, altura, encuentros y prestaciones acústicas y de fuego. |
| 06DS | [tabiques sencillos](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DS_TABIQUES_SENCILLOS/FICHA_MARCO_06DS.md) | tipo de partición, altura, encuentros y prestaciones acústicas y de fuego. |
| 06DT | [tabicones](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DT_TABICONES/FICHA_MARCO_06DT.md) | tipo de partición, altura, encuentros y prestaciones acústicas y de fuego. |
| 06DW | [varios](06_ALBA%C3%91ILER%C3%8DA/06D_DIVISIONES/06DW_VARIOS/FICHA_MARCO_06DW.md) | tipo de partición, altura, encuentros y prestaciones acústicas y de fuego. |
| 06EB | [muros bioclimáticos](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EB_MUROS_BIOCLIM%C3%81TICOS/FICHA_MARCO_06EB.md) | sistema de fachada, acciones de viento, cámara y fijaciones. |
| 06EV | [fachadas ventiladas](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EV_FACHADAS_VENTILADAS/FICHA_MARCO_06EV.md) | sistema de fachada, acciones de viento, cámara y fijaciones; acciones de viento, anclajes, cámara y comportamiento al fuego. |
| 06EW | [varios](06_ALBA%C3%91ILER%C3%8DA/06E_CERRAMIENTOS_ESPECIALES/06EW_VARIOS/FICHA_MARCO_06EW.md) | sistema de fachada, acciones de viento, cámara y fijaciones. |
| 06LE | [especiales](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LE_ESPECIALES/FICHA_MARCO_06LE.md) | acabado visto, aparejo, mortero y protección frente al agua. |
| 06LH | [huecos](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LH_HUECOS/FICHA_MARCO_06LH.md) | acabado visto, aparejo, mortero y protección frente al agua. |
| 06LP | [perforados](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LP_PERFORADOS/FICHA_MARCO_06LP.md) | acabado visto, aparejo, mortero y protección frente al agua. |
| 06LW | [varios](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LW_VARIOS/FICHA_MARCO_06LW.md) | acabado visto, aparejo, mortero y protección frente al agua. |
| 06LX | [mixtas](06_ALBA%C3%91ILER%C3%8DA/06L_F%C3%81BRICAS_DE_LADRILLOS/06LX_MIXTAS/FICHA_MARCO_06LX.md) | acabado visto, aparejo, mortero y protección frente al agua. |
| 06PC | [cerámicos](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PC_CER%C3%81MICOS/FICHA_MARCO_06PC.md) | peso, tolerancias, anclajes y procedimiento de montaje. |
| 06PH | [hormigón](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PH_HORMIG%C3%93N/FICHA_MARCO_06PH.md) | peso, tolerancias, anclajes y procedimiento de montaje. |
| 06PM | [metálicos](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PM_MET%C3%81LICOS/FICHA_MARCO_06PM.md) | peso, tolerancias, anclajes y procedimiento de montaje. |
| 06PS | [sintéticos](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PS_SINT%C3%89TICOS/FICHA_MARCO_06PS.md) | peso, tolerancias, anclajes y procedimiento de montaje. |
| 06PW | [varios](06_ALBA%C3%91ILER%C3%8DA/06P_PREFABRICADOS/06PW_VARIOS/FICHA_MARCO_06PW.md) | peso, tolerancias, anclajes y procedimiento de montaje. |
| 06WD | [dinteles](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WD_DINTELES/FICHA_MARCO_06WD.md) | geometría, soporte, armado y compatibilidad de materiales; luz, cargas, apoyo y armado o perfil. |
| 06WF | [formación de pendientes](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WF_FORMACI%C3%93N_DE_PENDIENTES/FICHA_MARCO_06WF.md) | geometría, soporte, armado y compatibilidad de materiales; espesores, densidad y pendientes. |
| 06WM | [mochetas](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WM_MOCHETAS/FICHA_MARCO_06WM.md) | geometría, soporte, armado y compatibilidad de materiales. |
| 06WP | [peldañeados](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WP_PELDA%C3%91EADOS/FICHA_MARCO_06WP.md) | geometría, soporte, armado y compatibilidad de materiales. |
| 06WR | [rampas](06_ALBA%C3%91ILER%C3%8DA/06W_VARIOS/06WR_RAMPAS/FICHA_MARCO_06WR.md) | geometría, soporte, armado y compatibilidad de materiales; pendientes, anchura, descansillos y protección de bordes. |
| 07HA | [ajardinadas](07_CUBIERTAS/07H_HORIZONTALES/07HA_AJARDINADAS/FICHA_MARCO_07HA.md) | uso transitable o no, capas, pendientes y sistema impermeable; carga saturada, especies, riego y drenaje. |
| 07HN | [no transitables](07_CUBIERTAS/07H_HORIZONTALES/07HN_NO_TRANSITABLES/FICHA_MARCO_07HN.md) | uso transitable o no, capas, pendientes y sistema impermeable. |
| 07HT | [transitables](07_CUBIERTAS/07H_HORIZONTALES/07HT_TRANSITABLES/FICHA_MARCO_07HT.md) | uso transitable o no, capas, pendientes y sistema impermeable. |
| 07HW | [varios](07_CUBIERTAS/07H_HORIZONTALES/07HW_VARIOS/FICHA_MARCO_07HW.md) | uso transitable o no, capas, pendientes y sistema impermeable. |
| 07IF | [fibrocemento](07_CUBIERTAS/07I_INCLINADAS/07IF_FIBROCEMENTO/FICHA_MARCO_07IF.md) | pendiente mínima del sistema, piezas, soporte y fijaciones; producto nuevo sin amianto o identificación del material existente. |
| 07IG | [galvanizados](07_CUBIERTAS/07I_INCLINADAS/07IG_GALVANIZADOS/FICHA_MARCO_07IG.md) | pendiente mínima del sistema, piezas, soporte y fijaciones. |
| 07IL | [aleaciones ligeras](07_CUBIERTAS/07I_INCLINADAS/07IL_ALEACIONES_LIGERAS/FICHA_MARCO_07IL.md) | pendiente mínima del sistema, piezas, soporte y fijaciones. |
| 07IP | [pizarra](07_CUBIERTAS/07I_INCLINADAS/07IP_PIZARRA/FICHA_MARCO_07IP.md) | pendiente mínima del sistema, piezas, soporte y fijaciones. |
| 07IS | [sintéticas](07_CUBIERTAS/07I_INCLINADAS/07IS_SINT%C3%89TICAS/FICHA_MARCO_07IS.md) | pendiente mínima del sistema, piezas, soporte y fijaciones. |
| 07IT | [tejas](07_CUBIERTAS/07I_INCLINADAS/07IT_TEJAS/FICHA_MARCO_07IT.md) | pendiente mínima del sistema, piezas, soporte y fijaciones. |
| 07IW | [varios](07_CUBIERTAS/07I_INCLINADAS/07IW_VARIOS/FICHA_MARCO_07IW.md) | pendiente mínima del sistema, piezas, soporte y fijaciones. |
| 07WL | [lucernarios y claraboyas](07_CUBIERTAS/07W_VARIOS/07WL_LUCERNARIOS_Y_CLARABOYAS/FICHA_MARCO_07WL.md) | detalle de encuentro, apertura, fijación y estanqueidad; clasificación del elemento, fijación y protección frente a caída. |
| 07WW | [varios](07_CUBIERTAS/07W_VARIOS/07WW_VARIOS/FICHA_MARCO_07WW.md) | detalle de encuentro, apertura, fijación y estanqueidad. |
| 08CA | [aire acondicionado](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CA_AIRE_ACONDICIONADO/FICHA_MARCO_08CA.md) | potencias, caudales, regulación, ruido y requisitos de instalaciones térmicas. |
| 08CC | [calefacción](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CC_CALEFACCI%C3%93N/FICHA_MARCO_08CC.md) | potencias, caudales, regulación, ruido y requisitos de instalaciones térmicas. |
| 08CV | [ventilación](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CV_VENTILACI%C3%93N/FICHA_MARCO_08CV.md) | potencias, caudales, regulación, ruido y requisitos de instalaciones térmicas. |
| 08CW | [varios](08_INSTALACIONES/08C_CLIMATIZACI%C3%93N/08CW_VARIOS/FICHA_MARCO_08CW.md) | potencias, caudales, regulación, ruido y requisitos de instalaciones térmicas. |
| 08EA | [acometidas](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EA_ACOMETIDAS/FICHA_MARCO_08EA.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08EC | [circuitos](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EC_CIRCUITOS/FICHA_MARCO_08EC.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08EI | [interruptores](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EI_INTERRUPTORES/FICHA_MARCO_08EI.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08EL | [puntos de luz](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EL_PUNTOS_DE_LUZ/FICHA_MARCO_08EL.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08ER | [líneas generales de alimentación](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ER_L%C3%8DNEAS_GENERALES_DE_ALIMENTACI%C3%93N/FICHA_MARCO_08ER.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08ET | [tomas de corriente](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08ET_TOMAS_DE_CORRIENTE/FICHA_MARCO_08ET.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08EW | [varios](08_INSTALACIONES/08E_EL%C3%89CTRICAS/08EW_VARIOS/FICHA_MARCO_08EW.md) | tensión, intensidad, sección, caída de tensión, esquema de tierra y protección. |
| 08FA | [acometidas y contadores](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FA_ACOMETIDAS_Y_CONTADORES/FICHA_MARCO_08FA.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FC | [canalizaciones agua caliente](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FC_CANALIZACIONES_AGUA_CALIENTE/FICHA_MARCO_08FC.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FD | [desagües](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FD_DESAG%C3%9CES/FICHA_MARCO_08FD.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FF | [canalizaciones agua fría](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FF_CANALIZACIONES_AGUA_FR%C3%8DA/FICHA_MARCO_08FF.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FG | [griferías](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FG_GRIFER%C3%8DAS/FICHA_MARCO_08FG.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FS | [aparatos sanitarios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FS_APARATOS_SANITARIOS/FICHA_MARCO_08FS.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FT | [termos y calentadores](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FT_TERMOS_Y_CALENTADORES/FICHA_MARCO_08FT.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FV | [valvulería](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FV_VALVULER%C3%8DA/FICHA_MARCO_08FV.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08FW | [varios](08_INSTALACIONES/08F_FONTANER%C3%8DA/08FW_VARIOS/FICHA_MARCO_08FW.md) | uso potable o no, presión, temperatura, materiales y prevención de retornos. |
| 08KD | [datos](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KD_DATOS/FICHA_MARCO_08KD.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KE | [electroacústicas](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KE_ELECTROAC%C3%9ASTICAS/FICHA_MARCO_08KE.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KF | [infraestructuras](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KF_INFRAESTRUCTURAS/FICHA_MARCO_08KF.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KI | [intercomunicación](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KI_INTERCOMUNICACI%C3%93N/FICHA_MARCO_08KI.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KR | [radio](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KR_RADIO/FICHA_MARCO_08KR.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KT | [telefonía](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KT_TELEFON%C3%8DA/FICHA_MARCO_08KT.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KV | [televisión](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KV_TELEVISI%C3%93N/FICHA_MARCO_08KV.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08KW | [varios](08_INSTALACIONES/08K_COMUNICACI%C3%93N/08KW_VARIOS/FICHA_MARCO_08KW.md) | tipo de señal, categoría, topología, atenuación y requisitos del operador. |
| 08LB | [butano](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LB_BUTANO/FICHA_MARCO_08LB.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08LC | [gas ciudad](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LC_GAS_CIUDAD/FICHA_MARCO_08LC.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08LF | [fuel oil](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LF_FUEL_OIL/FICHA_MARCO_08LF.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08LG | [gasóleo](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LG_GAS%C3%93LEO/FICHA_MARCO_08LG.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08LM | [gases medicinales](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LM_GASES_MEDICINALES/FICHA_MARCO_08LM.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial; gas, pureza, materiales, tomas y validación sanitaria. |
| 08LN | [gas natural](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LN_GAS_NATURAL/FICHA_MARCO_08LN.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08LP | [propano](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LP_PROPANO/FICHA_MARCO_08LP.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08LW | [varios](08_INSTALACIONES/08L_GASES_Y_LICUADOS/08LW_VARIOS/FICHA_MARCO_08LW.md) | fluido, almacenamiento, presión, ventilación, detección y régimen sanitario o industrial. |
| 08MA | [ascensores y montacargas](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MA_ASCENSORES_Y_MONTACARGAS/FICHA_MARCO_08MA.md) | equipo, capacidad, recorridos, cargas y regulación específica de seguridad; tipo de aparato, capacidad, recorrido y régimen de puesta en servicio. |
| 08MB | [equipos de bombeo](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MB_EQUIPOS_DE_BOMBEO/FICHA_MARCO_08MB.md) | equipo, capacidad, recorridos, cargas y regulación específica de seguridad; caudal, altura, NPSH requerido y control. |
| 08ME | [escaleras rampas y tapices](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08ME_ESCALERAS_RAMPAS_Y_TAPICES/FICHA_MARCO_08ME.md) | equipo, capacidad, recorridos, cargas y regulación específica de seguridad; tipo de equipo, desnivel, capacidad y protecciones. |
| 08MW | [varios](08_INSTALACIONES/08M_ELECTRO_MEC%C3%81NICAS/08MW_VARIOS/FICHA_MARCO_08MW.md) | equipo, capacidad, recorridos, cargas y regulación específica de seguridad. |
| 08NA | [acumuladores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NA_ACUMULADORES/FICHA_MARCO_08NA.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NB | [bancadas](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NB_BANCADAS/FICHA_MARCO_08NB.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NC | [contadores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NC_CONTADORES/FICHA_MARCO_08NC.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08ND | [sistemas de distribución](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08ND_SISTEMAS_DE_DISTRIBUCI%C3%93N/FICHA_MARCO_08ND.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NE | [estructuras portantes](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NE_ESTRUCTURAS_PORTANTES/FICHA_MARCO_08NE.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NI | [intercambiadores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NI_INTERCAMBIADORES/FICHA_MARCO_08NI.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NL | [sistemas de llenado vaciado](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NL_SISTEMAS_DE_LLENADO_VACIADO/FICHA_MARCO_08NL.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NO | [captadores](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NO_CAPTADORES/FICHA_MARCO_08NO.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NP | [circuito primario](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NP_CIRCUITO_PRIMARIO/FICHA_MARCO_08NP.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NR | [sistema de regulación y control](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NR_SISTEMA_DE_REGULACI%C3%93N_Y_CONTROL/FICHA_MARCO_08NR.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NS | [prevención de sobrecalentamiento](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NS_PREVENCI%C3%93N_DE_SOBRECALENTAMIENTO/FICHA_MARCO_08NS.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NT | [equipos de termosifón](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NT_EQUIPOS_DE_TERMOSIF%C3%93N/FICHA_MARCO_08NT.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad. |
| 08NU | [calentadores por aerotermia](08_INSTALACIONES/08N_ENERG%C3%8DA_SOLAR/08NU_CALENTADORES_POR_AEROTERMIA/FICHA_MARCO_08NU.md) | demanda, temperaturas, fluido, presiones y estrategia de seguridad; refrigerante, potencia, emplazamiento y requisitos ambientales. |
| 08OE | [estructuras portantes](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OE_ESTRUCTURAS_PORTANTES/FICHA_MARCO_08OE.md) | potencia, cargas de viento, esquema eléctrico y condiciones de conexión. |
| 08OO | [captadores](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OO_CAPTADORES/FICHA_MARCO_08OO.md) | potencia, cargas de viento, esquema eléctrico y condiciones de conexión. |
| 08OR | [sistema de regulación y control](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OR_SISTEMA_DE_REGULACI%C3%93N_Y_CONTROL/FICHA_MARCO_08OR.md) | potencia, cargas de viento, esquema eléctrico y condiciones de conexión. |
| 08OU | [monitorización y control](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OU_MONITORIZACI%C3%93N_Y_CONTROL/FICHA_MARCO_08OU.md) | potencia, cargas de viento, esquema eléctrico y condiciones de conexión. |
| 08OW | [varios](08_INSTALACIONES/08O_ENERG%C3%8DA_FOTOVOLTAICA/08OW_VARIOS/FICHA_MARCO_08OW.md) | potencia, cargas de viento, esquema eléctrico y condiciones de conexión. |
| 08PI | [contra incendios](08_INSTALACIONES/08P_PROTECCIONES/08PI_CONTRA_INCENDIOS/FICHA_MARCO_08PI.md) | tipo de protección, prestaciones, alimentación de seguridad y pruebas reglamentarias; riesgo, sistema, caudales o cobertura y mantenimiento. |
| 08PP | [pararrayos](08_INSTALACIONES/08P_PROTECCIONES/08PP_PARARRAYOS/FICHA_MARCO_08PP.md) | tipo de protección, prestaciones, alimentación de seguridad y pruebas reglamentarias; nivel de protección, captación, bajantes y uniones. |
| 08PR | [antirrobo](08_INSTALACIONES/08P_PROTECCIONES/08PR_ANTIRROBO/FICHA_MARCO_08PR.md) | tipo de protección, prestaciones, alimentación de seguridad y pruebas reglamentarias; grado del sistema, zonas, avisos y tratamiento de datos. |
| 08PW | [varios](08_INSTALACIONES/08P_PROTECCIONES/08PW_VARIOS/FICHA_MARCO_08PW.md) | tipo de protección, prestaciones, alimentación de seguridad y pruebas reglamentarias. |
| 08SB | [basuras](08_INSTALACIONES/08S_SALUBRIDAD/08SB_BASURAS/FICHA_MARCO_08SB.md) | tipo de residuo o efluente, sección, ventilación y limpieza. |
| 08SH | [humos y gases](08_INSTALACIONES/08S_SALUBRIDAD/08SH_HUMOS_Y_GASES/FICHA_MARCO_08SH.md) | tipo de residuo o efluente, sección, ventilación y limpieza. |
| 08SW | [varios](08_INSTALACIONES/08S_SALUBRIDAD/08SW_VARIOS/FICHA_MARCO_08SW.md) | tipo de residuo o efluente, sección, ventilación y limpieza. |
| 08TC | [control remoto](08_INSTALACIONES/08T_CONTROL_REMOTO/08TC_CONTROL_REMOTO/FICHA_MARCO_08TC.md) | señales, protocolo, permisos, alarmas y modo seguro. |
| 08WI | [iluminación](08_INSTALACIONES/08W_VARIOS/08WI_ILUMINACI%C3%93N/FICHA_MARCO_08WI.md) | equipo concreto, interfaces, alimentación y requisitos sectoriales. |
| 08WP | [puestos de trabajo mixtos](08_INSTALACIONES/08W_VARIOS/08WP_PUESTOS_DE_TRABAJO_MIXTOS/FICHA_MARCO_08WP.md) | equipo concreto, interfaces, alimentación y requisitos sectoriales. |
| 08WW | [varios](08_INSTALACIONES/08W_VARIOS/08WW_VARIOS/FICHA_MARCO_08WW.md) | equipo concreto, interfaces, alimentación y requisitos sectoriales. |
| 09AP | [paredes](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AP_PAREDES/FICHA_MARCO_09AP.md) | prestación acústica, masa, rigidez y composición del cerramiento. |
| 09AS | [suelos](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AS_SUELOS/FICHA_MARCO_09AS.md) | prestación acústica, masa, rigidez y composición del cerramiento. |
| 09AT | [techos](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AT_TECHOS/FICHA_MARCO_09AT.md) | prestación acústica, masa, rigidez y composición del cerramiento. |
| 09AW | [varios](09_AISLAMIENTOS/09A_AC%C3%9ASTICOS/09AW_VARIOS/FICHA_MARCO_09AW.md) | prestación acústica, masa, rigidez y composición del cerramiento. |
| 09IJ | [juntas](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IJ_JUNTAS/FICHA_MARCO_09IJ.md) | presencia y presión de agua, soporte, membrana y detalles de junta; movimiento, ancho, profundidad y sellante. |
| 09IM | [muros](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IM_MUROS/FICHA_MARCO_09IM.md) | presencia y presión de agua, soporte, membrana y detalles de junta. |
| 09IP | [paredes](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IP_PAREDES/FICHA_MARCO_09IP.md) | presencia y presión de agua, soporte, membrana y detalles de junta. |
| 09IS | [suelos](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IS_SUELOS/FICHA_MARCO_09IS.md) | presencia y presión de agua, soporte, membrana y detalles de junta. |
| 09IW | [varios](09_AISLAMIENTOS/09I_IMPERMEABILIZACI%C3%93N/09IW_VARIOS/FICHA_MARCO_09IW.md) | presencia y presión de agua, soporte, membrana y detalles de junta. |
| 09TC | [canalizaciones](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TC_CANALIZACIONES/FICHA_MARCO_09TC.md) | conductividad declarada, espesor, reacción al fuego y condensaciones. |
| 09TP | [paredes](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TP_PAREDES/FICHA_MARCO_09TP.md) | conductividad declarada, espesor, reacción al fuego y condensaciones. |
| 09TS | [suelos](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TS_SUELOS/FICHA_MARCO_09TS.md) | conductividad declarada, espesor, reacción al fuego y condensaciones. |
| 09TT | [techos](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TT_TECHOS/FICHA_MARCO_09TT.md) | conductividad declarada, espesor, reacción al fuego y condensaciones. |
| 09TW | [varios](09_AISLAMIENTOS/09T_T%C3%89RMICOS/09TW_VARIOS/FICHA_MARCO_09TW.md) | conductividad declarada, espesor, reacción al fuego y condensaciones. |
| 09WW | [varios](09_AISLAMIENTOS/09W_VARIOS/09WW_VARIOS/FICHA_MARCO_09WW.md) | función del aislamiento y sistema completo. |
| 10AA | [alicatados](10_REVESTIMIENTOS/10A_APLACADOS/10AA_ALICATADOS/FICHA_MARCO_10AA.md) | material, formato, soporte y adhesivo o anclaje. |
| 10AC | [chapados](10_REVESTIMIENTOS/10A_APLACADOS/10AC_CHAPADOS/FICHA_MARCO_10AC.md) | material, formato, soporte y adhesivo o anclaje. |
| 10AW | [varios](10_REVESTIMIENTOS/10A_APLACADOS/10AW_VARIOS/FICHA_MARCO_10AW.md) | material, formato, soporte y adhesivo o anclaje. |
| 10CE | [enfoscados](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CE_ENFOSCADOS/FICHA_MARCO_10CE.md) | conglomerante, preparación, espesor y ambiente. |
| 10CG | [guarnecidos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CG_GUARNECIDOS/FICHA_MARCO_10CG.md) | conglomerante, preparación, espesor y ambiente. |
| 10CP | [poliméricos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CP_POLIM%C3%89RICOS/FICHA_MARCO_10CP.md) | conglomerante, preparación, espesor y ambiente. |
| 10CR | [revocos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CR_REVOCOS/FICHA_MARCO_10CR.md) | conglomerante, preparación, espesor y ambiente. |
| 10CT | [tendidos](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CT_TENDIDOS/FICHA_MARCO_10CT.md) | conglomerante, preparación, espesor y ambiente. |
| 10CW | [varios](10_REVESTIMIENTOS/10C_CONT%C3%8DNUOS/10CW_VARIOS/FICHA_MARCO_10CW.md) | conglomerante, preparación, espesor y ambiente. |
| 10LA | [aleaciones ligeras](10_REVESTIMIENTOS/10L_LIGEROS/10LA_ALEACIONES_LIGERAS/FICHA_MARCO_10LA.md) | subestructura, modulación, reacción al fuego y fijaciones. |
| 10LC | [corcho](10_REVESTIMIENTOS/10L_LIGEROS/10LC_CORCHO/FICHA_MARCO_10LC.md) | subestructura, modulación, reacción al fuego y fijaciones. |
| 10LM | [madera](10_REVESTIMIENTOS/10L_LIGEROS/10LM_MADERA/FICHA_MARCO_10LM.md) | subestructura, modulación, reacción al fuego y fijaciones. |
| 10LW | [varios](10_REVESTIMIENTOS/10L_LIGEROS/10LW_VARIOS/FICHA_MARCO_10LW.md) | subestructura, modulación, reacción al fuego y fijaciones. |
| 10PA | [piedras artificiales](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PA_PIEDRAS_ARTIFICIALES/FICHA_MARCO_10PA.md) | geometría de escalera, piezas, resbaladicidad y encuentros. |
| 10PC | [cerámicos](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PC_CER%C3%81MICOS/FICHA_MARCO_10PC.md) | geometría de escalera, piezas, resbaladicidad y encuentros. |
| 10PL | [ligeros](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PL_LIGEROS/FICHA_MARCO_10PL.md) | geometría de escalera, piezas, resbaladicidad y encuentros. |
| 10PM | [maderas](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PM_MADERAS/FICHA_MARCO_10PM.md) | geometría de escalera, piezas, resbaladicidad y encuentros. |
| 10PN | [piedras naturales](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PN_PIEDRAS_NATURALES/FICHA_MARCO_10PN.md) | geometría de escalera, piezas, resbaladicidad y encuentros. |
| 10PW | [varios](10_REVESTIMIENTOS/10P_PELDA%C3%91OS/10PW_VARIOS/FICHA_MARCO_10PW.md) | geometría de escalera, piezas, resbaladicidad y encuentros. |
| 10SC | [cerámicos](10_REVESTIMIENTOS/10S_SUELOS/10SC_CER%C3%81MICOS/FICHA_MARCO_10SC.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SE | [especiales](10_REVESTIMIENTOS/10S_SUELOS/10SE_ESPECIALES/FICHA_MARCO_10SE.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SH | [hidráulicos](10_REVESTIMIENTOS/10S_SUELOS/10SH_HIDR%C3%81ULICOS/FICHA_MARCO_10SH.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SL | [ligeros](10_REVESTIMIENTOS/10S_SUELOS/10SL_LIGEROS/FICHA_MARCO_10SL.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SM | [maderas](10_REVESTIMIENTOS/10S_SUELOS/10SM_MADERAS/FICHA_MARCO_10SM.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SN | [piedras naturales](10_REVESTIMIENTOS/10S_SUELOS/10SN_PIEDRAS_NATURALES/FICHA_MARCO_10SN.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SS | [soleras](10_REVESTIMIENTOS/10S_SUELOS/10SS_SOLERAS/FICHA_MARCO_10SS.md) | carga, desgaste, deslizamiento, humedad y espesor; cargas, espesor, apoyo, juntas y armado. |
| 10ST | [terrazos](10_REVESTIMIENTOS/10S_SUELOS/10ST_TERRAZOS/FICHA_MARCO_10ST.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10SW | [varios](10_REVESTIMIENTOS/10S_SUELOS/10SW_VARIOS/FICHA_MARCO_10SW.md) | carga, desgaste, deslizamiento, humedad y espesor. |
| 10TE | [escayolas](10_REVESTIMIENTOS/10T_TECHOS/10TE_ESCAYOLAS/FICHA_MARCO_10TE.md) | luces, cargas, reacción y resistencia al fuego y accesos. |
| 10TF | [fibras](10_REVESTIMIENTOS/10T_TECHOS/10TF_FIBRAS/FICHA_MARCO_10TF.md) | luces, cargas, reacción y resistencia al fuego y accesos. |
| 10TL | [aleaciones ligeras](10_REVESTIMIENTOS/10T_TECHOS/10TL_ALEACIONES_LIGERAS/FICHA_MARCO_10TL.md) | luces, cargas, reacción y resistencia al fuego y accesos. |
| 10TM | [maderas](10_REVESTIMIENTOS/10T_TECHOS/10TM_MADERAS/FICHA_MARCO_10TM.md) | luces, cargas, reacción y resistencia al fuego y accesos. |
| 10TS | [sintéticos](10_REVESTIMIENTOS/10T_TECHOS/10TS_SINT%C3%89TICOS/FICHA_MARCO_10TS.md) | luces, cargas, reacción y resistencia al fuego y accesos. |
| 10TW | [varios](10_REVESTIMIENTOS/10T_TECHOS/10TW_VARIOS/FICHA_MARCO_10TW.md) | luces, cargas, reacción y resistencia al fuego y accesos. |
| 10WA | [alféizares](10_REVESTIMIENTOS/10W_VARIOS/10WA_ALF%C3%89IZARES/FICHA_MARCO_10WA.md) | geometría del remate, anclaje y estanqueidad. |
| 10WR | [remates](10_REVESTIMIENTOS/10W_VARIOS/10WR_REMATES/FICHA_MARCO_10WR.md) | geometría del remate, anclaje y estanqueidad. |
| 10WW | [varios](10_REVESTIMIENTOS/10W_VARIOS/10WW_VARIOS/FICHA_MARCO_10WW.md) | geometría del remate, anclaje y estanqueidad. |
| 11AM | [mamparas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AM_MAMPARAS/FICHA_MARCO_11AM.md) | perfiles, uniones, galvanizado o pintura y uso. |
| 11AP | [puertas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AP_PUERTAS/FICHA_MARCO_11AP.md) | perfiles, uniones, galvanizado o pintura y uso. |
| 11AV | [ventanas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AV_VENTANAS/FICHA_MARCO_11AV.md) | perfiles, uniones, galvanizado o pintura y uso. |
| 11AW | [varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11A_ACERO/11AW_VARIOS/FICHA_MARCO_11AW.md) | perfiles, uniones, galvanizado o pintura y uso. |
| 11LA | [armarios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LA_ARMARIOS/FICHA_MARCO_11LA.md) | aleación, acabado, rotura de puente térmico y herrajes. |
| 11LM | [mamparas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LM_MAMPARAS/FICHA_MARCO_11LM.md) | aleación, acabado, rotura de puente térmico y herrajes. |
| 11LP | [puertas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LP_PUERTAS/FICHA_MARCO_11LP.md) | aleación, acabado, rotura de puente térmico y herrajes. |
| 11LV | [ventanas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LV_VENTANAS/FICHA_MARCO_11LV.md) | aleación, acabado, rotura de puente térmico y herrajes. |
| 11LW | [varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11L_ALEACIONES_LIGERAS/11LW_VARIOS/FICHA_MARCO_11LW.md) | aleación, acabado, rotura de puente térmico y herrajes. |
| 11MA | [armarios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MA_ARMARIOS/FICHA_MARCO_11MA.md) | madera o tablero, exposición, acabado y herrajes. |
| 11MM | [mamparas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MM_MAMPARAS/FICHA_MARCO_11MM.md) | madera o tablero, exposición, acabado y herrajes. |
| 11MP | [puertas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MP_PUERTAS/FICHA_MARCO_11MP.md) | madera o tablero, exposición, acabado y herrajes. |
| 11MV | [ventanas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MV_VENTANAS/FICHA_MARCO_11MV.md) | madera o tablero, exposición, acabado y herrajes. |
| 11MW | [varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11M_MADERA/11MW_VARIOS/FICHA_MARCO_11MW.md) | madera o tablero, exposición, acabado y herrajes. |
| 11PM | [mamparas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PM_MAMPARAS/FICHA_MARCO_11PM.md) | perfil, refuerzos, dimensiones y prestaciones del conjunto. |
| 11PP | [puertas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PP_PUERTAS/FICHA_MARCO_11PP.md) | perfil, refuerzos, dimensiones y prestaciones del conjunto. |
| 11PV | [ventanas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PV_VENTANAS/FICHA_MARCO_11PV.md) | perfil, refuerzos, dimensiones y prestaciones del conjunto. |
| 11PW | [varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11P_PL%C3%81STICOS/11PW_VARIOS/FICHA_MARCO_11PW.md) | perfil, refuerzos, dimensiones y prestaciones del conjunto. |
| 11SB | [barandillas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SB_BARANDILLAS/FICHA_MARCO_11SB.md) | cargas, altura, huecos, soporte y ensayo de recepción; acciones, altura, huecos y resistencia del soporte. |
| 11SC | [celosías](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SC_CELOS%C3%8DAS/FICHA_MARCO_11SC.md) | cargas, altura, huecos, soporte y ensayo de recepción. |
| 11SE | [escaleras](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SE_ESCALERAS/FICHA_MARCO_11SE.md) | cargas, altura, huecos, soporte y ensayo de recepción; geometría, cargas, apoyos y barandillas. |
| 11SG | [cerramiento acero galvanizado](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SG_CERRAMIENTO_ACERO_GALVANIZADO/FICHA_MARCO_11SG.md) | cargas, altura, huecos, soporte y ensayo de recepción. |
| 11SP | [persianas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SP_PERSIANAS/FICHA_MARCO_11SP.md) | cargas, altura, huecos, soporte y ensayo de recepción. |
| 11SR | [rejas](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SR_REJAS/FICHA_MARCO_11SR.md) | cargas, altura, huecos, soporte y ensayo de recepción. |
| 11SW | [varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11S_SEGURIDAD_Y_PROTECCI%C3%93N/11SW_VARIOS/FICHA_MARCO_11SW.md) | cargas, altura, huecos, soporte y ensayo de recepción. |
| 11WW | [varios](11_CARPINTER%C3%8DA_Y_ELEMENTOS_DE_SEGURIDAD_Y_PROTECCI%C3%93N/11W_VARIOS/11WW_VARIOS/FICHA_MARCO_11WW.md) | elemento concreto, materiales y exigencias de uso. |
| 12AC | [vidrios compuestos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AC_VIDRIOS_COMPUESTOS/FICHA_MARCO_12AC.md) | composición, cámara, capa y prestaciones térmicas. |
| 12AS | [vidrios simples](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AS_VIDRIOS_SIMPLES/FICHA_MARCO_12AS.md) | composición, cámara, capa y prestaciones térmicas. |
| 12AW | [varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12A_VIDRIOS_AISLANTES/12AW_VARIOS/FICHA_MARCO_12AW.md) | composición, cámara, capa y prestaciones térmicas. |
| 12LA | [acústicos y térmicos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LA_AC%C3%9ASTICOS_Y_T%C3%89RMICOS/FICHA_MARCO_12LA.md) | tipo de laminado, clase de impacto y prestaciones declaradas. |
| 12LS | [seguridad](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LS_SEGURIDAD/FICHA_MARCO_12LS.md) | tipo de laminado, clase de impacto y prestaciones declaradas. |
| 12LW | [varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12L_VIDRIOS_LAMINARES/12LW_VARIOS/FICHA_MARCO_12LW.md) | tipo de laminado, clase de impacto y prestaciones declaradas. |
| 12NA | [armados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NA_ARMADOS/FICHA_MARCO_12NA.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12NF | [protección al fuego](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NF_PROTECCI%C3%93N_AL_FUEGO/FICHA_MARCO_12NF.md) | tratamiento, clase de seguridad y condiciones de montaje; clasificación de fuego, carpintería y sellos ensayados. |
| 12NM | [mateados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NM_MATEADOS/FICHA_MARCO_12NM.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12NN | [normales](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NN_NORMALES/FICHA_MARCO_12NN.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12NP | [impresos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NP_IMPRESOS/FICHA_MARCO_12NP.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12NR | [reflectantes](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NR_REFLECTANTES/FICHA_MARCO_12NR.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12NT | [templados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NT_TEMPLADOS/FICHA_MARCO_12NT.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12NW | [varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12N_VIDRIOS_SENCILLOS/12NW_VARIOS/FICHA_MARCO_12NW.md) | tratamiento, clase de seguridad y condiciones de montaje. |
| 12SM | [metacrilatos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SM_METACRILATOS/FICHA_MARCO_12SM.md) | polímero, espesor, protección UV y reacción al fuego. |
| 12SP | [policarbonatos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SP_POLICARBONATOS/FICHA_MARCO_12SP.md) | polímero, espesor, protección UV y reacción al fuego. |
| 12SW | [varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12S_ELABORADOS_SINT%C3%89TICOS/12SW_VARIOS/FICHA_MARCO_12SW.md) | polímero, espesor, protección UV y reacción al fuego. |
| 12WA | [autolimpiantes](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WA_AUTOLIMPIANTES/FICHA_MARCO_12WA.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 12WC | [conformados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WC_CONFORMADOS/FICHA_MARCO_12WC.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 12WE | [emplomados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WE_EMPLOMADOS/FICHA_MARCO_12WE.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 12WK | [muros cortina](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WK_MUROS_CORTINA/FICHA_MARCO_12WK.md) | sistema de fachada o pieza especial y prestaciones completas; acciones, modulación, anclajes y ensayos del sistema. |
| 12WM | [moldeados](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WM_MOLDEADOS/FICHA_MARCO_12WM.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 12WS | [espejos](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WS_ESPEJOS/FICHA_MARCO_12WS.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 12WW | [varios](12_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/12W_VARIOS/12WW_VARIOS/FICHA_MARCO_12WW.md) | sistema de fachada o pieza especial y prestaciones completas. |
| 13EA | [acrílicas](13_PINTURAS/13E_EXTERIORES/13EA_ACR%C3%8DLICAS/FICHA_MARCO_13EA.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13EB | [barniz](13_PINTURAS/13E_EXTERIORES/13EB_BARNIZ/FICHA_MARCO_13EB.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13EC | [cal](13_PINTURAS/13E_EXTERIORES/13EC_CAL/FICHA_MARCO_13EC.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13EE | [esmalte](13_PINTURAS/13E_EXTERIORES/13EE_ESMALTE/FICHA_MARCO_13EE.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13EO | [óleo](13_PINTURAS/13E_EXTERIORES/13EO_%C3%93LEO/FICHA_MARCO_13EO.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13EP | [pétreas](13_PINTURAS/13E_EXTERIORES/13EP_P%C3%89TREAS/FICHA_MARCO_13EP.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13ES | [silicato](13_PINTURAS/13E_EXTERIORES/13ES_SILICATO/FICHA_MARCO_13ES.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13EW | [varios](13_PINTURAS/13E_EXTERIORES/13EW_VARIOS/FICHA_MARCO_13EW.md) | ambiente exterior, radiación, permeabilidad y preparación. |
| 13IB | [barniz](13_PINTURAS/13I_INTERIORES/13IB_BARNIZ/FICHA_MARCO_13IB.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13IE | [esmalte](13_PINTURAS/13I_INTERIORES/13IE_ESMALTE/FICHA_MARCO_13IE.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13IL | [lacas](13_PINTURAS/13I_INTERIORES/13IL_LACAS/FICHA_MARCO_13IL.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13IO | [óleo](13_PINTURAS/13I_INTERIORES/13IO_%C3%93LEO/FICHA_MARCO_13IO.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13IP | [plásticos](13_PINTURAS/13I_INTERIORES/13IP_PL%C3%81STICOS/FICHA_MARCO_13IP.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13IT | [temple](13_PINTURAS/13I_INTERIORES/13IT_TEMPLE/FICHA_MARCO_13IT.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13IW | [varios](13_PINTURAS/13I_INTERIORES/13IW_VARIOS/FICHA_MARCO_13IW.md) | soporte, acabado, emisiones y resistencia al uso. |
| 13SA | [anticalóricas](13_PINTURAS/13S_ESPECIALES/13SA_ANTICAL%C3%93RICAS/FICHA_MARCO_13SA.md) | prestación especial, clasificación y espesor de película; temperatura de servicio, preparación y curado. |
| 13SC | [clorocaucho](13_PINTURAS/13S_ESPECIALES/13SC_CLOROCAUCHO/FICHA_MARCO_13SC.md) | prestación especial, clasificación y espesor de película. |
| 13SI | [ignífugas](13_PINTURAS/13S_ESPECIALES/13SI_IGN%C3%8DFUGAS/FICHA_MARCO_13SI.md) | prestación especial, clasificación y espesor de película; clasificación, soporte, sistema completo y espesor seco. |
| 13SW | [varios](13_PINTURAS/13S_ESPECIALES/13SW_VARIOS/FICHA_MARCO_13SW.md) | prestación especial, clasificación y espesor de película. |
| 13WW | [varios](13_PINTURAS/13W_VARIOS/13WW_VARIOS/FICHA_MARCO_13WW.md) | tipo de tratamiento y prestación requerida. |
| 14MA | [aseos y baños](14_EQUIPAMIENTO/14M_MOBILIARIO/14MA_ASEOS_Y_BA%C3%91OS/FICHA_MARCO_14MA.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14MC | [cocinas](14_EQUIPAMIENTO/14M_MOBILIARIO/14MC_COCINAS/FICHA_MARCO_14MC.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14MD | [dormitorios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MD_DORMITORIOS/FICHA_MARCO_14MD.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14ME | [estanterías](14_EQUIPAMIENTO/14M_MOBILIARIO/14ME_ESTANTER%C3%8DAS/FICHA_MARCO_14ME.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14ML | [lámparas](14_EQUIPAMIENTO/14M_MOBILIARIO/14ML_L%C3%81MPARAS/FICHA_MARCO_14ML.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14MM | [mesas](14_EQUIPAMIENTO/14M_MOBILIARIO/14MM_MESAS/FICHA_MARCO_14MM.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14MS | [sillas y sillones](14_EQUIPAMIENTO/14M_MOBILIARIO/14MS_SILLAS_Y_SILLONES/FICHA_MARCO_14MS.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14MV | [vestuarios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MV_VESTUARIOS/FICHA_MARCO_14MV.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14MW | [varios](14_EQUIPAMIENTO/14M_MOBILIARIO/14MW_VARIOS/FICHA_MARCO_14MW.md) | dimensiones, uso, cargas, acabado y fijaciones. |
| 14WA | [elementos artísticos](14_EQUIPAMIENTO/14W_VARIOS/14WA_ELEMENTOS_ART%C3%8DSTICOS/FICHA_MARCO_14WA.md) | elemento concreto, emplazamiento y prestaciones. |
| 14WB | [buzones](14_EQUIPAMIENTO/14W_VARIOS/14WB_BUZONES/FICHA_MARCO_14WB.md) | elemento concreto, emplazamiento y prestaciones. |
| 14WC | [cortinas](14_EQUIPAMIENTO/14W_VARIOS/14WC_CORTINAS/FICHA_MARCO_14WC.md) | elemento concreto, emplazamiento y prestaciones. |
| 14WE | [entelados y empapelados](14_EQUIPAMIENTO/14W_VARIOS/14WE_ENTELADOS_Y_EMPAPELADOS/FICHA_MARCO_14WE.md) | elemento concreto, emplazamiento y prestaciones. |
| 14WJ | [jardineras](14_EQUIPAMIENTO/14W_VARIOS/14WJ_JARDINERAS/FICHA_MARCO_14WJ.md) | elemento concreto, emplazamiento y prestaciones. |
| 14WS | [señalizaciones](14_EQUIPAMIENTO/14W_VARIOS/14WS_SE%C3%91ALIZACIONES/FICHA_MARCO_14WS.md) | elemento concreto, emplazamiento y prestaciones. |
| 14WW | [varios](14_EQUIPAMIENTO/14W_VARIOS/14WW_VARIOS/FICHA_MARCO_14WW.md) | elemento concreto, emplazamiento y prestaciones. |
| 15AA | [acometidas](15_URBANIZACIONES/15A_ALCANTARILLADO/15AA_ACOMETIDAS/FICHA_MARCO_15AA.md) | caudal, tipo de agua, receptor, sección y estanqueidad. |
| 15AD | [depuración y vertido](15_URBANIZACIONES/15A_ALCANTARILLADO/15AD_DEPURACI%C3%93N_Y_VERTIDO/FICHA_MARCO_15AD.md) | caudal, tipo de agua, receptor, sección y estanqueidad; cargas contaminantes, proceso, receptor y límites autorizados. |
| 15AW | [varios](15_URBANIZACIONES/15A_ALCANTARILLADO/15AW_VARIOS/FICHA_MARCO_15AW.md) | caudal, tipo de agua, receptor, sección y estanqueidad. |
| 15CS | [semáforos](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CS_SEM%C3%81FOROS/FICHA_MARCO_15CS.md) | clase de vía, geometría, visibilidad y autorización; plan semafórico, control, detección y alimentación. |
| 15CW | [varios](15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACI%C3%93N/15CW_VARIOS/FICHA_MARCO_15CW.md) | clase de vía, geometría, visibilidad y autorización. |
| 15ER | [redes aéreas](15_URBANIZACIONES/15E_ELECTRICIDAD/15ER_REDES_A%C3%89REAS/FICHA_MARCO_15ER.md) | tensión, potencia, titularidad y reglamentación eléctrica correspondiente; tensión, vano, conductor y cargas de viento. |
| 15ET | [transformadores](15_URBANIZACIONES/15E_ELECTRICIDAD/15ET_TRANSFORMADORES/FICHA_MARCO_15ET.md) | tensión, potencia, titularidad y reglamentación eléctrica correspondiente; tensión, potencia, esquema, protecciones y autorizaciones. |
| 15EW | [varios](15_URBANIZACIONES/15E_ELECTRICIDAD/15EW_VARIOS/FICHA_MARCO_15EW.md) | tensión, potencia, titularidad y reglamentación eléctrica correspondiente. |
| 15GC | [gas ciudad](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GC_GAS_CIUDAD/FICHA_MARCO_15GC.md) | tipo de gas o combustible, presión, almacenamiento y seguridad. |
| 15GF | [fuel oil](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GF_FUEL_OIL/FICHA_MARCO_15GF.md) | tipo de gas o combustible, presión, almacenamiento y seguridad. |
| 15GG | [gasóleo](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GG_GAS%C3%93LEO/FICHA_MARCO_15GG.md) | tipo de gas o combustible, presión, almacenamiento y seguridad. |
| 15GP | [propano](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GP_PROPANO/FICHA_MARCO_15GP.md) | tipo de gas o combustible, presión, almacenamiento y seguridad. |
| 15GW | [varios](15_URBANIZACIONES/15G_GASES_Y_LICUADOS/15GW_VARIOS/FICHA_MARCO_15GW.md) | tipo de gas o combustible, presión, almacenamiento y seguridad. |
| 15JS | [setos](15_URBANIZACIONES/15J_JARDINER%C3%8DA/15JS_SETOS/FICHA_MARCO_15JS.md) | especie, formato, suelo, riego y periodo de establecimiento; especie, marco, altura y mantenimiento. |
| 15MA | [apertura de cajas](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MA_APERTURA_DE_CAJAS/FICHA_MARCO_15MA.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MC | [compactaciones](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MC_COMPACTACIONES/FICHA_MARCO_15MC.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MD | [desmontes](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MD_DESMONTES/FICHA_MARCO_15MD.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15ME | [explanaciones](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15ME_EXPLANACIONES/FICHA_MARCO_15ME.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MP | [pozos](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MP_POZOS/FICHA_MARCO_15MP.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MR | [rellenos](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MR_RELLENOS/FICHA_MARCO_15MR.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MT | [transportes](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MT_TRANSPORTES/FICHA_MARCO_15MT.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MW | [varios](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MW_VARIOS/FICHA_MARCO_15MW.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15MZ | [zanjas](15_URBANIZACIONES/15M_MOVIMIENTO_DE_TIERRAS/15MZ_ZANJAS/FICHA_MARCO_15MZ.md) | geometría, geotecnia, sostenimiento y compactación. |
| 15PE | [encintados](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PE_ENCINTADOS/FICHA_MARCO_15PE.md) | tráfico, accesibilidad, espesor, pendiente y acabado. |
| 15PS | [soleras](15_URBANIZACIONES/15P_PAVIMENTACIONES/15PS_SOLERAS/FICHA_MARCO_15PS.md) | tráfico, accesibilidad, espesor, pendiente y acabado; espesor, cargas, armado y juntas. |
| 15SD | [desagües](15_URBANIZACIONES/15S_SUMINISTRO_DE_AGUA/15SD_DESAG%C3%9CES/FICHA_MARCO_15SD.md) | caudal, presión, material, titular y protocolo sanitario; punto de desagüe, caudal y protección frente a retorno. |
| 15TW | [varios](15_URBANIZACIONES/15T_TEL%C3%89FONO/15TW_VARIOS/FICHA_MARCO_15TW.md) | operador, número y sección de conductos, cámaras y ocupación. |
| 15UB | [bancos](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UB_BANCOS/FICHA_MARCO_15UB.md) | dimensiones, usuario, cargas, anclajes y mantenimiento. |
| 15UF | [fuentes](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UF_FUENTES/FICHA_MARCO_15UF.md) | dimensiones, usuario, cargas, anclajes y mantenimiento; uso del agua, circuito, tratamiento y régimen sanitario. |
| 15UJ | [juegos](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UJ_JUEGOS/FICHA_MARCO_15UJ.md) | dimensiones, usuario, cargas, anclajes y mantenimiento; edades, altura de caída, espacio libre y mantenimiento. |
| 15UP | [papeleras](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UP_PAPELERAS/FICHA_MARCO_15UP.md) | dimensiones, usuario, cargas, anclajes y mantenimiento. |
| 15US | [equipamiento deportivo](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15US_EQUIPAMIENTO_DEPORTIVO/FICHA_MARCO_15US.md) | dimensiones, usuario, cargas, anclajes y mantenimiento; disciplina, cargas, anclajes y espacio de uso. |
| 15UW | [varios](15_URBANIZACIONES/15U_AMUEBLAMIENTO_URBANO/15UW_VARIOS/FICHA_MARCO_15UW.md) | dimensiones, usuario, cargas, anclajes y mantenimiento. |
| 15WC | [cerramientos](15_URBANIZACIONES/15W_VARIOS/15WC_CERRAMIENTOS/FICHA_MARCO_15WC.md) | solución concreta, terreno, acciones y mantenimiento; altura, viento, soporte y accesos. |
| 15WW | [varios](15_URBANIZACIONES/15W_VARIOS/15WW_VARIOS/FICHA_MARCO_15WW.md) | solución concreta, terreno, acciones y mantenimiento. |
| 17AA | [aluminio](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AA_ALUMINIO/FICHA_MARCO_17AA.md) | metal, recubrimientos y contaminantes. |
| 17AB | [bronce cobre y latón](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AB_BRONCE_COBRE_Y_LAT%C3%93N/FICHA_MARCO_17AB.md) | metal, recubrimientos y contaminantes. |
| 17AC | [cables](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AC_CABLES/FICHA_MARCO_17AC.md) | metal, recubrimientos y contaminantes. |
| 17AE | [estaño](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AE_ESTA%C3%91O/FICHA_MARCO_17AE.md) | metal, recubrimientos y contaminantes. |
| 17AH | [hierro y acero](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AH_HIERRO_Y_ACERO/FICHA_MARCO_17AH.md) | metal, recubrimientos y contaminantes. |
| 17AM | [metales mezclados](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AM_METALES_MEZCLADOS/FICHA_MARCO_17AM.md) | metal, recubrimientos y contaminantes. |
| 17AP | [plomo](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AP_PLOMO/FICHA_MARCO_17AP.md) | metal, recubrimientos y contaminantes; forma del residuo, contaminación y medidas preventivas. |
| 17AW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AW_VARIOS/FICHA_MARCO_17AW.md) | metal, recubrimientos y contaminantes. |
| 17AZ | [zinc](17_GESTI%C3%93N_DE_RESIDUOS/17A_METALES_Y_ALEACIONES/17AZ_ZINC/FICHA_MARCO_17AZ.md) | metal, recubrimientos y contaminantes. |
| 17FA | [asfalto con alquitrán](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FA_ASFALTO_CON_ALQUITR%C3%81N/FICHA_MARCO_17FA.md) | presencia de alquitrán y clasificación del residuo; contenido de sustancias peligrosas y vía autorizada. |
| 17FS | [asfalto sin alquitrán](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FS_ASFALTO_SIN_ALQUITR%C3%81N/FICHA_MARCO_17FS.md) | presencia de alquitrán y clasificación del residuo. |
| 17FT | [alquitrán y productos alquitranados](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FT_ALQUITR%C3%81N_Y_PRODUCTOS_ALQUITRANADOS/FICHA_MARCO_17FT.md) | presencia de alquitrán y clasificación del residuo; composición, peligrosidad y tratamiento autorizado. |
| 17FW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17F_ASFALTO_ALQUITR%C3%81N_Y_OTROS_PRODUCTOS_ALQUITRANADOS/17FW_VARIOS/FICHA_MARCO_17FW.md) | presencia de alquitrán y clasificación del residuo. |
| 17HA | [áridos y piedras naturales](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HA_%C3%81RIDOS_Y_PIEDRAS_NATURALES/FICHA_MARCO_17HA.md) | composición mineral, contaminación y destino autorizado. |
| 17HC | [materiales cerámicos](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HC_MATERIALES_CER%C3%81MICOS/FICHA_MARCO_17HC.md) | composición mineral, contaminación y destino autorizado. |
| 17HH | [hormigones terrazos cementos y cales](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HH_HORMIGONES_TERRAZOS_CEMENTOS_Y_CALES/FICHA_MARCO_17HH.md) | composición mineral, contaminación y destino autorizado. |
| 17HM | [morteros](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HM_MORTEROS/FICHA_MARCO_17HM.md) | composición mineral, contaminación y destino autorizado. |
| 17HW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HW_VARIOS/FICHA_MARCO_17HW.md) | composición mineral, contaminación y destino autorizado. |
| 17HY | [materiales de construcción derivados del yeso](17_GESTI%C3%93N_DE_RESIDUOS/17H_HORMIGONES_LADRILLOS_TEJAS_MAT_CER%C3%81M_Y_DERIV_DEL_YESO/17HY_MATERIALES_DE_CONSTRUCCI%C3%93N_DERIVADOS_DEL_YESO/FICHA_MARCO_17HY.md) | composición mineral, contaminación y destino autorizado. |
| 17IA | [materiales derivados del yeso con amianto](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IA_MATERIALES_DERIVADOS_DEL_YESO_CON_AMIANTO/FICHA_MARCO_17IA.md) | composición del aislamiento y presencia de sustancias peligrosas; diagnóstico de amianto, plan específico y gestor autorizado. |
| 17IO | [otros materiales de aislamiento](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IO_OTROS_MATERIALES_DE_AISLAMIENTO/FICHA_MARCO_17IO.md) | composición del aislamiento y presencia de sustancias peligrosas. |
| 17IW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17I_MATERIALES_DE_AISLAMIENTO/17IW_VARIOS/FICHA_MARCO_17IW.md) | composición del aislamiento y presencia de sustancias peligrosas. |
| 17MM | [maderas papeles plásticos y sintéticos](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MM_MADERAS_PAPELES_PL%C3%81STICOS_Y_SINT%C3%89TICOS/FICHA_MARCO_17MM.md) | fracción real, tratamientos y contaminación. |
| 17MV | [vidrios](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MV_VIDRIOS/FICHA_MARCO_17MV.md) | fracción real, tratamientos y contaminación. |
| 17MW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17M_MADERAS_PAPELES_CARTONES_PL%C3%81STICOS_SINT%C3%89TICOS_Y_V%C3%8DDRIOS/17MW_VARIOS/FICHA_MARCO_17MW.md) | fracción real, tratamientos y contaminación. |
| 17RB | [residuos bituminosos](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RB_RESIDUOS_BITUMINOSOS/FICHA_MARCO_17RB.md) | composición de la mezcla y operaciones de separación. |
| 17RR | [residuos mezclados](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RR_RESIDUOS_MEZCLADOS/FICHA_MARCO_17RR.md) | composición de la mezcla y operaciones de separación. |
| 17RW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RW_VARIOS/FICHA_MARCO_17RW.md) | composición de la mezcla y operaciones de separación. |
| 17TL | [lodos de renaje](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TL_LODOS_DE_RENAJE/FICHA_MARCO_17TL.md) | analítica cuando proceda, humedad, contaminación y destino; analítica, humedad y aceptación del destino. |
| 17TT | [terrenos](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TT_TERRENOS/FICHA_MARCO_17TT.md) | analítica cuando proceda, humedad, contaminación y destino. |
| 17TW | [varios](17_GESTI%C3%93N_DE_RESIDUOS/17T_TERRENOS/17TW_VARIOS/FICHA_MARCO_17TW.md) | analítica cuando proceda, humedad, contaminación y destino. |
| 18AL | [laboratorio](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18A_%C3%81RIDOS_Y_SUELOS/18AL_LABORATORIO/FICHA_MARCO_18AL.md) | uso del agua, parámetros, muestreo y límites aplicables. |
| 18AS | [in situ](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18A_%C3%81RIDOS_Y_SUELOS/18AS_IN_SITU/FICHA_MARCO_18AS.md) | uso del agua, parámetros, muestreo y límites aplicables. |
| 18BB | [baldosas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BB_BALDOSAS/FICHA_MARCO_18BB.md) | material, lote, resistencia y prestación superficial. |
| 18BP | [paredes y fachadas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BP_PAREDES_Y_FACHADAS/FICHA_MARCO_18BP.md) | material, lote, resistencia y prestación superficial. |
| 18BS | [suelo](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BS_SUELO/FICHA_MARCO_18BS.md) | material, lote, resistencia y prestación superficial. |
| 18BT | [techos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18B_BALDOSAS_Y_REVESTIMIENTOS/18BT_TECHOS/FICHA_MARCO_18BT.md) | material, lote, resistencia y prestación superficial. |
| 18CA | [pantallas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CA_PANTALLAS/FICHA_MARCO_18CA.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18CE | [escolleras](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CE_ESCOLLERAS/FICHA_MARCO_18CE.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18CL | [lodos bentolíticos o suspensiones poliméricas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CL_LODOS_BENTOL%C3%8DTICOS_O_SUSPENSIONES_POLIM%C3%89RICAS/FICHA_MARCO_18CL.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18CM | [micropilotes](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CM_MICROPILOTES/FICHA_MARCO_18CM.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18CP | [pilotes](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CP_PILOTES/FICHA_MARCO_18CP.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18CW | [varios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACI%C3%93N/18CW_VARIOS/FICHA_MARCO_18CW.md) | tipología, elemento, método y criterio geotécnico o resistente. |
| 18EE | [estructura de fábrica](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18E_ESTRUCTURAS_DE_F%C3%81BRICA/18EE_ESTRUCTURA_DE_F%C3%81BRICA/FICHA_MARCO_18EE.md) | tipo de fábrica, resistencia y método de evaluación. |
| 18HH | [hormigón](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18H_ESTRUCTURAS_DE_HORMIG%C3%93N/18HH_HORMIG%C3%93N/FICHA_MARCO_18HH.md) | lotes, edad de ensayo y criterio de conformidad. |
| 18HW | [varios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18H_ESTRUCTURAS_DE_HORMIG%C3%93N/18HW_VARIOS/FICHA_MARCO_18HW.md) | lotes, edad de ensayo y criterio de conformidad. |
| 18IA | [saneamiento](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IA_SANEAMIENTO/FICHA_MARCO_18IA.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IB | [abastecimiento en redes exteriores de agua](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IB_ABASTECIMIENTO_EN_REDES_EXTERIORES_DE_AGUA/FICHA_MARCO_18IB.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IC | [fontaneria y redes interiores de suministro de agua](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IC_FONTANERIA_Y_REDES_INTERIORES_DE_SUMINISTRO_DE_AGUA/FICHA_MARCO_18IC.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18ID | [electricidad baja tensión bt](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18ID_ELECTRICIDAD_BAJA_TENSI%C3%93N_BT/FICHA_MARCO_18ID.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IE | [electricidad media tensión mt](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IE_ELECTRICIDAD_MEDIA_TENSI%C3%93N_MT/FICHA_MARCO_18IE.md) | instalación, magnitudes, protocolo y límites reglamentarios; tensión, equipos y reglamentación de alta tensión. |
| 18IF | [energía solar térmica](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IF_ENERG%C3%8DA_SOLAR_T%C3%89RMICA/FICHA_MARCO_18IF.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IG | [climatización y calefacción](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IG_CLIMATIZACI%C3%93N_Y_CALEFACCI%C3%93N/FICHA_MARCO_18IG.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IH | [ventilación](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IH_VENTILACI%C3%93N/FICHA_MARCO_18IH.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18II | [extracción](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18II_EXTRACCI%C3%93N/FICHA_MARCO_18II.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IJ | [instalación contra incendios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IJ_INSTALACI%C3%93N_CONTRA_INCENDIOS/FICHA_MARCO_18IJ.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IL | [riego](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IL_RIEGO/FICHA_MARCO_18IL.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IM | [piscinas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IM_PISCINAS/FICHA_MARCO_18IM.md) | instalación, magnitudes, protocolo y límites reglamentarios; uso, tratamiento, calidad del agua y seguridad. |
| 18IN | [detección de monóxido de carbono](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IN_DETECCI%C3%93N_DE_MON%C3%93XIDO_DE_CARBONO/FICHA_MARCO_18IN.md) | instalación, magnitudes, protocolo y límites reglamentarios; gas de referencia, calibración y consignas. |
| 18IO | [alumbrado exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IO_ALUMBRADO_EXTERIOR/FICHA_MARCO_18IO.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IP | [pararrayos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IP_PARARRAYOS/FICHA_MARCO_18IP.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IQ | [telecomunicaciones](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IQ_TELECOMUNICACIONES/FICHA_MARCO_18IQ.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IR | [gas natural](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IR_GAS_NATURAL/FICHA_MARCO_18IR.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IS | [elevación](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IS_ELEVACI%C3%93N/FICHA_MARCO_18IS.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18IT | [gases medicinales](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IT_GASES_MEDICINALES/FICHA_MARCO_18IT.md) | instalación, magnitudes, protocolo y límites reglamentarios; gas, puntos terminales y validación sanitaria. |
| 18IU | [instalaciones especiales](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18I_INSTALACIONES/18IU_INSTALACIONES_ESPECIALES/FICHA_MARCO_18IU.md) | instalación, magnitudes, protocolo y límites reglamentarios. |
| 18KA | [carpintería exterior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18K_CARPINTER%C3%8DA_Y_VIDRIOS/18KA_CARPINTER%C3%8DA_EXTERIOR/FICHA_MARCO_18KA.md) | conjunto, clase declarada y prestación ensayada. |
| 18KB | [carpintería interior](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18K_CARPINTER%C3%8DA_Y_VIDRIOS/18KB_CARPINTER%C3%8DA_INTERIOR/FICHA_MARCO_18KB.md) | conjunto, clase declarada y prestación ensayada. |
| 18KC | [vidrios](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18K_CARPINTER%C3%8DA_Y_VIDRIOS/18KC_VIDRIOS/FICHA_MARCO_18KC.md) | conjunto, clase declarada y prestación ensayada. |
| 18MA | [madera aserrada](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18MA_MADERA_ASERRADA/FICHA_MARCO_18MA.md) | tipo de madera o tablero, humedad y prestaciones resistentes. |
| 18ML | [madera laminada encolada](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18ML_MADERA_LAMINADA_ENCOLADA/FICHA_MARCO_18ML.md) | tipo de madera o tablero, humedad y prestaciones resistentes. |
| 18MT | [tableros](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18M_ESTRUCTURAS_DE_MADERA/18MT_TABLEROS/FICHA_MARCO_18MT.md) | tipo de madera o tablero, humedad y prestaciones resistentes. |
| 18OG | [guarnecido y enlucido de yeso](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18O_MORTEROS_YESOS_CALES_ESCAYOLAS_Y_CEMENTOS/18OG_GUARNECIDO_Y_ENLUCIDO_DE_YESO/FICHA_MARCO_18OG.md) | producto, lote, adherencia y método de ensayo. |
| 18OM | [mortero cola](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18O_MORTEROS_YESOS_CALES_ESCAYOLAS_Y_CEMENTOS/18OM_MORTERO_COLA/FICHA_MARCO_18OM.md) | producto, lote, adherencia y método de ensayo. |
| 18OR | [revoco y enlucido con mortero de cemento](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18O_MORTEROS_YESOS_CALES_ESCAYOLAS_Y_CEMENTOS/18OR_REVOCO_Y_ENLUCIDO_CON_MORTERO_DE_CEMENTO/FICHA_MARCO_18OR.md) | producto, lote, adherencia y método de ensayo. |
| 18PA | [pintura paramentos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18P_PINTURAS/18PA_PINTURA_PARAMENTOS/FICHA_MARCO_18PA.md) | sistema, espesor, adherencia y criterio de aceptación. |
| 18PM | [pintura estructura metálica](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18P_PINTURAS/18PM_PINTURA_ESTRUCTURA_MET%C3%81LICA/FICHA_MARCO_18PM.md) | sistema, espesor, adherencia y criterio de aceptación. |
| 18RB | [bovedillas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RB_BOVEDILLAS/FICHA_MARCO_18RB.md) | producto, lote y características exigibles. |
| 18RH | [bloques de hormigón](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RH_BLOQUES_DE_HORMIG%C3%93N/FICHA_MARCO_18RH.md) | producto, lote y características exigibles. |
| 18RR | [ladrillos y bloques cerámicos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RR_LADRILLOS_Y_BLOQUES_CER%C3%81MICOS/FICHA_MARCO_18RR.md) | producto, lote y características exigibles. |
| 18RT | [tejas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18R_MATERIALES_CER%C3%81MICOS_Y_BLOQUES_DE_HORMIG%C3%93N/18RT_TEJAS/FICHA_MARCO_18RT.md) | producto, lote y características exigibles. |
| 18SC | [protección anticorrosiva](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SC_PROTECCI%C3%93N_ANTICORROSIVA/FICHA_MARCO_18SC.md) | clase de ejecución, extensión de inspección y niveles de aceptación. |
| 18SE | [elementos metálicos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SE_ELEMENTOS_MET%C3%81LICOS/FICHA_MARCO_18SE.md) | clase de ejecución, extensión de inspección y niveles de aceptación. |
| 18SP | [perfiles](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SP_PERFILES/FICHA_MARCO_18SP.md) | clase de ejecución, extensión de inspección y niveles de aceptación. |
| 18SS | [soldaduras](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18S_ESTRUCTURAS_DE_ACERO/18SS_SOLDADURAS/FICHA_MARCO_18SS.md) | clase de ejecución, extensión de inspección y niveles de aceptación; procedimiento, extensión de ensayos y nivel de aceptación. |
| 18TA | [aislamientos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18T_AISLAMIENTOS_E_IMPERMEABILIZACIONES/18TA_AISLAMIENTOS/FICHA_MARCO_18TA.md) | producto, función, prestación y dirección de ensayo. |
| 18TG | [geosintéticos](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18T_AISLAMIENTOS_E_IMPERMEABILIZACIONES/18TG_GEOSINT%C3%89TICOS/FICHA_MARCO_18TG.md) | producto, función, prestación y dirección de ensayo. |
| 18UA | [pruebas de acústica](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UA_PRUEBAS_DE_AC%C3%9ASTICA/FICHA_MARCO_18UA.md) | escenario de servicio, instrumentación y umbrales; magnitud, método, recintos y exigencia. |
| 18UB | [pruebas de estanqueidad en cubiertas y fachadas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UB_PRUEBAS_DE_ESTANQUEIDAD_EN_CUBIERTAS_Y_FACHADAS/FICHA_MARCO_18UB.md) | escenario de servicio, instrumentación y umbrales; presión o altura, duración, cargas y criterio de fuga. |
| 18UC | [pruebas sobre barandillas](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UC_PRUEBAS_SOBRE_BARANDILLAS/FICHA_MARCO_18UC.md) | escenario de servicio, instrumentación y umbrales; cargas, deformación, geometría y anclajes. |
| 18UD | [pruebas de eficiencia energética](18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18U_PRUEBAS_DE_SERVICIO/18UD_PRUEBAS_DE_EFICIENCIA_ENERG%C3%89TICA/FICHA_MARCO_18UD.md) | escenario de servicio, instrumentación y umbrales; indicador energético, periodo y condiciones de ensayo. |
| 19LA | [adaptaciones](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LA_ADAPTACIONES/FICHA_MARCO_19LA.md) | usuarios, periodo de uso y servicios disponibles. |
| 19LI | [instalaciones](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LI_INSTALACIONES/FICHA_MARCO_19LI.md) | usuarios, periodo de uso y servicios disponibles. |
| 19LL | [locales](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LL_LOCALES/FICHA_MARCO_19LL.md) | usuarios, periodo de uso y servicios disponibles. |
| 19LM | [amueblamiento](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LM_AMUEBLAMIENTO/FICHA_MARCO_19LM.md) | usuarios, periodo de uso y servicios disponibles. |
| 19LP | [prefabricados](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LP_PREFABRICADOS/FICHA_MARCO_19LP.md) | usuarios, periodo de uso y servicios disponibles. |
| 19LW | [varios](19_SEGURIDAD_Y_SALUD/19L_LOCALES_Y_SERVICIOS/19LW_VARIOS/FICHA_MARCO_19LW.md) | usuarios, periodo de uso y servicios disponibles. |
| 19SI | [individual](19_SEGURIDAD_Y_SALUD/19S_SEGURIDAD/19SI_INDIVIDUAL/FICHA_MARCO_19SI.md) | riesgo, clase de protección, anclajes y revisiones; riesgo residual, clase, compatibilidad y reposición. |
| 19WF | [formación específica](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WF_FORMACI%C3%93N_ESPEC%C3%8DFICA/FICHA_MARCO_19WF.md) | actividad preventiva concreta, frecuencia y responsable; destinatarios, contenidos, duración y acreditación. |
| 19WM | [medicina preventiva](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WM_MEDICINA_PREVENTIVA/FICHA_MARCO_19WM.md) | actividad preventiva concreta, frecuencia y responsable; servicio sanitario, protocolos y confidencialidad. |
| 19WP | [primeros auxilios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WP_PRIMEROS_AUXILIOS/FICHA_MARCO_19WP.md) | actividad preventiva concreta, frecuencia y responsable; medios, responsables, comunicaciones y acceso de emergencias. |
| 19WS | [seguimiento y control interno](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WS_SEGUIMIENTO_Y_CONTROL_INTERNO/FICHA_MARCO_19WS.md) | actividad preventiva concreta, frecuencia y responsable. |
| 19WW | [varios](19_SEGURIDAD_Y_SALUD/19W_VARIOS/19WW_VARIOS/FICHA_MARCO_19WW.md) | actividad preventiva concreta, frecuencia y responsable. |
| 21AA | [arcos y bóvedas de ladrillo](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AA_ARCOS_Y_B%C3%93VEDAS_DE_LADRILLO/FICHA_MARCO_21AA.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AB | [fábricas de bloques](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AB_F%C3%81BRICAS_DE_BLOQUES/FICHA_MARCO_21AB.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AC | [cantería](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AC_CANTER%C3%8DA/FICHA_MARCO_21AC.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AE | [cerramientos especiales](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AE_CERRAMIENTOS_ESPECIALES/FICHA_MARCO_21AE.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AL | [ladrillo](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AL_LADRILLO/FICHA_MARCO_21AL.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AP | [prefabricados](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AP_PREFABRICADOS/FICHA_MARCO_21AP.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AT | [cerramientos tipo](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AT_CERRAMIENTOS_TIPO/FICHA_MARCO_21AT.md) | patología, estabilidad y compatibilidad de morteros. |
| 21AW | [varios](21_MANTENIMIENTO/21A_ALBA%C3%91ILER%C3%8DA/21AW_VARIOS/FICHA_MARCO_21AW.md) | patología, estabilidad y compatibilidad de morteros. |
| 21EM | [mobiliario](21_MANTENIMIENTO/21E_EQUIPAMIENTO/21EM_MOBILIARIO/FICHA_MARCO_21EM.md) | equipo, repuestos compatibles y cargas de uso. |
| 21IC | [climatización](21_MANTENIMIENTO/21I_INSTALACIONES/21IC_CLIMATIZACI%C3%93N/FICHA_MARCO_21IC.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IE | [eléctricas](21_MANTENIMIENTO/21I_INSTALACIONES/21IE_EL%C3%89CTRICAS/FICHA_MARCO_21IE.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IF | [fontanería](21_MANTENIMIENTO/21I_INSTALACIONES/21IF_FONTANER%C3%8DA/FICHA_MARCO_21IF.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IK | [comunicación](21_MANTENIMIENTO/21I_INSTALACIONES/21IK_COMUNICACI%C3%93N/FICHA_MARCO_21IK.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IL | [gases y licuados](21_MANTENIMIENTO/21I_INSTALACIONES/21IL_GASES_Y_LICUADOS/FICHA_MARCO_21IL.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IM | [electro mecánicas](21_MANTENIMIENTO/21I_INSTALACIONES/21IM_ELECTRO_MEC%C3%81NICAS/FICHA_MARCO_21IM.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IN | [energía solar](21_MANTENIMIENTO/21I_INSTALACIONES/21IN_ENERG%C3%8DA_SOLAR/FICHA_MARCO_21IN.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IO | [energía fotovoltaica](21_MANTENIMIENTO/21I_INSTALACIONES/21IO_ENERG%C3%8DA_FOTOVOLTAICA/FICHA_MARCO_21IO.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IP | [protecciones](21_MANTENIMIENTO/21I_INSTALACIONES/21IP_PROTECCIONES/FICHA_MARCO_21IP.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21IW | [varios](21_MANTENIMIENTO/21I_INSTALACIONES/21IW_VARIOS/FICHA_MARCO_21IW.md) | instalación, operaciones autorizadas y requisitos de empresa mantenedora. |
| 21KA | [armarios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KA_ARMARIOS/FICHA_MARCO_21KA.md) | material, lesión y prestaciones originales. |
| 21KB | [barandillas y rejas](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KB_BARANDILLAS_Y_REJAS/FICHA_MARCO_21KB.md) | material, lesión y prestaciones originales. |
| 21KC | [celosías y persianas](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KC_CELOS%C3%8DAS_Y_PERSIANAS/FICHA_MARCO_21KC.md) | material, lesión y prestaciones originales. |
| 21KM | [mamparas](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KM_MAMPARAS/FICHA_MARCO_21KM.md) | material, lesión y prestaciones originales. |
| 21KP | [puertas](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KP_PUERTAS/FICHA_MARCO_21KP.md) | material, lesión y prestaciones originales. |
| 21KV | [ventanas](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KV_VENTANAS/FICHA_MARCO_21KV.md) | material, lesión y prestaciones originales. |
| 21KW | [varios](21_MANTENIMIENTO/21K_CARPINTER%C3%8DA_SEGURIDAD_Y_PROTECCI%C3%93N/21KW_VARIOS/FICHA_MARCO_21KW.md) | material, lesión y prestaciones originales. |
| 21ML | [losas](21_MANTENIMIENTO/21M_CIMENTACIONES/21ML_LOSAS/FICHA_MARCO_21ML.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MP | [pilotes y pantallas](21_MANTENIMIENTO/21M_CIMENTACIONES/21MP_PILOTES_Y_PANTALLAS/FICHA_MARCO_21MP.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MV | [vigas y zunchos](21_MANTENIMIENTO/21M_CIMENTACIONES/21MV_VIGAS_Y_ZUNCHOS/FICHA_MARCO_21MV.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MW | [varios](21_MANTENIMIENTO/21M_CIMENTACIONES/21MW_VARIOS/FICHA_MARCO_21MW.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MX | [auxiliares](21_MANTENIMIENTO/21M_CIMENTACIONES/21MX_AUXILIARES/FICHA_MARCO_21MX.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21MZ | [zapatas](21_MANTENIMIENTO/21M_CIMENTACIONES/21MZ_ZAPATAS/FICHA_MARCO_21MZ.md) | causa del daño, evaluación resistente y sistema de reparación. |
| 21PE | [exteriores](21_MANTENIMIENTO/21P_PINTURAS/21PE_EXTERIORES/FICHA_MARCO_21PE.md) | pintura previa, adherencia y sistema de repintado. |
| 21PI | [interiores](21_MANTENIMIENTO/21P_PINTURAS/21PI_INTERIORES/FICHA_MARCO_21PI.md) | pintura previa, adherencia y sistema de repintado. |
| 21PV | [varios](21_MANTENIMIENTO/21P_PINTURAS/21PV_VARIOS/FICHA_MARCO_21PV.md) | pintura previa, adherencia y sistema de repintado. |
| 21QH | [horizontales](21_MANTENIMIENTO/21Q_CUBIERTAS/21QH_HORIZONTALES/FICHA_MARCO_21QH.md) | composición existente, lesión y prueba de estanqueidad. |
| 21QI | [inclinadas](21_MANTENIMIENTO/21Q_CUBIERTAS/21QI_INCLINADAS/FICHA_MARCO_21QI.md) | composición existente, lesión y prueba de estanqueidad. |
| 21QW | [varios](21_MANTENIMIENTO/21Q_CUBIERTAS/21QW_VARIOS/FICHA_MARCO_21QW.md) | composición existente, lesión y prueba de estanqueidad. |
| 21RP | [peldaños](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RP_PELDA%C3%91OS/FICHA_MARCO_21RP.md) | daño, soporte, alcance y acabado de reposición. |
| 21RS | [suelos](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RS_SUELOS/FICHA_MARCO_21RS.md) | daño, soporte, alcance y acabado de reposición. |
| 21RT | [techos](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RT_TECHOS/FICHA_MARCO_21RT.md) | daño, soporte, alcance y acabado de reposición. |
| 21RV | [paramentos verticales](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RV_PARAMENTOS_VERTICALES/FICHA_MARCO_21RV.md) | daño, soporte, alcance y acabado de reposición. |
| 21RW | [varios](21_MANTENIMIENTO/21R_REVESTIMIENTOS/21RW_VARIOS/FICHA_MARCO_21RW.md) | daño, soporte, alcance y acabado de reposición. |
| 21SC | [redes colgadas](21_MANTENIMIENTO/21S_SANEAMIENTO/21SC_REDES_COLGADAS/FICHA_MARCO_21SC.md) | material, obstrucción o fuga, acceso y prueba final. |
| 21SE | [redes enterradas](21_MANTENIMIENTO/21S_SANEAMIENTO/21SE_REDES_ENTERRADAS/FICHA_MARCO_21SE.md) | material, obstrucción o fuga, acceso y prueba final. |
| 21SV | [redes verticales](21_MANTENIMIENTO/21S_SANEAMIENTO/21SV_REDES_VERTICALES/FICHA_MARCO_21SV.md) | material, obstrucción o fuga, acceso y prueba final. |
| 21SW | [varios](21_MANTENIMIENTO/21S_SANEAMIENTO/21SW_VARIOS/FICHA_MARCO_21SW.md) | material, obstrucción o fuga, acceso y prueba final. |
| 21TL | [limpieza y tratamientos](21_MANTENIMIENTO/21T_TRABAJOS_PREVIOS/21TL_LIMPIEZA_Y_TRATAMIENTOS/FICHA_MARCO_21TL.md) | suciedad, producto, compatibilidad y gestión de efluentes. |
| 21VA | [vidrios aislantes](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VA_VIDRIOS_AISLANTES/FICHA_MARCO_21VA.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21VL | [vidrios laminados](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VL_VIDRIOS_LAMINADOS/FICHA_MARCO_21VL.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21VN | [vidrios sencillos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VN_VIDRIOS_SENCILLOS/FICHA_MARCO_21VN.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21VS | [elaborados sintéticos](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VS_ELABORADOS_SINT%C3%89TICOS/FICHA_MARCO_21VS.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21VT | [vidrios templados](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VT_VIDRIOS_TEMPLADOS/FICHA_MARCO_21VT.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21VW | [varios](21_MANTENIMIENTO/21V_VIDRIER%C3%8DA_Y_ELABORADOS_SINT%C3%89TICOS/21VW_VARIOS/FICHA_MARCO_21VW.md) | vidrio, dimensiones, apoyos y prestaciones originales. |
| 21W | [varios](21_MANTENIMIENTO/21W_VARIOS/FICHA_MARCO_21W.md) | elemento, avería, operación y criterio de recepción. |
| 21XA | [acero](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XA_ACERO/FICHA_MARCO_21XA.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XF | [forjados](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XF_FORJADOS/FICHA_MARCO_21XF.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XH | [hormigón](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XH_HORMIG%C3%93N/FICHA_MARCO_21XH.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XM | [madera](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XM_MADERA/FICHA_MARCO_21XM.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
| 21XW | [varios](21_MANTENIMIENTO/21X_ESTRUCTURAS/21XW_VARIOS/FICHA_MARCO_21XW.md) | sistema resistente, lesión, cálculo y control del refuerzo. |
