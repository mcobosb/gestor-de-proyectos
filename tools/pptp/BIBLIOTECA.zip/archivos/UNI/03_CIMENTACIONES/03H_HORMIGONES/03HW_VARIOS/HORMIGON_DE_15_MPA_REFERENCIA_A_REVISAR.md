# Hormigón de 15 MPa: referencia del original a revisar

**Clasificación:** 03HW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original asocia 15 MPa a cimentación de cerramientos y otros elementos potencialmente estructurales. Esas aplicaciones requieren revisión y no pueden ejecutarse con esta resistencia por remisión al texto.

## Definición

### Criterio de la ficha y complemento técnico

Material de 15 N/mm² mencionado en el original para diversos usos; la relación se conserva como antecedente, no como autorización de uso estructural.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 861–869. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

- Hormigón con una resistencia de 15 N/mm2:
- Aceras de hormigón.
- Soleras reforzadas de aceras.
- Arquetas de tomas de agua.
- Sumideros.
- Rellenos en muretes de bloques.
- Cimentación de cerramientos.
- Macizos de contrarresto.
- Rellenos reforzados.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Antes del suministro, reclasificar cada aplicación por su función. No emplearlo como hormigón estructural en masa, armado o pretensado, al ser inferior a los mínimos del Código Estructural. Para usos realmente no estructurales, definir producto, condiciones y prestaciones en una especificación aprobada; las operaciones de vertido, compactación y curado deben adaptarse a esa solución.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Instrucción para la recepción de cementos RC-16, aprobada por Real Decreto 256/2016.](https://www.boe.es/buscar/doc.php?id=BOE-A-2016-6167)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

No generar una nueva partida por esta ficha. Aplicar el precio de la solución aprobada y tramitar cualquier sustitución contractual por el procedimiento correspondiente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
