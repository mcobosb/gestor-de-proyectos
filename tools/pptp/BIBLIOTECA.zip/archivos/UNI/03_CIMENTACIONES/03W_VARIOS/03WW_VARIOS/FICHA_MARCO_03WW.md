# varios

**Clasificación:** 03WW. **Capítulo:** cimentaciones. **Familia:** varios.

## Definición

Componentes y trabajos de cimentación que transmiten al terreno las acciones de la estructura según el proyecto geotécnico y estructural.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

Antes de incorporarla al pliego se concretarán capacidad y cota de apoyo, dimensiones, acciones, materiales, durabilidad y plan de control. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Replantear y comprobar el terreno de apoyo antes de ocultarlo. Ejecutar con el procedimiento aprobado, controlando agua, estabilidad de excavaciones, posición de armaduras y continuidad del hormigonado cuando proceda. No modificar cotas ni tipologías sin validación del proyectista.

### Condiciones de esta clasificación

Precisar si la subbase es granular, de limpieza u otro sistema; aceptar apoyo, espesor y nivel antes de construir encima.

Para la variante «varios» se comprobarán expresamente material, función y geometría de la capa auxiliar. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Documentar la recepción del fondo, la geometría, los materiales y los puntos de inspección previos al hormigonado o al cierre de la unidad.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

Desglosar por naturaleza: m³ de hormigón según geometría de proyecto, kg de armadura según despiece aprobado, m² de encofrado en contacto y m o ud de elementos profundos definidos. No mezclar sus mediciones ni duplicar componentes incluidos.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
