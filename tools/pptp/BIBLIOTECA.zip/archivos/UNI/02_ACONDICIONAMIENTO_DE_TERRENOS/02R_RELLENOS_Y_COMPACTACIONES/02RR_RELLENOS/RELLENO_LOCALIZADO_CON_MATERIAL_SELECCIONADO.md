# Relleno localizado con material seleccionado

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** 4.9 menciona el 85 % del ensayo Proctor sin precisar su modalidad, frente a otras exigencias del documento. Debe fijarse el criterio de aceptación para la ubicación concreta; no adoptar ese mínimo genérico.

## Definición

### Criterio de la ficha y complemento técnico

Aportación y compactación localizada de material seleccionado procedente de préstamos en zonas de dimensiones reducidas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 425–429. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENO LOCALIZADO
### DEFINICIÓN
Se definen los siguientes rellenos localizados:
- Relleno localizado de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 565–569. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENOS DE TIERRAS
### DEFINICIÓN
Se define como relleno la extensión y compactación de materiales pétreos o terrosos para relleno de zanjas, trasdós de obras de fábrica, o cualquier otra zona cuyas dimensiones no permitan la utilización de los grandes equipos de maquinaria con que se lleva a cabo la ejecución de terraplenes o pedraplenes.
### MATERIALES
Los suelos para rellenos en general serán de los clasificados como adecuados o tolerables en el PG

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar procedencia y características del suelo conforme al proyecto y al PG-3 incorporado. Preparar apoyo y drenaje, extender tongadas compatibles con el equipo ligero, ajustar humedad y verificar densidad. No cargar estructuras ni conducciones antes de su resistencia o autorización.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 570–576. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENOS PARA TRASDOSADO DE OBRAS DE FÁBRICA Y/O MUROS
Los materiales de relleno se extenderán en tongadas sucesivas de espesor uniforme y sensiblemente horizontales. El espesor de estas tongadas será lo suficientemente reducido para que, con los medios disponibles, se obtenga en toda ella el mismo grado de compactación exigido.
Los materiales de cada tongada serán de características uniformes o, si no lo fueran, se conseguirá esta uniformidad mezclándose convenientemente con los medios adecuados.
Una vez extendida la tongada, se procederá a su humectación, si es necesario. El contenido óptimo de humedad se determinará en obra, a la vista de la maquinaria disponible y de los resultados que se obtengan de los ensayos realizados.
En los casos especiales en que la humedad natural del material sea excesiva para conseguir la compactación prevista, se tomarán las medidas adecuadas, procediendo incluso a la desecación por oreo, o por adición y mezcla de materiales secos o sustancias apropiadas.
Conseguida la humectación más conveniente, se procederá a la compactación mecánica de la tongada. El grado de compactación a alcanzar en cada tongada en ningún caso será inferior al mayor del que posean los terrenos o materiales adyacentes, a su mismo nivel y siempre igual o superior al ochenta  y cinco por ciento (85 %) del Ensayo Próctor.
Las zonas que, por su forma, pudieran retener aguas en su superficie, se corregirán inmediatamente por el contratista.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m³ realmente colocados y compactados, con transporte, humectación y compactación incluidos conforme a 3.21.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 430–431. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1137–1139. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENOS
Los rellenos se medirán por metro cúbico (m3) compactado, adaptando los perfiles teóricos de zanja de los planos a los datos del terreno resultante de los replanteos definitivos. El abono se efectuará por aplicación de los precios correspondientes del presupuesto, cualquiera que sea la procedencia de los materiales y la distancia de transporte.
En dicho precio están incluidos todos los materiales, equipo y operaciones necesarias para la completa terminación de la unidad de referencia.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
