# Relleno y compactación de zanjas

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original mezcla 98 % Proctor Modificado, más del 95 % Proctor Modificado y 95 % Proctor Normal, y distintos espesores de tongada. Resolver por zona y servicio antes de ejecutar; no tratarlos como equivalentes.

## Definición

### Criterio de la ficha y complemento técnico

Relleno de la envolvente y del resto de la zanja tras la colocación y aceptación de las tuberías, con materiales compatibles con cada zona.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 565–569. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENOS DE TIERRAS
### DEFINICIÓN
Se define como relleno la extensión y compactación de materiales pétreos o terrosos para relleno de zanjas, trasdós de obras de fábrica, o cualquier otra zona cuyas dimensiones no permitan la utilización de los grandes equipos de maquinaria con que se lleva a cabo la ejecución de terraplenes o pedraplenes.
### MATERIALES
Los suelos para rellenos en general serán de los clasificados como adecuados o tolerables en el PG

## Ejecución en obra

### Criterio de la ficha y complemento técnico

No cubrir sin los controles y autorización previstos. Ejecutar el apoyo y relleno lateral simétrico sin desplazar el tubo; compactar por tongadas con equipos que no lo dañen y ajustar el recubrimiento antes de usar maquinaria pesada. La humedad, el ensayo de referencia y el grado de compactación se fijarán por zona en el procedimiento aprobado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 123–126. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Cuando en los trabajos de excavación aparezcan servicios existentes, los trabajos se ejecutarán con medios adecuados para no dañar la instalación completándose con el colgado o calzado de dichas instalaciones. Todo ello no dará lugar a compensación económica alguna.
El relleno se ejecutará de acuerdo a lo especificado en planos de proyecto, teniendo en cuenta que el material en contacto con la tubería no tendrá áridos con tamaño superior a 2 cm. Si en el presupuesto no se incluye partida especifica para cama o protección de arena, esta se considera incluida en los precios, si el Director de obra considera necesario su colocación.
La compactación de las zanjas se hará con el mismo grado que el exigido a los terraplenes, es decir al 98% del Proctor Modificado.
Previo al relleno de las zanjas será necesaria la aprobación expresa de la Dirección Facultativa. En caso contrario podrá exigirse el descubrimiento de la tubería con cargo al Contratista.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 577–583. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENOS EN ZANJAS PARA TUBERÍAS
En general, se considera de aplicación lo indicado en III.2.2., con un grado de compactación no inferior al (95%) del Próctor Normal, tanto en rellenos ordinarios como seleccionados.
No serán rellenadas las zanjas hasta que se hayan realizado todas las pruebas necesarias sobre la conducción y lo autorice el Director de las obras.
Sin embargo, si, teniendo en cuenta las características de la tubería, existe peligro de flotación en el caso de llenarse las zanjas por fuertes lluvias o por agua freática, deberá efectuarse un relleno parcial de las mismas hasta contrarrestar este peligro, pero teniendo en cuenta de que si al efectuar las pruebas correspondientes no resultasen satisfactorias, todas las maniobras de excavar de nuevo el relleno o su posterior colocación correrán por cuenta del contratista.
Tanto el relleno de arena, como el relleno seleccionado de productos de excavación, se realizarán cuidadosamente por tongadas no mayores de quince (15) centímetros de espesor, las cuales se compactarán con mecanismos adecuados, manuales o mecánicos, hasta que la tubería esté cubierta por un espesor mínimo de treinta (30) centímetros. Se pondrá especial cuidado en la compactación de los flancos del tubo.
La superficie de arena para asiento de la tubería estará perfectamente enrasada con una tolerancia no superior a un (1) centímetro en la longitud del tubo, de forma que permita que éstos se apoyen sin discontinuidad a lo largo de su generatriz inferior, salvo en las zonas de juntas.
En zona de cultivos el relleno superior de tierra vegetal se efectuará con una compactación ligera, dejando una sobre elevación sobre el terreno circundante de unos diez (10) centímetros para que permita el asentamiento natural de aquel.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m³ compactados según la sección teórica aprobada, deduciendo los volúmenes según la partida. Incluir suministro, transporte, humectación y compactación que el precio contemple; no duplicar cama y protección si ya forman parte de la conducción.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 127–130. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
La excavación se abonará por metros cúbicos (m³) y la medición de la excavación se realizará sobre los perfiles teóricos de proyecto, no habiendo lugar al abono de la sobre excavación, quedando incluido dentro del precio el agotamiento y entibación de las mismas, así como el calzado de los servicios existentes.
El precio fijado en el proyecto será independiente de las características geotécnicas del terreno. La medición del relleno de las zanjas se hará de acuerdo a las secciones tipo teóricas definidas en proyecto y el abono se hará por metros cúbicos (m³).
En el precio del relleno se encuentran incluidos la aportación de materiales procedentes de prestamos, incluida su excavación y trasporte, la compactación por tongadas no superiores a 20 cms de espesor obteniendo una densidad superior al 95% de la máxima obtenida en el ensayo Proctor Modificado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1137–1139. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENOS
Los rellenos se medirán por metro cúbico (m3) compactado, adaptando los perfiles teóricos de zanja de los planos a los datos del terreno resultante de los replanteos definitivos. El abono se efectuará por aplicación de los precios correspondientes del presupuesto, cualquiera que sea la procedencia de los materiales y la distancia de transporte.
En dicho precio están incluidos todos los materiales, equipo y operaciones necesarias para la completa terminación de la unidad de referencia.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
