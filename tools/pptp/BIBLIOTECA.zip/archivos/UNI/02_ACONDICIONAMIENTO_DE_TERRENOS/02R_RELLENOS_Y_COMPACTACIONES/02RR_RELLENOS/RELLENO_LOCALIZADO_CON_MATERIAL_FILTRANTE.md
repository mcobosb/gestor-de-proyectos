# Relleno localizado con material filtrante

**Clasificación:** 02RR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original no aporta criterios de filtro; deben establecerse con los suelos y el drenaje proyectados, no mediante una granulometría arbitraria.

## Definición

### Criterio de la ficha y complemento técnico

Relleno granular permeable destinado a permitir drenaje sin arrastre del terreno adyacente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 425–429. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RELLENO LOCALIZADO
### DEFINICIÓN
Se definen los siguientes rellenos localizados:
- Relleno localizado de material seleccionado con material procedente de préstamos.
- Relleno de material filtrante con material procedente de préstamos

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Definir granulometría, permeabilidad y compatibilidad de filtro con el suelo y los drenajes. Recibir material limpio y extender evitando contaminación, segregación y daño de tubos o geotextiles, si están previstos. Compactar con el método aprobado y comprobar continuidad de la evacuación.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m³ colocados según 3.21; suministro, transporte y operaciones incluidos, con geotextil o drenajes separados sólo si el presupuesto lo establece.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 430–431. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) realmente colocados, medidos en el terreno. La humectación y compactación están incluidas en el precio y no hay lugar a su abono independiente, así como el transporte del material desde cualquier distancia.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
