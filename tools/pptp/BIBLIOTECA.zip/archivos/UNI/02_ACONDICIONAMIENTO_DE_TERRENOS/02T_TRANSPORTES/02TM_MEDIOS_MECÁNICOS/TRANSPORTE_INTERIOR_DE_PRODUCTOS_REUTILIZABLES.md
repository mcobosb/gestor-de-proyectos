# Transporte interior de productos reutilizables

**Clasificación:** 02TM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La reutilización debe ser técnicamente apta y legalmente admisible; no se presume por estar el material dentro de la obra.

## Definición

### Criterio de la ficha y complemento técnico

Movimiento dentro de la actuación de productos de excavación o cajeado destinados a reutilización.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1124–1125. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### TRANSPORTE DENTRO DE LA ZONA DE ACTUACIÓN
Se refiere al transporte de aquellos productos que, procedentes de las propias excavaciones o cajeos, sean susceptibles de ser nuevamente utilizados.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar aptitud del material y destino aprobado, separar fracciones y organizar recorridos y acopios seguros evitando contaminación, polvo y vertidos. Mantener trazabilidad de volúmenes y origen para no mezclar material no apto.

### Referencias de aplicación

- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Ley 7/2022, de residuos y suelos contaminados para una economía circular: jerarquía, separación, trazabilidad y gestión autorizada de residuos.](https://www.boe.es/buscar/act.php?id=BOE-A-2022-5809)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El apartado 5.7 declara que no es de abono independiente y lo incluye en excavación, colocación de tubería u otras unidades.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1126–1126. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Este transporte no será de abono, y está incluido dentro de las unidades de excavación, colocación de tubería, etc.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
