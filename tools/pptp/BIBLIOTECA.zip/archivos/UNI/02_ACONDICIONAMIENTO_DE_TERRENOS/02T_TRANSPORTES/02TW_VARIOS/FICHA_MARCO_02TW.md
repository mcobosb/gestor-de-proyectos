# varios

**Clasificación:** 02TW. **Capítulo:** acondicionamiento de terrenos. **Familia:** transportes.

## Definición

Excavación, preparación, sostenimiento, relleno o transporte de terrenos conforme a las secciones y cotas aprobadas.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

Antes de incorporarla al pliego se concretarán geometría, estudio geotécnico, presencia de agua, sostenimiento y criterios de aceptación por zona. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Replantear y levantar perfiles previos; identificar redes, terreno y agua. Ejecutar por fases compatibles con la estabilidad y el drenaje, manteniendo accesos seguros. Separar productos aptos para reutilización y no ocupar ni cargar los bordes sin comprobar su estabilidad.

### Condiciones de esta clasificación

Distinguir producto reutilizable de residuo y registrar origen, destino y recorridos autorizados; acondicionar las rutas internas.

Para la variante «varios» se comprobarán expresamente naturaleza del producto, distancia y criterio de carga y descarga. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Registrar perfiles y cotas, naturaleza del terreno, destino de materiales y, en rellenos, espesor de tongada, humedad y resultados de compactación.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

Según presupuesto, m³ de material de referencia transportado a distancia definida, t acreditadas o t·km con masa y recorrido comprobados. No mezclar volumen en banco y suelto; carga, descarga, tasas y tratamiento sólo se abonarán separadamente si no están incluidos.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
