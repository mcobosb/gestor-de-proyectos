# Terraplenes

**Clasificación:** 02AT. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Verificar la clasificación de los suelos y las exigencias de cada zona del terraplén con el PG-3 incorporado al proyecto.

## Definición

### Criterio de la ficha y complemento técnico

Aportación, extendido, humectación y compactación de suelos procedentes de excavación o préstamos para formar el terraplén.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 48–53. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### TERRAPLENES
### DESCRIPCIÓN
Consiste en la aportación, extendido y compactación de materiales terrosos, procedentes de excavación o préstamos.
Condiciones que han de cumplir los materiales:
- Se utilizarán como núcleos de terraplén los terrenos clasificados en el PG 3 como adecuados.
- Tanto para núcleos de terraplén, como la coronación, así como la explanada en desmontes se exigirá una densidad igual al 98% de la máxima del ensayo Proctor Modificado.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar la procedencia y clasificación de los suelos y preparar el cimiento, escalonando las laderas cuando corresponda. Extender tongadas uniformes compatibles con el equipo y comprobar humedad y densidad antes de colocar la siguiente. Mantener el drenaje y reparar zonas reblandecidas. El texto particular exige el 98 % del Proctor Modificado; no sustituirlo por porcentajes referidos a un ensayo distinto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 54–63. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EJECUCIÓN DE LAS OBRAS
El cimiento del terraplén se preparará de forma adecuada para suprimir discontinuidades efectuando los correspondientes trabajos de refino y compactación.
En zonas con pendiente transversal se escalonará el contacto con el terreno con escalones de ancho superior a 2´5 m, y con pendientes transversales que impidan el deslizamiento del terraplén.
Antes de iniciar el terraplén se procederá a levantar los perfiles transversales, necesarios para la posterior medición.
En zonas con filtraciones se procederá a realizar el drenaje necesario, con el sistema que apruebe la Dirección Facultativa.
Las tongadas serán de espesor uniforme y lo suficientemente reducido en el fin de conseguir, con los medios de compactación disponible, el grado de compactación exigida. El espesor de la tongada habrá de estar comprendida entre 20 y 35 cm.
Durante el extendido se eliminarán las piedras de tamaño superior a la mitad del espesor de la tongada.
No se extenderá ninguna tongada mientras no se haya comprobado que la capa inferior cumple las condiciones exigidas.
En el caso de la capa inferior se haya reblandecido por inundación o por cualquier otra causa, el contratista procederá a escarificarla y dejarla airear, sin derecho a compensación económica alguna.
En caso de ser necesaria la utilización de préstamos será perceptiva la autorización expresa de la Dirección Facultativa, previa al acopio de material.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m³ compactados entre perfiles aprobados, con materiales, agua, extendido, compactación y correcciones incluidos en el alcance descrito.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 64–67. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirán y abonarán por metros cúbicos (m3) realmente ejecutados y compactados a su nivel definitivo, medidas por diferencias entre perfiles tomados antes y después de los trabajos.
Se entenderá que el precio del terraplén comprende la aportación de material procedente de la traza o de préstamos, incluyendo en el precio el canon, las excavaciones y carga en préstamos, el transporte, extendido, humectación, compactación y nivelación del terraplén, la eliminación de filtraciones en la base del terraplén, incluso el refino de los taludes resultantes, y la aportación de tierra vegetal para permitir la plantación en los mismos.
El precio incluye la adquisición, transporte, extendido, humectación y compactación del material, el refino y compactación de la explanada, y todos aquellos materiales y maquinaria necesarios para dejar la obra correctamente terminada, incluso la utilización de medios de compactación especiales para zonas singulares o el extendido a mano.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1119–1123. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### TERRAPLENES Y RELLENOS COMPACTADOS
Se medirán por los metros cúbicos (m³) resultantes de la diferencia entre el perfil natural del terreno, una vez ejecutada la preparación de la base del terraplén, y los correspondientes perfiles de los Planos, para lo que es de valor lo especificado en los Artículos 5.6., sobre comprobación de perfiles.
Los perfiles correspondientes comprenden el coste de todas las operaciones necesarias para formar el terraplén o relleno, cualquiera que sea la procedencia de las tierras.
Incluye la pequeña remoción de la base del terraplén para facilitar la trabazón del mismo con el terreno natural, el agua para humedecer las tierras, el extendido y compactación de las mismas por tongadas de espesor definido por el Director de la obra y todas las operaciones previas de clasificación y acopios de suelos para la formación de terraplenes, así como un acabado de los taludes suave, uniforme, ajustado o lo estipulado en Planos totalmente acorde con la superficie del terreno natural colindante.
Asimismo, el precio incluye los materiales y trabajos adicionales necesarios en la zona de trabajo y la corrección de las irregularidades superiores a las tolerables, así como de los daños ocasionados por bajas temperaturas, paso de tráfico indebido y secuelas de una mala ejecución.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
