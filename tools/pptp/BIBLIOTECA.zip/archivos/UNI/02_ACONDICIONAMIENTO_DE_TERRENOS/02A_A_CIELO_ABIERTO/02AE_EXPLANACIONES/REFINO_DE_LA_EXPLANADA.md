# Refino de la explanada

**Clasificación:** 02AE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La frase sobre refino aparece también al final de 5.8, bajo transporte a vertedero; debe revisarse su ubicación contractual para no duplicar costes.

## Definición

### Criterio de la ficha y complemento técnico

Operaciones de acabado geométrico de la explanada antes de ejecutar el firme.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 584–585. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REFINO DE LA EXPLANADA
Consiste en el conjunto de operaciones necesarias para conseguir el acabado geométrico de la explanada fijado en planos.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Replantear cotas y perfiles, corregir irregularidades mediante escarificado y recrecido compatible, compactar y comprobar rasante, regularidad y ausencia de zonas que retengan agua. No cubrir sin aceptación del soporte y de su capacidad.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 586–592. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Se ejecutará con posterioridad a la explanación y construcción de todos los servicios que discurran por ella, e inmediatamente antes de iniciarse la construcción del firme.
Si hubiese que proceder a un recrecido de espesor inferior a la mitad (1/2) de la tongada compactada, se procederá previamente a un escarificado de todo el espesor de la misma, con objeto de asegurar la trabazón entre el recrecido y su asiento. 
No se extenderá la subbase del firme sin que, antes, se comprueben las condiciones de calidad y características geométricas de la explanada.
En la explanada se dispondrán estacas de refino a lo largo del eje y a ambos bordes de la misma, con una distancia entre perfiles transversales no superiores a veinte metros (20 m) y niveladas hasta milímetros (mm) con arreglo a los Planos. En los recuadros entre estacas, la superficie no rebasará la teórica definida por ellas, ni rebajará de ella más de tres centímetros (3 cm) en ningún punto.
La superficie acabada no deberá variar en más de quince milímetros (15 mm) cuando se compruebe con una regla de tres metros (3 m), aplicada tanto paralela como normalmente al eje de la carretera.
Tampoco podrá haber zonas capaces de retener agua.
Las irregularidades que excedan de dichas tolerancias se corregirán por el Contratista.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original lo incluye en excavaciones y zahorra. No establecer abono separado sin partida específica; si la hubiera, su unidad y geometría de medición deben fijarse en ella.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 43–47. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá por metros cúbicos (m3) realmente excavados medidos por diferencia entre los perfiles tomados antes y después de los trabajos.
Si durante las excavaciones aparecen manantiales o filtraciones motivadas por cualquier causa, los trabajos específicos que sea preciso ejecutar para eliminarlas se considerarán incluidas en los precios de excavación.
En el precio de las excavaciones se encuentra incluido el transporte a cualquier distancia, tanto a terraplén como a vertedero. Para su vertido en terraplén será necesaria la aprobación previa y expresa de la Dirección Facultativa.
Se entiende que el precio de la excavación incluye todos los materiales y operaciones para ejecutar correctamente la unidad.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 78–80. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos medidos sobre perfil teórico de planos una vez compactado.
El precio incluye la adquisición, transporte, extendido, humectación y compactación de la zahorra artificial, el refino y compactación de la explanada, y todos aquellos materiales y maquinaria necesarios para dejar la obra correctamente terminada, incluso la utilización de medios de compactación especiales para zonas singulares o el extendido a mano.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
