# Excavación sin clasificar para cimientos y emplazamientos

**Clasificación:** 02AV. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El terreno, la cota y la solución de cimentación requieren comprobación geotécnica y estructural antes de hormigonar.

## Definición

### Criterio de la ficha y complemento técnico

Excavación hasta las cotas y el terreno de apoyo adecuados para las cimentaciones, sin clasificación económica por tipo de terreno según el original.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 418–422. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EXCAVACIÓN, SIN CLASIFICAR, EN EMPLAZAMIENTO Y CIMIENTOS DE OBRAS
### CLASIFICACIÓN DE LAS EXCAVACIONES
Las excavaciones serán no clasificadas. No se hormigonará ninguna zapata ni cimiento sin que el Ingeniero Director de las obras haya comprobado las características del terreno. Si éstas resultaran inferiores a las necesarias, el Contratista continuará la excavación hasta la profundidad adecuada.
Cuando aparezca agua en las excavaciones se utilizarán los medios necesarios para poder evacuarla e impedir su entrada.
Los correspondientes precios unitarios son aplicables a la excavación en todo tipo de terreno y para cualquier profundidad, incluyendo las entibaciones y agotamientos que fuesen necesarios.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Replantear y excavar con sostenimiento, drenaje y accesos seguros. Mantener el fondo sin alteración y obtener la aprobación del terreno por la dirección antes del hormigonado. Toda profundización necesaria debe documentarse y aprobarse; no decidir la cimentación sólo durante la excavación sin comprobar el cálculo.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m³ según planos y modificaciones aprobadas, con transporte e inclusiones previstas en 3.20 y en su partida. No abonar sobreexcavaciones no autorizadas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 423–424. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) realmente excavados, deducidos de los planos de construcción, quedando incluido en el precio del transporte de los productos a vertedero a cualquier distancia.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1112–1114. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### OBSERVACIONES GENERALES A TODAS LAS EXCAVACIONES
El precio correspondiente a cualquier excavación comprende, salvo que expresamente no se indique otra cosa en el Cuadro de Precios o en este Pliego, todos los trabajos necesarios para realizarla y sacar los productos resultantes, o sea, la excavación, elevación y carga de los productos, transporte a vertedero o lugar de empleo, descarga y, en los casos en que fuese preciso, las entibaciones y agotamientos.
Para realizar los agotamientos el Contratista utilizará los medios e instalaciones adecuadas para agotar el agua y verterla en algún cauce o colector. Cuando estas operaciones den lugar a arrastres del terreno, se evitarán los agotamientos y se adoptarán las medidas que juzgue convenientes el Director de la obra. Serán de cuenta del Contratista incluso los agotamientos que sea preciso realizar durante el plazo de garantía de las obras.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
