# Manguitos electrosoldables para tuberías de PE

**Clasificación:** 15SP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** No confundir los manguitos electrosoldables de PE con otros accesorios «retráctiles» citados en el original; confirmar el sistema concreto.

## Definición

### Criterio de la ficha y complemento técnico

Accesorios de PE con resistencia eléctrica incorporada para realizar uniones estancas por electrofusión.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 214–217. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### UNIONES ELECTROSOLDABLES
Se utilizarán para diámetros en los que el polietileno se suministra en tubos rígidos, para facilitar posibles reparaciones con accesorios convencionales.
Por ser el polietileno un material de rápida evolución, los tipos de P.E. de media densidad, banda azul, etc., que no dispongan todavía de homologación AENOR, precisarán de la aprobación expresa del Servicio de Aguas, y, en general, son a evitar.
La realización de los distintos tipos de soldadura por termofusión, sea manguito retráctil electrosoldable, sea soldadura a tope en canalización, se realizará bajo las especificaciones del fabricante, que deberá ser suministrado tanto de la junta como del generador eléctrico correspondiente, y dicho fabricante deberá asegurar la adecuación del tubo a su procedimiento, en caso de ser de otra procedencia.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Verificar compatibilidad, raspar la zona de fusión, limpiar con el producto y método prescritos, inmovilizar y ejecutar el ciclo con equipo adecuado. Respetar tiempos de enfriamiento, registrar los parámetros y comprobar las uniones en la prueba de la red.

### Referencias de aplicación

- [Real Decreto 3/2023: calidad del agua de consumo; en particular, artículo 44 sobre materiales en contacto con el agua, y condiciones sanitarias de la infraestructura.](https://www.boe.es/buscar/act.php?id=BOE-A-2023-628)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Incluidos en el metro de conducción cuando sean sus uniones normales. Sólo abonables por ud si el presupuesto los define expresamente como pieza independiente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
