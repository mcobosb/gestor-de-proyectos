# Uniones mecánicas y embridadas de conducciones

**Clasificación:** 15SP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Definición

### Criterio de la ficha y complemento técnico

Accesorios de unión de tuberías mediante acoplamientos o bridas compatibles con el material y la presión de servicio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 204–211. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### UNIONES
La unión entre tubos será mediante:
- Accesorios específicos para P.E.
- Uniones universales para tubos rígidos.
- Soldadura a tope por termofusión.
- Manguitos electrosoldables.
La soldadura se considerará inadecuada para acometidas o para ramales de diámetro inferior a 110 mm, para los cuales sólo se admitirán uniones mediante accesorios convencionales en latón estampado, aluminio, fundición dúctil o gris, con las especificaciones contempladas en los apartados correspondientes.
Estas acometidas o ramales de diámetros inferiores se harán exclusivamente en polietileno de baja densidad conforme a las normas UNE53-131 y 53-133.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar diámetros y tolerancias, limpiar superficies y colocar juntas de aptitud sanitaria. Alinear sin forzar, apretar según secuencia y par del fabricante y proteger frente a corrosión. Verificar estanqueidad con la conducción.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 212–217. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### UNIÓN DE TUBOS DE PEAD
Las uniones de los tubos de polietileno de alta densidad se podrán hacer como se ha descrito en el apartado anterior, y también mediante soldadura a tope o accesorios retráctiles electrosoldables, según las especificaciones del fabricante, estando, en principio, indicados todos los accesorios adecuados para el P.E. de baja densidad, en los diámetros en que existan comercialmente, a condición de que la conducción se suministre en tubos rígidos y no por rollos.
### UNIONES ELECTROSOLDABLES
Se utilizarán para diámetros en los que el polietileno se suministra en tubos rígidos, para facilitar posibles reparaciones con accesorios convencionales.
Por ser el polietileno un material de rápida evolución, los tipos de P.E. de media densidad, banda azul, etc., que no dispongan todavía de homologación AENOR, precisarán de la aprobación expresa del Servicio de Aguas, y, en general, son a evitar.
La realización de los distintos tipos de soldadura por termofusión, sea manguito retráctil electrosoldable, sea soldadura a tope en canalización, se realizará bajo las especificaciones del fabricante, que deberá ser suministrado tanto de la junta como del generador eléctrico correspondiente, y dicho fabricante deberá asegurar la adecuación del tubo a su procedimiento, en caso de ser de otra procedencia.

### Referencias de aplicación

- [Real Decreto 3/2023: calidad del agua de consumo; en particular, artículo 44 sobre materiales en contacto con el agua, y condiciones sanitarias de la infraestructura.](https://www.boe.es/buscar/act.php?id=BOE-A-2023-628)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Las juntas y uniones ordinarias están incluidas en el metro de tubería según 3.16.7. No abonarlas de nuevo como pieza especial salvo exclusión y partida expresas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
