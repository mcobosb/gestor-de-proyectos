# Piezas en T y derivaciones de abastecimiento

**Clasificación:** 15SP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Definición

### Criterio de la ficha y complemento técnico

Accesorios que permiten derivar el caudal hacia otro ramal.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 266–267. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

EJECUCIÓN DE TOPES EN LAS CURVAS, CONOS Y DERIVACIONES
Las curvas, conos y tés se anclarán por el lado por donde se dirige la resultante de las fuerzas de presión internas.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar diámetros, presión, aptitud sanitaria y compatibilidad de uniones. Instalar según el replanteo, disponer el anclaje o sistema resistente a tracción calculado y comprobar estanqueidad con la red.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 268–270. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Se excavará hasta llegar a terreno consistente, se hará un encofrado no englobando las uniones y tornillos de las bridas, y se rellenará de hormigón en masa.
Las dimensiones de los topes serán las que fija la “Normativa para Redes de Distribución de Agua Potable” de la Asociación Española de Abastecimiento y Saneamiento.
De no resultar posible la construcción de un tope de las medidas que figuren en la norma, se construirá según las instrucciones del facultativo responsable del servicio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 954–959. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### CURVAS DE GRAN RADIO
Los cambios de alineación o rasante de gran radio, deberán realizarse con tubos rectos o de acuerdo con lo indicado en los planos del proyecto.
### BLOQUES DE EMPUJE
Se colocarán bloques de empuje en todos los codos o cambios de dirección bruscos de la tubería, aún cuando éstos no estuviesen específicamente señalados en los planos. Las dimensiones y peso serán las adecuadas en función de la velocidad y altura de presión de cada tramo de tubería.
Estos bloques de empuje, deberán construirse una vez montados los tubos y las piezas especiales, fundiendo el hormigón entre las zanjas y la parte lateral e inferior de los mismos.
En ningún caso, el hormigón deberá interferir en las juntas de las piezas, perturbando su posible reparación.

### Referencias de aplicación

- [Real Decreto 3/2023: calidad del agua de consumo; en particular, artículo 44 sobre materiales en contacto con el agua, y condiciones sanitarias de la infraestructura.](https://www.boe.es/buscar/act.php?id=BOE-A-2023-628)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por ud de pieza en T o derivación instalada conforme a 3.16.7 y al presupuesto, sin duplicar los accesorios incluidos en acometidas completas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
