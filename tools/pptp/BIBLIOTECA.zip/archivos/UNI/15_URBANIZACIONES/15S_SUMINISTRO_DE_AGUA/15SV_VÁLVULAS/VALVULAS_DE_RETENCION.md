# Válvulas de retención

**Clasificación:** 15SV. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La selección de tipo y la limitación de velocidad del original no sustituyen el estudio de golpes de ariete ni permiten adoptar un modelo comercial sin comprobarlo.

## Definición

### Criterio de la ficha y complemento técnico

Elementos que impiden el flujo inverso en la conducción, del tipo que resulte compatible con el cálculo hidráulico.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 236–244. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Serán del tipo disco partido tipo “Rubber Check” o bien de obturador de muelle axial a la conducción y baja inercia del tipo “Clasar”, o bien del tipo de globo “Williams-Hager”.
Las válvulas del tipo clapeta son a evitar, por la gran inercia de su obturador, causante de golpes de ariete secundarios.
La instalación de válvulas de disco partido se realizará previa comprobación mediante cálculo hidráulico de no sobrepasar 1,5 m/s de velocidad de paso del agua, y se instalarán alejadas de codos, tés y volvería que puedan causar su deterioro. El eje de giro de las válvulas de disco se situará en el mismo plano que el plano de giro del codo o té más próximo situado aguas arriba, salvo que está separado de estos elementos perturbadores del flujo en una distancia superior a 10 diámetros, en cuyo caso el montaje queda liberado de esta condición.
El cuerpo será de fundición nodular o fundición gris para presión nominal hasta 25 Kg/cm², y de acero fundido o inoxidable para presiones superiores y los ejes, muelles y tornillería será exclusivamente de acero inoxidable.
La unión de los tubos se realizará entre accesorios provistos de pletinas (montaje tipo Wafer), o mediante bridas ISO PN 16.
El cierre siempre será estanco mediante elastómetro EPDM, nitrilo o bien mediante contacto de anillos de bronce.
Arquetas de registro y acceso
Se emplean para la colocación visitable de toda clase de accesorios de las conducciones tales como ventosas, válvulas, etc.
Coronarán arquetas realizadas en fábrica de ladrillo macizo dispuesto a tizón, de forma cuadrada o redonda, y que estarán enfoscadas de mortero de cemento interiormente. Las tapas serán de fundición dúctil, de buena calidad y con robustez suficiente para no romperse con los golpes o las cargas del tráfico.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Verificar respuesta frente a transitorios, sentido de flujo y orientación de montaje, y respetar los tramos rectos y condiciones del fabricante. Apoyar la válvula sin esfuerzos de la tubería y dejar acceso de mantenimiento. Comprobar funcionamiento y estanqueidad.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 271–290. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

ARQUETAS PARA VALVULERÍA.
Este apartado se refiere a elementos como válvulas de retención, reguladoras de presión o de caudal, ventosas y demás elementos de valvulería con excepción de las válvulas de corte, que se dispondrán enterradas, de preferencias, hasta un diámetro de 300 mm y se dispondrán en arquetas para mariposas de mayores diámetros, del modo que se determina a continuación.
INSTALACIÓN
Se efectuará de forma que sea posible desmontar la válvula sin necesidad de cortar la tubería.
ALOJAMIENTO
Todas las válvulas se ubicarán en una arqueta que será suficiente para permitir, sin necesidad se romperla, el cambio de la válvula existente por otra de iguales características.
En caso de que sea necesario, por estar la tubería demasiado profunda, bajar al interior de la cámara, se dotará a ésta de una entrada, de un diámetro no inferior a 60 cm, y una escalera adosada a la pared, provista de pates metálicos forrados de polipropileno. En la instalación de válvulas mariposa la arqueta tendrá una abertura que permita la extracción del desmultiplicador.
La tapa de la arqueta no sobresaldrá de la rasante de la calle y llevará impreso “Abastecimiento de Agua” o “Agua Potable”. Estarán provistas de taladros para facilitar el levantamiento. Serán de fundición y deberán ser capaces de resistir las cargas móviles reguladas en la norma UNE 82-211-83.
Se prohíben expresamente los pates conformados con acero para la construcción, debiendo ser pates fabricados específicamente como tales, en material inoxidable, de acero forrado de polipropileno o similares.
La cámara que deba construirse en calzada tendrá las siguientes características: 
- Solera: de 15 cm de espesor de hormigón de resistencia característica de 100 Kg/cm².
- Muros: De hormigón de resistencia característica de 250 Kg/cm² y 20 cm de espesor, a los que se dispondrá de armadura de reparto según las cuantías mínimas definidas en el CODIGO ESTRUCTURAL.
- Acabado: Enfoscado sin maestrear de paredes con mortero 1:3 de 15 mm de espesor con  acabado bruñido. Ángulos redondeados.
Las paredes de la arqueta no se apoyarán en ningún caso sobre las tuberías, haciéndose pasamuros.
INSTALACIÓN DE TUBERÍA
Se procurará instalar la tubería en viales públicos y bajo la acera de acuerdo con las recomendaciones del fabricante. Antes de su colocación se inspeccionarán los tubos interior y exteriormente para evitar suciedad, adherencias, etc. En el interior y grietas, defectos de protección, etc., en el exterior.
La tubería no se apoyará sobre el fondo de la zanja sino que se colocará una capa de arena fina o gravilla, de unos 10 cm de espesor, para asegurar el perfecto asiento de la tubería se efectuará con los medios mecánicos adecuados.
Una vez en la zanja cada tubo deberá alinearse perfectamente con los ya colocados sin forzar los tubos, excepto en los tubos de polietileno en los que se efectuará un serpenteo dentro de la zanja para prevenir los efectos de la dilatación.
Las uniones en su caso, los cambios de dirección o sección y las derivaciones se realizarán con los correspondientes accesorios o piezas especiales. En los cambios de dirección las alineaciones rectas serán tangentes a las piezas empleadas.
En caso de instalación de tuberías con pendientes superiores al 20% de la tubería se colocará en sentido ascendente o se emplearán juntas resistentes a la tracción.

### Referencias de aplicación

- [Real Decreto 3/2023: calidad del agua de consumo; en particular, artículo 44 sobre materiales en contacto con el agua, y condiciones sanitarias de la infraestructura.](https://www.boe.es/buscar/act.php?id=BOE-A-2023-628)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en ud instalada, conectada y probada conforme a la partida correspondiente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
