# Hidrantes contra incendios

**Clasificación:** 15SH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original no fija tipo, caudal ni presión disponible; deben comprobarse con el cálculo y la reglamentación de incendios aplicable.

## Definición

### Criterio de la ficha y complemento técnico

Puntos de suministro de agua para extinción conectados a la red, definidos por el proyecto y las condiciones de protección contra incendios aplicables.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 319–320. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

HIDRANTES
Deberán estar normalizados y cumplirán con las prescripciones del Servicio Municipal de Bomberos.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Seleccionar el tipo y prestaciones conforme al RIPCI dentro de su ámbito y coordinar con el servicio de bomberos. Instalar con accesibilidad, protección, aislamiento y anclaje adecuados, mantener su señalización y realizar las comprobaciones hidráulicas y funcionales exigibles antes de la recepción.

### Referencias de aplicación

- [Reglamento de instalaciones de protección contra incendios, Real Decreto 513/2017: requisitos de los hidrantes y de su instalación dentro de su ámbito.](https://www.boe.es/buscar/act.php?id=BOE-A-2017-6606)
- [Real Decreto 3/2023: calidad del agua de consumo; en particular, artículo 44 sobre materiales en contacto con el agua, y condiciones sanitarias de la infraestructura.](https://www.boe.es/buscar/act.php?id=BOE-A-2023-628)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en ud independiente instalada y probada según 3.16.7 y el alcance de la partida.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
