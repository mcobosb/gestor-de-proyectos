# Bordillos prefabricados de hormigón

**Clasificación:** 15PB. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** 3.15 exige HM-20 y 4.17.3 cita H-150 para el asiento. Aclarar la partida y el hormigón aprobado; no asumir equivalencia de estas designaciones.

## Definición

### Criterio de la ficha y complemento técnico

Piezas prefabricadas que delimitan calzadas, aceras y otras superficies, recibidas sobre una base de hormigón.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 179–187. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### BORDILLOS
### DESCRIPCIÓN
Son piezas o elementos prefabricados que asentados sobre la subbase granular mediante un lecho de hormigón con el cual son solidarios sirven para reparar la calzada de las aceras.
Condiciones que han de cumplir los materiales.
El hormigón de asiento será HM 20 con 200 Kg/cm² de resistencia característica.
Los bordillos habrán de cumplir que su resistencia a la compresión en probeta cúbica cortada con sierra circular a los 28 días debe ser como mínimo de 350 Kg/ cm².
Los bordillos deberán ser aceptados previamente por la Dirección de obra, debiendo tener doble capa de terminación.
Se rechazarán en acopio bordillos que presenten defectos, aunque sean debidos al transporte.
No se podrán recepcionar bordillos con tolerancias dimensionales de más de un centímetro, en cualquier caso.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Recepcionar piezas con geometría, acabado y prestaciones adecuados, comprobar su norma de producto aplicable, habitualmente UNE-EN 1340, y rechazar las dañadas. Replantear alineación y rasante, ejecutar base y refuerzo lateral, colocar piezas y juntas y proteger hasta su estabilidad. Mantener transiciones accesibles y drenaje.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1002–1010. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### BORDILLOS
EJECUCIÓN DE LAS OBRAS
Se recibirán sobre solera de hormigón H 150, abrigándolos a ambas caras con el mismo material. Las juntas entre piezas se ejecutarán con mortero de cemento y, según la utilización serán de dos tipos:
- Bordillos tipo A 1: La junta será de 2 cm., y se terminará resaltada abrigando las cabezas de los bordillos 1 cm., a cada lado de la misma.
- Bordillos tipo E 3, E 5: La junta será de 1 cm., y se terminará rehundida.
Compresión, absorción y resistencia a flexión. El material que compone cada partida deberá ser homogéneo y de mismo fabricante, con condiciones según albarán ajustadas a las de proyecto.
CONTROL DE LA EJECUCIÓN
Se verificarán la correcta alineación, el ajuste a rasante y la correcta ejecución de las soleras de apoyo y juntas.
La tolerancia en rasante será de 3 mm., al comprobar con regla de 3 m., y en alineación las diferencias en cualquier punto no serán superiores a 1 cm.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m colocados y aceptados. Incluye base de hormigón y mortero de juntas conforme a 3.15.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 188–189. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirán y abonarán por ml colocado realmente, quedando incluidos en este precio tanto el hormigón de base dispuesto según planos como el mortero necesario para el rejuntado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1162–1165. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### PAVIMENTOS
Se incluyen en este concepto tanto bordillos en delimitación de zonas de tráfico rodado a peatonal, como los materiales de pavimentación de zonas peatonales.
### BORDILLOS
Se medirán y abonarán por metro lineal (m), colocado perfectamente según las indicaciones del presente Pliego y de los planos.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
