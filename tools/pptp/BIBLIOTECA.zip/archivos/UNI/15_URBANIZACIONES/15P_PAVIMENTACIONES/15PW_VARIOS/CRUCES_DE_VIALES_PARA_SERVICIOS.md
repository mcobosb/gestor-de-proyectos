# Cruces de viales para servicios

**Clasificación:** 15PW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** No trasladar a todos los servicios el detalle de protección de una red concreta; aprobar el correspondiente a cada cruce.

## Definición

### Criterio de la ficha y complemento técnico

Canalizaciones transversales que permiten el paso de servicios bajo el viario.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 171–173. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### CRUCES VIALES
### DESCRIPCIÓN
Son las canalizaciones transversales que permiten los cruces de viales de todos los servicios. Se ejecutarán simultáneamente a la construcción de acometidas de alcantarillado.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Coordinar servicios y ejecutar antes de las capas de firme. Verificar recubrimiento, resistencia del conjunto y protecciones según las cargas y el titular de cada red. Mantener separaciones y reservas previstas y documentar cotas y ubicación antes del relleno.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 174–175. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EJECUCIÓN DE LAS OBRAS
Se ha de realizar su ejecución previa a la realización de la base granular, de esta manera se evitará la contaminación de la subbase.

### Referencias de aplicación

- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m dentro de la conducción correspondiente salvo partida específica. El original incluye su protección en la tubería si el presupuesto no dispone lo contrario.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 176–178. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Salvo la indicación en contrario, los cruces de viales se medirán por ml realmente ejecutados y dentro de la unidad de conducción a que pertenezcan.
Se considera, salvo indicación en contrario del presupuesto, que la protección de la tubería en el cruce se encuentra incluida en el precio de la tubería.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
