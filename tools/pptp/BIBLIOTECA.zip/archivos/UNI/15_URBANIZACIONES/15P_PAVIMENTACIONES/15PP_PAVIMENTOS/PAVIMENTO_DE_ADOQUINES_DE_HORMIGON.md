# Pavimento de adoquines de hormigón

**Clasificación:** 15PP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El intervalo de pendiente transversal del 1,5–3 % del original debe limitarse al máximo del 2 % en itinerarios peatonales accesibles conforme a TMA/851/2021.

## Definición

### Criterio de la ficha y complemento técnico

Pavimento de piezas de hormigón colocadas sobre cama de asiento con juntas y confinamiento lateral.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 991–991. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ADOQUINES Y SOLERÍA DE HORMIGÓN

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar producto y prestaciones según su uso y norma aplicable, habitualmente UNE-EN 1338 para adoquines. Preparar base y cama uniformes, colocar según aparejo, cortar piezas sin generar elementos inestables y rellenar juntas. Compactar con equipo compatible y reponer material de juntas. Respetar accesibilidad y pendientes reglamentarias del itinerario.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 992–1001. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Se colocarán sobre una cama de grava o mortero debidamente nivelada.
Tras la extensión, nivelación y compactación de la capa base tierra de aportación, a la cota de rasante necesaria para que el pavimento terminado se adapte a la arista superior del bordillo colocado y con una pendiente transversal comprendida entre el uno y medio y el tres por ciento (1,5 3%), se procederá a la extensión de la capa de asiento (arena ó mortero) y a su nivelación mediante una barra de longitud igual al ancho de la acera.
El dibujo en la colocación del adoquín será definido en los planos de proyecto o directamente en la obra por la dirección, y siempre de tal forma que se evite el excesivo corte de piezas. Se evitará, asimismo, el empleo de tamaños menores de la mitad de la dimensión de los adoquines.
En el caso de pavimentado alrededor de pozos de registro se procurará la disposición de adoquines con su dimensión mayor, radial al centro de los pozos en una o dos hileras de adoquines.
Tras la disposición de los adoquines se procederá al relleno de juntas con aportación de arena sobre la totalidad del pavimento, y al taqueado de los adoquines cubiertos mediante un compresor vibrador o manualmente con pisones de madera.
Se cubrirá de nuevo el pavimento con arena, tras el taqueado, y se dejará un tiempo procediendo después al barrido de la superficie para facilitar el rellano de las juntas de adoquines.
Este proceso se repetirá tantas veces como estime necesario la Dirección de obra, hasta que considere debidamente selladas las juntas y asentado el adoquín.
En caso de emplear agua para el relleno de juntas, está se aplicará en forma de lluvia para evitar el lavado de la arena.
Salvo en casos especiales, se evitará el rejuntado de piezas con mortero de cemento.
Estos casos serán debidamente consultados con la Dirección de obra, y siempre a dicho mortero le será añadido el colorante necesario para conseguir la coloración análoga a la de los adoquines que une.

### Referencias de aplicación

- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m² realmente ejecutados según 5.18.3, con el alcance de bases y cama que establezca la partida.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1168–1169. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ADOQUINADO
Se medirá y abonará por metros cuadrados (m2) realmente ejecutados tal y como se marca en planos y en el Presente Pliego.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
