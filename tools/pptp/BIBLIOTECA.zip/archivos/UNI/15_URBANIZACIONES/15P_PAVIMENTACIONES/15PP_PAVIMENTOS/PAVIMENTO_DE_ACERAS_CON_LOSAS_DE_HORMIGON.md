# Pavimento de aceras con losas de hormigón

**Clasificación:** 15PP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** 3.19 describe losas pero en el abono habla de adoquines. 4.17.2 admite pendientes de hasta el 3 %, incompatibles con el límite transversal del itinerario peatonal accesible. Precisar producto y sección sin trasladar ese 3 %.

## Definición

### Criterio de la ficha y complemento técnico

Pavimento peatonal con losas de hormigón de 40 × 20 × 8 cm sin bisel, sobre cama granular y losa de apoyo según 3.19.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 409–411. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### PAVIMENTO DE ACERAS
### CONDICIONES QUE DEBEN CUMPLIR LOS MATERIALES
Se utilizarán losas de hormigón 40x20x8 cm sin bisel que irán dispuestas con una capa de arrocillo de 3-4 cm sobre losa de hormigón.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar soporte, compactación y cotas, disponer base y cama uniformes y colocar las losas sin cejas ni balanceos, con juntas y confinamiento adecuados. Comprobar prestaciones de las piezas, habitualmente según UNE-EN 1339 para baldosas cuando corresponda. En itinerario accesible, garantizar pavimento estable y no deslizante y pendiente transversal máxima del 2 % conforme a la Orden TMA/851/2021.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 412–414. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EJECUCIÓN DE LAS OBRAS
El relleno de las aceras, desde la capa de subbase se realizará mediante suelo seleccionado compactado al 95% del Proctor Modificado.
El dibujo y color serán elegidos serán los indicados en planos y memoria, o en su defecto el indicado por la Dirección Facultativa, con visto bueno del Ayuntamiento, no justificando alteraciones de precio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 991–1001. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ADOQUINES Y SOLERÍA DE HORMIGÓN
Se colocarán sobre una cama de grava o mortero debidamente nivelada.
Tras la extensión, nivelación y compactación de la capa base tierra de aportación, a la cota de rasante necesaria para que el pavimento terminado se adapte a la arista superior del bordillo colocado y con una pendiente transversal comprendida entre el uno y medio y el tres por ciento (1,5 3%), se procederá a la extensión de la capa de asiento (arena ó mortero) y a su nivelación mediante una barra de longitud igual al ancho de la acera.
El dibujo en la colocación del adoquín será definido en los planos de proyecto o directamente en la obra por la dirección, y siempre de tal forma que se evite el excesivo corte de piezas. Se evitará, asimismo, el empleo de tamaños menores de la mitad de la dimensión de los adoquines.
En el caso de pavimentado alrededor de pozos de registro se procurará la disposición de adoquines con su dimensión mayor, radial al centro de los pozos en una o dos hileras de adoquines.
Tras la disposición de los adoquines se procederá al relleno de juntas con aportación de arena sobre la totalidad del pavimento, y al taqueado de los adoquines cubiertos mediante un compresor vibrador o manualmente con pisones de madera.
Se cubrirá de nuevo el pavimento con arena, tras el taqueado, y se dejará un tiempo procediendo después al barrido de la superficie para facilitar el rellano de las juntas de adoquines.
Este proceso se repetirá tantas veces como estime necesario la Dirección de obra, hasta que considere debidamente selladas las juntas y asentado el adoquín.
En caso de emplear agua para el relleno de juntas, está se aplicará en forma de lluvia para evitar el lavado de la arena.
Salvo en casos especiales, se evitará el rejuntado de piezas con mortero de cemento.
Estos casos serán debidamente consultados con la Dirección de obra, y siempre a dicho mortero le será añadido el colorante necesario para conseguir la coloración análoga a la de los adoquines que une.

### Referencias de aplicación

- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m² ejecutados con relleno, preparación, piezas, compactación y operaciones incluidas en 3.19, sin duplicar bases medidas aparte.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 415–417. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cuadrados ejecutados.
El precio incluye el relleno, nivelación y compactación de la capa de suelo, los encofrados necesarios para huecos de alcorques, bordes, etc. El suministro y puesta en obra de los adoquines, la compactación de los mismos, así como los materiales, maquinaria y operaciones necesarias para acabar correctamente la unidad.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
