# Pavimento de hormigón impreso

**Clasificación:** 15PP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La remisión a EH-91 es obsoleta. El soporte, espesor, armadura y recubrimientos requieren diseño; el acabado o sellado no debe reducir la resistencia al deslizamiento exigida.

## Definición

### Criterio de la ficha y complemento técnico

Pavimento continuo de hormigón con acabado estampado, colorante y tratamiento superficial.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 973–974. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### PAVIMENTOS
### HORMIGÓN IMPRESO

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Dimensionar losa, soporte y juntas y comprobar cotas y pendientes. Extender y compactar el hormigón conforme a la normativa aplicable, incorporar los productos compatibles en el momento prescrito y estampar sin comprometer el curado. Ejecutar juntas, limpiar y sellar con el sistema aprobado, comprobando deslizamiento y accesibilidad en uso peatonal.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 975–990. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Operaciones preparatorias:
    1. Preparación del terreno.
    2. Compactación del terreno al 100% PROCTOR NORMAL.
    3. Saneamiento y preparación de la base en caso de recrecidos.
    4. Cálculo y dimensionamiento de la losa indicado por la Dirección Facultativa.
    5. Descripción y situación de las juntas de dilatación y retracción proyectadas por la Dirección de la obra.
    6. Estar colocados los bordillos o en su caso encofrados perimetrales.
Ejecución:
    1. Colación y extendido del hormigón según lo dispuesto por la EH 91.
    2. Nivelado y fratasado manual del hormigón.
    3. Suministro y aplicación manual del producto colorante.
    4. Suministro y aplicación manual del producto desencofrante y de curado.
    5. Estampado del hormigón con el molde elegido, esta operación se realiza mientras el hormigón siga en el estado de fraguado plástico.
    6. Corte de juntas de dilatación y retracción.
    7. Una vez endurecido el hormigón, se procede a la limpieza con agua a presión de toda la superficie.
    8. Suministro y aplicación del componente de sellado.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m² realmente ejecutados conforme a 5.18.2 y a la sección completa definida en su precio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1166–1167. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### HORMIGÓN IMPRESO
Se medirá y abonará por metros cuadrados (m2) realmente ejecutados tal y como se marca en planos y en el Presente Pliego.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
