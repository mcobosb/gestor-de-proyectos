# Mezcla bituminosa AC22 BIN D

**Clasificación:** 15PC. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original llama «capa base» a la AC22 BIN D al describir la capa intermedia. Además, 4.12 tiene tablas ausentes y frases truncadas; deben sustituirse como criterio de control por el artículo 542 aplicable y la fórmula aprobada.

## Definición

### Criterio de la ficha y complemento técnico

Mezcla bituminosa densa para capa intermedia, designada AC22 BIN D en el documento, con betún 50/70.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 81–92. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEZCLA BITUMINOSA
### DEFINICIÓN
Se define como mezcla bituminosa la combinación de un betún asfáltico, áridos con granulometría continua, polvo mineral y, eventualmente, aditivos, de manera que todas las partículas del árido queden recubiertas por una película homogénea de ligante, cuyo proceso de fabricación y puesta en obra deben realizarse a una temperatura muy superior a la del ambiente.
Se utilizarán la tipo AC32 BASE G, capa base de granulometría gruesa y con tamaño máximo de árido de 32mm; como capa intermedia la tipo AC22 BIN D, capa base de granulometría densa y con tamaño máximo de árido de 22mm y la AC16 SURF S, capa de rodadura semidensa y con tamaño máximo de árido de 16mm.
Condiciones que han de cumplir los materiales.
- Ligante hidrocarbonado. El ligante hidrocarbonado a emplear en la mezcla será betún asfáltico, tipo 50/70. El contenido de ligante en la mezcla será del 4,9 5%.
- Árido grueso. Deberá ser de machaqueo y trituración de piedra de cantera ofítica; se compondrá de elementos limpios, sólidos y resistentes, de uniformidad razonable, exentos de polvo, suciedad, arcilla u otras materias extrañas.
- El coeficiente de desgaste medido por el ensayo de Los Ángeles será inferior o igual a 25. Para una correcta adhesividad, la pérdida de resistencia en el ensayo de inmersión-compresión no rebasará el 25%.
- El índice de lajas será inferior o igual a 30.
- Queda totalmente prohibido el empleo de árido grueso procedente de escombreras.
- Árido fino. Deberá proceder de la trituración de piedra de cantera o grava natural en su totalidad.
- Filler. Procederá de machaqueo de los áridos o será de aportación como producto comercial. La densidad aparente del filler, determinada por el ensayo de sedimentación en tolueno estará comprendida entre 0,5 0,8g/cm3.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar su fórmula de trabajo específica conforme al artículo 542 del PG-3 y no reutilizar sin verificación la de otra capa. Recibir componentes, fabricar y transportar sin segregación, extender sobre soporte y riego aceptados y compactar según el tramo de prueba. Verificar espesor, densidad y adherencia entre capas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 93–98. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

- El coeficiente de emulsibilidad será inferior a 0,6.
- La relación entre polvo mineral y ligante será 1,2.
- Equipo necesario para la ejecución de las obras. El equipo necesario para la ejecución de las obras deberá ser aprobado por el Ingeniero Director y habrá de mantenerse, en todo momento, en condiciones de trabajar satisfactorias. En cualquier caso, deberá reunir las condiciones precisas para garantizar que las mezclas puestas en obras posean las características impuestas en el Pliego de Prescripciones Técnicas.
- Extensión de la mezcla. La entendedora se regulará de forma que la superficie de la capa extendida quede lisa y con espesor tal que, una vez compactada, se ajuste a la sección transversal indicada en los planos. Cuando sea posible, se realizará la extensión en todo el ancho a pavimentar, si esto no es posible se hará por franjas de forma que la zona de compactación incluya quince centímetros de la primera franja.
Donde no resulte factible, la mezcla podrá extenderse a mano.
Si en la puesta en obra de las mezclas se utilizará compactador de neumáticos en cabeza, deberá estar dotados de equipo de calentamiento y llevar protegidas las ruedas para evitar enfriamientos. La compactación será terminada con apisonadora

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 597–701. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEZCLAS BITUMINOSAS
Cuando sea necesario aplicar un tratamiento antiadherente sobre los equipos de fabricación, transporte, extendido o compactación, éste consistirá en general en una solución jabonosa, un agente tensoactivo u otros productos sancionados por la experiencia, que garanticen que no son perjudiciales para la mezcla bituminosa, ni para el medioambiente, debiendo ser aprobados por el Director de las Obras. No se permitirá en ningún caso el empleo de productos derivados de la destilación del petróleo.
### CENTRAL DE FABRICACIÓN
Las mezclas bituminosas se fabricarán por medio de centrales capaces de manejar simultáneamente en frío el número de fracciones del árido que exija la fórmula de trabajo adoptada.
En centrales de mezcla continua con tambor secador mezclador, el sistema de dosificación será ponderal, al menos para la arena y para el conjunto de los áridos, y tendrá en cuenta la humedad de éstos, para corregir la dosificación en función de ella.
La central tendrá sistemas separados de almacenamiento y dosificación del polvo mineral recuperado y de aportación, los cuales serán independientes de los correspondientes al resto de los áridos, y estarán protegidos de la humedad. Las centrales cuyo secador no sea a la vez mezclador estarán provistas de un sistema de clasificación de los áridos en caliente (de capacidad acorde con su producción) en un número de fracciones no inferior a tres (3), y de silos para almacenarlos.
Las centrales de mezcla discontinua estarán provistas en cualquier circunstancia de dosificadores ponderales independientes: al menos uno (1) para los áridos calientes, cuya precisión sea superior al cinco (1) para el ligante hidrocarbonado, cuya previera la incorporación de aditivos a la mezcla, la central deberá poder dosificarlos con homogeneidad y precisión suficiente, a juicio del Director de las Obras. Si la central estuviera dotada de tolvas de almacenamiento de las mezclas fabricadas, deberá garantizar que en las cuarenta y ocho horas (48 h) siguientes a la fabricación, el material acopiado no ha perdido ninguna de sus características, en especial la homogeneidad del conjunto y las propiedades del ligante. Cuando se vayan a emplear áridos procedentes del fresado o trituración de capas de mezclas bituminosas en proporciones superiores al quince por ciento (> 15 %) de la masa total de la mezcla, la central de fabricación dispondrá de los elementos necesarios para que se cumplan los requisitos y especificaciones recogidas en el epígrafe 542.5.4. La central de fabricación (de funcionamiento continuo o discontinuo) dispondrá de, al menos, dos tolvas adicionales para el material bituminoso a reciclar tratado, y será capaz de incorporarlo durante el proceso de mezcla sin afección negativa a los materiales constituyentes, en especial, al ligante bituminoso de aportación.
### ELEMENTOS DE TRANSPORTE
La mezcla bituminosa se transportará al lugar de empleo en camiones de caja abierta, lisa y estanca, perfectamente limpia, y que se tratará, para evitar que la mezcla se adhiera a ella. Dichos camiones deberán estar siempre provistos de una lona o cobertor adecuado para proteger la mezcla bituminosa durante su transporte.
La forma y altura de la caja de los camiones deberá ser tal que, durante el vertido en la extendedora, cuando éstas no dispongan de elementos de transferencia de carga, el camión sólo toque a aquélla a través de los rodillos previstos al efecto.
Los medios de transporte deberán estar adaptados, en todo momento, al ritmo de ejecución de la obra teniendo en cuenta la capacidad de producción de la central de fabricación y del equipo de extensión y la distancia entre ésta y la zona de extensión.
### EQUIPO DE EXTENSIÓN
Las extendedoras serán autopropulsadas, y estarán dotadas de los dispositivos necesarios para la puesta en obra de la mezcla bituminosa con la geometría y producción deseadas, y un mínimo de precompactación que será fijado por el Director de las Obras. La capacidad de sus elementos, así como la potencia, serán adecuadas para el tipo de trabajo que deban desarrollar.
La extendedora deberá estar dotada de un dispositivo automático de nivelación y de un elemento calefactor para la ejecución de la junta longitudinal cuando sea precisa.
Se comprobará, en su caso, que los ajustes del enrasador y de la maestra se atienen a las tolerancias mecánicas especificadas por el fabricante, y que dichos ajustes no han sido afectados por el desgaste u otras causas. Para las categorías de tráfico pesado T00 a T2 o con superficies a extender en calzada superiores a setenta mil metros cuadrados (> 70 000 m2), será preceptivo disponer delante de la extendedora un equipo de transferencia autopropulsado, que esencialmente colabore a garantizar la homogeneización granulométrica y permita, además, la uniformidad térmica y de las características superficiales.
La anchura mínima y máxima de extensión se definirá por el Director de las Obras. Si a la extendedora se acoplaran piezas para aumentar su anchura, éstas deberán quedar perfectamente alineadas con las originales.
### EQUIPO DE COMPACTACIÓN
Se podrán utilizar compactadores de rodillos metálicos, estáticos o vibrantes, de neumáticos o mixtos.
La composición mínima del equipo será un (1) compactador vibratorio de rodillo metálico o mixto, y un (1) compactador de neumáticos y será aprobada por el Director de las Obras a la vista de los resultados del tramo de prueba.
Todos los tipos de compactadores deberán ser autopropulsados, tener inversores de sentido de marcha de acción suave y estar dotados de dispositivos para la limpieza de sus llantas o neumáticos durante la compactación y para mantenerlos húmedos en caso necesario.
Los compactadores de llantas metálicas no presentarán surcos ni irregularidades en ellas. Los compactadores vibratorios tendrán dispositivos automáticos para eliminar la vibración al invertir el sentido de su marcha. Los de neumáticos tendrán ruedas lisas, en número, tamaño y configuración tales que permitan el solape de las huellas de las delanteras y traseras, y faldones de lona protectores contra el enfriamiento de los neumáticos.
Las presiones de contacto, estáticas o dinámicas, de los diversos tipos de compactadores serán las necesarias para conseguir la densidad adecuada y homogénea de la mezcla en todo su espesor, sin producir roturas del árido, ni arrollamientos de la mezcla a la temperatura de compactación, y serán aprobadas por el Director de las Obras a la vista de los resultados del tramo de prueba.
### EJECUCIÓN DE LAS OBRAS
ESTUDIO DE LA MEZCLA Y OBTENCIÓN DE LA FÓRMULA DE TRABAJO
La fabricación y puesta en obra de la mezcla no se iniciará hasta que se haya aprobado por el Director de las Obras la correspondiente fórmula de trabajo, estudiada en laboratorio y verificada en la central de fabricación.
Dicha fórmula fijará como mínimo las siguientes características: 
- Identificación y proporción de cada fracción del árido en la alimentación y, en su caso, después de su clasificación en caliente.
- Granulometría de los áridos combinados, incluido el polvo mineral, por los tamices 45 mm; 32 mm; 22 mm; 16 mm; 8 mm; 4 mm; 2 mm; 0,500 mm; 0,250 mm y 0,063 mm de la norma UNE EN 933 2 que correspondan para cada tipo de mezcla según la tabla 542.8, expresada en porcentaje del árido total con una aproximación del uno por ciento (1%), con excepción del tamiz 0,063 mm que se expresará con
- Dosificación, en su caso, de polvo mineral de aportación, expresada en porcentaje del árido total con aproximación del uno por mil.
- Dosificación, en su caso, de polvo mineral de recuperación expresada en porcentaje del árido total con aproximación del uno por mil.
- Tipo y características del ligante hidrocarbonado.
- Dosificación de ligante hidrocarbonado referida a la masa de la mezcla total (incluido el polvo mineral) y la de aditivos al ligante, referida a la masa del ligante hidrocarbonado.
- En su caso, tipo y dotación de las adiciones a la mezcla bituminosa, referida a la masa de la mezcla total.
También se señalarán:
- Los tiempos a exigir para la mezcla de los áridos en seco y para la mezcla de los áridos con el ligante.
- Las temperaturas máxima y mínima de calentamiento previo de áridos y ligante. En ningún caso se introducirá en el mezclador árido a una temperatura superior a la del ligante en más de quince grados Celsius (15 ºC).
- La temperatura de mezclado con betunes asfálticos se fijará dentro del rango correspondiente a una viscosidad dinámica del betún (norma UNE EN 13302), de ciento cincuenta a trescientos centipoises (150 300 cP). Además, en el caso de betunes modificados con polímeros, betunes mejorados con caucho o de betunes especiales para mezclas semicalientes, en la temperatura de mezclado se tendrá en cuenta el rango recomendado por el fabricante. El Director de las Obras podrá solicitar la curva de viscosidad del betún en función de la temperatura.
- La temperatura mínima de la mezcla en la descarga desde los elementos de transporte y a la salida de la extendedora, que no será inferior a ciento treinta grados Celsius ( 130ºC), salvo en mezclas semicalientes o justificación en contrario.
- La temperatura máxima de la mezcla al iniciar la compactación y la mínima al terminarla. 
- En el caso de que se empleen adiciones se incluirán las prescripciones necesarias sobre su forma de incorporación y tiempo de mezclado.
Salvo justificación en contrario, por viscosidad del ligante o condiciones climáticas adversas, la temperatura máxima de la mezcla en caliente al salir del mezclador no será superior a ciento sesenta y cinco grados Celsius ( 165 ºC), salvo en centrales de tambor secador mezclador, en las que no excederá de los ciento cincuenta grados Celsius ( 150 ºC). Para mezclas bituminosas de alto módulo dicha temperatura máxima podrá aumentarse en diez grados Celsius (10 ºC). En mezclas semicalientes la temperatura máxima al salir del mezclador no será superior a ciento cuarenta grados Celsius ( 140 ºC).
En todos los casos, la temperatura mínima de la mezcla al salir del mezclador será aprobada por el Director de las Obras, de forma que la temperatura de la mezcla en la descarga de los camiones sea superior al mínimo fijado.
La dosificación de ligante hidrocarbonado en la fórmula de trabajo se fijará teniendo en cuenta los materiales disponibles, la experiencia obtenida en casos análogos y verificando que la mezcla obtenida en la central de fabricación cumple los criterios establecidos en este Pliego.
El Contratista deberá entregar al Director de las Obras para su aceptación, las características de la mezcla respecto de las siguientes propiedades:
- Contenido de huecos y densidad aparente asociada a ese valor.
- Resistencia a la deformación permanente.
- Sensibilidad al agua.
- Adicionalmente, en el caso de mezclas de alto módulo, valor del módulo dinámico y de la resistencia a fatiga.
El suministrador del ligante deberá indicar la temperatura de referencia para la compactación de las probetas y para la fabricación, extendido y compactación de la mezcla.
En el caso de categorías de tráfico pesado T00 a T2, el Pliego de Prescripciones Técnicas Particulares, o en su defecto el Director de las Obras, podrá exigir un estudio de sensibilidad de las propiedades de la mezcla a variaciones de granulometría y dosificación de ligante hidrocarbonado que no excedan de las admitidas.
Para capas de rodadura, la fórmula de trabajo de la mezcla bituminosa deberá asegurar el cumplimiento de las características de la unidad terminada en lo referente a la macrotextura superficial y a la resistencia al deslizamiento.
Se estudiará y aprobará una nueva fórmula si varía la procedencia de alguno de los componentes, o si durante la producción se rebasan las tolerancias granulométricas establecidas en este artículo.
El Director de las Obras podrá exigir la corrección de la fórmula de trabajo, con objeto de mejorar la calidad de la mezcla, para lo que se realizará un nuevo estudio y los ensayos oportunos.
El contenido de huecos, determinado según el método de ensayo de la norma UNE EN 12697 8, indicado en el Anexo B de la norma UNE EN 13108 2020, deberá cumplir lo establecido en la tabla 542.12.
La determinación del contenido de huecos en cualquier tipo de mezclas con tamaño nominal D inferior compactadas (norma UNE EN 12697 30), aplicando setenta y cinco (75) golpes por cara. En mezclas con tamaño nominal D superior a veintidós milímetros (D > 22 mm), la determinación de huecos se efectuará sobre probetas preparadas bien por compactación vibratoria (norma UNE EN 12697 32), o bien por compactación giratoria (norma UNE EN12697 31). Se determinará la energía de compactación necesaria para que las probetas preparadas tengan la misma densidad que las obtenidas por impactos (norma UNE EN 12697 30), aplicando setenta y cinco (75) golpes por cara y en las que se haya sustituido el material retenido en el tamiz 22 mm por una cantidad igual de material comprendido entre los tamices 16 mm y 22 mm (norma UNE EN 933 2).
La determinación del contenido de huecos en mezclas semicalientes podrá hacerse sobre probetas preparadas por compactación giratoria (norma UNE EN 12697 31), a la temperatura de compactación prevista en obra. Para ello se compactarán hasta el número de giros que permitan obtener una densidad geométrica idéntica a la que se obtiene en probetas compactadas (norma UNE EN 12697 30), aplicando setenta y cinco (75) golpes por cara, en una mezcla en caliente de idénticas características con la excepción del tipo de ligante que deberá ser un betún asfáltico, modificado con polímeros en su caso, del mismo grado que el ligante que se desee emplear en la mezcla semicaliente. Los valores se considerarán válidos siempre que el número máximo de giros necesario para alcanzar dicha densidad geométrica sea de ciento sesenta (160) para mezclas tipo AC32 y AC22 con molde de diámetro interior de 150 mm, o de cien (100) giros para mezcla tipo AC16 con molde de diámetro interior de 100 mm.

[TABLA 542.12 CONTENIDO DE HUECOS EN MEZCLA]
El Director de las Obras, en el uso de sus atribuciones, podrá exigir el contenido de huecos en áridos, de acuerdo con el método de ensayo de la norma UNE EN 12697 8 indicado en el Anexo B de la norma UNE EN 13108 20, siempre que, por las características de los mismos o por su granulometría combinada, se prevean anomalías en la fórmula de trabajo. En tal caso, el contenido de huecos en áridos, de mezclas con tamaño máximo de dieciséis milímetros (D = 16 mm) deberá ser mayor o igual que al quince por ciento, y en mezclas con tamaño máximo de veintidós o de treinta y dos milímetros (D = 22 mm o D = 32 mm) deberá ser mayor o igual al catorce por ciento.
La resistencia a deformaciones plásticas, determinada mediante el ensayo de pista de laboratorio, deberá cumplir lo establecido en las tablas 542.13.a o 542.13.b. Este ensayo se hará según la norma UNE EN 12697 22, empleando el dispositivo pequeño, el procedimiento B en aire, a una temperatura de sesenta grados Celsius (60 ºC) y con una duración de diez mil (10 000) ciclos. Para la realización de este ensayo, se prepararán probetas con mezcla obtenida en la central de fabricación, mediante compactador de placa con el dispositivo de rodillo de acero (norma UNE EN 12697 33), con una densidad superior al noventa y ocho por ciento (> 98%) de la obtenida en probetas cilíndricas preparadas.
[TABLA 542.13a y b]
En cualquier circunstancia se comprobará la adhesividad árido ligante mediante la caracterización de la acción del agua. Para ello, la resistencia conservada en el ensayo de tracción indirecta tras inmersión, realizado a quince grados Celsius (15 ºC) (norma UNE EN 12697 12), tendrá un valor mínimo del ochenta por ciento (ITSR 80%) para capas de base e intermedia, y d para capas de rodadura. En mezclas de tamaño máximo no mayor de veintidós milímetros (D 22 mm), las probetas para la realización del ensayo se prepararán conforme a la norma UNE EN 12697 30 con cincuenta (50) golpes por cara. Para mezclas con tamaño máximo superior a veintidós milímetros (D > 22 mm), las probetas se prepararán bien mediante compactación con vibración (norma UNE EN 12697 32), o bien por compactación giratoria (norma UNE EN 12697 31). Se determinará la energía de compactación necesaria para que las probetas preparadas tengan la misma densidad que las obtenidas por impactos (norma UNE EN 12697 30), aplicando cincuenta (50) golpes por cara y en las que se haya sustituido el material retenido en el tamiz 22 mm por una cantidad igual de material comprendido entre los tamices 2 mm y 22 mm (norma UNE EN 933 2), de manera proporcional al porcentaje en peso que corresponda a cada uno de ellos, una vez eliminada la fracción retenida por el tamiz 22 mm.
Se podrá mejorar la adhesividad entre el árido y el ligante hidrocarbonado mediante activantes directamente incorporados al ligante. En todo caso, la dotación mínima no será inferior a la indicada en la tabla 542.10. En mezclas de alto módulo, el valor del módulo dinámico a veinte grados Celsius (20 ºC) (Anexo C de la norma UNE EN 12697 26), no será inferior a once mil megapascales ( 11 000 MPa). Las probetas para la realización del ensayo se prepararán conforme a la norma UNEEN 12697 30, aplicando setenta y cinco (75) golpes por cara.
En mezclas de alto módulo, realizado el ensayo de resistencia a la fatiga con una frecuencia de treinta hercios (30 Hz) y a una temperatura de veinte grados Celsius (20 ºC) (Anexo D de la norma UNE EN 12697 24), el valor de la deformación para un millón (106) de
PREPARACIÓN DE LA SUPERFICIE EXISTENTE
Se comprobará la regularidad superficial y el estado de la superficie sobre la que se vaya a extender la mezcla bituminosa. El Director de las Obras, indicará las medidas encaminadas a restablecer una regularidad superficial aceptable y, en su caso, a reparar zonas dañadas.
La regularidad superficial de la superficie existente deberá cumplir, dependiendo de su naturaleza, y sobre ella se ejecutará un riego de imprimación o un riego de adherencia, según corresponda.
Si la superficie estuviese constituida por un pavimento hidrocarbonado heterogéneo, se deberán además, eliminar mediante fresado los excesos de ligante y sellar las zonas demasiado permeables, de acuerdo con las instrucciones del Director de las Obras.
Se comprobará especialmente que transcurrido el plazo de rotura del ligante de los tratamientos aplicados, no quedan restos de agua en la superficie. Además, si ha pasado mucho tiempo desde su aplicación, se verificará que su capacidad de unión con la mezcla bituminosa no ha disminuido en forma perjudicial; en caso contrario, el Director de las Obras podrá ordenar la ejecución de un riego de adherencia adicional.
APROVISIONAMIENTO DE ÁRIDOS
Los áridos se producirán o suministrarán en fracciones granulométricas diferenciadas, que se acopiarán y manejarán por separado hasta su introducción en las tolvas en frío. Cada fracción será suficientemente homogénea y se podrá acopiar y manejar sin peligro de segregación. Para mezclas con tamaño máximo de árido de dieciséis milímetros (D = 16 mm) el número mínimo de fracciones será de tres (3); para el resto de las mezclas será de cuatro (4). El Director de las Obras podrá exigir un mayor número de fracciones, si lo estima necesario para cumplir las tolerancias exigidas a la granulometría de la mezcla.
Cada fracción del árido se acopiará separada de las demás, para evitar intercontaminaciones. Los acopios se dispondrán preferiblemente sobre zonas pavimentadas. Si se dispusieran sobre el terreno natural, no se utilizarán sus quince centímetros (15 cm) inferiores. Los acopios se construirán por tongadas de espesor no superior a un metro y medio ( 1,5 m), y no por montones cónicos. Las cargas del material se colocarán adyacentes, tomando las medidas oportunas para evitar su segregación.
Cuando se detecten anomalías en la producción o suministro de los áridos, se acopiarán por separado hasta confirmar su aceptabilidad. Esta misma medida se aplicará cuando esté pendiente de autorización el cambio de procedencia de un árido, que obligaría siempre al estudio de una nueva fórmula de trabajo.
El Director de las Obras, fijará el volumen mínimo de acopios antes de iniciar las obras. Salvo justificación en contrario dicho volumen no será inferior al correspondiente a un (1) mes de trabajo con la producción prevista.
FABRICACIÓN DE LA MEZCLA
Lo dispuesto en este epígrafe se entenderá sin perjuicio de lo establecido en la norma UNE EN 13108 1 para el marcado CE.
La carga de cada una de las tolvas de áridos en frío se realizará de forma que su contenido esté siempre comprendido entre el cincuenta y el cien por ciento (50% a 100%) de su capacidad, sin rebosar.
Para mezclas densas y semidensas la alimentación del árido fino, aun cuando éste fuera de un único tipo y granulometría, se efectuará dividiendo la carga entre dos (2) tolvas.
Si se utilizase material procedente del fresado o trituración de capas de mezclas bituminosas, en proporción superior al quince por ciento (> 15%) de la masa total de la mezcla, se procederá como se especifica a continuación:
- En centrales cuyo secador no sea a la vez mezclador, si la alimentación de éste fuera discontinua, para cada amasada, después de haber introducido los áridos, se pesarán e introducirán los áridos procedentes de mezclas bituminosas, y después de un tiempo de disgregación, calentado y mezcla, se agregará el ligante hidrocarbonado, y en su caso los aditivos, y se continuará la operación de mezcla durante el tiempo especificado en la fórmula de trabajo.
Si la alimentación fuese continua, los áridos procedentes de mezclas bituminosas se incorporarán junto al resto de los áridos en la zona de pesaje en caliente a la salida del secador.
- En centrales de mezcla continua con tambor secador mezclador se aportará el material procedente del fresado o trituración de capas de mezclas bituminosas tras la llama, de forma que no exista riesgo de contacto con ella.
En ningún caso se calentarán los áridos de aportación a más de doscientos veinte grados Celsius (220ºC), ni el material bituminoso a reciclar a una temperatura superior a la del ligante de aportación.
A la descarga del mezclador todos los tamaños del árido deberán estar uniformemente distribuidos en la mezcla, y todas sus partículas total y homogéneamente cubiertas de ligante. La temperatura de la mezcla al salir del mezclador no excederá de la fijada en la fórmula de trabajo.
En el caso de utilizar adiciones al ligante o a la mezcla se cuidará su correcta dosificación, la distribución homogénea, así como que no pierda sus características iniciales durante todo el proceso de fabricación.
Los gases producidos en el calentamiento de la mezcla, se recogerán durante el proceso de fabricación de la mezcla, evitando en todo momento su emisión a la atmósfera.
Se estará, en todo caso, a lo dispuesto en la legislación vigente en materia ambiental y de seguridad y salud.
TRANSPORTE
La mezcla bituminosa se transportará en camiones de la central de fabricación a la extendedora. La caja del camión se tratará previamente con un líquido antiadherente. Dicha solución se pulverizará de manera uniforme sobre los laterales y fondo de la caja, utilizando la mínima cantidad para impregnar toda la superficie, y sin que se produzca un exceso de líquido antiadherente, que deberá drenarse en su caso, antes de cargar la mezcla bituminosa. No se permitirá en ningún caso el empleo de productos derivados del petróleo.
Para evitar el enfriamiento superficial de la mezcla, deberá protegerse durante el transporte mediante lonas u otros cobertores adecuados. En el momento de descargarla en la extendedora o en el equipo de transferencia, su temperatura no podrá ser inferior a la especificada en la fórmula de trabajo.
EXTENSIÓN
La extensión comenzará por el borde inferior y se realizará por franjas longitudinales, salvo que el Director de las Obras indique otro procedimiento. La anchura de estas franjas se fijará de manera que se realice el menor número de juntas posible y se consiga la mayor continuidad de la extensión, teniendo en cuenta la anchura de la sección, el eventual mantenimiento de la circulación, las características de la extendedora y la producción de la central.
En obras sin mantenimiento de la circulación, para carreteras con calzadas separadas con superficies a extender superiores a setenta mil metros cuadrados (> 70 000 m2), se realizará la extensión de cualquier capa bituminosa a ancho completo, trabajando si fuera necesario con dos (2) o más extendedoras ligeramente desfasadas, evitando juntas longitudinales. En los demás casos, después de haber extendido y compactado una franja, se extenderá la siguiente mientras el borde de la primera se encuentre aún caliente y en condiciones de ser compactado; en caso contrario, se ejecutará una junta longitudinal.
La extendedora se regulará de forma que la superficie de la capa extendida resulte lisa y uniforme, sin segregaciones ni arrastres, y con un espesor tal que, una vez compactada, se ajuste a la rasante y sección transversal indicadas en los Planos del Proyecto, con las tolerancias establecidas.
La extensión se realizará con la mayor continuidad posible, ajustando la velocidad de la extendedora a la producción de la central de fabricación de modo que sea constante y que no se detenga. En caso de parada, se comprobará que la temperatura de la mezcla que quede sin extender, en la tolva de la extendedora y debajo de ésta, no baje de la prescrita en la fórmula de trabajo para el inicio de la compactación; de lo contrario, se ejecutará una junta transversal.
COMPACTACIÓN
La compactación se realizará según el plan aprobado por el Director de las Obras en función de los resultados del tramo de prueba hasta que se alcance la densidad especificada. Se deberá hacer a la mayor temperatura posible sin rebasar la máxima prescrita en la fórmula de trabajo y sin que se produzca desplazamiento de la mezcla extendida, y se continuará, mientras la mezcla esté en condiciones de ser compactada y su temperatura no sea inferior a la mínima prescrita en la fórmula de trabajo.
En mezclas bituminosas fabricadas con betunes modificados o mejorados con caucho, y en mezclas bituminosas con adición de caucho, se continuará obligatoriamente el proceso de compactación hasta que la temperatura de la mezcla baje de la mínima establecida en la fórmula de trabajo, aunque se hubiera alcanzado previamente la densidad especificada, con el fin de mantener la densidad de la tongada hasta que el aumento de viscosidad del betún contrarreste una eventual tendencia del caucho a recuperar su forma.
La compactación se realizará longitudinalmente, de manera continua y sistemática. Si la extensión de la mezcla bituminosa se realizara por franjas, al compactar una de ellas se ampliará la zona de compactación para que incluya al menos quince centímetros (15 cm) de la anterior.
Los rodillos deberán llevar su rueda motriz del lado más cercano a la extendedora; los cambios de dirección se realizarán sobre mezcla ya apisonada, y los cambios de sentido se efectuarán con suavidad.
Los elementos de compactación deberán estar siempre limpios y, si fuera preciso, húmedos.
JUNTAS TRANSVERSALES Y LONGITUDINALES
Cuando sean inevitables, se procurará que las juntas de capas superpuestas guarden una separación mínima de cinco metros (5 m) las transversales, y quince centímetros (15 cm) las longitudinales.
Al extender franjas longitudinales contiguas, si la temperatura de la extendida en primer lugar no fuera superior al mínimo fijado en la fórmula de trabajo para la finalización de la compactación, el borde de esta franja se cortará verticalmente, dejando al descubierto una superficie plana y vertical en todo su espesor. Se le aplicará una capa uniforme y ligera de riego de adherencia, de acuerdo con el artículo 531 de este Pliego, dejando transcurrir el tiempo necesario para la rotura de la emulsión. A continuación, se calentará la junta y se extenderá la siguiente franja contra ella. Este procedimiento se aplicará de manera análoga a la ejecución de juntas transversales.
En capas de rodadura, las juntas transversales se compactarán transversalmente, disponiendo los apoyos precisos para los elementos de compactación.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Se conserva la medición contractual en m³ del original, pendiente de su contraste con el cuadro de precios. Evitar doble abono del ligante, filler y riegos incluidos.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
