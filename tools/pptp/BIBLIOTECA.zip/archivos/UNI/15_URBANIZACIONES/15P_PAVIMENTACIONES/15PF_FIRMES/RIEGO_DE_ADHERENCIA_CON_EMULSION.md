# Riego de adherencia con emulsión bituminosa

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Confirmar la designación completa y aptitud de C60B3 y si los 250 g/m² se refieren a emulsión o a ligante residual; no son magnitudes intercambiables. Resolver la inclusión del riego en la mezcla.

## Definición

### Criterio de la ficha y complemento técnico

Aplicación uniforme de emulsión para asegurar la unión entre capas del firme. El original identifica el ligante como C60B3.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 102–106. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RIEGO DE ADHERENCIA
### MATERIALES
El ligante a emplear será una emulsión bituminosa C60B3.
Dosificación del ligante.
La dosificación del ligante a utilizar será mayor de 250g/m². Esta dosificación podrá ser modificada a la vista de los ensayos realizados en obra, previa autorización del Ingeniero de Construcción.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aplicar el artículo 531 y el artículo 214 del PG-3: limpiar y comprobar el soporte, proteger elementos adyacentes, calibrar el distribuidor y pulverizar uniformemente. Fijar y comprobar la dotación de ligante residual, respetar la rotura de la emulsión y evitar tránsito o contaminación antes de extender la capa superior.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m² realmente ejecutados conforme al original únicamente cuando no esté incluido en el precio de la mezcla. El transporte y la aplicación forman parte del precio descrito.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 107–108. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
El ligante se abonará por m² realmente ejecutado en obra. No se abonará en transporte del ligante ni la ejecución del riego de adherencia por estar incluidos en el precio anterior.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
