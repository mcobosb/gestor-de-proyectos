# Arena y grava para camas de asiento y protección

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Los espesores del original varían según servicio. Aplicar el detalle aprobado, no un espesor común a todas las camas.

## Definición

### Criterio de la ficha y complemento técnico

Materiales granulares de apoyo y envolvente de tuberías o pavimentos, con características distintas según la aplicación.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 137–137. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Las tuberías hormigón irán sobre asiento de arena con un espesor de 10 cms sobre suelo adecuado, compactado al 95% del Proctor Modificado, las tuberías de hormigón irán alojadas sobre lecho de material granular de diámetro inferior a 13 mm compactado al 95% del PM y se rellenará por capas de pequeño espesor hasta un recubrimiento mínimo de 30 cms con el mismo material compactado. Los tubos serán uniformes y no tendrán irregularidades. No contendrán ningún defecto que pueda reducir su resistencia, impermeabilidad o duración.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 411–411. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Se utilizarán losas de hormigón 40x20x8 cm sin bisel que irán dispuestas con una capa de arrocillo de 3-4 cm sobre losa de hormigón.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar granulometría, limpieza y compatibilidad con el producto apoyado; evitar finos o elementos que dañen tubos y piezas. Extender con espesor uniforme y compactar o asentar por el método aprobado, cuidando especialmente los laterales de las tuberías. No emplear una misma especificación para cama de tubo, filtro drenante y lecho de pavimento sin comprobarla.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 143–145. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

- Prueba de la tubería.
En la preparación del asiento se incluirá la limpieza, nivelación y compactación del terreno natural, y la ejecución de un lecho de arena de 10 cm de espesor.
La colocación de los tubos se hará en sentido ascendente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 249–257. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

EJECUCIÓN DE LAS OBRAS
Las zanjas para la instalación de tuberías tendrán un ancho mínimo de 50 cm superior al diámetro exterior del tubo, y una profundidad suficiente para instalar la tubería de forma que quede una altura mínima entre la generatriz superior del tubo y la superficie de 80 cm.
La profundidad máxima de una zanja será, por el contrario de 1,00 m en aceras y de 1,40 bajo calzadas, salvo acuerdo en contra del Servicio de Aguas.
No obstante, lo determinado en el apartado anterior, en el caso de conducciones bajo cargas pesadas, o enterradas a gran profundidad, será de aplicación obligatoria la metodología de cálculo y dimensionamiento de timbrajes según UNE 88.211 90.
El fondo de la zanja se rasanteará y nivelará, extendiendo posteriormente una capa de arena, de 10 cm como mínimo, incrementándose en función del diámetro de la tubería a instalar.
Una vez montada la tubería se tapará hasta 10cm por encima del tubo con arena, compactado perfectamente los lados del tubo.
El resto de la zanja se rellenará con zahorra o material granular seleccionado procedente de la excavación, escogiendo lo fino y separando las piedras, tierra vegetal o contenido en materia orgánica.
La primera compactación se hará cuando haya como mínimo 50cm de tierra sobre el tubo. 
El sobrante de la excavación se retirará y llevará a un vertedero.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 992–1001. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Se colocarán sobre una cama de grava o mortero debidamente nivelada.
Tras la extensión, nivelación y compactación de la capa base tierra de aportación, a la cota de rasante necesaria para que el pavimento terminado se adapte a la arista superior del bordillo colocado y con una pendiente transversal comprendida entre el uno y medio y el tres por ciento (1,5 3%), se procederá a la extensión de la capa de asiento (arena ó mortero) y a su nivelación mediante una barra de longitud igual al ancho de la acera.
El dibujo en la colocación del adoquín será definido en los planos de proyecto o directamente en la obra por la dirección, y siempre de tal forma que se evite el excesivo corte de piezas. Se evitará, asimismo, el empleo de tamaños menores de la mitad de la dimensión de los adoquines.
En el caso de pavimentado alrededor de pozos de registro se procurará la disposición de adoquines con su dimensión mayor, radial al centro de los pozos en una o dos hileras de adoquines.
Tras la disposición de los adoquines se procederá al relleno de juntas con aportación de arena sobre la totalidad del pavimento, y al taqueado de los adoquines cubiertos mediante un compresor vibrador o manualmente con pisones de madera.
Se cubrirá de nuevo el pavimento con arena, tras el taqueado, y se dejará un tiempo procediendo después al barrido de la superficie para facilitar el rellano de las juntas de adoquines.
Este proceso se repetirá tantas veces como estime necesario la Dirección de obra, hasta que considere debidamente selladas las juntas y asentado el adoquín.
En caso de emplear agua para el relleno de juntas, está se aplicará en forma de lluvia para evitar el lavado de la arena.
Salvo en casos especiales, se evitará el rejuntado de piezas con mortero de cemento.
Estos casos serán debidamente consultados con la Dirección de obra, y siempre a dicho mortero le será añadido el colorante necesario para conseguir la coloración análoga a la de los adoquines que une.

### Referencias de aplicación

- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Incluidos normalmente en la conducción o pavimento; medir aparte sólo cuando exista partida propia, con su unidad y espesor.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 147–150. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por los metros de longitud, descontando longitudes debidas a pozos y arquetas, aplicadas según el diámetro del tubo.
Dentro del precio se encontrarán incluidos el suministro de los tubos, ejecución de juntas, las piezas especiales y la confluencia con los pozos, y las pruebas finales de estanqueidad y presión.
Siempre que el presupuesto no contemple una partida específica se entenderá que el material de asiento o lecho de arena queda incluido dentro del precio unitario.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 321–331. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las tuberías para abastecimiento de agua se medirán por ml realmente ejecutado, entendiéndose que el precio incluirá además de la tubería, la colocación y la prueba, también la parte proporcional de juntas, uniones, topes protecciones y los materiales, operaciones necesarias para ejecutar completamente la unidad, e incluso el lecho de arena si fuera necesario a juicio de la Dirección Facultativa y siempre que no se haya indicada como unidad aparte en el presupuesto así como la prueba de la tubería y los medios necesarios para la misma.
Se medirán y abonarán por uds independientes los siguientes apartados:
- Codos
- Válvulas
- Hidrantes contra incendios
- Bocas de riego
- Arquetas
- Dados de anclaje
- Piezas en T
- Otras piezas especiales

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 415–417. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cuadrados ejecutados.
El precio incluye el relleno, nivelación y compactación de la capa de suelo, los encofrados necesarios para huecos de alcorques, bordes, etc. El suministro y puesta en obra de los adoquines, la compactación de los mismos, así como los materiales, maquinaria y operaciones necesarias para acabar correctamente la unidad.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
