# Árido fino para mezclas bituminosas

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Definición

### Criterio de la ficha y complemento técnico

Fracción fina de los áridos de la mezcla bituminosa, procedente de trituración según la prescripción del proyecto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 91–91. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

- Árido fino. Deberá proceder de la trituración de piedra de cantera o grava natural en su totalidad.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar procedencia, limpieza, granulometría y compatibilidad con la fórmula de trabajo. Acopiar por separado y dosificar de forma uniforme, corrigiendo la humedad cuando proceda, conforme al artículo 542 del PG-3.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 673–677. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

La carga de cada una de las tolvas de áridos en frío se realizará de forma que su contenido esté siempre comprendido entre el cincuenta y el cien por ciento (50% a 100%) de su capacidad, sin rebosar.
Para mezclas densas y semidensas la alimentación del árido fino, aun cuando éste fuera de un único tipo y granulometría, se efectuará dividiendo la carga entre dos (2) tolvas.
Si se utilizase material procedente del fresado o trituración de capas de mezclas bituminosas, en proporción superior al quince por ciento (> 15%) de la masa total de la mezcla, se procederá como se especifica a continuación:
- En centrales cuyo secador no sea a la vez mezclador, si la alimentación de éste fuera discontinua, para cada amasada, después de haber introducido los áridos, se pesarán e introducirán los áridos procedentes de mezclas bituminosas, y después de un tiempo de disgregación, calentado y mezcla, se agregará el ligante hidrocarbonado, y en su caso los aditivos, y se continuará la operación de mezcla durante el tiempo especificado en la fórmula de trabajo.
Si la alimentación fuese continua, los áridos procedentes de mezclas bituminosas se incorporarán junto al resto de los áridos en la zona de pesaje en caliente a la salida del secador.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Su suministro y manipulación quedan incluidos en la mezcla bituminosa, salvo partida contractual independiente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
