# Betún asfáltico 50/70

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El contenido de ligante «4,9 5%» está mal transcrito; no es una dosificación inequívoca y debe fijarse mediante fórmula de trabajo.

## Definición

### Criterio de la ficha y complemento técnico

Ligante hidrocarbonado de las mezclas bituminosas descritas en 3.7, de grado 50/70.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 81–86. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEZCLA BITUMINOSA
### DEFINICIÓN
Se define como mezcla bituminosa la combinación de un betún asfáltico, áridos con granulometría continua, polvo mineral y, eventualmente, aditivos, de manera que todas las partículas del árido queden recubiertas por una película homogénea de ligante, cuyo proceso de fabricación y puesta en obra deben realizarse a una temperatura muy superior a la del ambiente.
Se utilizarán la tipo AC32 BASE G, capa base de granulometría gruesa y con tamaño máximo de árido de 32mm; como capa intermedia la tipo AC22 BIN D, capa base de granulometría densa y con tamaño máximo de árido de 22mm y la AC16 SURF S, capa de rodadura semidensa y con tamaño máximo de árido de 16mm.
Condiciones que han de cumplir los materiales.
- Ligante hidrocarbonado. El ligante hidrocarbonado a emplear en la mezcla será betún asfáltico, tipo 50/70. El contenido de ligante en la mezcla será del 4,9 5%.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Recibir el producto con identificación, documentación de prestaciones que corresponda y trazabilidad. Almacenar y calentar con equipos regulados evitando contaminación y sobrecalentamiento. Dosificar según la fórmula aprobada de cada mezcla; aplicar los artículos 211 y 542 del PG-3.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El documento lo integra en el precio de la mezcla. No se crea abono independiente. Sólo se medirá como suministro separado si existe partida aprobada con unidad y criterio propios.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
