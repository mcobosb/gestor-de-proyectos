# Riego de imprimación con emulsión bituminosa

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Confirmar que la emulsión prescrita es adecuada para imprimación y aclarar si los 500 g/m² son de emulsión o de ligante residual. No fijar una dotación sólo por el umbral ambiguo del original.

## Definición

### Criterio de la ficha y complemento técnico

Tratamiento de una capa granular mediante ligante adecuado para preparar su unión con la capa bituminosa. El original designa la emulsión C60BF4.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 109–113. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RIEGO DE IMPRIMACIÓN
### MATERIALES
El ligante a emplear será una emulsión bituminosa tipo C60BF4.
Dosificación de los materiales.
La dosificación del ligante será mayor de 500g/m². Esta dosificación podrá ser modificada a la vista de los ensayos realizados en obra, previa autorización del Ingeniero de Construcción.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aplicar los artículos 530 y 214 del PG-3: comprobar el soporte granular, retirar polvo suelto, ajustar su estado superficial y efectuar riego uniforme con dotación aprobada según absorción. Esperar la absorción y curado necesarios, tratar excesos según procedimiento aprobado y proteger la superficie hasta el extendido.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m² según el documento, sólo si la partida de mezcla no incluye ya la imprimación. Transporte y puesta en obra están incluidos en el precio descrito.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 114–115. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
El ligante se medirá y abonará por m² realmente ejecutados. No se abonará el transporte de los materiales ni la ejecución y puesta en obra del riesgo por estar incluidos en los precios anteriores.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
