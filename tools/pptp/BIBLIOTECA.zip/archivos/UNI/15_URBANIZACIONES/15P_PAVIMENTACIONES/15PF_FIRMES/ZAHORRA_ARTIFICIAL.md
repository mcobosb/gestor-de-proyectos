# Zahorra artificial para bases y subbases

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Las designaciones ZA(40) y ZA(25) del original deben contrastarse con el artículo 510 y la sección de firme aplicables; no se sustituyen automáticamente por otros husos.

## Definición

### Criterio de la ficha y complemento técnico

Capa granular de áridos de granulometría continua para base o subbase del firme.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 68–77. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ZAHORRA ARTIFICIAL
### DESCRIPCIÓN
Es una zona de áridos procedente de una instalación de machaqueo con granulometría de tipo continuo.
Condiciones mínimas de aceptación.

Antes del acopio del material, la Dirección Facultativa habrá de autorizar expresamente la capa inferior.
La zahorra artificial cumplirá las especificaciones del Pliego de Prescripciones Técnicas Generales para Obras de Carreteras y Puentes.
La curva granulométrica estará comprendida en los husos ZA(40) o ZA(25) del PG 3. El material habrá de conservar sus características una vez compactado.
La densidad de la zahorra una vez compactada será igual al 100% de la máxima obtenida en el ensayo Proctor Modificado, debiendo cumplirse esta densidad en zonas como borde y otros elementos singulares de la calzada.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Conforme al artículo 510 del PG-3 aplicable, recibir los áridos con su documentación, aprobar el soporte, extender sin segregación, ajustar la humedad y compactar uniformemente, incluidos bordes y zonas singulares. Comprobar espesor, densidad, capacidad de soporte y regularidad antes de cubrir. El original prescribe el 100 % del Proctor Modificado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 593–596. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### BASE DE ZAHORRA ARTIFICIAL
La zahorra artificial no se extenderá hasta que se haya comprobado que la superficie sobre la que haya de asentarse tenga las condiciones de calidad y formas previstas, con las tolerancias establecidas.
Los materiales serán extendidos tomando las precauciones necesarias para evitar segregaciones y contaminaciones, en tongadas con espesores comprendidos entre diez y treinta centímetros.
La superficie acabada no deberá rebasar a la teórica en ningún punto, ni diferir de ella en más quince milímetros del espesor previsto en los Planos. La compactación de la zahorra artificial deberá alcanzar una densidad no inferior a la que corresponda al cien por cien de la máximo modificado 108.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m³ sobre la sección teórica una vez compactada. Incluye adquisición, transporte, preparación, extendido, agua, compactación y refino conforme a la partida.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 78–80. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos medidos sobre perfil teórico de planos una vez compactado.
El precio incluye la adquisición, transporte, extendido, humectación y compactación de la zahorra artificial, el refino y compactación de la explanada, y todos aquellos materiales y maquinaria necesarios para dejar la obra correctamente terminada, incluso la utilización de medios de compactación especiales para zonas singulares o el extendido a mano.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1140–1142. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### SUBBASE Y BASE DE ZAHORRAS
Se medirán por metros cúbicos (m³) medidos según las dimensiones especificadas en las secciones tipo que figuran en los Planos, y las longitudes reales de los viales medidos por el eje, abonándose al precio correspondiente que figura en el Cuadro de Precios nº 1.
El precio comprende todos los gastos necesarios para la adquisición del material, carga, transporte al lugar de empleo, descarga, extensión, humectación y compactación, refino de la superficie, así como los de cribado, machaqueo y, en general, todos los necesarios para la correcta terminación de la unidad de obra según las especificaciones del Proyecto.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
