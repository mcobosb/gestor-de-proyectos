# Polvo mineral o filler para mezclas bituminosas

**Clasificación:** 15PF. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Los intervalos y ensayos antiguos del original no sustituyen la caracterización del producto conforme al artículo 542 y su documentación aplicable.

## Definición

### Criterio de la ficha y complemento técnico

Fracción mineral fina recuperada o de aportación que forma parte de la mezcla bituminosa.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 92–94. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

- Filler. Procederá de machaqueo de los áridos o será de aportación como producto comercial. La densidad aparente del filler, determinada por el ensayo de sedimentación en tolueno estará comprendida entre 0,5 0,8g/cm3.
- El coeficiente de emulsibilidad será inferior a 0,6.
- La relación entre polvo mineral y ligante será 1,2.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Identificar el origen, acreditar sus prestaciones y almacenar evitando humedad y contaminación. Dosificar homogéneamente según la fórmula de trabajo, controlando la proporción respecto al ligante y las prestaciones de la mezcla conforme al artículo 542 del PG-3.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El filler de aportación está incluido expresamente en el precio de la mezcla; no procede duplicar su abono.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 99–101. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se abonarán por m³ realmente colocadas, medidas a partir de perfil teórico y de las densidades realmente obtenidas en obra.
El precio de fabricación y puesta en obra comprende el de todos los áridos, filler de aportación, activantes y aditivos, así como el proceso de fabricación, transporte y puesta en obra. El porcentaje real se obtendrá como media ponderada de los resultados de las extracciones que se hagan en obra, corregidas con las del laboratorio para calcinación del residuo. Si no se especifica en mediciones, se encuentra incluido en el precio por m3 de mezcla, la parte proporcional de los riegos de adherencia e imprimación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
