# Luminarias, lámparas y proyectores

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La altura mínima genérica de 6 m, IPX3 y la suspensión por cable no definen todas las luminarias posibles. Ajustar cada tipo al proyecto y al régimen reglamentario correspondiente.

## Definición

### Criterio de la ficha y complemento técnico

Equipos de iluminación exterior completos, con su fuente luminosa y auxiliares.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 388–393. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### LUMINARIAS
DESCRIPCIÓN
Las luminarias utilizadas en el alumbrado exterior serán conforma a la mona UNE EN 60598 2 3 y la UNE EN 60598 2 5 en el caso de proyectores exteriores.
La conexión se realizará mediante cables flexibles, que penetren en la luminaria con la holgura suficiente para evitar que las oscilaciones de ésta provoquen esfuerzos perjudiciales en los cables y en los terminales de conexión, utilizándose dispositivos que no disminuyan el grado de protección de luminaria IPX3 según UNE 20324.
La suspensión de las luminarias se hará mediante cable de acero protegido contra la corrosión, de sección suficiente para que, posea una resistencia mecánica con coeficiente de seguridad no inferior a 3,5.
La altura mínima sobre el nivel del suelo será de 6m.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Seleccionar equipos conforme al estudio luminotécnico y al REBT, con protección ambiental y mecánica adecuada al lugar. Montar y orientar según cálculo sin alterar los grados de protección y sin esfuerzos en los cables. Verificar encendido, regulación, consumo y prestaciones luminotécnicas conforme al RD 1890/2008 cuando sea aplicable.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Reglamento de eficiencia energética en instalaciones de alumbrado exterior, Real Decreto 1890/2008 e ITC-EA-01 a 07, dentro de su ámbito de aplicación.](https://www.boe.es/buscar/act.php?id=BOE-A-2008-18634)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por ud instalada y comprobada, con lámpara o fuente luminosa y cableado de conexión incluidos según 3.17.7.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 394–395. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
Se medirán por Uds. Completamente terminadas realmente ejecutado, incluido lámpara y cableado de conexión, según indicaciones de la D.T.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1170–1171. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### BÁCULOS, LUMINARIAS Y LÁMPARAS
Se medirán por unidades de iguales características realmente colocadas.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
