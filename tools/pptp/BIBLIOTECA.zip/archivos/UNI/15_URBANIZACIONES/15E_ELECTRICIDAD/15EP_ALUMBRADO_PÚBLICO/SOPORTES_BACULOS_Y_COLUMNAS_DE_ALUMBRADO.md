# Soportes, báculos y columnas de alumbrado

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Revisar las referencias históricas RD 2642/85, RD 401/89 y la orden de 1989 frente al régimen de producto aplicable, habitualmente serie UNE-EN 40 según material y soporte.

## Definición

### Criterio de la ficha y complemento técnico

Elementos resistentes de sustentación de luminarias con sus cimentaciones, anclajes y accesos de mantenimiento.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 382–385. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### SOPORTES
DESCRIPCIÓN
Los soportes de las luminarias de alumbrado exterior, se ajustarán a la normativa vigente (en el caso de que sea de acero deberán cumplir el RD 2642/85, RD 401/89 y OM de 16/5/89). Los soportes, sus anclajes y cimentaciones, se dimensionarán de forma que resistan las solicitaciones mecánicas, particularmente teniendo en cuenta la acción del viento, con un coeficiente de seguridad no inferior a 2,5, considerando las luminarias completas instaladas en el soporte.
Los soportes que lo requieran, deberán poseer una abertura de dimensiones adecuadas al equipo eléctrico para acceder a los elementos de protección y maniobra; la parte inferior de dicha abertura estará situada, como mínimo, a 0,30 m de la rasante y estará dotada de puerta o trampilla con grado de protección IP44 según UNE 20324 (EN 60529) e IK 10 según UNE EN 50102. La puerta solamente se podrá abrir mediante el empleo de útiles especiales y dispondrán de un borne a tierra cuando sea metálico.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Verificar cálculo frente al viento con las luminarias instaladas, documentación de producto y protección anticorrosiva. Ejecutar cimentación y pernos con geometría aprobada, respetar la resistencia antes del izado, aplomar y apretar conforme a fabricante. Disponer acceso protegido y conexión de las partes metálicas a la red de tierra según ITC-BT-09.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por ud completamente instalada, incluida excavación y cimentación según 3.17.6 y las características de su partida.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 386–387. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
Se medirán por Uds. Completamente terminadas realmente ejecutado, incluido cimentación y excavación necesaria según indicaciones de la D.T.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1170–1171. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### BÁCULOS, LUMINARIAS Y LÁMPARAS
Se medirán por unidades de iguales características realmente colocadas.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
