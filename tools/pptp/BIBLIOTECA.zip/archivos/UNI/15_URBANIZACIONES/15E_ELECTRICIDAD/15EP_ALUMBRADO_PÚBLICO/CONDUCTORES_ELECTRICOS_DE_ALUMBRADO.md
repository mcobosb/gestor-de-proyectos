# Conductores eléctricos de alumbrado

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Las tablas y factores antiguos del original deben contrastarse con el cálculo reglamentario. El cableado de conexión incluido en la luminaria no se abonará de nuevo.

## Definición

### Criterio de la ficha y complemento técnico

Cables de alimentación y conexión interior de los puntos de luz del alumbrado exterior.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 368–377. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### CONDUCTORES
DESCRIPCIÓN
Para la alimentación eléctrica de las luminarias, se utilizarán conductores que serán del tipo plastigrón UNE RV 0.6/1 kv con una sección mínima, cuando discurran enterrados de 6 mm² para una tensión de prueba de 4000 voltios y con aislamiento de Polietileno reticulado, con cobre como material conductor y deberán cumplir los requisitos especificados en la parte correspondiente de la norma UNE HD 603.
El conductor neutro de cada circuito que parte de cuadro, no podrá ser utilizado por ningún otro circuito.
Las derivaciones y empalmes que se hayan de realizar, siempre se efectuarán en las arquetas o armarios de que dispongan las luminarias, y en ningún caso, podrán quedar estos en el interior de los tubos.
Estas derivaciones se efectuarán siempre aplicando elementos en los que se garantice una perfecta continuidad del conductor y el aislamiento, así como, su estanqueidad y resistencia a la corrosión, para lo que se utilizará cintas vulcanizables y del tipo normal.
Los empalmes y derivaciones deberán realizarse en caja de bornas adecuadas, situadas dentro de los soportes de las luminarias, y a una altura mímica de 0,3 m. sobre el nivel del suelo en una arqueta registrable, que garanticen, en ambos casos, la continuidad, el aislamiento y la estanqueidad del conductor.
Las secciones de estos conductores será la adecuada a las intensidades, según la Tabla II, Columna 007, afectada por el coeficiente 0,8 por tratarse de conductores canalizados bajo tubo y caída de tensión prevista, para sección del neutro será conforme a lo indicado en la tabla 1 de la ITC BT 07.
La caída de tensión máxima permitida entre el origen y el final de cada circuito será del 3% de la nominal.
Las conexiones de las luminarias a las redes generales de alumbrado se realizarán utilizándose conductores RV0.6/1kv de 2x6mm² en cobre, ascendiendo a través del tubo de los báculos o columnas hasta las luminarias con conductor del mismo tipo de 2x2,5 mm², reforzándose mediante tubo de plástico o cualquier otro sistema adecuado en los puntos donde el conductor pueda dañarse.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Dimensionar sección, caída de tensión y protecciones conforme a ITC-BT-09 y al cálculo. Para redes subterráneas de alimentación, utilizar cables de cobre de tensión asignada 0,6/1 kV y sección mínima de 6 mm², incluido neutro, sin confundirlos con el cableado interior de soportes. Tender sin dañar cubierta ni exceder esfuerzos y radios del fabricante. Identificar y comprobar continuidad y aislamiento.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 378–379. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

EJECUCIÓN DE OBRA
El conductor se introducirá dentro del tubo de protección mediante un cable guía cuidando que no sufra torsiones ni daños de cobertura. Se exigirá protocolo de ensayo por cada bobina. El instalador cuidará que no se produzca daños ni torsiones en su cubierta al sacarlo de la bobina.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m de cable colocado y conectado con el criterio de la partida; diferenciar metro de cable multipolar y metro de conductor unipolar para evitar multiplicaciones indebidas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 380–381. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
Se medirán por ml. Completamente terminadas realmente ejecutado.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
