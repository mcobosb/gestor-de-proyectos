# Cuadro de protección, medida y control de alumbrado

**Clasificación:** 15EP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La altura de acceso «entre 2 y 1,3 m» del original no reproduce ITC-BT-09, que indica entre 2 y 0,3 m. Resolver el detalle accesible y seguro del proyecto.

## Definición

### Criterio de la ficha y complemento técnico

Conjunto de mando, seccionamiento y protección de los circuitos de alumbrado exterior.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 350–353. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### CUADRO DE PROTECCIÓN
DESCRIPCIÓN
Los cuadros, además de la correspondiente caja de I.C.P., contendrán los elementos reflejados en la medición, la envolvente del cuadro, proporcionará un grado de protección mínima IP55 según UNE 20324 e IK10 según UNE EN50102 y dispondrá de un sistema de cierre que permita el acceso exclusivo al mismo, del personal autorizado, con su puerta de acceso situada a una altura comprendida entre 2 y 1,3 m. Los elementos de medida estarán situados en un módulo independiente.
Las partes metálicas del cuadro irán conectada a tierra.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aplicar ITC-BT-09: montar envolvente con protección al menos IP55 e IK10, acceso reservado y elementos de medida segregados; conectar las masas a tierra. Seleccionar y coordinar protecciones frente a sobreintensidad y contactos indirectos y comprobar accionamiento automático y manual. Verificar instalación y documentación antes de la puesta en servicio.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Reglamento de eficiencia energética en instalaciones de alumbrado exterior, Real Decreto 1890/2008 e ITC-EA-01 a 07, dentro de su ámbito de aplicación.](https://www.boe.es/buscar/act.php?id=BOE-A-2008-18634)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir por ud completamente instalada y comprobada, con los equipos y conexiones de su partida.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 354–355. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
El cuadro de protección se medirá como Uds. De obra completamente terminada, realmente ejecutada.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
