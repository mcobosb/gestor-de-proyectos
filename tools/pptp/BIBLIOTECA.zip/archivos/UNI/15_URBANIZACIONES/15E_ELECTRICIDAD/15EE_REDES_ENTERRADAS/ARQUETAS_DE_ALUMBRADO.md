# Arquetas de alumbrado

**Clasificación:** 15EE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Aprobar la clase resistente de la tapa según su ubicación; no basta con especificar únicamente que es de fundición.

## Definición

### Criterio de la ficha y complemento técnico

Registros para facilitar tendido, derivaciones autorizadas y mantenimiento del cableado de alumbrado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 359–361. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Las redes se instalarán discurriendo en todo su trazado por terrenos de acceso públicos, como viales no accesibles al tráfico rodado, lo harán a una profundidad mínima de 0,4 metros medidos desde la generatriz superior del tubo hasta solería o revestimiento terminado, se colocara una cinta señalizadora que advierta de la existencia de cable de alumbrado exterior, situada a una distancia mínima del nivel del suelo de 0,10 m y a 0,25 m por encima del tubo, y aumentándose la profundidad a 0.6 metros y reforzándose con prisma de hormigón en masa de 200 Kg./cm² de 15 cm de espesor en los cruces de los viales o zonas aptas para el tráfico rodado. Se instalará una canalización vacía de las mismas características antes mencionadas para posibles ampliaciones de la instalación, indicada en los planos como Las arquetas serán de 0,40 x 0,40 x 0,50 m, para derivaciones y cambios de dirección, y de 0,60 x 0,60 x 0,50 m en cruces de calzada.
Se dispondrán de arquetas o registros en número suficiente para la colocación y reposición de los conductores.
Las tapaderas serán de fundición, en el fondo de todas las arquetas se colocará un lecho absorbente.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Construir con dimensiones aprobadas, entradas de conductos sin aristas y drenaje compatible con el terreno y el servicio. Colocar tapa resistente a las cargas y a rasante; los empalmes autorizados deberán garantizar continuidad, aislamiento y estanqueidad conforme al REBT.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 362–363. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

EJECUCIÓN DE OBRA
Las instalaciones y puesta en obra de los tubos protectores deberán cumplir según ITBT 21 y en su defecto lo prescrito en la norma UNE 20460 5 523 y en la ITC BT 19 y ITC BT 20.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1018–1022. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ARQUETAS
Las arquetas se construirán con el tipo de hormigón indicado en los planos, tanto para la solera como para alzados y cuando así se indique en los planos se construirán de fábrica de ladrillo macizo, enfoscadas interiormente.
Cuando sean de hormigón, el espesor de las soleras y los alzados será al menos de veinte (20) centímetros.
En caso de construirse de fábrica de ladrillo no será inferior a diez (10) centímetros.
En general, se tendrán en cuenta las especificaciones según la Norma Tecnológica de la Edificación NTE/ISS, y siguiendo las especificaciones de los planos.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por ud realmente terminada con excavación, cuerpo, cerco y tapa conforme a 3.17.4, comprobando que no estén ya incluidos en otra unidad.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 364–367. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
La canalización se medirá por m.l. realmente ejecutado. El precio comprende la excavación de la zanja en cualquier tipo de terreno, reposición de acera o calzada si procede el caso, arena en lecho y protección de los tubos necesarios, la cinta de señalización, el relleno y compactación de la zanja al 95% del Proctor modificado, el alambre guía incluso la protección en cruces si en el proyecto no se especifica dicha protección.
Se medirán por uds completamente terminadas realmente ejecutado.
El precio incluye la excavación necesaria, la arqueta, cerco y tapa según indicación de la D.T.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
