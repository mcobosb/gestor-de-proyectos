# Acometidas eléctricas de alumbrado

**Clasificación:** 15EA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Las prescripciones particulares de la distribuidora deben ser las aplicables y aprobadas, no las de una compañía citada históricamente.

## Definición

### Criterio de la ficha y complemento técnico

Enlace desde la red de distribución hasta los equipos de medida del alumbrado público.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 332–337. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### RED DE ALUMBRADO PÚBLICO
### ACOMETIDAS
DESCRIPCIÓN
La acometida podrá ser subterránea o aérea, según proceda, con cables aislados, y se realizará de acuerdo con las prescripciones particulares de la compañía suministradora.
La acometida enterrada irá a una profundidad mínima de 0,6 mts y se ejecutará según la ITC BT 07, el tubo empleado será de polietileno corrugado de doble pared y diámetro del tubo será según la tabla 9 de la ITC BT 21, normalmente de 90 mm de diámetro.
Los conductores serán del tipo RV 0.6/1kv en aluminio y enlazará desde la red de baja tensión arqueta próxima al C.T. o desde el cuadro de baja tensión del transformador, según aconseje la compañía, hasta los equipos de medida, donde se conectarán a través de los elementos bimetálicos adecuados que garanticen las conexiones y eviten la aparición de corrientes galvánicas y la restauración de los aislamientos mediante las cintas normal y vulcanizable.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Coordinar trazado y conexión con la distribuidora, ejecutar por empresa instaladora habilitada y aplicar ITC-BT-11 y las ITC-BT-06 o 07 según sea aérea o subterránea. Verificar sección, protección mecánica y terminales compatibles con aluminio y cobre. Realizar conexión sin tensión y comprobaciones reglamentarias.

### Referencias de aplicación

- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original separa m de canalización y m de conductor con conexionado, incluyendo en la canalización las operaciones auxiliares descritas. Ajustar la medición al presupuesto y no duplicar zanjas ni reposiciones.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 338–340. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

MEDICIÓN Y ABONO
La canalización se medirá por m.l. realmente ejecutado. El precio comprende la excavación de la zanja en cualquier tipo de terreno, reposición de acera o calzada si procede el caso, arena en lecho y protección de los tubos necesarios, la cinta de señalización, el relleno y compactación de la zanja al 95 % del Proctor modificado, el alambre guía incluso la protección en cruces si en el proyecto no se especifica dicha protección.
Los conductores se medirán por ml. Completamente terminados realmente ejecutado, incluso conexionado.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
