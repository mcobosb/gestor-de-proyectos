# transformadores

**Clasificación:** 15ET. **Capítulo:** urbanizaciones. **Familia:** electricidad.

## Definición

Elementos de urbanización y redes exteriores definidos por los planos, el presupuesto y las condiciones del titular del espacio o servicio.

El objeto de esta ficha es «transformadores», dentro de «electricidad». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán emplazamiento, sección, materiales, cargas, servicios afectados y criterios del titular. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Coordinar replanteo y servicios existentes, mantener itinerarios seguros y ejecutar por fases compatibles con el tráfico y otras redes. Revisar apoyos, cotas y encuentros antes de ocultar elementos y reponer las superficies afectadas.

### Condiciones de esta clasificación

Coordinar con el titular eléctrico; comprobar canalizaciones, puesta a tierra y protecciones antes de la puesta en servicio. Aplicar reglamentación de alta tensión y condiciones del distribuidor cuando corresponda; el REBT no basta para definir un centro de transformación.

Para la variante «transformadores» se comprobarán expresamente tensión, potencia, titularidad y reglamentación eléctrica correspondiente; tensión, potencia, esquema, protecciones y autorizaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar geometría, funcionalidad, accesibilidad y recepción por el titular; documentar trazados y elementos ocultos mediante planos finales.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

ud de transformador de potencia, tensiones y características definidas, instalado y con las pruebas de recepción previstas. Si la partida comprende un centro de transformación completo, detallar celdas, protecciones, tierra, ventilación, obra civil, conexiones y puesta en servicio incluidas, sin abonar nuevamente esos componentes.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
