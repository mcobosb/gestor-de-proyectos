# Siembras y resiembras

**Clasificación:** 15JT. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original menciona siembras pero no define mezcla, dosis ni criterio de aceptación. Son decisiones de proyecto pendientes, no datos que pueda suplir una norma general.

## Definición

### Criterio de la ficha y complemento técnico

Implantación de cobertura vegetal por siembra, citada en las obligaciones de garantía y reposición.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1055–1058. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### Plazo de Garantía de las plantaciones y siembras.
Será el que se especifique en el Contrato, contado a partir de la fecha de recepción de las plantaciones.
Durante dicho período de garantía serán de cuenta del Contratista la reposición de marras y la resiembra de las superficies falladas.
Cuando el porcentaje de marras producido durante el período de garantía sea superior al cuarenta por ciento (40%) de la plantación efectuada, el período de garantía contará a partir de la reposición de las marras antedichas.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Definir previamente especies, mezcla, dosis y época compatibles con clima, suelo y uso. Preparar la tierra vegetal, sembrar uniformemente, cubrir según semilla y regar sin arrastre; mantener humedad y proteger hasta establecimiento. Reponer superficies falladas en las condiciones de garantía.

### Referencias de aplicación

- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Si existe partida, proponer m² de superficie sembrada y aceptada según sus condiciones; las resiembras de garantía previstas no generan un nuevo abono.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1172–1173. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### JARDINERÍA
La medición y abono de las unidades del capítulo de jardinería se hará por el sistema de precios unitarios de acuerdo con los indicados en el Cuadro de Precios nº 1 y aplicados al número de unidades de la misma.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
