# Enmiendas orgánicas: estiércol, compost y turba

**Clasificación:** 15JW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Esta ficha no valida cualquier compost o estiércol ni supone que un residuo pueda aplicarse al suelo sin cumplir su régimen específico.

## Definición

### Criterio de la ficha y complemento técnico

Materiales orgánicos citados para acondicionar la tierra vegetal y los hoyos de plantación.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1067–1068. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

3. Extracción de la tierra vegetal.
    4. Colocación de la tierra vegetal original en pequeños montones, no mayores de doscientos decímetros cúbicos (200 dm³) para su mezcla manual o con un equipo mezclador mecánico de la tierra vegetal con las debidas cantidades de estiércol, compost o turba. En todo caso debe garantizarse una mezcla suficientemente uniforme como para que no progrese su grado de homogeneidad con la reiteración del proceso de mezclado.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Identificar origen y aptitud del producto, verificar madurez, salinidad y ausencia de contaminantes, semillas indeseadas y riesgos sanitarios conforme a la especificación aprobada. Ajustar dosis al análisis del suelo y especie y mezclar uniformemente evitando contacto perjudicial con las raíces. Si proceden de residuos, verificar antes su régimen legal de uso.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1045–1045. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Se incorporará en los hoyos medio (0,5) kilogramo de estiércol. Encima se situará una capa de tierra vegetal, para que no haya contacto directo entre el estiércol y las raíces de la planta, operación que se debe hacer con esmero, puesto que si el contacto se verifica, las raíces se queman.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1083–1091. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

ENMIENDA ORGÁNICA
Para verificar las características de las enmiendas aportadas se realizarán las pruebas siguientes:
- Densidad
- Presencia de semillas de adventicias
- Riqueza en nitrógeno
- Grado de descomposición
- Color, consistencia y humedad
### CONTROL DE CALIDAD
El Director podrá ordenar la realización de aquellos ensayos y pruebas que juzgue oportunos para verificar el cumplimiento de las especificaciones exigidas en el presente artículo.

### Referencias de aplicación

- [Real Decreto 506/2013, sobre productos fertilizantes: identificación, requisitos y régimen aplicable a abonos y enmiendas comercializados conforme a esta vía. Comprobar el régimen del producto concreto; no sustituye al análisis del suelo ni define dosis universales.](https://www.boe.es/buscar/act.php?id=BOE-A-2013-7540)
- [Ley 7/2022, de residuos y suelos contaminados para una economía circular: jerarquía, separación, trazabilidad y gestión autorizada de residuos.](https://www.boe.es/buscar/act.php?id=BOE-A-2022-5809)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Incluidas en la preparación de tierra vegetal o plantación cuando así se define la partida; no abonables de nuevo por su ficha de material.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1172–1173. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### JARDINERÍA
La medición y abono de las unidades del capítulo de jardinería se hará por el sistema de precios unitarios de acuerdo con los indicados en el Cuadro de Precios nº 1 y aplicados al número de unidades de la misma.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
