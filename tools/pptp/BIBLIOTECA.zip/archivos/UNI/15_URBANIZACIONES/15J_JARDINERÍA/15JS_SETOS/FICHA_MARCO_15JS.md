# setos

**Clasificación:** 15JS. **Capítulo:** urbanizaciones. **Familia:** jardinería.

## Definición

Elementos de urbanización y redes exteriores definidos por los planos, el presupuesto y las condiciones del titular del espacio o servicio.

El objeto de esta ficha es «setos», dentro de «jardinería». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán emplazamiento, sección, materiales, cargas, servicios afectados y criterios del titular. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Coordinar replanteo y servicios existentes, mantener itinerarios seguros y ejecutar por fases compatibles con el tráfico y otras redes. Revisar apoyos, cotas y encuentros antes de ocultar elementos y reponer las superficies afectadas.

### Condiciones de esta clasificación

Comprobar suelo, drenaje y estado fitosanitario; plantar en época compatible, regar y mantener hasta la recepción prevista. Replantear alineación y densidad y prever desarrollo del seto sin invadir recorridos ni visibilidad.

Para la variante «setos» se comprobarán expresamente especie, formato, suelo, riego y periodo de establecimiento; especie, marco, altura y mantenimiento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar geometría, funcionalidad, accesibilidad y recepción por el titular; documentar trazados y elementos ocultos mediante planos finales.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

Árboles y plantas aisladas: ud aceptada por especie y formato; setos: m con densidad definida; tapizantes: m² de superficie implantada. Precisar tierra, tutorado, riego, reposición de marras y mantenimiento incluidos y los hitos de recepción.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
