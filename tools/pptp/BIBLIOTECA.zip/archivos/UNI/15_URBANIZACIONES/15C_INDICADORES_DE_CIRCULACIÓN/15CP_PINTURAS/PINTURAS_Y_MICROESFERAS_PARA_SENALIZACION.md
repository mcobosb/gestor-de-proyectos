# Pinturas y microesferas para señalización horizontal

**Clasificación:** 15CP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Confirmar las designaciones y dotaciones ambiguas del original antes de aprobar el producto.

## Definición

### Criterio de la ficha y complemento técnico

Material base y productos de postmezclado para obtener las prestaciones de las marcas viales.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 527–530. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### LA PINTURA A UTILIZAR EN SEÑALIZACIÓN HORIZONTAL SERÁ:
Marcas longitudinales en pintura acrílica termoplástica en disolución, con 720 gr/m² de pintura y 480 gr/m² de microesferas, aplicada con maquinaria automática.
Marcas transversales con pintura plástica en frío de dos componentes, con 3.000 gr/m² de microesferas, aplicada manualmente.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Recepcionar productos identificados, compatibles entre sí y con el soporte, con prestaciones y documentación exigibles. Almacenar dentro de condiciones y vida útil del fabricante y dosificar con equipo calibrado conforme al sistema aprobado y al artículo 700 del PG-3. Gestionar envases y restos según su clasificación.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1092–1094. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MARCAS VIALES
Cumplirán, en todo, las normas exigidas en el PG 3.
Se situarán en los sitios marcados en los Planos o que indique el Director de la obra.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)
- [Ley 7/2022, de residuos y suelos contaminados para una economía circular: jerarquía, separación, trazabilidad y gestión autorizada de residuos.](https://www.boe.es/buscar/act.php?id=BOE-A-2022-5809)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Materiales incluidos en las unidades de marca vial; no tienen abono adicional por su ficha independiente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 531–534. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
La señalización, tanto horizontal como vertical, de todo el proyecto, será medida y abonada de acuerdo con los precios unitarios del proyecto. Se considerarán incluidos en los precios de las unidades de obra todo el material auxiliar necesario para la completa ejecución de las mismas, como pueden ser tornillos, remaches, soldaduras, pinturas, hincas, etc., no habiendo lugar, en ningún caso, a su abono independiente.
La medición y abono de las marcas viales longitudinales se hará por metros lineales (ml) realmente pintados. La medición y abono de las marcas viales en cebra se hará por unidades (uds) y por metros cuadrados (m²), de acuerdo con los precios unitarios.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
