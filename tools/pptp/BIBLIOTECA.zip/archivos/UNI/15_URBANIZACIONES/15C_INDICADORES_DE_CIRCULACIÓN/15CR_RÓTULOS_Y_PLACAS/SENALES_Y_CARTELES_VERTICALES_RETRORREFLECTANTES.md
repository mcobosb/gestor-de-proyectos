# Señales y carteles verticales retrorreflectantes

**Clasificación:** 15CR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La «reflectancia nivel 3ª» no define inequívocamente una clase de producto actual. Verificar también los símbolos y catálogo vigentes con la autoridad de tráfico, sin perpetuar señales obsoletas.

## Definición

### Criterio de la ficha y complemento técnico

Placas, señales y carteles de circulación con sus soportes y anclajes, de formas y dimensiones definidas en el proyecto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 508–526. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### SEÑALIZACIÓN
### CARACTERÍSTICAS DE LOS MATERIALES
Las características geométricas de las señales a utilizar serán las siguientes:
- Señal circular Diámetro 0,60 metros
- Señal triangular Lado 0,90 metros
- Señal cuadrada Lado 0,60 metros
- Señal octogonal Doble apotema 0,90 metros
- Señal rectangular 0,90*1,35 metros
### LAS CARACTERÍSTICAS TÉCNICAS DE LAS SEÑALES SERÁN LAS SIGUIENTES
- Chapa de acero galvanizado de 1,8 mm.
- Pestaña de 25 mm
- Símbolo no troquelado en chapa.
- Parte posterior: capa de pintura
- Parte delantera: imprimación y esmalte normal en color
- Lamina reflectante con el símbolo generalmente calado.
- Tortillería de acero cincado
- Abrazadera de acero pregalvanizado de 1,8 mm
- Reflectancia nivel 3ª
- Soportes de acero galvanizado

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar catálogo y diseño de señal vigentes, material, retrorreflexión y documentación de producto. Replantear visibilidad, gálibos y accesibilidad; ejecutar cimentación y soportes y orientar las placas sin interferir con el itinerario peatonal. Aplicar el artículo 701 del PG-3 en el ámbito previsto por el proyecto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1095–1096. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### CARTELES INDICADORES CON PINTURA REFLECTANTE
La forma, calidad y dimensiones de las señales de tráfico y carteles indicadores, tanto en lo que se refiere a las placas como a sus elementos de sustentación y anclajes, serán de los tipos actualmente aprobados por la Dirección General de Carreteras del Ministerio de Fomento, y se colocarán en sitios marcados en Planos o que indique el Director de la obra.

### Referencias de aplicación

- [PG-3: materiales, firmes y señalización; Orden FOM/2523/2014, artículos concretos indicados en la ficha. Referencia técnica incorporada por el pliego; comprobar las modificaciones y el régimen transitorio aplicables al proyecto.](https://www.boe.es/buscar/doc.php?id=BOE-A-2015-48)
- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por las unidades de señal o superficies de cartel que defina el cuadro de precios, incluidos soportes, fijaciones y operaciones auxiliares. El original no permite asignar una unidad económica única a toda señalización.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 531–534. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
La señalización, tanto horizontal como vertical, de todo el proyecto, será medida y abonada de acuerdo con los precios unitarios del proyecto. Se considerarán incluidos en los precios de las unidades de obra todo el material auxiliar necesario para la completa ejecución de las mismas, como pueden ser tornillos, remaches, soldaduras, pinturas, hincas, etc., no habiendo lugar, en ningún caso, a su abono independiente.
La medición y abono de las marcas viales longitudinales se hará por metros lineales (ml) realmente pintados. La medición y abono de las marcas viales en cebra se hará por unidades (uds) y por metros cuadrados (m²), de acuerdo con los precios unitarios.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
