# Tapas, marcos y rejillas de fundición

**Clasificación:** 15AP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Las normas antiguas y pesos mínimos de tapas del original no sustituyen la clase de producto. D400 se cita para calzada; no debe extenderse sin comprobar grupos y ubicación a cualquier registro.

## Definición

### Criterio de la ficha y complemento técnico

Elementos de cierre y captación de registros y sumideros, con clase resistente y geometría adecuadas al lugar de instalación.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 245–248. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Constarán siempre de tapa y marco. La tapa entrará dentro del marco, quedando enrasada con el mismo y con el pavimento y dispondrán de marca de fabricante, grabada en la tapa. La pestaña de apoyo de la tapa tendrá una anchura mínima de 8 mm.
Se instalarán dos modelos de tapas de registro:
- Registros en aceras. Serán de forma cuadrada de 60 x 60 cm mínimo. (El peso de la tapa no será inferior a 16 Kg). Este trampillón, que permite una colocación fácil de los terrazos de las aceras, se instalará solamente en ellas y para accesorios que permitan su fácil desmontaje en una arqueta de tales dimensiones, excepto válvulas dispuestas con trampillón.
- Registros en calzadas. Serán de forma redonda y la luz de diámetro 60 cm, para colocarlos en las calzadas, o cuando las medidas de los accesorios a colocar sean superiores a 100 mm o la profundidad superior a 1 m, clase D400. Cumplirá la norma europea EN 124 D400, soportando una carga de rotura de 40 Mgf, así como la norma UNE 41 300 87.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar producto y clase de carga según ubicación y partes aplicables de la serie UNE-EN 124, verificando edición y material. Recibir el marco sobre apoyo continuo, asegurar asiento y estabilidad y dejar a rasante sin resaltes ni balanceo. En itinerarios peatonales, cumplir las condiciones de accesibilidad y abertura y orientación de rejillas de la Orden TMA/851/2021.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 278–285. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

La tapa de la arqueta no sobresaldrá de la rasante de la calle y llevará impreso “Abastecimiento de Agua” o “Agua Potable”. Estarán provistas de taladros para facilitar el levantamiento. Serán de fundición y deberán ser capaces de resistir las cargas móviles reguladas en la norma UNE 82-211-83.
Se prohíben expresamente los pates conformados con acero para la construcción, debiendo ser pates fabricados específicamente como tales, en material inoxidable, de acero forrado de polipropileno o similares.
La cámara que deba construirse en calzada tendrá las siguientes características: 
- Solera: de 15 cm de espesor de hormigón de resistencia característica de 100 Kg/cm².
- Muros: De hormigón de resistencia característica de 250 Kg/cm² y 20 cm de espesor, a los que se dispondrá de armadura de reparto según las cuantías mínimas definidas en el CODIGO ESTRUCTURAL.
- Acabado: Enfoscado sin maestrear de paredes con mortero 1:3 de 15 mm de espesor con  acabado bruñido. Ángulos redondeados.
Las paredes de la arqueta no se apoyarán en ningún caso sobre las tuberías, haciéndose pasamuros.
INSTALACIÓN DE TUBERÍA

### Referencias de aplicación

- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por ud sólo cuando exista partida independiente según 5.17. Si cerco, tapa o rejilla ya están incluidos en pozo, arqueta o imbornal, no procede abono adicional.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 161–163. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Los pozos de registro se abonarán por ml realmente ejecutados, independientemente de altura total que tengan.
En esta unidad está incluida el cerco y tapa de fundición, salvo indicación en contra en el Presupuesto. En este caso no se abonarán los ml de cada pozo hasta no esté recibido el cerco y colocada la tapa. Asimismo, queda incluido dentro de la unidad el coste de personalización de arquetas según indique la Dirección Facultativa.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 168–170. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirán y abonarán por unidades completamente terminadas.
En esta unidad se encuentra incluida la rejilla, el bordillo buzón, la arqueta de recogida, el sifón en caso de sistema unitario, la tubería de conexión con los pozos de los colectores generales, así como la excavación, asiento, relleno y compactación de la zanja.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1160–1161. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### TAPAS DE ARQUETAS Y POZOS
Se medirán y abonarán por unidades realmente ejecutadas (ud) con arreglo a este proyecto y las órdenes escritas del Director de la Obra, y se aplicarán los diferentes precios para cada una de ellas, en función a sus dimensiones, resistencia exigida o tipología.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
