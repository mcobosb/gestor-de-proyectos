# Pozos de registro de saneamiento

**Clasificación:** 15AP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La frase «por ml ... independientemente de altura total» requiere aclaración. Revisar también el conflicto entre HA-25 de 3.12 y 35 MPa para pozos prefabricados de 4.13.2.

## Definición

### Criterio de la ficha y complemento técnico

Pozos de acceso y conexión de colectores de saneamiento, prefabricados o ejecutados in situ.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 151–153. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ARQUETAS Y POZOS DE REGISTRO
### DESCRIPCIÓN
Se definen como las obras que completan el sistema de drenaje, ejecutadas en obra de fábrica donde ingieren otros colectores, acometidas, etc.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Construir la base y canal de paso, disponer juntas y conexiones estancas y ejecutar el fuste y coronación conforme al cálculo y los planos. Comprobar la documentación de prefabricados, habitualmente bajo UNE-EN 1917 según producto, y de pates y tapas. No acceder al pozo sin medidas específicas frente a atmósferas peligrosas y caídas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 154–160. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EJECUCIÓN DE LAS OBRAS
Para su ejecución se utilizará hormigón HM 20 y ladrillo macizo.
En caso de ejecutarse con elementos prefabricados se utilizarán hormigones mínimos de HA 25.
El fondo de los pozos de registro se ejecutará con hormigón, formando un caz para la circulación de agua, y evitar el depósito de suciedad.
Se enfoscarán interiormente con mortero de cemento.
Se colocarán pates de acero forrados con polipropileno en pozos con altura superior a 1.20 m de altura.
Los pozos prefabricados en hormigón tendrán junta de goma y cumplirán con la normativa UNE 127011.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1018–1022. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ARQUETAS
Las arquetas se construirán con el tipo de hormigón indicado en los planos, tanto para la solera como para alzados y cuando así se indique en los planos se construirán de fábrica de ladrillo macizo, enfoscadas interiormente.
Cuando sean de hormigón, el espesor de las soleras y los alzados será al menos de veinte (20) centímetros.
En caso de construirse de fábrica de ladrillo no será inferior a diez (10) centímetros.
En general, se tendrán en cuenta las especificaciones según la Norma Tecnológica de la Edificación NTE/ISS, y siguiendo las especificaciones de los planos.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original prescribe metro lineal de pozo ejecutado e incluye cerco y tapa salvo exclusión del presupuesto. Confirmar el criterio geométrico y su correspondencia con el cuadro de precios.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 161–163. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Los pozos de registro se abonarán por ml realmente ejecutados, independientemente de altura total que tengan.
En esta unidad está incluida el cerco y tapa de fundición, salvo indicación en contra en el Presupuesto. En este caso no se abonarán los ml de cada pozo hasta no esté recibido el cerco y colocada la tapa. Asimismo, queda incluido dentro de la unidad el coste de personalización de arquetas según indique la Dirección Facultativa.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1160–1161. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### TAPAS DE ARQUETAS Y POZOS
Se medirán y abonarán por unidades realmente ejecutadas (ud) con arreglo a este proyecto y las órdenes escritas del Director de la Obra, y se aplicarán los diferentes precios para cada una de ellas, en función a sus dimensiones, resistencia exigida o tipología.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
