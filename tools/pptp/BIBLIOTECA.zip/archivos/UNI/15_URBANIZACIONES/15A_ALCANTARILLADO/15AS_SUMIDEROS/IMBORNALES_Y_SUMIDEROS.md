# Imbornales y sumideros

**Clasificación:** 15AS. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La resistencia del cuerpo y del asiento debe ajustarse al proyecto; no adoptar el hormigón de 15 MPa mencionado genéricamente en 4.13 para un elemento estructural.

## Definición

### Criterio de la ficha y complemento técnico

Elementos de recogida de escorrentía superficial y conexión con los colectores, situados en los puntos bajos efectivos.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 164–167. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### IMBORNALES
### DESCRIPCIÓN
Son los elementos que se ejecutarán para la recogida de la escorrentía superficial de los viales.
Se situarán comprobando que se colocan en los puntos más bajos de la calzada, aunque no coincidan con las referencias de los planos.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar cotas y captación antes de colocar. Ejecutar apoyo, cuerpo y conexión estanca con pendiente adecuada, colocar sifón cuando corresponda y recibir cerco y rejilla sin resaltes. Verificar capacidad de drenaje, limpieza y compatibilidad con el tránsito y la accesibilidad conforme a la Orden TMA/851/2021.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Orden TMA/851/2021: condiciones básicas de accesibilidad de los espacios públicos urbanizados, especialmente pavimentos, rejillas, registros e itinerarios peatonales. Comprobar también la normativa autonómica y local aplicable.](https://www.boe.es/buscar/act.php?id=BOE-A-2021-13488)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en ud completamente terminada, incluida rejilla, bordillo buzón, arqueta, sifón si procede y conexión con excavación y rellenos según 3.13.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 168–170. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirán y abonarán por unidades completamente terminadas.
En esta unidad se encuentra incluida la rejilla, el bordillo buzón, la arqueta de recogida, el sifón en caso de sistema unitario, la tubería de conexión con los pozos de los colectores generales, así como la excavación, asiento, relleno y compactación de la zanja.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
