# estructuras especiales

**Clasificación:** 05WE. **Capítulo:** estructuras. **Familia:** varios.

## Definición

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

El objeto de esta ficha es «estructuras especiales», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán acciones y cálculo, geometría, resistencia, exposición, protección, uniones y estabilidad durante la ejecución. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

### Condiciones de esta clasificación

Definir el sistema resistente y sus interfaces; las estructuras especiales y tratamientos requieren especificación propia.

Para la variante «estructuras especiales» se comprobarán expresamente sistema, materiales, fases, puntos de control y prestaciones. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

Aplicar la base de cada material: kg de acero de despiece, m³ de hormigón o madera, m² de forjado tipificado o de encofrado en contacto. Las estructuras completas necesitan un alcance cerrado para no repetir partidas de sus componentes.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
