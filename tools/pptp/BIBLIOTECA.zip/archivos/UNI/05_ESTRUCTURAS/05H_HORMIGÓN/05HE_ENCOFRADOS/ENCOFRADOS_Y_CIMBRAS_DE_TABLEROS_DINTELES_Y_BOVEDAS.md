# Encofrados y cimbras de tableros, dinteles y bóvedas

**Clasificación:** 05HE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El abono incluido no elimina la necesidad de justificar estructuralmente cimbras y apeos.

## Definición

### Criterio de la ficha y complemento técnico

Moldes y sistemas de apeo temporal para ejecutar elementos elevados de hormigón.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 432–439. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ENCOFRADOS
### GENERALIDADES
Los encofrados a emplear en las obras serán metálicos o de otro material rígido que reúna análogas condiciones de eficacia.
### DEFINICIÓN
Se definen los siguientes encofrados:
- Encofrado plano en paramentos verticales e inclinados.
- Encofrado curvo en paramentos verticales.
- Encofrado en tableros, dinteles y bóvedas.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Disponer proyecto o justificación del sistema de apeo según su entidad, apoyos resistentes y arriostramiento. Controlar montaje, deformaciones y secuencia de vertido y no retirar apoyos hasta comprobar la resistencia y autorizar el descimbrado conforme al Código Estructural. Prever las cargas de fases posteriores.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 903–906. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### DESENCOFRADO Y DESCIMBRADO
La retirada de apoyos en los encofrados no podrá hacerse antes de cumplir los plazos fijados por la vigente Instrucción. Para efectuar esta operación se precisará la autorización del Director de la Obra, el cual determinará la forma de proceder de acuerdo con las circunstancias de cada caso.
Cuando se trate de apoyos y encofrados laterales, el contratista se atendrá a las normas dadas por el Director de las Obras, según la temperatura y humedad del ambiente, relación agua/cemento  empleado y resultado de las probetas ensayo, al objeto de que el desencofrado se efectúe cuando convenga al curado del hormigón y necesidades de la obra, sin la posibilidad de que sufra distorsiones o daños por dicha causa. 
No se enlucirá ni se taparán los defectos o coqueras que aparezcan sin la autorización del Director de la Obra, quién resolverá en cada caso la forma de corregir el defecto.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m² de contacto de encofrado con el hormigón según 3.22, incluyendo cimbras y las operaciones descritas salvo partida específica contractual.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 440–441. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirán y abonarán los metros cuadrados (m²) de encofrado en cada tipo empleado en obra, deducidos de los planos de construcción, por las superficies de hormigón que han de contener. Incluye, igualmente, el precio unitario las operaciones de encofrado, desencofrado, limpieza de encofrado, cimbras y cuantas operaciones se requieran para que las obras sean acordes con los planos de construcción y el Pliego de Prescripciones.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
