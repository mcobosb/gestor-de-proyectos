# Hormigón de 35 MPa para elementos prefabricados

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** 3.12 menciona HA-25 para prefabricados y 4.13.2 prescribe 35 MPa. Confirmar con planos, cálculo y producto; no certificar equivalencia entre ambos.

## Definición

### Criterio de la ficha y complemento técnico

Hormigón al que el original asigna resistencia de 35 N/mm² en pozos de saneamiento y otros elementos prefabricados.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 848–852. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### UTILIZACIÓN Y PUESTA EN OBRA
Como norma general, la utilización de los distintos hormigones se efectuará atendiendo a la siguiente relación:
- Hormigón con una resistencia de 35 N/mm2:
- Pozos de saneamiento prefabricados.
- Elementos prefabricados.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Completar la designación y exposición según el elemento; comprobar documentación del prefabricado, resistencia, durabilidad y uniones bajo su norma de producto y el Código Estructural cuando corresponda. No confundir resistencia del hormigón con capacidad resistente de todo el producto.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Instrucción para la recepción de cementos RC-16, aprobada por Real Decreto 256/2016.](https://www.boe.es/buscar/doc.php?id=BOE-A-2016-6167)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Normalmente integrado en el precio del prefabricado o del pozo. Sólo por m³ si existe una partida específica de ese hormigón, sin duplicar el producto completo.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
