# Hormigón de 30 MPa para losas de aparcamiento y rigolas

**Clasificación:** 05HH. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Los 30 MPa no constituyen una designación completa ni fijan espesor o armado.

## Definición

### Criterio de la ficha y complemento técnico

Hormigón de resistencia indicada de 30 N/mm² para losas de aparcamiento y rigolas citadas en 4.13.2.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 853–855. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

- Hormigón con una resistencia de 30 N/mm2:
- Losas de aparcamiento.
- Rigolas.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Definir sección, armadura, juntas y exposición del elemento. Preparar soporte, colocar y compactar sin segregación, ejecutar acabado, pendientes y juntas y asegurar curado. Cuando se requiera resistencia a flexotracción, comprobarla según proyecto y no deducirla sólo de la compresión.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 879–894. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Los hormigones de los elementos prefabricados (bordillos, caz, etc.) tendrán una resistencia al desgaste, según la norma UNE 7015 y con un recorrido de doscientos cincuenta metros (250 m.), inferior a dos con cincuenta milímetros (2,50 mm).
Los hormigones empleados en losas de aparcamientos tendrán una resistencia característica a flexotracción de cuatro newton por milímetro cuadrado (4 N/mm2).
Los hormigones que deberán utilizarse cuando exista peligro de ataque por aguas selenitosas, o existan contactos con terrenos yesíferos, deberán contener la dosificación adecuada de cemento Portland resistente al yeso (denominación SR).
Los citados hormigones, como norma general, deberán adoptarse cuando el porcentaje de sulfato soluble en agua expresado en SO4 de las muestras del suelo sea superior al cero con dos por ciento (0,2 %); o cuando en las muestras de agua del subsuelo, el contenido en SO4 sea superior a cuatrocientas partes por millón (0,04 %). El cemento a emplear será I 42,5/SR (UNE 80303). 
La consistencia de todos los hormigones que se utilicen, salvo circunstancias justificadas ante la Inspección de la obra, será plástica corresponderá a un asiento del cono de Abrams comprendido entre tres (3) centímetros y cinco (5)centímetros con una tolerancia de _1.
En zanjas, rellenos de trasdos, etc., serán de consistencia blanda (asiento 6 9 centímetros) e incluso fluida (asiento10 15 centímetros).
En condiciones ambientales normales (no calurosas) el tiempo transcurrido entre la adición de agua del amasado al cemento y a los áridos y la colocación del hormigón, no será mayor de una hora y media (1 1/2 h).
Los hormigones de central transportados por cubas agitadoras, deberán ponerse en obra dentro de la hora y media posterior a la adición de agua del amasado, no siendo admisibles los amasijos con un tiempo superior. Cada carga de hormigón fabricado en central irá acompañada de una hoja de suministro que estará en todo momento a disposición de la Inspección Facultativa.
El recubrimiento nominal de las armaduras de los hormigones en función de la clase de exposición ambiental, para conseguir una adecuada durabilidad, seré el siguiente:
[Falta el recubrimiento nominal]
Todos los hormigones se compactarán y curarán debidamente. A título orientativo el método de compactación adecuado para hormigones plásticos es la vibración normal. La duración mínima del curado será de 5 días. La altura máxima de vertido libre del hormigón, será de un metro (1 m.). Deberá suspenderse el hormigonado cuando la temperatura de ambiente sea superior a cuarenta grados centígrados (40 ºC) y siempre que se prevea que, dentro de las cuarenta y ocho horas (48 h.) siguientes, pueda descender la temperatura ambiente por debajo de cero grados centígrados (0 ºC).
### JUNTAS Y TERMINACIÓN
En las losas de aparcamientos, deberán disponerse juntas de retracción a distancias inferiores a seis metros (6 m.), disponiendo las superficies de encuentro a testa y sellando las juntas horizontales con un mástic bituminoso. Las juntas de hormigonado, deberán ajustarse siempre que sea posible a las de retracción, y en caso contrario, deberán adoptarse las medidas necesarias para asegurar la perfecta unión de las masas en contacto y obtener una correcta superficie vista.
La parada en el proceso de hormigonado superior a treinta minutos (30 min.), requerirá realizar una junta de hormigonado correctamente dispuesta en el punto en que se encuentra la unidad, si técnicamente es admisible. Si no fuera admisible dicha junta, deberá demolerse lo ejecutado hasta el punto donde se pueda realizar.
Todos los muros deberán disponer de mechinales y de berenjenos en los lugares que disponga la Inspección de la obra.
Los defectos deberán ser corregidos por cuenta del Contratista, de acuerdo con las indicaciones de la Inspección de la obra.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Instrucción para la recepción de cementos RC-16, aprobada por Real Decreto 256/2016.](https://www.boe.es/buscar/doc.php?id=BOE-A-2016-6167)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Integrado en la unidad de losa o rigola si se abona completa; por m³ únicamente cuando así lo defina el presupuesto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 912–913. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
En los casos en que estas unidades sean objeto de abono independiente, se medirán de acuerdo con lo especificado en los planos y se abonarán al precio correspondiente que para cada tipo de hormigón figura en el Cuadro de Precios número UNO, que incluye el hormigón, transporte, colocación, compactación, curado, juntas, mechinales, berenjenos y demás operaciones complementarias para la total terminación de la unidad, así como excesos debido a sobreexcavaciones propias del método de ejecución o no justificados a juicio de la Inspección de la obra.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
