# Armaduras de acero corrugado para hormigón

**Clasificación:** 05HA. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** 3.23 incluye mermas, despuntes y solapes; 5.13 admite hasta un 5 % adicional. No aplicar ambos criterios acumulativamente. Los 5.100 kg/cm² no identifican por sí solos una clase de acero aprobada.

## Definición

### Criterio de la ficha y complemento técnico

Barras corrugadas para armar los elementos de hormigón conforme al Código Estructural y a los despieces aprobados.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 442–444. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ARMADURAS PARA HORMIGÓN ARMADO
### MATERIALES
Serán barras corrugadas de límite elástico 5.100 Kg/cm² y cumplirá con el Código Estructural.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Recibir acero identificado y trazable con documentación y controles exigibles. Cortar, doblar y montar conforme a planos sin calentamiento o soldadura no autorizados. Mantener posición mediante atado y separadores adecuados; comprobar anclajes, solapos y recubrimientos antes de hormigonar. El recubrimiento nominal será c_nom = c_min + Δc_dev según exposición y control, no un valor universal.

### Referencias de aplicación

- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por kg deducidos de los planos de construcción y masas nominales de cada diámetro. Resolver el tratamiento de solapes y despuntes conforme a la partida antes de certificar.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 445–446. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por kilogramos (Kg), realmente colocados en obra, deducidos de los planos de construcción. En el precio de la unidad está incluido el abono de las mermas, despuntes y solapes.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1148–1150. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ACERO PARA ARMADURAS
Las armaduras de acero empleadas en hormigón armado se medirán por kilogramos (kg), realmente empleados, deducidos de los planos de construcción, en las mediciones del proyecto por medición de su longitud y aplicando los pesos unitarios correspondientes a los distintos diámetros empleados. A estas mediciones podrá aplicárseles como máximo, un cinco por ciento (5%) de aumento, en concepto de empalmes de despuntes.
El abono se efectuará de acuerdo con los precios indicados en el presupuesto, en el que se incluyen las partidas de adquisición del material, corte, doblado y colocación del mismo.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
