# varios

**Clasificación:** 05AW. **Capítulo:** estructuras. **Familia:** acero.

## Definición

Elementos resistentes y componentes de estructuras definidos por cálculo y planos de montaje o de armado aprobados.

Esta categoría es residual: no identifica por sí sola una unidad de obra. Es obligatorio concretar el elemento, material y operación antes de usar la ficha en un contrato.

Antes de incorporarla al pliego se concretarán acciones y cálculo, geometría, resistencia, exposición, protección, uniones y estabilidad durante la ejecución. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Aprobar materiales, despieces y secuencia de montaje, incluidos apeos y estabilidad provisional. Ejecutar uniones y apoyos con personal competente, respetar juntas y proteger los materiales frente a humedad, corrosión o incendio según su función.

### Condiciones de esta clasificación

Verificar identificación de perfiles, uniones, apriete o soldadura, tolerancias de montaje y continuidad de la protección.

Para la variante «varios» se comprobarán expresamente clase de acero, ejecución, soldaduras, tornillos y protección anticorrosiva y de fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Inspeccionar geometría, apoyos y uniones antes de ocultarlos. Registrar lotes, controles de recepción y resultados del plan de control estructural.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

kg de acero conforme a despiece aprobado y a la regla contractual sobre longitudes y masa nominal; fijar tratamiento de empalmes, tornillos, soldaduras y mermas. No añadir pérdidas de taller ni protección si ya están incluidas en el precio.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
