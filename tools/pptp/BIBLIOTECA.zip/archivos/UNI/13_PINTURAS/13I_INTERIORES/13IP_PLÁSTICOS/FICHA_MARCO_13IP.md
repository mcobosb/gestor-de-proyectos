# plásticos

**Clasificación:** 13IP. **Capítulo:** pinturas. **Familia:** interiores.

## Definición

Sistemas de pintura, barniz o protección superficial sobre el soporte y en el ambiente especificados.

El objeto de esta ficha es «plásticos», dentro de «interiores». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán soporte, preparación, imprimación, número y espesor de capas, ambiente, color y prestación específica. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Identificar y preparar el soporte, eliminar partes no adheridas y comprobar humedad y condiciones ambientales. Aplicar imprimación y capas compatibles respetando consumos y tiempos del sistema aprobado, con ventilación y protección de zonas contiguas.

### Condiciones de esta clasificación

Comprobar compatibilidad con el soporte interior, ventilación y condiciones de uso y limpieza del local.

Para la variante «plásticos» se comprobarán expresamente soporte, acabado, emisiones y resistencia al uso. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar uniformidad, adherencia, cubrición y espesor del sistema cuando su función lo requiera; registrar producto, lote y condiciones de aplicación.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m² de superficie tratada con regla de huecos y desarrollo de elementos; piezas singulares en m o ud cuando se tipifiquen. Precisar preparación y capas incluidas, sin multiplicar la medición por número de manos.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
