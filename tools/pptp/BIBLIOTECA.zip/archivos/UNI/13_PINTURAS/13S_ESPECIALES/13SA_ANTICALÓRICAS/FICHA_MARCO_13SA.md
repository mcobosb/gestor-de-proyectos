# anticalóricas

**Clasificación:** 13SA. **Capítulo:** pinturas. **Familia:** especiales.

## Definición

Sistemas de pintura, barniz o protección superficial sobre el soporte y en el ambiente especificados.

El objeto de esta ficha es «anticalóricas», dentro de «especiales». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán soporte, preparación, imprimación, número y espesor de capas, ambiente, color y prestación específica. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Identificar y preparar el soporte, eliminar partes no adheridas y comprobar humedad y condiciones ambientales. Aplicar imprimación y capas compatibles respetando consumos y tiempos del sistema aprobado, con ventilación y protección de zonas contiguas.

### Condiciones de esta clasificación

Una pintura especial debe acreditar su prestación en el sistema, soporte y espesor prescritos; no aceptarla sólo por su denominación. Comprobar rango de temperatura y ciclos térmicos del recubrimiento, no sólo su denominación anticalórica.

Para la variante «anticalóricas» se comprobarán expresamente prestación especial, clasificación y espesor de película; temperatura de servicio, preparación y curado. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar uniformidad, adherencia, cubrición y espesor del sistema cuando su función lo requiera; registrar producto, lote y condiciones de aplicación.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m² de superficie tratada con regla de huecos y desarrollo de elementos; piezas singulares en m o ud cuando se tipifiquen. Precisar preparación y capas incluidas, sin multiplicar la medición por número de manos.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
