# rampas

**Clasificación:** 06WR. **Capítulo:** albañilería. **Familia:** varios.

## Definición

Fábricas, particiones, cerramientos y elementos auxiliares de albañilería con los materiales y la función definidos en proyecto.

El objeto de esta ficha es «rampas», dentro de «varios». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán función portante o no portante, tipo de pieza, mortero, espesor, juntas, arriostramiento y prestaciones del cerramiento. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Comprobar soporte, replanteo y modulación. Recibir las piezas con mortero o sistema compatible, resolver trabas, juntas, encuentros y anclajes y proteger la obra durante su endurecimiento. No cargar fábricas ni eliminar apeos antes de su aceptación.

### Condiciones de esta clasificación

Replantear el elemento auxiliar y comprobar su apoyo e integración con el resto de la obra. Comprobar continuidad del itinerario y encuentros, además de pendientes y acabado antideslizante exigibles.

Para la variante «rampas» se comprobarán expresamente geometría, soporte, armado y compatibilidad de materiales; pendientes, anchura, descansillos y protección de bordes. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Verificar plomo, nivel, espesor, juntas y conexiones con la estructura; comprobar prestaciones térmicas, acústicas, de fuego y de estanqueidad cuando sean exigibles.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

Habitualmente m² de fábrica o partición con espesor y composición definidos; elementos macizos especiales pueden medirse en m³ y remates en m o ud. Fijar la regla de huecos y el alcance de dinteles y anclajes en el presupuesto.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
