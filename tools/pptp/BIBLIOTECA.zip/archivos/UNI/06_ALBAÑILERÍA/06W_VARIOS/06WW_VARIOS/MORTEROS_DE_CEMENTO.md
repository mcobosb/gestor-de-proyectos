# Morteros de cemento

**Clasificación:** 06WW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La clase y el uso se deben precisar; las normas de mortero de fábrica y revestimiento no son intercambiables. Los 45 minutos del original se conservarán sólo si son compatibles con el sistema aprobado.

## Definición

### Criterio de la ficha y complemento técnico

Mezclas de cemento, áridos y agua para fábricas, revestimientos y juntas según su uso y las dosificaciones o clases prescritas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1059–1060. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MORTEROS DE CEMENTO
Deberán emplearse todos los tipos de morteros que figuran el los Cuadros de Precios y Presupuestos Parciales del Proyecto, con las dosificaciones que en dichos documentos se indican, las cuales podrán ser modificadas en forma adecuada por el Director de la obra si se producen circunstancias que lo aconsejen, sin que el Contratista tenga derecho a reclamar modificación en el precio de la unidad de obra correspondiente.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Seleccionar mortero compatible con soporte y exposición, verificar documentación del producto y cemento y dosificar de manera controlada. Amasar homogéneamente con agua adecuada, utilizar dentro del tiempo útil del sistema y desechar producto iniciado el fraguado. No rebatir para recuperar consistencia ni aplicar una receta de volumen sin comprobar la prestación exigida.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1061–1062. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

La mezcla podrá realizarse con medios mecánicos o a mano, en este caso sobre un piso impermeable. El amasado del mortero se hará de modo que resulte una mezcla homogénea y con la rapidez necesaria para que no tenga lugar un principio de fraguado antes de su empleo. La cantidad de agua será la necesaria para obtener una consistencia jugosa, sin que se forme en la superficie una capa de agua de espesor apreciable cuando se introduzca en una vasija y se sacuda ligeramente. Solamente se fabricará el mortero preciso para uso inmediato, desechándose todo aquel que haya empezado a fraguar y el que no haya sido empleado dentro de los cuarenta y cinco (45) minutos que sigan a su amasado. Se rechazarán asimismo, los morteros rebatidos.
Los morteros que se confeccionen para enlucido tendrán una consistencia menos fluida que los restantes, principalmente cuando las superficies en que hayan de ser empleados sean verticales o poco rugosas, sin que llegue a agrietarse al ser aplicado lanzándolo enérgicamente contra las paredes.

### Referencias de aplicación

- [Instrucción para la recepción de cementos RC-16, aprobada por Real Decreto 256/2016.](https://www.boe.es/buscar/doc.php?id=BOE-A-2016-6167)
- [Código Técnico de la Edificación, Real Decreto 314/2006. Su aplicación a fábricas se limita a su ámbito de edificación; no se presume obligatorio para toda obra civil.](https://www.boe.es/buscar/act.php?id=BOE-A-2006-5515)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original los integra en las unidades de fábrica, revestimiento o junta correspondientes. Sólo abonar suministro independiente si una partida lo define con su unidad y alcance.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1151–1156. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### FÁBRICA DE LADRILLO
Las obras de fábrica de ladrillo se medirán en metros cúbicos (mi) y siempre de acuerdo con las dimensiones indicadas en los planos o las modificaciones ordenadas por el Director de la Obra.
En ambos casos se abonará a los precios respectivos del presupuesto, en los que se encuentran incluidos los materiales, equipo y mano de obra necesarios para la completa terminación de la unidad.
### ENFOSCADOS Y ENLUCIDOS
Los enlucidos de las obras de fábrica, ya sea en hormigón o ladrillo se medirán por metro cuadrado (m2) realmente ejecutado.
El abono se efectuará aplicando a estas mediciones los precios que se indican en el presupuesto, en los que se incluyen los materiales y la colocación.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 188–189. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirán y abonarán por ml colocado realmente, quedando incluidos en este precio tanto el hormigón de base dispuesto según planos como el mortero necesario para el rejuntado.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
