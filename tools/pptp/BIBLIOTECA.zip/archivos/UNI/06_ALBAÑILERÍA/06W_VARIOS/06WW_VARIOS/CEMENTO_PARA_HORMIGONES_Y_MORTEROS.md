# Cemento para hormigones y morteros

**Clasificación:** 06WW. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La afirmación del original que vincula «endurecimiento rápido» a a/c ≤ 0,50 no es un criterio válido de clasificación del cemento. Confirmar la designación completa y la agresividad real.

## Definición

### Criterio de la ficha y complemento técnico

Conglomerante hidráulico de los hormigones y morteros; el original cita tipo I 42,5 y cemento resistente a sulfatos.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 735–735. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

El cemento a emplear será I 42,5 (UNE 80301), que a efectos del Codigo Estructural se trata de un cemento de endurecimiento rápido, siempre que su relación agua/cemento sea menor o igual que 0,50.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 881–882. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Los hormigones que deberán utilizarse cuando exista peligro de ataque por aguas selenitosas, o existan contactos con terrenos yesíferos, deberán contener la dosificación adecuada de cemento Portland resistente al yeso (denominación SR).
Los citados hormigones, como norma general, deberán adoptarse cuando el porcentaje de sulfato soluble en agua expresado en SO4 de las muestras del suelo sea superior al cero con dos por ciento (0,2 %); o cuando en las muestras de agua del subsuelo, el contenido en SO4 sea superior a cuatrocientas partes por millón (0,04 %). El cemento a emplear será I 42,5/SR (UNE 80303).

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Recibir e identificar según RC-16, comprobar documentación y compatibilidad con uso y exposición y almacenar protegido de humedad y contaminaciones. La velocidad de endurecimiento se determina por la designación y prestaciones del cemento, no por la relación agua/cemento del hormigón. Seleccionar resistencia a sulfatos a partir del ambiente y de las exigencias aplicables.

### Referencias de aplicación

- [Instrucción para la recepción de cementos RC-16, aprobada por Real Decreto 256/2016.](https://www.boe.es/buscar/doc.php?id=BOE-A-2016-6167)
- [Código Estructural, aprobado por Real Decreto 470/2021: recepción de materiales, durabilidad, ejecución y control. Artículos 33, 43, 44 y 48 a 66, según la unidad y su ámbito.](https://www.boe.es/buscar/doc.php?id=BOE-A-2021-13681)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Incluido en el hormigón o mortero; no genera abono separado salvo suministro previsto expresamente.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 448–451. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Se medirá y abonará por metros cúbicos (m³) de cada uno de los tipos realmente colocados en obra, medidos sobre los planos de construcción.
El control de calidad se realizará según el Código Estructural.
La exigencia por parte del Ingeniero Director de las obras de la adición de colorantes no dará lugar a la variación en el precio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1059–1062. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MORTEROS DE CEMENTO
Deberán emplearse todos los tipos de morteros que figuran el los Cuadros de Precios y Presupuestos Parciales del Proyecto, con las dosificaciones que en dichos documentos se indican, las cuales podrán ser modificadas en forma adecuada por el Director de la obra si se producen circunstancias que lo aconsejen, sin que el Contratista tenga derecho a reclamar modificación en el precio de la unidad de obra correspondiente.
La mezcla podrá realizarse con medios mecánicos o a mano, en este caso sobre un piso impermeable. El amasado del mortero se hará de modo que resulte una mezcla homogénea y con la rapidez necesaria para que no tenga lugar un principio de fraguado antes de su empleo. La cantidad de agua será la necesaria para obtener una consistencia jugosa, sin que se forme en la superficie una capa de agua de espesor apreciable cuando se introduzca en una vasija y se sacuda ligeramente. Solamente se fabricará el mortero preciso para uso inmediato, desechándose todo aquel que haya empezado a fraguar y el que no haya sido empleado dentro de los cuarenta y cinco (45) minutos que sigan a su amasado. Se rechazarán asimismo, los morteros rebatidos.
Los morteros que se confeccionen para enlucido tendrán una consistencia menos fluida que los restantes, principalmente cuando las superficies en que hayan de ser empleados sean verticales o poco rugosas, sin que llegue a agrietarse al ser aplicado lanzándolo enérgicamente contra las paredes.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
