# Mampostería ordinaria

**Clasificación:** 06CM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** La aplicación del CTE depende de que se trate de edificación. Los mechinales y el drenaje deben adecuarse al diseño, no únicamente a una regla genérica de número por superficie.

## Definición

### Criterio de la ficha y complemento técnico

Fábrica de piedra natural trabada con mortero, con geometría y función definidas en el proyecto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1011–1011. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MAMPOSTERÍA ORDINARIA

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar piedra y mortero, preparar apoyo y disponer piezas estables con trabazón transversal y juntas llenas. Evitar continuidad de juntas, comprobar alineación y disponer drenaje cuando retenga tierras. Las dimensiones, capacidad y cimentación deben estar justificadas; no deducir estabilidad sólo de la cantidad de tizones.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1012–1017. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Las piedras se trabajarán con el fin de quitarles todas las partes delgadas o débiles, así como las irregularidades de las caras que puedan dificultar la adherencia entre el mortero y la piedra, o el encaje de las piedras entre sí.
Las caras vistas de los mampuestos se prepararán únicamente a labra tosca, con martillo, pudiéndose emplear mampuestos de todas las dimensiones, con las limitaciones anteriormente indicadas.
Las tolerancias de desvío en las caras de asiento, respecto a un plano, y en juntas respecto a la línea recta, serán inferiores a 1,5 cm.
La capacidad de absorción de agua de las piedras será inferior al 3% de su peso.
Se colocarán mampuestos de suficiente tizón para atravesarlo en todo su espesor, de forma que exista al menos una de estas piezas por metro cuadrado.
El Contratista vendrá obligado a dejar en la fábrica mechinales u orificios, regularmente dispuestos, para facilitar la evacuación de agua de trasdós de la misma, a razón de uno por cada cuatro metros de paramento.

### Referencias de aplicación

- [Código Técnico de la Edificación, Real Decreto 314/2006. Su aplicación a fábricas se limita a su ámbito de edificación; no se presume obligatorio para toda obra civil.](https://www.boe.es/buscar/act.php?id=BOE-A-2006-5515)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

El original no fija criterio económico específico. Se propone m³ netos de fábrica terminada, con piedra, mortero, colocación y auxiliares, sujeto a aprobación y a que no esté incluida en otra unidad.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
