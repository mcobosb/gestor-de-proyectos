# Fábrica de ladrillo cerámico

**Clasificación:** 06LM. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Las exigencias de humectación deben ser compatibles con el producto. No medir separadamente fábrica ya incluida en una arqueta o pozo.

## Definición

### Criterio de la ficha y complemento técnico

Obra de fábrica de ladrillo con mortero y aparejo previstos en planos.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 914–914. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### FÁBRICA DE LADRILLO CERÁMICO

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Recibir piezas y mortero adecuados al uso, replantear, preparar apoyo y ajustar la humectación a la absorción y al fabricante, sin saturar indiscriminadamente cualquier pieza. Ejecutar juntas llenas y trabazón, comprobar geometría y proteger frente a heladas o desecación. Para fábrica estructural de edificación, aplicar CTE DB-SE-F; para obra civil, la especificación y cálculo propios del proyecto.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 915–921. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EJECUCIÓN
Los ladrillos se colocarán según el aparejo previsto en los planos o en su caso designe el Ingeniero Técnico Director de las obras. Antes de su colocación deberán ser saturados de humedad, aunque bien escurridos del exceso de agua, con objeto de evitar el deslavamiento del mortero. Deberán demolerse toda la fábrica en la que el ladrillo hubiese sido insuficientemente humedecido a juicio del Ingeniero Técnico Director de las obras.
Los tendeles no deberán exceder a los diez (10) milímetros, ni las juntas de nueve (9) milímetros. Para la colocación, una vez limpias y humedecidas las superficies sobre las que han de descansar, se echará el mortero en cantidad suficiente para que, comprimiendo fuertemente sobre el ladrillo y  apretando contra los inmediatos queden los espesores de juntas deseados y el mortero refluya por todas partes. En los parámetros que hayan de revocarse, las juntas quedarán sin rellenar a tope, para facilitar la adherencia al revoco.
La subida de fábrica se hará horizontalmente. Después de una interrupción y al reanudarse el trabajo, se regarán abundantemente la fábrica y todo el ladrillo que no hubiere quedado debidamente colocado. Los parámetros se harán con los cuidados y precauciones indispensables, para cualquier elemento se encuentre en el plano, superficie y perfil prescritos. En las superficies curvas las juntas serán normales a los parámetros.
### LIMITACIONES DE EJECUCIÓN
No se efectuarán fábricas de ladrillo cuando la temperatura ambiente sea de seis grados centígrados (6º C) con tendencia a decrecer.
En tiempo caluroso, la fábrica de ladrillo se rociará frecuentemente con agua, para evitar la desecación del mortero.

### Referencias de aplicación

- [Código Técnico de la Edificación, Real Decreto 314/2006. Su aplicación a fábricas se limita a su ámbito de edificación; no se presume obligatorio para toda obra civil.](https://www.boe.es/buscar/act.php?id=BOE-A-2006-5515)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m³ según planos conforme a 5.14, con materiales, equipo y mano de obra incluidos, salvo que forme parte de una arqueta completa.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1151–1153. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### FÁBRICA DE LADRILLO
Las obras de fábrica de ladrillo se medirán en metros cúbicos (mi) y siempre de acuerdo con las dimensiones indicadas en los planos o las modificaciones ordenadas por el Director de la Obra.
En ambos casos se abonará a los precios respectivos del presupuesto, en los que se encuentran incluidos los materiales, equipo y mano de obra necesarios para la completa terminación de la unidad.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
