# paredes

**Clasificación:** 09AP. **Capítulo:** aislamientos. **Familia:** acústicos.

## Definición

Capas y sistemas de aislamiento o impermeabilización que proporcionan la prestación prevista en el cerramiento o la instalación.

El objeto de esta ficha es «paredes», dentro de «acústicos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán prestación térmica, acústica o de estanqueidad, producto, espesor, soporte, fijación y encuentros. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Verificar sequedad, limpieza y regularidad del soporte. Instalar sin discontinuidades, con juntas, solapes y fijaciones propios del sistema. Resolver encuentros, pasos y puentes y proteger la capa antes de ocultarla o aplicar revestimientos.

### Condiciones de esta clasificación

Evitar puentes acústicos y contactos rígidos no previstos; mantener juntas y sellados del sistema completo.

Para la variante «paredes» se comprobarán expresamente prestación acústica, masa, rigidez y composición del cerramiento. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar espesor, continuidad y compatibilidad; inspeccionar puntos singulares y realizar las pruebas de prestación o estanqueidad previstas antes de cerrar.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m² de superficie realmente tratada con espesor y sistema definidos; juntas y coquillas en m y tratamientos puntuales en ud. Precisar solapes, recortes y huecos; no incrementar automáticamente la superficie útil por mermas.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
