# Reposición y desvío de servicios afectados

**Clasificación:** 01TR. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Distinguir reposición prevista de reparación de daños. La clasificación general no reemplaza los requisitos del servicio concreto.

## Definición

### Criterio de la ficha y complemento técnico

Trabajos autorizados para restituir las condiciones de servicio de redes afectadas por el proyecto, diferenciados de la reparación de daños imputables al contratista.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1023–1026. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIÓN DE SERVICIOS AFECTADOS
El contratista realizará las operaciones y desvíos de aquellos Servicios que la Dirección de Obra considere como afectados, teniendo en cuenta lo especificado por las compañías suministradoras.
Toda la obra se realizará según los Métodos de construcciones y Seguridad y Salud.
Se definirán como unidades de obra que comprenden todos los materiales y trabajos necesarios para restituir las condiciones de servicio iniciales con la nueva situación del trazado del proyecto, de acuerdo con la entidad concesionaria del servicio.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Inventariar y localizar servicios, coordinar con titulares y aprobar desvíos y secuencias de corte antes de intervenir. Mantener suministros y accesos según la solución acordada, probar la reposición y entregar documentación de su ubicación final.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 542–543. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### DESVÍOS DE SERVICIOS
Antes de comenzar las obras, el Contratista, basado en los planos y datos de que disponga, o reconocimientos efectuados, deberá estudiar y replantear sobre el terreno los servicios e instalaciones afectadas, considerando la mejor forma de ejecutar los trabajos para no dañarlos y señalando los que, en último extremo, considera necesario modificar. Si el Director de la obra se muestra conforme, solicitará de las Empresas u Organismos correspondientes la modificación de estas instalaciones, abonándose los trabajos que sean necesarios realizar.

### Referencias de aplicación

- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por las unidades previstas en el cuadro de precios para reposiciones necesarias autorizadas, conforme a 5.3. Las reparaciones de roturas imputables al contratista no se convierten en partidas nuevas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1108–1111. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIONES
Se medirán y abonarán por la dimensión especificada en el Cuadro de Precios, metro lineal (ml), metro cuadrado (m²), metro cúbico (m³), de la unidad realmente ejecutada y referida únicamente a aquellas que, a juicio del Director de la obra, sean consecuencia obligada de la ejecución del Proyecto contratado.
Los precios incluyen todas las operaciones, materiales, mano de obra, maquinaria y medios auxiliares necesarios para la completa ejecución y perfecto acabado.
Todas las reparaciones de roturas o averías en los diversos servicios públicos o particulares, los tendrá que realizar obligatoriamente el Contratista por su cuenta exclusiva y sin derecho a abono de cantidad alguna.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
