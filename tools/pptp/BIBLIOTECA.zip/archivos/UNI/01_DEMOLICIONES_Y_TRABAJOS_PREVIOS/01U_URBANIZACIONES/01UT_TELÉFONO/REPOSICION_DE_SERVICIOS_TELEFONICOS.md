# Reposición de servicios telefónicos

**Clasificación:** 01UT. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

## Definición

### Criterio de la ficha y complemento técnico

Desvío o reposición de redes telefónicas y sus infraestructuras afectadas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1023–1026. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIÓN DE SERVICIOS AFECTADOS
El contratista realizará las operaciones y desvíos de aquellos Servicios que la Dirección de Obra considere como afectados, teniendo en cuenta lo especificado por las compañías suministradoras.
Toda la obra se realizará según los Métodos de construcciones y Seguridad y Salud.
Se definirán como unidades de obra que comprenden todos los materiales y trabajos necesarios para restituir las condiciones de servicio iniciales con la nueva situación del trazado del proyecto, de acuerdo con la entidad concesionaria del servicio.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Coordinar con el operador, localizar cables, aprobar trazado, interrupciones y solución de empalme y protección. Ejecutar con personal competente, respetar radios y esfuerzos y comprobar el servicio antes de cerrar y recibir.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1032–1034. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIÓN DE SERVICIOS TELEFÓNICOS
El Contratista realizará las operaciones y desvíos de los Servicios telefónicos afectados por la obra de acuerdo con lo que se establece en los planos del proyecto y en las correspondientes mediciones y presupuestos, siguiendo además las normas de la Compañía Telefónica y las Instrucciones de la Dirección de Obra.
Toda obra se realizará según los métodos de Construcciones y Seguridad y Salud en el Trabajo.

### Referencias de aplicación

- [Ley 11/2022, General de Telecomunicaciones: marco de las redes y sus infraestructuras; no sustituye al diseño civil ni a las especificaciones del titular de la red.](https://www.boe.es/buscar/act.php?id=BOE-A-2022-10757)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Según las partidas y unidades del presupuesto y los trabajos autorizados, sin abonar reparaciones imputables al contratista como reposiciones previstas.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1108–1111. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIONES
Se medirán y abonarán por la dimensión especificada en el Cuadro de Precios, metro lineal (ml), metro cuadrado (m²), metro cúbico (m³), de la unidad realmente ejecutada y referida únicamente a aquellas que, a juicio del Director de la obra, sean consecuencia obligada de la ejecución del Proyecto contratado.
Los precios incluyen todas las operaciones, materiales, mano de obra, maquinaria y medios auxiliares necesarios para la completa ejecución y perfecto acabado.
Todas las reparaciones de roturas o averías en los diversos servicios públicos o particulares, los tendrá que realizar obligatoriamente el Contratista por su cuenta exclusiva y sin derecho a abono de cantidad alguna.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
