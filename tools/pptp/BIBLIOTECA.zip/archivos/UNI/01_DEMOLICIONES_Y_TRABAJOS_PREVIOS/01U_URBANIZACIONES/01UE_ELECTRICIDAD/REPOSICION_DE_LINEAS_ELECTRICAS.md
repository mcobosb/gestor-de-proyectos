# Reposición de líneas eléctricas

**Clasificación:** 01UE. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El REBT sólo cubre baja tensión. Si la línea es de media o alta tensión deberá aplicarse su reglamentación específica; el original no identifica su tensión.

## Definición

### Criterio de la ficha y complemento técnico

Desplazamiento o reposición autorizada de líneas eléctricas afectadas por las obras.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1023–1026. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIÓN DE SERVICIOS AFECTADOS
El contratista realizará las operaciones y desvíos de aquellos Servicios que la Dirección de Obra considere como afectados, teniendo en cuenta lo especificado por las compañías suministradoras.
Toda la obra se realizará según los Métodos de construcciones y Seguridad y Salud.
Se definirán como unidades de obra que comprenden todos los materiales y trabajos necesarios para restituir las condiciones de servicio iniciales con la nueva situación del trazado del proyecto, de acuerdo con la entidad concesionaria del servicio.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Aprobar nuevo trazado con el titular, establecer consignación y verificar ausencia de tensión por personal autorizado según RD 614/2001. Ejecutar la red conforme al reglamento de su tensión, probar y legalizar cuando proceda antes de restituir el servicio.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1027–1031. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIÓN DE LÍNEAS ELÉCTRICAS
Para proceder al desplazamiento y reposición de líneas eléctricas, se procederá a determinar la disposición más adecuada del nuevo trazado.
Todas las operaciones se realizarán cuidadosamente por personal especializado, siguiendo las órdenes del Ingeniero Técnico Director e indicaciones de la Compañía Suministradora.
Cuando se vaya a realizar la conexión se comprobará especialmente que no haya tensión en la línea. 
Se procederá según las normas de buena práctica constructiva, siguiendo la reglamentación e instrucciones y las indicaciones del Ingeniero Técnico Director.

### Referencias de aplicación

- [Real Decreto 614/2001: disposiciones mínimas para la protección de los trabajadores frente al riesgo eléctrico.](https://www.boe.es/buscar/act.php?id=BOE-A-2001-11881)
- [Reglamento electrotécnico para baja tensión, Real Decreto 842/2002: ITC-BT-04, 05, 07, 09, 11 a 24, según corresponda. Aplicar las disposiciones y normas de referencia exigibles a la instalación.](https://www.boe.es/buscar/act.php?id=BOE-A-2002-18099)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Aplicar los m, ud u otra magnitud de cada partida aprobada de reposición; no abonar daños por mala ejecución como servicio afectado.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1108–1111. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### REPOSICIONES
Se medirán y abonarán por la dimensión especificada en el Cuadro de Precios, metro lineal (ml), metro cuadrado (m²), metro cúbico (m³), de la unidad realmente ejecutada y referida únicamente a aquellas que, a juicio del Director de la obra, sean consecuencia obligada de la ejecución del Proyecto contratado.
Los precios incluyen todas las operaciones, materiales, mano de obra, maquinaria y medios auxiliares necesarios para la completa ejecución y perfecto acabado.
Todas las reparaciones de roturas o averías en los diversos servicios públicos o particulares, los tendrá que realizar obligatoriamente el Contratista por su cuenta exclusiva y sin derecho a abono de cantidad alguna.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
