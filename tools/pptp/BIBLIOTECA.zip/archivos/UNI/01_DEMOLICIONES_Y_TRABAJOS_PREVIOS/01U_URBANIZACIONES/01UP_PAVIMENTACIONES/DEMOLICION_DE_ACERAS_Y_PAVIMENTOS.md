# Demolición de aceras y pavimentos

**Clasificación:** 01UP. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** Comprobar el espesor de cada partida y la inclusión del transporte frente a 5.8.

## Definición

### Criterio de la ficha y complemento técnico

Levantado de los pavimentos afectados por las obras, manteniendo las superficies y servicios que deban conservarse.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 3–8. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### DEMOLICIONES
### DEFINICIÓN
Consiste en el conjunto de operaciones necesarias para la demolición de construcciones, muros, firmes, aceras y obras de fábrica afectadas, y el consiguiente transporte de todos los productos al lugar de empleo o vertedero.
Su ejecución incluye:
- Derribo de obras de fábrica o construcciones, o demoliciones de las aceras y pavimentos.
- Retirada de los materiales de derribo.

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Replantear y delimitar los bordes, cortar cuando sea necesario para evitar daños fuera de la zona autorizada, levantar las capas, separar materiales y retirar residuos. Mantener itinerarios seguros y prever la reposición de accesos. Aplicar la seguridad del derribo y la gestión de RCD.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 9–13. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### EJECUCIÓN DE LAS OBRAS
Será de aplicación lo indicado en el Artículo 301 del PG-3.
El equipo necesario para la ejecución de la demolición será aprobado por el Director de las obras y se mantendrá, en todo momento, en condiciones de trabajo satisfactorias.
La demolición se llevará a cabo en las zonas que indique el Proyecto y en su defecto donde indique el Director de las obras que determinará también la profundidad de demolición necesaria.
Los materiales procedentes de las demoliciones se retirarán a vertedero salvo indicación en contrario del Director de obras.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 550–553. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### DEMOLICIONES
Se define como demolición la operación de derribo de todas las edificaciones, obras de fábrica, estructuras, pavimentos e instalaciones que obstaculicen la construcción de una obra o que sea necesario hacer desaparecer para dar por terminada la ejecución de la misma, incluso la retirada de los materiales resultantes a vertedero o en su lugar de empleo o acopio definitivo.
Las operaciones de derribo o excavación se efectuarán con las precauciones necesarias para lograr unas condiciones de seguridad suficientes y evitar daños en las obras o instalaciones que no hayan de ser demolidas y de acuerdo con lo que sobre el particular ordene el Director de la obra, quien designará y marcará los elementos de las obras a demoler que se deban conservar intactos para su aprovechamiento posterior, así como las condiciones para el transporte y acopio de los mismos. En cualquier caso, el Contratista requerirá autorización expresa para los derribos.
Cuando los firmes, pavimentos, bordillos u otros elementos deban reponerse a la finalización de las obras a que afecten, la reposición se realizará en el plazo más breve posible y en condiciones análogas a las existentes antes de su demolición.

### Referencias de aplicación

- [PG-3: Orden FOM/1382/2002, explanaciones, drenajes y cimentaciones. Artículos 300, 301, 320, 321, 330, 332, 340, 410, 411, 421, 422 y 658 según el trabajo. Aplicación por remisión del proyecto y con sus modificaciones y régimen transitorio.](https://www.boe.es/buscar/doc.php?id=BOE-A-2002-11394)
- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Real Decreto 105/2008: producción y gestión de residuos de construcción y demolición, obligaciones de productor y poseedor y acreditación de la entrega.](https://www.boe.es/buscar/act.php?id=BOE-A-2008-2486)
- [Ley 7/2022, de residuos y suelos contaminados para una economía circular: jerarquía, separación, trazabilidad y gestión autorizada de residuos.](https://www.boe.es/buscar/act.php?id=BOE-A-2022-5809)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Medir en m² la superficie realmente demolida, descontando huecos y zonas no levantadas. Aplicar el precio del tipo y espesor previstos, sin duplicar la retirada incluida en él.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 14–17. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### MEDICIÓN Y ABONO
Las demoliciones se abonarán por metros cúbicos (m3) realmente demolidos y retirados de su emplazamiento, medido por diferencia entre los datos iniciales, tomados inmediatamente antes de comenzar la demolición, y los datos finales, tomados inmediatamente después de finalizar la misma.
En el caso de demolición de aceras y pavimentos el precio será por metro cuadrado (m2) de superficie de acera realmente demolida.
El precio incluye la retirada de los productos sobrantes a vertedero.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1103–1104. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### DEMOLICIONES
Las demoliciones de los diferentes pavimentos se abonarán por metros cuadrados de superficie realmente demolida, descontando zonas y huecos intermedios y según el precio que figura en el Cuadro de Precios nº 1.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
