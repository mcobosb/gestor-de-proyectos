# rejas

**Clasificación:** 11SR. **Capítulo:** carpintería y elementos de seguridad y protección. **Familia:** seguridad y protección.

## Definición

Carpinterías, cierres y elementos de protección con dimensiones, herrajes, anclajes y prestaciones definidos para su emplazamiento.

El objeto de esta ficha es «rejas», dentro de «seguridad y protección». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán dimensiones, material, apertura, herrajes, soporte de anclaje y prestaciones exigibles. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Comprobar huecos y apoyos; replantear, anclar y sellar con productos compatibles. Ajustar hojas y herrajes y proteger acabados. No fijar elementos de seguridad a soportes sin capacidad resistente comprobada.

### Condiciones de esta clasificación

Comprobar anclajes y resistencia del sistema de protección sin basar su aceptación sólo en el aspecto; mantener pasos accesibles.

Para la variante «rejas» se comprobarán expresamente cargas, altura, huecos, soporte y ensayo de recepción. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar apertura, cierre, holguras, anclajes y sellados; verificar prestaciones de seguridad, accesibilidad, viento, agua, aire y fuego según el uso.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

ud de conjunto completo o m² de carpintería tipificada; barandillas, rejas o cerramientos en m, m² o ud según presupuesto. Definir vidrio, herrajes, sellado y acabados incluidos antes de medir.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
