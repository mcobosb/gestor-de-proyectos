# policarbonatos

**Clasificación:** 12SP. **Capítulo:** vidriería y elaborados sintéticos. **Familia:** elaborados sintéticos.

## Definición

Acristalamientos y elaborados sintéticos seleccionados para la seguridad, exposición y prestaciones del hueco o cerramiento.

El objeto de esta ficha es «policarbonatos», dentro de «elaborados sintéticos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán composición y espesor calculados, tamaño, apoyos, cargas, seguridad frente a impacto y prestaciones térmicas o de fuego. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Comprobar composición y dimensiones, estado de cantos y compatibilidad de apoyos y sellantes. Manipular con medios adecuados, colocar calzos y holguras previstos y evitar contactos rígidos o daños en capas funcionales.

### Condiciones de esta clasificación

Permitir dilatación y comprobar caras protegidas frente a radiación y compatibilidad química con sellantes.

Para la variante «policarbonatos» se comprobarán expresamente polímero, espesor, protección UV y reacción al fuego. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Verificar marcado e identificación, apoyos, retención y sellado, ausencia de daños y correspondencia con las prestaciones de seguridad y de fuego cuando procedan.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m² de paño de composición definida o ud de pieza especial. Establecer si se mide dimensión nominal o vista y si calzos, juntas y sellados están incluidos; no duplicar vidrios ya incluidos en la carpintería.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
