# especiales

**Clasificación:** 10SE. **Capítulo:** revestimientos. **Familia:** suelos.

## Definición

Revestimientos y acabados de suelos, paredes, techos, peldaños y remates sobre un soporte apto para el sistema seleccionado.

El objeto de esta ficha es «especiales», dentro de «suelos». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán material, formato, espesor, soporte, exposición, juntas, acabado y prestaciones de uso. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Comprobar soporte, humedad y planeidad; aprobar muestra y replanteo. Ejecutar adherencia o fijación y juntas según el sistema, resolver encuentros y proteger el acabado hasta su recepción.

### Condiciones de esta clasificación

Comprobar humedad y regularidad del soporte, juntas de movimiento y aptitud del pavimento para las cargas y el uso.

Para la variante «especiales» se comprobarán expresamente carga, desgaste, deslizamiento, humedad y espesor. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar adherencia o fijaciones, planeidad, juntas, aspecto y, en zonas de paso, resbaladicidad y accesibilidad exigibles.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m² de revestimiento con regla de deducción de huecos; peldaños, rodapiés y remates en m o ud tipificada. Definir si preparación, adhesivos, rejuntados y protección quedan incluidos; no medir capas duplicadas.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
