# Enfoscados y enlucidos de cemento

**Clasificación:** 10CL. [Índice y criterios de uso](../../../INDICE_FICHAS.md). [Condiciones generales](../../../CONDICIONES_GENERALES.md).

> **REVISIÓN NECESARIA:** El original ordena enlucir hormigón «todavía fresco». Debe verificarse la compatibilidad y preparación del soporte del sistema elegido antes de aplicar esa instrucción.

## Definición

### Criterio de la ficha y complemento técnico

Revestimientos de mortero para regularizar y terminar paramentos de fábrica u hormigón.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 922–922. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ENLUCIDOS

## Ejecución en obra

### Criterio de la ficha y complemento técnico

Comprobar estabilidad, limpieza y textura del soporte; retirar desencofrantes y partes débiles, humedecer sin encharcar y aplicar mortero compatible con el soporte y ambiente. Respetar espesores y tiempos de capa del sistema, tratar encuentros y proteger el curado contra desecación y heladas. No aplicar sobre un soporte fresco o inadecuado sólo por la frase genérica del original.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 923–925. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

Sobre el ladrillo y hormigones se ejecutarán embebiendo previamente de agua las superficies de la fábrica.
Los enlucidos sobre hormigones se ejecutarán cuando estos estén todavía frescos, resecando previamente la superficie para obtener una buena adherencia. Al tiempo de aplicar el mortero a la superficie que se enluzca, se hallará esta húmeda, pero sin escaso de agua que pudiera deslavar los morteros.
Los enlucidos se mantendrán húmedos por medio de riegos muy frecuentes durante el tiempo necesario para que no sea de temer la formación de grietas de desecación.

### Referencias de aplicación

- [Real Decreto 1627/1997: seguridad y salud en las obras; en particular, anexo IV para excavaciones, accesos, protecciones y trabajos de construcción.](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614)
- [Código Técnico de la Edificación, Real Decreto 314/2006. Su aplicación a fábricas se limita a su ámbito de edificación; no se presume obligatorio para toda obra civil.](https://www.boe.es/buscar/act.php?id=BOE-A-2006-5515)

Los complementos son redacción técnica de apoyo, no transcripción de normas UNE. No se asigna a una norma un precio ni una unidad de abono que deba decidir el contrato. Las normas UNE citadas en el original requieren comprobación de edición y vigencia; no se ha consultado su texto completo.

## Medición y abono

### Criterio de la ficha y complemento técnico

Por m² realmente ejecutados según 5.15, con materiales y colocación, salvo inclusión en la unidad de arqueta u otro elemento completo.

### Prescripciones del documento de origen

Fuente: [PPTP.md](../../../../../PPTP.md), líneas 1154–1156. Transcripción para trazabilidad; los avisos de revisión de esta ficha son de aplicación.

### ENFOSCADOS Y ENLUCIDOS
Los enlucidos de las obras de fábrica, ya sea en hormigón o ladrillo se medirán por metro cuadrado (m2) realmente ejecutado.
El abono se efectuará aplicando a estas mediciones los precios que se indican en el presupuesto, en los que se incluyen los materiales y la colocación.

### Regla de valoración

Aplicar la partida y el cuadro de precios aprobados, sin duplicar conceptos incluidos en otras unidades. Cuando el texto de esta ficha completa un criterio no definido en el original, se trata de una propuesta para aprobación por la dirección facultativa y, cuando proceda, por el órgano de contratación; no crea por sí misma un precio nuevo ni modifica el contrato.
