# colectores

**Clasificación:** 04EC. **Capítulo:** saneamiento. **Familia:** redes enterradas.

## Definición

Elementos de recogida y evacuación de aguas de saneamiento, con sus uniones y conexiones compatibles con el sistema proyectado.

El objeto de esta ficha es «colectores», dentro de «redes enterradas». No comprende automáticamente otras variantes de la familia ni trabajos ajenos a la partida aprobada.

Antes de incorporarla al pliego se concretarán tipo de agua, caudal de cálculo, material, diámetro, pendientes, resistencia mecánica y procedimiento de prueba. Los valores se tomarán de los planos, cálculos, presupuesto y documentación aprobada, no del nombre de la carpeta.

## Ejecución en obra

### Preparación y procedimiento

Replantear pendientes, cotas y encuentros. Preparar apoyos y fijaciones, montar piezas compatibles y mantener registros accesibles. Probar los tramos antes de su ocultación, documentando las conexiones y evitando entradas de tierra o residuos.

### Condiciones de esta clasificación

Comprobar cama, pendiente, uniones y relleno lateral antes de cubrir; inspeccionar pozos y pruebas por tramos.

Para la variante «colectores» se comprobarán expresamente cargas de tráfico, sección de zanja y ensayo de estanqueidad. Las denominaciones del catálogo no acreditan por sí solas la idoneidad del material o del procedimiento.

### Control y recepción

Comprobar continuidad hidráulica, pendientes, estanqueidad, accesibilidad para limpieza y ausencia de conexiones cruzadas.

Definir antes del inicio los lotes o zonas de control, tolerancias, frecuencia de comprobación y responsable de aceptación. Registrar incidencias y no ocultar unidades pendientes de inspección; las no conformidades necesitan resolución técnica documentada.

## Medición y abono

### Criterio propuesto para particularizar

m de trazado realmente instalado y aceptado, diferenciado por material, diámetro o sección y condiciones de montaje. El presupuesto definirá longitud en eje, accesorios, soportes y conexiones incluidos; separar equipos y obra civil sólo si no se incluyen en el precio.

### Alcance contractual

La unidad de medida, deducción de huecos, límites geométricos, operaciones auxiliares, pruebas y documentación incluidos deben fijarse en la partida y el cuadro de precios aprobados. Medir únicamente trabajos ejecutados, comprobados y aceptados conforme al contrato, con soporte de medición trazable.

Esta propuesta no establece precios ni crea derecho a abono independiente. Los trabajos no previstos y cambios de alcance se tramitarán por el procedimiento contractual aplicable antes de certificarlos. No se duplicarán transportes, gestión de residuos, medios auxiliares ni ensayos ya incluidos en otras unidades.
