"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 3. CONTROL DE RECEPCIÓN DE MATERIALES

Los materiales estarán sujetos a la aprobación de la Dirección Facultativa. Se verificarán el albarán, la identificación y trazabilidad del lote, la documentación de calidad y el marcado CE cuando corresponda.

- Materiales granulares: granulometría, equivalente de arena y desgaste Los Ángeles para las zahorras, según pliego.
- Mezclas bituminosas: fórmula de trabajo, temperatura de llegada conforme al PG-3 aplicable y contenido de betún.
- Hormigones: albarán, clase de exposición, resistencia y consistencia en cimentaciones, zanjas y bases de isletas cuando corresponda.
- Prefabricados: bordillos remontables o peatonales, baldosas tacto-visuales de botones y direccionales, tapas y sumideros.
- Señalización y alumbrado: pintura de marcas viales, señales verticales, báculos y luminarias LED; comprobar prestaciones y documentación exigibles.
