"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 2. NORMATIVA DE APLICACIÓN

El control se regirá por el proyecto y por la normativa vigente que resulte aplicable a cada unidad:

- PG-3: Pliego de Prescripciones Técnicas Generales para Obras de Carreteras y Puentes y sus actualizaciones.
- Norma 6.1-IC, Secciones de firme, y Norma 6.3-IC, Rehabilitación de firmes, según el alcance. La antigua 6.2-IC no se adopta como norma vigente independiente.
- Código Estructural (Real Decreto 470/2021) cuando corresponda a los elementos de hormigón.
- REBT (Real Decreto 842/2002) para las instalaciones de baja tensión, incluida la red de alumbrado cuando proceda.
- Normativa estatal y autonómica de accesibilidad y condiciones municipales aplicables a pendientes y pavimentos tacto-visuales.
- Marcado CE y documentación de prestaciones de los productos de construcción cuando sean exigibles: áridos, mezclas, prefabricados, luminarias y señales, según el producto.
