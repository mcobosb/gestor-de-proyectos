"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 6. GESTIÓN DE NO CONFORMIDADES

Si un material o unidad no alcanza los parámetros exigidos, la Dirección Facultativa abrirá un parte de no conformidad donde consten el lote, los resultados y la unidad afectada.

El contratista propondrá una acción correctiva, como el fresado y la reposición de una capa defectuosa. La Dirección Facultativa deberá aprobarla y comprobar su resultado antes de continuar con las unidades superpuestas.
