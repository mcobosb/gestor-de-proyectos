"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 1. OBJETO Y ALCANCE

El presente anejo establece los criterios, procedimientos y ensayos para controlar la calidad de los materiales y unidades durante la ejecución de la obra. El alcance concreto viene dado por el proyecto, su pliego y las unidades revisadas en la Tabla 2.

En actuaciones como una nueva glorieta sobre viario urbano existente, se prestará especial atención al fresado y saneamiento del firme, a las zanjas de servicios y drenaje, a la transición de rasantes y a la accesibilidad de los pasos peatonales perimetrales, cuando esas unidades formen parte de la obra.
