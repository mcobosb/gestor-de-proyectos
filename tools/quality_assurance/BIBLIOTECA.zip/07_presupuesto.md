"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 7. PRESUPUESTO DE CONTROL DE CALIDAD

La valoración comprende la toma de muestras, los ensayos, las pruebas de carga y las comprobaciones topográficas previstas. El intervalo del 1,5 % al 2,0 % del PEM es solo una referencia inicial; no sustituye la medición y valoración de cada ensayo.

{{presupuesto_control}}
