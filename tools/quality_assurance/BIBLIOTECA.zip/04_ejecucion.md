"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 4. CONTROL DE EJECUCIÓN

Los siguientes puntos de inspección y parada se aplicarán a las fases incluidas en el proyecto.

## 4.1. TRABAJOS PREVIOS Y DEMOLICIONES

- Fresado: comprobar la profundidad y la transición de rasantes con los umbrales y vados existentes.
- Servicios afectados: verificar in situ trazado y cotas de abastecimiento, saneamiento, gas y telecomunicaciones antes de excavar.

## 4.2. MOVIMIENTO DE TIERRAS Y ZANJAS

- Sanear los blandones detectados al retirar el firme y controlar el material de sustitución.
- Controlar la compactación por tongadas y el espesor definido en el pliego; 25–30 cm es una referencia de partida, no un límite universal.

## 4.3. EJECUCIÓN DEL FIRME Y PAVIMENTACIÓN

- Controlar la dotación de riegos de imprimación y adherencia (kg/m²) y las temperaturas en tolva y tras la regla durante el extendido.
- Inspeccionar juntas longitudinales y transversales con el pavimento existente, comprobando corte y sellado según proyecto.

## 4.4. ISLETA CENTRAL Y ACERADOS PERIMETRALES

- Comprobar radios, ancho del carril anular y geometría de los islotes mediante replanteo topográfico.
- Verificar pendientes, enrase de bordillos y pavimento tacto-visual en los vados según su geometría y la normativa de accesibilidad aplicable. No se admiten resaltes ni pendientes por el mero hecho de ajustarse a un valor tipo.

## 4.5. DRENAJE SUPERFICIAL

- Comprobar la pendiente transversal prevista y las cotas y posiciones de los sumideros. En una calzada anular se verificará el desagüe hacia los puntos previstos sin encharcar los pasos peatonales.
