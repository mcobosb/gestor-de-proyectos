"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Edición inicial.
"""

# 5. PLAN DE ENSAYOS DE LABORATORIO

El contratista recurrirá a un laboratorio habilitado o acreditado para los ensayos cuando resulte exigible. Las frecuencias de la Tabla 1 son orientativas: no sustituyen los lotes, métodos ni criterios del pliego o de la normativa aplicable.

{{tabla_frecuencias}}

La Tabla 2 recoge los ensayos revisados, sus cantidades y los criterios de aceptación por unidad de obra. No incluye filas descartadas.

{{tabla_ensayos}}

## 5.1. DETALLE DE LAS FICHAS DEL CAT?LOGO

Las fichas seleccionadas a?aden el m?todo, los par?metros y las evidencias disponibles en el libro de referencia. Los controles no incluidos en la revisi?n no aparecen aqu?.

{{detalles_catalogo}}
