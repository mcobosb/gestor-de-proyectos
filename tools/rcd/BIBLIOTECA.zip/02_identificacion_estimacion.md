## 1.1. IDENTIFICACIÓN DE LOS RESIDUOS A GENERAR

Los residuos se identificarán con la Lista Europea de Residuos establecida por la Decisión 2000/532/CE y sus modificaciones, atendiendo a su origen, composición y características de peligrosidad. Los códigos marcados con asterisco corresponden a residuos peligrosos.

A efectos descriptivos del modelo se distinguen tierras y pétreos de excavación, denominados Nivel I, y residuos asociados a construcción, demolición, reparación e implantación de servicios, denominados Nivel II. Estas categorías de cálculo no sustituyen la clasificación legal ni implican que todos los residuos sean inertes.

Los suelos no contaminados y otros materiales naturales excavados podrán quedar fuera del régimen de residuos únicamente cuando se cumplan las condiciones legales, incluida la certeza de utilización en estado natural en el lugar u obra de extracción. Los destinos externos requerirán comprobar el régimen aplicable; no se presume una exclusión por tratarse de tierras.

Se incluyen a continuación las selecciones y evidencias revisables del análisis:

{{tabla_residuos}}

Los códigos repetidos y la clasificación del grupo otros proceden del modelo. El grupo económico «potencialmente peligrosos y otros» incluye materiales de distinta naturaleza y no acredita que todos sean peligrosos. Se deberán contrastar los códigos, sus asteriscos y las entradas aplicables antes de utilizarlos en documentos de traslado o aceptación.

No se excluyen residuos del estudio por tener un volumen inferior a 1 m³. La falta de una coincidencia automática tampoco acredita su ausencia.

En demolición, rehabilitación, reparación o reforma se realizará un inventario previo de residuos peligrosos y se preverá su retirada selectiva. La selección automática es una ayuda, no ese inventario.

Inventario e inspecciones particulares: {{hazardous}}

## 1.2. ESTIMACIÓN DE LAS CANTIDADES

{{metodo_estimacion}}

{{nota_modelo}}

En el modo estadístico, el volumen se estima a partir de la superficie y el coeficiente de generación; la masa se obtiene con la densidad global y se distribuye con los porcentajes revisados por grupo. El coeficiente actualmente indicado en el formulario es {{coeficiente_generacion}} m³/m²; si se utilizan mediciones de demolición, no interviene en ese cálculo.

{{tabla_demolicion}}

{{tabla_estimacion}}

Las cantidades se presentan en toneladas y metros cúbicos por grupo. No se renormalizan los porcentajes al marcar residuos. Si se seleccionan varios códigos LER de un mismo grupo, la tabla no reparte artificialmente el peso entre ellos: deberá completarse el desglose por código para la gestión efectiva.

Las mediciones de demolición conservan la procedencia, la unidad original y el factor revisado a metros cúbicos. Los ajustes del transporte y del capítulo presupuestario mantienen su revisión independiente.
