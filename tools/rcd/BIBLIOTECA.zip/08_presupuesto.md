"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# 3. PRESUPUESTO DE GESTIÓN DE RCDs

La valoración se obtiene del mismo cálculo revisado en la herramienta. Se conservan los volúmenes, tarifas, complementos y redondeos de las tablas originales; la elaboración del estudio no modifica las mediciones ni incorpora por sí misma nuevas partidas.

{{aviso_moneda}}

{{tabla_presupuesto}}

Los porcentajes mínimos, complementos y costes de gestión son criterios configurables del modelo, no tasas ni mínimos legales universales. Los importes se expresan sin fianza ni IVA.

Se comprobará que la valoración cubre las operaciones realmente previstas y no duplica el transporte ni otros conceptos ya presupuestados. Al guardar RCDs se mantiene la incorporación del capítulo económico al presupuesto del proyecto mediante la función existente.

Los costes indirectos se aplican a las partidas del presupuesto conforme a su configuración; este documento no añade un segundo recargo a las tablas del modelo.
