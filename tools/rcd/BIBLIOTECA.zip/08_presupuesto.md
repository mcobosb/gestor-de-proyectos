"""
## Registro de cambios
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 23/11/2026 | Cambio: Presupuesto integrado en el apartado 1.11 con referencia al capítulo e importe real, en letra y cifra.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
## 1.11. PRESUPUESTO DE GESTIÓN DE RCDs

El presupuesto de gestión de RCDs se encuentra en el capítulo {{capitulo_presupuesto_rcds}} del presupuesto del proyecto.

El presupuesto de gestión de RCDs asciende a {{presupuesto_rcds}}.
