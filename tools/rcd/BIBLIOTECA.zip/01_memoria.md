"""
Base adaptada del estudio tipo aportado por el usuario. No incorporar nombres,
direcciones ni importes de aquella obra como datos de otros proyectos.
Los marcadores tabla_* deben conservarse una vez cada uno en el conjunto.
"""
# 1. MEMORIA

{{tabla_proyecto}}

El presente Estudio de Gestión de Residuos de Construcción y Demolición se redacta de acuerdo con el Real Decreto 105/2008, de 1 de febrero, y la Ley 7/2022, de 8 de abril, para los trabajos previstos en el proyecto.

El estudio estima los residuos que pueden producirse en los trabajos directamente relacionados con la obra y establece criterios para prevenir su generación, separarlos y gestionarlos. Servirá de base al Plan de Gestión de Residuos del constructor, que desarrollará y complementará estas previsiones en función de sus proveedores, medios y sistema de ejecución.

El plan deberá ser aprobado por la dirección facultativa y aceptado por la propiedad. La estimación automática no sustituye la caracterización del residuo, el inventario de sustancias peligrosas, la identificación de gestores ni los planos de instalaciones.

Los apartados señalados como pendientes deben concretarse para la obra antes de aprobar el estudio. No se presupone que los residuos deban enviarse a vertedero ni que estén autorizadas operaciones de tratamiento en la propia obra.
