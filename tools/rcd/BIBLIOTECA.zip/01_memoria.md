"""
## Registro de cambios
- Versión: 6 | Autor: Biblioteca distribuida con el programa | Fecha: 23/11/2026 | Cambio: Eliminado notas previas
- Versión: 5 | Autor: Biblioteca distribuida con el programa | Fecha: 23/11/2026 | Cambio: Texto sobre contenido
- Versión: 4 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Encabezado de descripción en mayúsculas y sin dos puntos.
- Versión: 3 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Sección 1.2 de descripción de la actuación y ajuste de la numeración.
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Sección de antecedentes y numeración de la memoria.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
Base adaptada del estudio tipo aportado por el usuario. No incorporar nombres,
direcciones ni importes de aquella obra como datos de otros proyectos.
Los marcadores tabla_* deben conservarse una vez cada uno en el conjunto.
"""
# 1. MEMORIA

## 1.1. ANTECEDENTES

El presente Estudio de Gestión de Residuos de Construcción y Demolición se redacta de acuerdo con el Real Decreto 105/2008, de 1 de febrero, y la Ley 7/2022, de 8 de abril, para los trabajos previstos en el proyecto (Tabla 1).

El estudio estima los residuos que pueden producirse en los trabajos directamente relacionados con la obra y establece criterios para prevenir su generación, separarlos y gestionarlos. Servirá de base al Plan de Gestión de Residuos del constructor, que desarrollará y complementará estas previsiones en función de sus proveedores, medios y sistema de ejecución. El plan deberá ser aprobado por la dirección facultativa y aceptado por la propiedad.

{{tabla_proyecto}}

En el proyecto de ejecución de una obra de construcción o demolición se debe incluir un Estudio de Gestión de Residuos de la Construcción y Demolición que contendrá como mínimo:
	a) Una estimación de la cantidad, expresada en toneladas y en metros cúbicos, de los residuos de construcción y demolición que se generarán en la obra, codificados con arreglo a la Lista Europea de Residuos (LER).
	b) Las medidas para la prevención de residuos.
	c) Las operaciones de reutilización, valorización o eliminación a que se destinarán los residuos que se generarán en la obra.
	d) Las medidas para la separación de los residuos en obra.
	e) Planos de las instalaciones previstas para el almacenamiento, manejo, separación y, en su caso, otras operaciones de gestión de los residuos de construcción y demolición dentro de la obra.
	f) Las prescripciones del pliego de prescripciones técnicas particulares del proyecto, en relación con el almacenamiento, manejo, separación y, en su caso, otras operaciones de gestión de los residuos de construcción y demolición dentro de la obra.
	g) Valoración del coste previsto de la gestión de los residuos de construcción y demolición que formará parte del presupuesto del proyecto en capítulo independiente.

## 1.2. DESCRIPCIÓN DE LA ACTUACIÓN

{{descripcion_actuacion}}
