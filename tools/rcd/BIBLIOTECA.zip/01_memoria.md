"""
## Registro de cambios
- Versión: 4 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Encabezado de descripción en mayúsculas y sin dos puntos.
- Versión: 3 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Sección 1.2 de descripción de la actuación y ajuste de la numeración.
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Sección de antecedentes y numeración de la memoria.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
Base adaptada del estudio tipo aportado por el usuario. No incorporar nombres,
direcciones ni importes de aquella obra como datos de otros proyectos.
Los marcadores tabla_* deben conservarse una vez cada uno en el conjunto.
"""
# 1. MEMORIA

## 1.1. ANTECEDENTES

El presente Estudio de Gestión de Residuos de Construcción y Demolición se redacta de acuerdo con el Real Decreto 105/2008, de 1 de febrero, y la Ley 7/2022, de 8 de abril, para los trabajos previstos en el proyecto (Tabla 1).

El estudio estima los residuos que pueden producirse en los trabajos directamente relacionados con la obra y establece criterios para prevenir su generación, separarlos y gestionarlos. Servirá de base al Plan de Gestión de Residuos del constructor, que desarrollará y complementará estas previsiones en función de sus proveedores, medios y sistema de ejecución.

El plan deberá ser aprobado por la dirección facultativa y aceptado por la propiedad. La estimación automática no sustituye la caracterización del residuo, el inventario de sustancias peligrosas, la identificación de gestores ni los planos de instalaciones.

{{tabla_proyecto}}

## 1.2. DESCRIPCIÓN DE LA ACTUACIÓN

{{descripcion_actuacion}}
