## 2.2. PRESCRIPCIONES DE ALMACENAMIENTO, MANEJO Y GESTIÓN EN OBRA

- Los depósitos temporales se situarán en zonas definidas, señalizadas y compatibles con la seguridad, la circulación, la protección de terceros y las ordenanzas municipales.
- Los contenedores, sacos y acopios se elegirán según el residuo y su cantidad. Se identificarán las fracciones y, cuando proceda, la peligrosidad y los datos exigibles del titular. No se atribuye a toda obra una capacidad única de saco o un modelo municipal de rotulación.
- Se evitarán el depósito de residuos ajenos y las dispersiones. Los contenedores se cerrarán o cubrirán cuando proceda, especialmente fuera de horario, y se mantendrán las zonas de acopio en condiciones adecuadas.
- Las fracciones valorizables se separarán y protegerán de mezclas, contaminación y humedad perjudicial. No se mezclarán plásticos, madera o escombros con productos peligrosos.
- Los residuos peligrosos se almacenarán con envases compatibles, cierre, etiquetado y protección frente a derrames, respetando los plazos, límites y demás condiciones legalmente aplicables.
- Los materiales con amianto se retirarán mediante procedimientos y empresas habilitadas conforme a la normativa laboral y ambiental, con el plan de trabajo que proceda. Los residuos de materiales de construcción con amianto se gestionarán como peligrosos; no se mezclarán ni triturarán con otros RCD.
- Las aguas y lodos de lavado de hormigoneras y canaletas se recogerán y gestionarán según su naturaleza. No se verterán directamente al terreno, al saneamiento ni al medio hídrico. Los restos endurecidos se clasificarán separadamente cuando corresponda.
- Las tierras superficiales aptas para un uso posterior se retirarán, protegerán y almacenarán de forma que se conserve su calidad. La geometría y duración de los acopios se adaptarán a su estabilidad y a las condiciones del emplazamiento.
- Los residuos asimilables a domésticos generados por el personal, envases y otras fracciones se gestionarán por sus cauces de recogida separados y con arreglo a las condiciones locales.
- Antes de contratar se comprobarán las autorizaciones o comunicaciones e inscripciones exigibles al transportista y al gestor, así como la habilitación de la instalación para el código LER y tratamiento previstos.
- La eliminación en vertedero cumplirá el RD 646/2020 y el régimen específico de los RCD. No se autoriza de forma general el depósito sin tratamiento previo.
