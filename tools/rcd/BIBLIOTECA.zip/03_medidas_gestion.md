"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
## 1.3. MEDIDAS DE SEPARACIÓN Y DEMOLICIÓN SELECTIVA

Se retirarán y manejarán de forma segura las sustancias peligrosas antes de las operaciones que puedan mezclarlas con otros residuos, en particular los materiales que contengan amianto.

El artículo 30.2 de la Ley 7/2022 exige, desde el 1 de julio de 2022, clasificar los RCD no peligrosos al menos en madera, fracciones minerales de hormigón, ladrillos, azulejos, cerámica y piedra, metales, vidrio, plástico y yeso. Se clasificarán también los elementos susceptibles de reutilización. La clasificación se realizará preferentemente en el lugar de generación, sin perjuicio de las demás recogidas separadas obligatorias.

La demolición selectiva es obligatoria desde el 1 de enero de 2024 en los términos del artículo 30.3 de dicha ley. Las previsiones se adaptarán al tipo de actuación y a las fracciones realmente presentes.

El RD 105/2008 recoge además los siguientes umbrales de separación:

{{tabla_separacion}}

Estos umbrales no se utilizarán para eximir de la clasificación establecida por la Ley 7/2022. Cuando la separación en origen no resulte técnicamente viable por falta de espacio, se justificará la solución admisible y se obtendrá la acreditación de la separación por gestor, sin presumir autorizada una recogida de todo mezclado.

Medios y organización previstos: {{separation}}

## 1.4. PREVISIÓN DE REUTILIZACIÓN

Se evaluará la conservación y reutilización de elementos desmontables, materiales de excavación y componentes minerales, cerámicos, metálicos, de madera o vidrio que sean aptos para el uso previsto. Se distinguirá la reutilización de productos de la preparación para la reutilización de materiales que ya sean residuos.

Para cada operación se identificarán los materiales, las cantidades, el emplazamiento de utilización, las condiciones técnicas y la justificación del régimen jurídico aplicable. Si no se prevé ninguna reutilización, se indicará expresamente, sin deducir de ello un destino obligatorio a vertedero.

Operaciones y destinos particulares: {{reuse}}

## 1.5. PREVISIÓN DE VALORIZACIÓN EN LA PROPIA OBRA

La valorización en la obra se limitará a las operaciones técnica y legalmente admisibles, con las autorizaciones, comunicaciones o controles que correspondan. No se supondrá autorizada una instalación por el mero hecho de incluirla en el estudio.

Se especificarán las fracciones, cantidades y tratamientos, su ubicación, las medidas de control y la operación de valorización aplicable de acuerdo con los anexos vigentes de la legislación de residuos. Si no se prevén operaciones in situ, se hará constar expresamente.

Previsión particular: {{recovery}}

## 1.6. DESTINO DE LOS RESIDUOS NO REUTILIZADOS NI VALORIZADOS EN LA OBRA

Se priorizarán la preparación para la reutilización, el reciclado y las demás formas de valorización frente a la eliminación. Para cada tipo de residuo se concretarán su código LER validado, naturaleza, cantidad, gestor e instalación previstos y operación de tratamiento.

Se comprobará que la autorización de la instalación comprende el residuo y la operación correspondiente. Si interviene un centro de transferencia o almacenamiento, se identificará también el tratamiento ulterior y se mantendrá la trazabilidad hasta el destino final.

El depósito en vertedero será la última opción y estará sujeto al tratamiento previo y a las condiciones de admisión aplicables, incluidas las excepciones legalmente previstas y debidamente justificadas.

Relación de residuos, destinos y gestores: {{destinations}}

## 1.7. MEDIDAS DE PREVENCIÓN

Se ajustarán las compras y mediciones, se planificarán los desmontajes y cortes, se protegerán los acopios frente a deterioros y se estudiarán suministros con embalajes retornables, sistemas reutilizables y posibilidades de devolución al proveedor.

Se evitarán mezclas que conviertan fracciones aprovechables en residuos no valorizables. El personal conocerá las zonas de depósito y las instrucciones de separación.

Medidas concretas de la actuación: {{prevention}}

## 1.8. INSTALACIONES Y PLANOS DE GESTIÓN

El proyecto debe concretar los planos de las instalaciones previstas para almacenamiento, manejo, separación y, en su caso, otras operaciones de gestión. Se identificarán las zonas de acopio, contenedores, almacenamiento de peligrosos, recorridos y accesos de retirada y los medios de protección.

Este documento no genera automáticamente esos planos. Deberán incorporarse al proyecto, indicar sus referencias y adaptarse al sistema de ejecución previo acuerdo de la dirección facultativa.

Emplazamientos, medios y referencia a los planos: {{facilities}}
