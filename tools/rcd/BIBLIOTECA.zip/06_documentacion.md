## 2.3. DOCUMENTACIÓN Y TRAZABILIDAD

La entrega de los residuos se acreditará mediante documentación fehaciente que identifique al productor, poseedor, obra de procedencia y, cuando corresponda, licencia, cantidad, código LER validado y gestor e instalación de destino. Las cantidades se expresarán en toneladas, metros cúbicos o ambas unidades cuando sea posible.

Se conservarán los documentos de aceptación o contratos de tratamiento que procedan, albaranes y pesajes, documentos de identificación del traslado, certificados y acreditaciones del tratamiento final. Si la primera entrega se realiza a un transportista, recogedor o centro intermedio, se documentará también el gestor de valorización o eliminación ulterior.

Los traslados incluidos en el ámbito del RD 553/2020 se ajustarán a sus requisitos. En los supuestos sujetos a notificación previa, se presentará ante la comunidad autónoma de origen con la antelación mínima de diez días prevista en su artículo 8, y se respetarán el procedimiento y los plazos de oposición. No se impone una notificación general a un ministerio por el simple hecho de atravesar varias provincias.

El documento de identificación acompañará al traslado en los casos exigibles y se utilizarán los sistemas electrónicos y procedimientos aplicables. No se reproducen modelos documentales antiguos como requisito universal.

La gestión de residuos peligrosos se sujetará a la Ley 7/2022 y su normativa de desarrollo y autonómica vigente. Los materiales de construcción que contengan amianto se identificarán con el código peligroso que corresponda, entre ellos el 17 06 05*, sin atribuirles una alternativa no peligrosa por defecto.

La reutilización o utilización de materiales en otros emplazamientos se justificará con identificación del destino, cantidades y documentación técnica y administrativa que corresponda. Fotografías u otras evidencias podrán complementar, pero no sustituir, las acreditaciones exigidas.

Se conservará la documentación por los plazos aplicables. El régimen de cinco años del RD 105/2008 y del archivo cronológico cuando sea exigible no se reduce por el plazo específico de otro documento de traslado.
