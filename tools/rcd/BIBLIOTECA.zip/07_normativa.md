"""
## Registro de cambios
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 24/11/2026 | Cambio: Incorporación completa de las referencias normativa estatales, europeas y territoriales aplicables a RCDs.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
## 2.4. NORMATIVA DE REFERENCIA

Se comprobarán el ámbito, la vigencia, las modificaciones y las disposiciones complementarias aplicables a la fecha de ejecución. El marco de referencia comprende:

- Directiva 2008/98/CE, sobre residuos, modificada por la Directiva (UE) 2018/851, y la normativa europea de transposición.
- Directiva 1999/31/CE, relativa al vertido de residuos.
- Decisión 2000/532/CE, que establece la Lista Europea de Residuos, con sus modificaciones, y las disposiciones aplicables para determinar las características de peligrosidad.
- Directiva 94/62/CE, relativa a los envases y residuos de envases, y su normativa europea de desarrollo cuando el embalaje sea objeto de gestión.
- Ley 7/2022, de 8 de abril, de residuos y suelos contaminados para una economía circular.
- Ley 21/2013, de 9 de diciembre, de evaluación ambiental.
- Real Decreto 105/2008, de 1 de febrero, por el que se regula la producción y gestión de los residuos de construcción y demolición.
- Real Decreto 553/2020, de 2 de junio, por el que se regula el traslado de residuos en el interior del territorio del Estado.
- Real Decreto 646/2020, de 7 de julio, por el que se regula la eliminación de residuos mediante depósito en vertedero.
- Real Decreto 9/2005, de 14 de enero, por el que se establece la relación de actividades potencialmente contaminantes del suelo y los criterios y estándares para la declaración de suelos contaminados.
- Real Decreto 180/2015, de 17 de febrero, por el que se aprueba el Reglamento de operaciones de valorización y eliminación de residuos peligrosos.
- Real Decreto 110/2015, de 20 de febrero, sobre residuos de aparatos eléctricos y electrónicos.
- Real Decreto 1055/2022, de 27 de diciembre, sobre envases y residuos de envases.
- Orden APM/1007/2017, de 10 de octubre, sobre normas generales de valorización de materiales naturales excavados para su utilización en operaciones de relleno y obras distintas a aquellas en las que se generaron.
- Ley 31/1995, de 8 de noviembre, de Prevención de Riesgos Laborales.
- Real Decreto 1627/1997, de 24 de octubre, por el que se establecen disposiciones mínimas de seguridad y salud en las obras de construcción.
- Real Decreto 486/1997, de 14 de abril, sobre lugares de trabajo.
- Real Decreto 396/2006, de 31 de marzo, sobre disposiciones mínimas de seguridad y salud aplicables a los trabajos con riesgo de exposición al amianto.
- Real Decreto 108/1991, de 1 de febrero, sobre prevención y reducción de la contaminación producida por el amianto.
- Ley 37/2003, de 17 de noviembre, del Ruido, y Real Decreto 1367/2007, de 19 de octubre, sobre áreas acústicas y emisión y niveles de ruido.
- Real Decreto 1432/2008, de 29 de agosto, por el que se regulan las obligaciones de notificación y evaluación de determinados proyectos públicos y privados.
- Normativa autonómica y ordenanzas municipales de la obra: {{normativa_autonomica}}

Condiciones o referencias particulares del emplazamiento: {{regional}}

Las condiciones de la licencia, del contrato, de las autorizaciones administrativas y de las instalaciones receptoras completarán estas prescripciones.
