## 2.4. NORMATIVA DE REFERENCIA

Se comprobarán el ámbito, la vigencia, las modificaciones y las disposiciones complementarias aplicables a la fecha de ejecución. Como referencias principales, sin carácter exhaustivo, se consideran:

- Ley 7/2022, de 8 de abril, de residuos y suelos contaminados para una economía circular.
- Real Decreto 105/2008, de 1 de febrero, por el que se regula la producción y gestión de los residuos de construcción y demolición.
- Lista Europea de Residuos establecida por la Decisión 2000/532/CE, con sus modificaciones, y las disposiciones aplicables para determinar las características de peligrosidad.
- Real Decreto 553/2020, de 2 de junio, por el que se regula el traslado de residuos en el interior del territorio del Estado, cuando resulte de aplicación.
- Real Decreto 646/2020, de 7 de julio, por el que se regula la eliminación de residuos mediante depósito en vertedero.
- Orden APM/1007/2017, de 10 de octubre, sobre normas generales de valorización de materiales naturales excavados para su utilización en operaciones de relleno y obras distintas a aquellas en las que se generaron, cuando proceda.
- Real Decreto 396/2006, de 31 de marzo, sobre disposiciones mínimas de seguridad y salud aplicables a los trabajos con riesgo de exposición al amianto, y Real Decreto 108/1991, de 1 de febrero, sobre prevención y reducción de la contaminación del medio ambiente producida por el amianto, cuando existan estos materiales.
- Normativa autonómica y ordenanzas municipales de la obra: {{normativa_autonomica}}

Condiciones o referencias particulares del emplazamiento: {{regional}}

No se presentan como disposiciones vigentes los planes de residuos de 2001-2006 ni las leyes derogadas citadas en modelos históricos. Las condiciones de la licencia, del contrato y de las autorizaciones completarán estas prescripciones.
