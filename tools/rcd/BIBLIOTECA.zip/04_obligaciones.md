# 2. PLIEGO DE CONDICIONES

## 2.1. OBLIGACIONES DE LOS AGENTES INTERVINIENTES

El productor de residuos, con el alcance definido en la normativa y normalmente el promotor, incluirá el estudio en el proyecto y dispondrá de la documentación acreditativa de la correcta gestión. En las actuaciones sobre construcciones existentes realizará el inventario de residuos peligrosos que corresponda.

El constructor, como poseedor de los residuos en los términos aplicables, presentará a la propiedad el Plan de Gestión de Residuos. Una vez aprobado por la dirección facultativa y aceptado por la propiedad, pasará a formar parte de los documentos contractuales.

El poseedor mantendrá los residuos en condiciones de higiene y seguridad, evitará mezclar fracciones seleccionadas y, cuando no los gestione por sí mismo conforme a derecho, los entregará a gestores habilitados para el residuo y la operación previstos.

La gestión se ajustará a la jerarquía de residuos y a las previsiones del proyecto. La contratación de la retirada no sustituye la comprobación de la recepción y del tratamiento final.

Productor y poseedor conservarán la documentación de cada año natural durante los cinco años siguientes en los términos del RD 105/2008. Se cumplirá además el régimen de archivo cronológico de la Ley 7/2022 cuando resulte exigible.

Se constituirá la fianza o garantía equivalente cuando proceda según la legislación autonómica y las condiciones de la licencia. Su existencia e importe no se deducen automáticamente de un porcentaje del modelo de cálculo.
