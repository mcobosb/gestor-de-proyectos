### 2.4.1. RESUMEN DEL MÉTODO DE CÁLCULO

El método de referencia distingue el coste de puesta a disposición y el coste de funcionamiento. Se emplean las siguientes nomenclaturas y definiciones:

- E: promedio anual de días de puesta a disposición de la máquina. La base temporal adoptada deberá mantenerse coherente en todos los parámetros.
- T: vida económica, en años, durante la que la máquina puede alcanzar sus rendimientos normales.
- V_t: valor de reposición de la máquina o de otra equivalente, expresado en {{moneda}}.
- H_ut: promedio de horas totales de funcionamiento económico durante la vida útil.
- H_ua: promedio anual de horas de funcionamiento.
- M+C: gastos acumulados de reparaciones generales y conservación ordinaria durante la vida útil, expresados como porcentaje de V_t.
- i: interés anual de la inversión, en porcentaje.
- i_m: interés medio anual equivalente aplicado al valor de reposición durante la vida económica, en porcentaje.
- S: seguros y otros gastos fijos anuales, como impuestos y almacenamiento, expresados como porcentaje de V_t.
- A_d: porcentaje de la amortización imputado a la puesta a disposición; su complemento a 100 se imputa al funcionamiento.
- C_d: coeficiente del coste intrínseco por día de puesta a disposición, expresado como porcentaje de V_t por día.
- C_dm: coste medio diario, en {{moneda}} por día, referido al régimen de utilización que se haya definido.
- C_h: coeficiente del coste intrínseco por hora efectiva de funcionamiento, expresado como porcentaje de V_t por hora.
- C_hm: coeficiente del coste intrínseco de la hora media, que distribuye también el coste de disponibilidad entre las horas anuales de funcionamiento.

La vida económica se obtiene de la relación:

$$
T = H_ut / H_ua
$$

Admitiendo un capital C que se recupera mediante anualidades constantes a durante T años, dichas anualidades deben cubrir el capital y los intereses totales I:

$$
a T = C + I
$$

Los intereses totales se expresan mediante el interés medio anual equivalente:

$$
I = C (i_m / 100) T
$$

Por tanto:

$$
i_m = 100 a / C - 100 / T
$$

La anualidad de amortización, para un interés anual i expresado en porcentaje, es:

$$
a = [C (i / 100) (1 + i / 100)^T] / [(1 + i / 100)^T - 1]
$$

Y el interés medio anual equivalente:

$$
i_m = [i (1 + i / 100)^T / ((1 + i / 100)^T - 1)] - 100 / T
$$

Estas expresiones de anualidad se refieren a un interés no nulo; para i = 0 se utiliza a = C / T e i_m = 0. La vida y los denominadores de las fórmulas deberán ser positivos. Las letras son locales a cada apartado: el capital C de este método no es el coste horario C de mano de obra.

Valor de reposición. La amortización, las reparaciones, la conservación, los seguros y otros gastos están afectados por la evolución de precios y las condiciones de adquisición. Por ello se considera el valor de reposición de la máquina o de otra equivalente, documentado a la fecha de valoración, en lugar de trasladar sin actualización su precio histórico de compra.

Reposición del capital. La parte de amortización correspondiente a la pérdida de valor por obsolescencia se imputa al tiempo de disposición; el resto, asociado al desgaste, se imputa a las horas de funcionamiento. El reparto A_d se justificará para cada tipo de máquina.

Reparaciones generales y conservación ordinaria. Las primeras comprenden revisiones, desmontajes y reparación o sustitución de componentes; la conservación ordinaria persigue la puesta a punto continua y la sustitución de elementos de desgaste. En materiales abrasivos o condiciones especiales se atenderá a los consumos reales.

Ambos gastos se agrupan en M+C por la dificultad de separar sus límites. Este término está relacionado con las horas de vida económica adoptadas y no debe fijarse al margen de ellas.

Horas anuales de funcionamiento. La diversidad de máquinas, capacidades, trabajos y regímenes de utilización exige justificar las horas útiles anuales de cada equipo, sin atribuir un único rendimiento estadístico a toda la maquinaria.

Días anuales de puesta a disposición. Se determinarán con un criterio compatible con las horas anuales y con la definición de día empleada. La presencia de la máquina en obra puede originar costes aunque no esté funcionando.

Seguros y otros gastos fijos. Comprenden, cuando proceda, daños propios, impuestos, almacenamiento y conservación fuera de servicio. El porcentaje S y el interés i se documentarán, sin adoptar automáticamente los valores económicos del ejemplo.

Parámetros y fuentes particulares:

{{machinery_parameters}}
