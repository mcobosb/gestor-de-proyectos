"""
## Registro de cambios
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Ajustes de presentación en el anejo.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
"""
Texto base adaptado del ejemplo aportado por el usuario.
Los salarios, cotizaciones y calendarios de 2008-2009 no se presentan como vigentes.
Los datos comunes proceden de Configuración general. Las revisiones salariales y
otros datos específicos se completan en el asistente o editando esta biblioteca.
"""
# 1. LEGISLACIÓN VIGENTE

Para la determinación de los costes de las distintas unidades de obra que se incluyen en el presente proyecto se han tenido en cuenta las disposiciones y referencias que se indican a continuación, en lo que resulte aplicable a la naturaleza de los trabajos y a su fecha de valoración.

{{tabla_proyecto}}

- Método de cálculo para la obtención del coste de maquinaria en obras de carretera (MOPU, 1976), como referencia técnica histórica, con las actualizaciones y parámetros que se justifiquen para cada equipo.
- {{normativa_contratacion}}
- [Ley 31/1995, de 8 de noviembre, de Prevención de Riesgos Laborales](https://www.boe.es/buscar/act.php?id=BOE-A-1995-24292).
- [Real Decreto 1627/1997, de 24 de octubre, sobre disposiciones mínimas de seguridad y salud en las obras de construcción](https://www.boe.es/buscar/act.php?id=BOE-A-1997-22614).
- [Estatuto de los Trabajadores](https://www.boe.es/buscar/act.php?id=BOE-A-2015-11430), en particular las disposiciones sobre salario mínimo, horas extraordinarias y vacaciones.
- [Ley General de la Seguridad Social](https://www.boe.es/buscar/act.php?id=BOE-A-2015-11724), para el régimen general de cotización y las contingencias profesionales.
- [Real Decreto 486/1997, de 14 de abril](https://www.boe.es/buscar/act.php?id=BOE-A-1997-8669), incluida la protección frente a fenómenos meteorológicos adversos en trabajos al aire libre.

{{tabla_convenio}}

El importe salarial de referencia corresponde a {{salario_texto}}.

{{fuentes_cotizacion}}

{{tabla_cotizaciones}}

Para el plan de pensiones de empleo simplificado, la aportación empresarial de referencia es {{pension_texto}}.

Como referencia para el calendario laboral se adopta el siguiente criterio: {{calendario_texto}}. {{condiciones_texto}}.

{{fuentes_calendario}}

Las referencias laborales se contrastarán con su publicación oficial y con la fecha efectiva de la valoración; no se trasladan automáticamente al proyecto importes ni calendarios de ejercicios anteriores.

{{legislation_notes}}
