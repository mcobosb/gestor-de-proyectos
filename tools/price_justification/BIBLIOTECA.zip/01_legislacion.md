"""
Texto base adaptado del ejemplo aportado por el usuario.
Los salarios, cotizaciones y calendarios de 2008-2009 no se presentan como vigentes.
Los datos comunes proceden de Configuración general. Las revisiones salariales y
otros datos específicos se completan en el asistente o editando esta biblioteca.
"""
# 1. LEGISLACIÓN VIGENTE

Para la determinación de los costes de las distintas unidades de obra que se incluyen en el presente proyecto se han tenido en cuenta las disposiciones y referencias que se indican a continuación, en lo que resulte aplicable a la naturaleza de los trabajos y a su fecha de valoración.

Proyecto: {{titulo_proyecto}}.

Entidad: {{entidad}}. Expediente: {{expediente}}.

Emplazamiento: {{emplazamiento}}. Provincia o provincias: {{provincias}}. Comunidad o comunidades autónomas: {{comunidades_autonomas}}.

Fecha de referencia de los precios: {{fecha_referencia}}.

- Método de cálculo para la obtención del coste de maquinaria en obras de carretera (MOPU, 1976), como referencia técnica histórica, con las actualizaciones y parámetros que se justifiquen para cada equipo.
- {{normativa_contratacion}}
- Ley 31/1995, de 8 de noviembre, de Prevención de Riesgos Laborales.
- Real Decreto 1627/1997, de 24 de octubre, por el que se establecen disposiciones mínimas de seguridad y salud en las obras de construcción.
- Convenio colectivo de construcción y obras públicas aplicable al ámbito territorial de {{provincias}}, junto con sus revisiones salariales. Referencia concreta: {{agreement}}.
- Disposición que fija el salario mínimo interprofesional aplicable a la fecha de valoración. Referencia salarial utilizada: {{wage_reference}}.
- Disposiciones de cotización a la Seguridad Social, desempleo, Fondo de Garantía Salarial, formación profesional y contingencias profesionales aplicables. Referencias y tipos adoptados: {{contributions}}.
- Calendario de fiestas nacionales, autonómicas y locales y calendario laboral del convenio correspondiente al emplazamiento indicado. Referencias: {{calendar}}.

Las referencias laborales se contrastarán con su publicación oficial y con la fecha efectiva de la valoración; no se trasladan automáticamente al proyecto importes ni calendarios de ejercicios anteriores.

{{legislation_notes}}
