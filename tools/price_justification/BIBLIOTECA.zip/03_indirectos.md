"""
## Registro de cambios
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Ajustes de presentación en el anejo.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
## 2.1. COSTES INDIRECTOS

Los costes indirectos comprenden los gastos comunes de la obra que no puedan atribuirse directamente a una unidad concreta. Se expresan mediante un porcentaje sobre los costes directos, adoptado a la vista de la naturaleza de la obra, la importancia del presupuesto y su plazo previsible de ejecución.

Como esquema de justificación se distinguen los costes indirectos propios de la obra y, cuando proceda y esté justificada, la previsión de imprevistos:

$$
K = K_1 + K_2
$$

- K_1 corresponde a los costes indirectos propios de la obra.
- K_2 corresponde a los imprevistos cuya inclusión y cuantía se justifiquen para el contrato.

El coeficiente correspondiente a los costes indirectos propios puede expresarse como:

$$
K_1 = 100 \frac{C_I}{C_D}
$$

Siendo C_I el importe de los costes indirectos justificados y C_D el coste directo total sobre el que se distribuyen.

Se revisarán, entre otros, los siguientes conceptos:

- Personal técnico y administrativo adscrito a la obra: puestos, número de personas, coste mensual, plazo y dedicación efectivamente imputables. Justificación particular: {{indirect_staff}}
- Instalaciones provisionales, oficinas, almacenes, talleres y comunicaciones, sin duplicar las previstas en el presupuesto de seguridad y salud ni en otras unidades. Justificación particular: {{indirect_installations}}
- Trabajos de carácter técnico exigidos por el contrato, incluidos, cuando proceda, levantamientos topográficos del estado final. Justificación particular: {{indirect_technical}}
- Análisis de materiales, pruebas, ensayos de laboratorio y control de obra que sean contractualmente exigibles y no estén valorados por otro concepto. Otros costes y criterio de adopción: {{indirect_other}}

No se computarán dos veces los gastos reflejados en unidades de obra o partidas específicas. Las obligaciones del contratista y de la Administración se delimitarán de acuerdo con el contrato y sus pliegos.

El porcentaje configurado para los informes del proyecto es K = {{porcentaje_indirectos}} %. Los descompuestos muestran los importes efectivos de las partidas. Los coeficientes K_1 y K_2 deberán ser coherentes con el porcentaje adoptado; no se trasladan del ejemplo límites ni porcentajes de imprevistos como reglas universales.

Las fórmulas forman parte del método de justificación. Su inclusión no acredita por sí sola el cálculo de unos importes que no se hayan documentado.
