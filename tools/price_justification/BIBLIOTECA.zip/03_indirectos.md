"""
## Registro de cambios
- Versión: 3 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Revisión de referencias, costes indirectos y presentación del anejo.
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Ajustes de presentación en el anejo.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
## 2.1. COSTES INDIRECTOS

Los costes indirectos comprenden los gastos comunes de la obra que no puedan atribuirse directamente a una unidad concreta. Se expresan mediante un porcentaje sobre los costes directos, adoptado a la vista de la naturaleza de la obra, la importancia del presupuesto y su plazo previsible de ejecución.

Se estima el coste de los gastos comunes por unidades, tarifa mensual, meses y dedicación imputable. No se computan de nuevo gastos ya incluidos en partidas específicas, en seguridad y salud o en otros apartados del presupuesto [[tabla:tabla_indirectos]].

{{tabla_indirectos}}

El coeficiente propio se obtiene dividiendo los costes indirectos propios C_I entre el coste directo total C_D. Se limita K_1 al 2 % como criterio de este anejo, no como una regla general de contratación:

$$
K_1 = 100 \frac{C_I}{C_D} [#k1]
$$

Al coeficiente adoptado se suma K_2, correspondiente a la previsión de imprevistos:

$$
K = K_1 + K_2 [#k]
$$

{{calculo_indirectos}}

{{indirect_staff}}

{{indirect_installations}}

{{indirect_technical}}

{{indirect_other}}
