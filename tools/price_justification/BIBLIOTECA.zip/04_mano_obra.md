"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Ajustes de presentación en el anejo.
"""
## 2.2. MANO DE OBRA

El coste horario para la empresa se determina a partir de las retribuciones, las cargas empresariales y las horas anuales efectivas de trabajo:

$$
C = \frac{A + B + (\frac{k}{100}) A}{H_a}
$$

En esta expresión:

- C, en {{moneda}} por hora, expresa el coste horario para la empresa.
- A, en {{moneda}} anuales, comprende las cantidades percibidas por el trabajador sujetas a cotización.
- B, en {{moneda}} anuales, comprende las cantidades no sujetas a cotización en los términos y con los límites legalmente aplicables.
- k es el porcentaje de cargas empresariales aplicado sobre la base considerada; se divide entre 100 por estar expresado en porcentaje.
- H_a son las horas anuales efectivas de trabajo.

Entre los conceptos retributivos se consideran el salario base, los pluses establecidos en el convenio, las vacaciones, las gratificaciones extraordinarias y cualquier otra retribución salarial que proceda.

Los pluses de distancia, dietas, compensaciones por desgaste de herramienta o ropa de trabajo e indemnizaciones se tratarán según su verdadera naturaleza y régimen de cotización. No se presupone que todo concepto extrasalarial esté exento ni que la base de cotización coincida siempre con la totalidad de A.

Las cargas empresariales incluyen, según proceda, contingencias comunes, desempleo, Fondo de Garantía Salarial, formación profesional, accidentes de trabajo y enfermedades profesionales, así como las cotizaciones adicionales legalmente exigibles. Las horas extraordinarias se tratarán con su régimen específico.

Cuando existan distintas bases, topes, bonificaciones o tipos, el cálculo se desglosará por conceptos en lugar de aplicar indiscriminadamente un único porcentaje.

{{tabla_mano_obra}}

Jornada anual efectiva de referencia: {{annual_hours}} horas.

{{labor_notes}}
