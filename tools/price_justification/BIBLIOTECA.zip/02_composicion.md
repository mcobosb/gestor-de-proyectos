"""
## Registro de cambios
- Versión: 3 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Revisión de referencias, costes indirectos y presentación del anejo.
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Ajustes de presentación en el anejo.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# 2. COMPOSICIÓN DE LOS PRECIOS

{{referencia_composicion}}, cada precio de ejecución material se obtiene a partir del coste directo de la unidad y del porcentaje de costes indirectos que corresponda, según la ecuación [[ec:precio]]:

$$
P_n = (1 + \frac{K}{100}) C_n [#precio]
$$

En esta expresión:

- P_n es el precio de ejecución material de la unidad correspondiente, expresado en {{moneda}}.
- C_n es el coste directo de la unidad, expresado en {{moneda}}.
- K es el porcentaje de costes indirectos sobre los costes directos.

Se consideran costes directos:

- La mano de obra que interviene directamente en la ejecución de la unidad de obra, con sus cargas, pluses y seguros sociales.
- Los materiales que quedan integrados en la unidad o que sean necesarios para su ejecución, a los precios resultantes a pie de obra.
- Los gastos de personal, combustible, energía y demás consumos ocasionados por el funcionamiento de la maquinaria e instalaciones utilizadas en la ejecución de la unidad.
- Los gastos de amortización y conservación de dicha maquinaria e instalaciones.

Los precios de ejecución material no incluyen IVA, gastos generales de empresa ni beneficio industrial, que se consideran en el nivel presupuestario correspondiente.

Los listados de precios elementales, auxiliares y descompuestos que cierran el anejo se obtienen del presupuesto actual del proyecto, conservando sus rendimientos, precios y criterios de redondeo. La emisión del anejo no modifica el presupuesto ni vuelve a aplicar los recargos ya incorporados.

{{composition_notes}}
