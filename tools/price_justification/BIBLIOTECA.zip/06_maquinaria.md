## 2.4. MAQUINARIA

En los gastos debidos a la maquinaria e instalaciones utilizadas en la ejecución de cada unidad de obra se consideran:

- Los costes inherentes a cada máquina: intereses, seguros, gastos fijos, reposición de capital, reparaciones y conservación.
- Los costes complementarios debidos al funcionamiento: operarios, consumos principales y secundarios y otros gastos que no estén ya incorporados al precio.

Los costes indirectos de obra y las cargas de estructura de la empresa se considerarán en sus niveles respectivos, evitando su repetición dentro del coste directo de la máquina.

{{criterio_maquinaria}}

Para el cálculo o contraste de estos costes se describen a continuación la nomenclatura, el método de cálculo y la estructura del coste. Los parámetros económicos y de utilización se justificarán para las máquinas concretas y las condiciones reales de trabajo.

{{machinery_notes}}
