"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
## 2.3. MATERIAL A PIE DE OBRA

El coste a pie de obra de los materiales básicos que integran cada unidad resulta de incrementar el precio de adquisición con los gastos debidos a su carga, transporte y descarga, cuando estos no estén ya incluidos en la oferta o en otros componentes del precio.

Se tendrán en cuenta las procedencias, las condiciones de suministro, las distancias efectivas y los medios de transporte necesarios. Los precios se referirán a materiales con las prestaciones y condiciones de recepción exigidas por el proyecto.

Se comprobará que las mermas, los embalajes y los medios de manipulación se incorporan únicamente cuando proceda y sin duplicar conceptos ya valorados.

{{materials_notes}}
