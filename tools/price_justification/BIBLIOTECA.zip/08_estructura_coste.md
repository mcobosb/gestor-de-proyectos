"""
## Registro de cambios
- Versión: 4 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Se convierte el rótulo de operarios y consumos en un subapartado.
- Versión: 3 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Revisión de referencias, costes indirectos y presentación del anejo.
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 19/11/2026 | Cambio: Ajustes de presentación en el anejo.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
### 2.4.2. ESTRUCTURA DEL COSTE

El coste directo del equipo es la suma del coste intrínseco, relacionado con su valor, y del coste complementario, ligado principalmente al personal y a los consumos no incluidos previamente.

Coste intrínseco. Comprende:

- El interés del capital invertido, aplicado mediante el interés medio anual equivalente.
- Los seguros y otros gastos fijos.
- La reposición del capital: parte por tiempo de disposición y parte por horas de funcionamiento.
- Las reparaciones generales y la conservación ordinaria, imputadas al funcionamiento en el esquema de referencia. Los gastos que realmente se produzcan en parada se tratarán de forma expresa.

Los coeficientes se expresan en porcentaje del valor de reposición V_t. El coeficiente diario de disposición es la suma de intereses y seguros y de la reposición imputada al tiempo de disposición:

$$
C_d = \frac{i_m + S}{E} + \frac{A_d H_ua}{E H_ut}
$$

El coeficiente por hora de funcionamiento incorpora la parte restante de amortización y las reparaciones y conservación:

$$
C_h = \frac{100 - A_d}{H_ut} + \frac{M + C}{H_ut}
$$

Para una máquina de valor V_t, puesta a disposición durante D días y utilizada durante H horas, el coste intrínseco del período es:

$$
C_intrinseco = \frac{(C_d D + C_h H) V_t}{100}
$$

Si se distribuye el coste anual de disposición entre las horas anuales de funcionamiento, el coeficiente de la hora media resulta:

$$
C_hm = C_h + \frac{C_d E}{H_ua}
$$

Sustituyendo los coeficientes anteriores:

$$
C_hm = \frac{100 - A_d}{H_ut} + \frac{M + C}{H_ut} + \frac{[\frac{i_m + S}{E} + \frac{A_d H_ua}{E H_ut}] E}{H_ua}
$$

Simplificando:

$$
C_hm = \frac{100 + (M + C)}{H_ut} + \frac{i_m + S}{H_ua}
$$

De forma equivalente:

$$
C_hm = \frac{100 + (M + C) + \frac{(i_m + S) H_ut}{H_ua}}{H_ut}
$$

El coste intrínseco de utilización de la máquina durante H horas, con ese régimen medio, es:

$$
C_intrinseco = \frac{C_hm H V_t}{100}
$$

La denominación M+C representa el porcentaje conjunto de reparaciones y conservación definido en el apartado anterior, no la suma de otros capitales o costes homónimos. Debe mantenerse coherencia entre porcentajes, días, horas y valor de reposición.

**Coste complementario.**

No depende directamente del valor de reposición, aunque sí de las características del equipo y de su utilización. Comprende la mano de obra de manejo y conservación y los consumos.

La mano de obra suele corresponder al maquinista y, cuando proceda, a la colaboración de ayudantes o peones. Se atenderá a las reglamentaciones y convenios aplicables, a las cargas sociales y a las horas extraordinarias. El coste del personal puede corresponder al tiempo de disposición aunque la máquina no esté funcionando.

Los consumos principales son gasóleo, gasolina y energía eléctrica; dependen de la potencia, del trabajo y del estado de la máquina. Los secundarios comprenden lubricantes y otros materiales de conservación y podrán expresarse como proporción de los principales cuando ese criterio esté justificado.

Como referencias orientativas del método histórico, para condiciones normales se citan los siguientes órdenes de magnitud, que no sustituyen los datos del fabricante ni se aplican automáticamente al presupuesto:

- Gasóleo: de 0,15 a 0,20 litros por hora y kW instalado.
- Gasolina: de 0,30 a 0,40 litros por hora y kW instalado.
- Energía eléctrica: de 0,60 a 0,70 kWh por hora y kW instalado.
- Consumos secundarios: referencias del 20 % del consumo principal en motores de gasóleo, del 10 % en gasolina y del 5 % en accionamiento eléctrico, sujetas a contraste para el equipo concreto.

#### Operarios, consumos y condiciones particulares

{{machinery_consumption}}

Se comprobará qué conceptos incorpora cada precio horario utilizado para no duplicar operarios, energía, combustible, transporte, mantenimiento ni otros gastos. Las fórmulas se incorporan como parte del documento técnico; no recalculan por sí solas los precios del presupuesto.
