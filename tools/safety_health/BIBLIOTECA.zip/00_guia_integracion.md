# Guia de integracion del Estudio de Seguridad y Salud

Este conjunto documental esta preparado para que un generador produzca un Estudio de Seguridad y Salud (ESS) a partir de datos estructurados del proyecto y de referencias a catalogos reutilizables.

## Estructura

| Archivo | Funcion |
|---|---|
| `01_datos_proyecto.md` | Datos y variables de una obra concreta. |
| `02_memoria_general.md` | Texto comun de la memoria, adaptable al proyecto. |
| `03_fichas_unidades_obra.md` | Fichas de unidades de obra y sus relaciones preventivas. |
| `04_catalogos_preventivos.md` | Catalogos normalizados de riesgos, medidas, protecciones, EPI y equipos. |
| `05_gestion_emergencias.md` | Implantacion, emergencias, seguimiento y documentacion. |
| `06_pliego_condiciones.md` | Condiciones tecnicas, organizativas y normativas. |
| `08_matriz_riesgos_por_unidad.md` | Matriz detallada de riesgos aplicables a cada unidad de obra. |
| `09_enlace_automatico_presupuesto.md` | Reglas deterministas para convertir partidas presupuestarias en contenido preventivo. |
| `UNI/` | Biblioteca ESS organizada por prefijos BCCA, con índice y fichas por familia de partidas. |

## Reglas para el generador

1. Sustituir cada variable con formato `{{nombre_variable}}` por un valor validado antes de publicar el documento.
2. No dejar variables sin resolver. Si un dato no esta disponible, generar una advertencia y usar el texto de contingencia indicado.
3. Importar `{{partidas_presupuesto}}` y aplicar `09_enlace_automatico_presupuesto.md` a cada partida.
4. Generar `{{unidades_obra_bcca}}` y `{{unidades_obra}}` a partir de las coincidencias resultantes.
5. Incluir las fichas devueltas por esas reglas.
6. Resolver los identificadores de cada ficha contra `04_catalogos_preventivos.md`. Por ejemplo, `R-ATROPELLO` enlaza con su riesgo, y `PC-BALIZAMIENTO` con su control colectivo.
7. Incorporar las condiciones generales y el texto de la ficha ESS seleccionada una sola vez.
8. Consolidar las referencias duplicadas al redactar: un EPI o una proteccion se describe una vez en el apartado general y se cita en cada ficha aplicable.
9. La seleccion final de medidas, EPI y equipos debe ajustarse a la evaluacion de riesgos, al procedimiento de trabajo y a las condiciones reales de cada tajo.
10. El contenido marcado como `[VALIDAR]` exige comprobacion tecnica o documental antes de emitir el ESS.

## Modelo de relaciones

```text
unidad de obra
  -> riesgos
  -> medidas preventivas
  -> protecciones colectivas
  -> EPI
  -> equipos y maquinaria
  -> requisitos previos / condicionantes
```

Los identificadores son estables y se usan como claves de enlace. El texto visible puede adaptarse al proyecto sin cambiar dichos identificadores.

## Salidas minimas

El generador debera emitir, como minimo:

- portada y datos de la obra;
- memoria general adaptada;
- fichas de las unidades de obra seleccionadas;
- relacion consolidada de riesgos y medidas;
- medios de proteccion y EPI requeridos;
- organizacion preventiva, emergencias y seguimiento;
- pliego de condiciones;
- listado de datos pendientes y advertencias de validacion.
