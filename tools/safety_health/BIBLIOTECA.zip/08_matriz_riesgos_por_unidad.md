# Matriz detallada de riesgos por unidad de obra

Esta matriz complementa las fichas de `03_fichas_unidades_obra.md`. El software debe incluir los riesgos de la fila de la unidad seleccionada y resolver sus controles mediante `04_catalogos_preventivos.md`. La relacion no elimina la obligacion de identificar riesgos adicionales derivados de las condiciones reales del tajo.

| Unidad de obra | Riesgos aplicables |
|---|---|
| `UO-IMPLANTACION` | `R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-TERCEROS`, `R-CAIDA-MISMO-NIVEL`, `R-RESBALON`, `R-GOLPE-OBJETOS`, `R-CORTE`, `R-PINCHAZO`, `R-SOBREESFUERZO`, `R-POSTURA-FORZADA`, `R-ESCASA-ILUMINACION`, `R-CARGA-MENTAL` |
| `UO-DESMONTAJE` | `R-ATROPELLO`, `R-TERCEROS`, `R-GOLPE-ATRAPAMIENTO`, `R-GOLPE-OBJETOS`, `R-APLASTAMIENTO`, `R-CAIDA-OBJETOS`, `R-CORTE`, `R-PINCHAZO`, `R-PROYECCION`, `R-SOBREESFUERZO`, `R-POSTURA-FORZADA`, `R-IZADO-CARGAS`, `R-CAIDA-CARGA-SUSPENDIDA` |
| `UO-FRESADO` | `R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-ATRAPAMIENTO`, `R-VUELCO`, `R-PROYECCION`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-HERRAMIENTA-PORTATIL`, `R-PRESION-HIDRAULICA`, `R-DESNIVEL`, `R-CAIDA-MISMO-NIVEL`, `R-RADIACION-SOLAR`, `R-TERCEROS` |
| `UO-ARQUETAS` | `R-CAIDA-DISTINTO-NIVEL`, `R-CAIDA-OBJETOS`, `R-GOLPE-ATRAPAMIENTO`, `R-APLASTAMIENTO`, `R-CORTE`, `R-PROYECCION`, `R-HERRAMIENTA-PORTATIL`, `R-SOBREESFUERZO`, `R-POSTURA-FORZADA`, `R-CONTACTO-CEMENTO`, `R-DERMATITIS`, `R-ATROPELLO`, `R-TERCEROS` |
| `UO-SANEAMIENTO` | `R-CAIDA-DISTINTO-NIVEL`, `R-DERRUMBE`, `R-CAIDA-OBJETOS`, `R-ASFIXIA`, `R-ESPACIO-CONFINADO`, `R-AGENTE-BIOLOGICO`, `R-SERVICIOS-AFECTADOS`, `R-ELECTRICO`, `R-ATROPELLO`, `R-APLASTAMIENTO`, `R-IZADO-CARGAS`, `R-CAIDA-CARGA-SUSPENDIDA`, `R-RESBALON`, `R-POSTURA-FORZADA` |
| `UO-DEMOLICION` | `R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-ATRAPAMIENTO`, `R-PROYECCION`, `R-CAIDA-OBJETOS`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-HERRAMIENTA-PORTATIL`, `R-PRESION-HIDRAULICA`, `R-DESNIVEL`, `R-CAIDA-MISMO-NIVEL`, `R-SOBREESFUERZO`, `R-TERCEROS` |
| `UO-ASFALTO` | `R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-ATRAPAMIENTO`, `R-APLASTAMIENTO`, `R-VUELCO`, `R-QUEMADURA`, `R-SALPICADURA`, `R-CALOR`, `R-RADIACION-SOLAR`, `R-HUMOS`, `R-QUIMICO`, `R-DERMATITIS`, `R-RUIDO`, `R-VIBRACION`, `R-CAIDA-MISMO-NIVEL`, `R-TERCEROS`, `R-CARGA-MENTAL` |
| `UO-SENALIZACION-H` | `R-ATROPELLO`, `R-TERCEROS`, `R-POLVO`, `R-PROYECCION`, `R-QUIMICO`, `R-DERMATITIS`, `R-SALPICADURA`, `R-INCENDIO`, `R-EXPLOSION`, `R-QUEMADURA`, `R-HERRAMIENTA-PORTATIL`, `R-POSTURA-FORZADA`, `R-RADIACION-SOLAR` |
| `UO-SENALIZACION-V` | `R-ATROPELLO`, `R-TERCEROS`, `R-SERVICIOS-AFECTADOS`, `R-ELECTRICO`, `R-GOLPE-ATRAPAMIENTO`, `R-CORTE`, `R-CAIDA-OBJETOS`, `R-IZADO-CARGAS`, `R-CAIDA-CARGA-SUSPENDIDA`, `R-SOBREESFUERZO`, `R-VIENTO`, `R-RADIACION-SOLAR` |
| `UO-RESIDUOS` | `R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-CAIDA-MISMO-NIVEL`, `R-RESBALON`, `R-GOLPE-ATRAPAMIENTO`, `R-APLASTAMIENTO`, `R-PINCHAZO`, `R-CORTE`, `R-QUIMICO`, `R-DERMATITIS`, `R-CAIDA-OBJETOS`, `R-TERCEROS` |
| `UO-CALIDAD` | `R-ATROPELLO`, `R-TERCEROS`, `R-PROYECCION`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-HERRAMIENTA-PORTATIL`, `R-ELECTRICO`, `R-CAIDA-MISMO-NIVEL`, `R-POSTURA-FORZADA`, `R-ESCASA-ILUMINACION` |
| `UO-METEOROLOGIA` | `R-CALOR`, `R-RADIACION-SOLAR`, `R-HIPOTERMIA`, `R-LLUVIA`, `R-RESBALON`, `R-VIENTO`, `R-VISIBILIDAD-REDUCIDA`, `R-ESCASA-ILUMINACION`, `R-TRABAJOS-NOCTURNOS`, `R-VUELCO` |

## Aplicacion de la matriz

1. Partir de la unidad de obra seleccionada por el codigo BCCA o por `{{unidades_obra}}`.
2. Incorporar los riesgos de su fila, sin sustituir los riesgos ya definidos en la ficha.
3. Identificar los controles y EPI aplicables a cada riesgo mediante evaluacion de riesgos, instrucciones de los equipos y fichas de seguridad.
4. Eliminar riesgos que no concurran y añadir los que introduzcan los equipos, productos, procedimientos o condiciones reales.

Los riesgos de espacio confinado, exposicion quimica, ruido, vibraciones, calor, radiacion solar, electricidad y agentes biologicos requieren una valoracion especifica de la exposicion antes de fijar medidas o EPI definitivos.
