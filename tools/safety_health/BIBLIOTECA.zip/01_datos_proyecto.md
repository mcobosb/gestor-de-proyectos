# Datos del proyecto

Este archivo contiene exclusivamente datos de entrada. Debe completarse para cada obra antes de generar el ESS.

## Identificacion

| Variable | Valor / formato | Obligatoria |
|---|---|---|
| `{{titulo_proyecto}}` | Denominacion oficial de la actuacion | Si |
| `{{tipo_actuacion}}` | Tipologia de obra | Si |
| `{{entidad}}` | Promotor | Si |
| `{{contratista}}` | Contratista, si se conoce | No |
| `{{municipio}}` | Municipio | Si |
| `{{provincia}}` | Provincia | Si |
| `{{emplazamiento}}` | Direccion, viales o ambito de actuacion | Si |
| `{{autor_estudio}}` | Tecnico redactor | Si |
| `{{fecha_documento}}` | Fecha de emision | Si |

## Magnitudes y planificacion

| Variable | Valor / formato | Obligatoria |
|---|---|---|
| `{{presupuesto_ejecucion_material}}` | Importe sin IVA | Si |
| `{{presupuesto_licitacion}}` | Importe total o sin IVA, indicando criterio | Si |
| `{{presupuesto_seguridad_salud}}` | Importe de seguridad y salud | No |
| `{{plazo_ejecucion}}` | Duracion prevista del proyecto | Si |
| `{{numero_trabajadores_punta}}` | Maximo simultaneo previsto | Si |
| `{{superficie_actuacion}}` | Superficie, longitud o volumen significativo | No |
| `{{fecha_inicio_prevista}}` | Fecha o condicion de inicio | No |

## Condicionantes de obra

| Variable | Contenido esperado |
|---|---|
| `{{descripcion_obras}}` | Resumen de unidades y proceso constructivo. |
| `{{partidas_presupuesto}}` | Partidas importadas del presupuesto: codigo, unidad, descripcion, medicion y capitulo. |
| `{{unidades_obra}}` | Resultado generado a partir de las partidas: lista de fichas aplicables. No se rellena manualmente. |
| `{{unidades_obra_bcca}}` | Resultado generado: lista de codigos BCCA identificados. No se rellena manualmente. |
| `{{trafico_existente}}` | Tipo de trafico, cortes, desvíos y restricciones. |
| `{{peatones_terceros}}` | Afeccion a peatones, residentes, comercios y accesibilidad. |
| `{{servicios_afectados}}` | Redes, instalaciones y verificaciones necesarias. |
| `{{condiciones_terreno}}` | Terreno, pendientes, huecos, excavaciones o estabilidad. |
| `{{condiciones_ambientales}}` | Calor, lluvia, viento, polvo, ruido u otras exposiciones. |
| `{{instalaciones_provisionales}}` | Casetas, aseos, electricidad, acopios y accesos. |
| `{{centro_asistencial}}` | Centro de referencia y telefono de emergencia. |
| `{{coordinador_seguridad_salud}}` | CSS durante la ejecucion, si procede. |

## Datos pendientes

Cuando una variable obligatoria no este disponible, el documento debe indicar:

> [VALIDAR] Falta definir `{{nombre_variable}}`. Debera concretarse antes de la aprobacion del Plan de Seguridad y Salud.

No se deben inventar mediciones, ubicaciones de protecciones, itinerarios de evacuacion, dotaciones de EPI ni condiciones de trafico.

La relacion automatica entre `{{partidas_presupuesto}}`, `{{unidades_obra}}` y los contenidos preventivos se define en `09_enlace_automatico_presupuesto.md`.
