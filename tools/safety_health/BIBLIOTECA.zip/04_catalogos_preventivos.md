# Catalogos preventivos

## Riesgos

| ID | Riesgo |
|---|---|
| `R-ATROPELLO` | Atropello, colision o interferencia con vehiculos y maquinaria movil. |
| `R-ATRAPAMIENTO` | Atrapamiento con organos moviles, vehiculos o equipos. |
| `R-CAIDA-MISMO-NIVEL` | Caida por irregularidades, residuos, derrames o falta de orden. |
| `R-CAIDA-DISTINTO-NIVEL` | Caida a huecos, excavaciones, registros o desniveles. |
| `R-DERRUMBE` | Desprendimiento o inestabilidad de excavaciones. |
| `R-DESNIVEL` | Tropiezo o circulacion insegura por escalones y cambios de cota. |
| `R-ESPACIO-CONFINADO` | Atmosfera peligrosa, atrapamiento o rescate complejo en recinto confinado. |
| `R-GOLPE-ATRAPAMIENTO` | Golpe, corte o atrapamiento durante manipulacion de materiales. |
| `R-HUMOS` | Exposicion a humos, vapores o aerosoles. |
| `R-INCENDIO` | Incendio o explosion por productos inflamables o fuentes de ignicion. |
| `R-CALOR` | Estres termico, radiacion solar o contacto con superficies calientes. |
| `R-LLUVIA` | Resbalones, perdida de visibilidad o deterioro de condiciones por lluvia. |
| `R-POLVO` | Exposicion a polvo y particulas. |
| `R-PROYECCION` | Proyeccion de fragmentos, virutas, salpicaduras o microesferas. |
| `R-QUEMADURA` | Contacto con mezclas, equipos o productos a alta temperatura. |
| `R-QUIMICO` | Contacto o inhalacion de agentes quimicos. |
| `R-RUIDO` | Exposicion a niveles de ruido. |
| `R-SERVICIOS-AFECTADOS` | Contacto o daño a redes existentes. |
| `R-SOBREESFUERZO` | Manipulacion manual de cargas y posturas forzadas. |
| `R-TERCEROS` | Acceso de peatones, residentes o personal ajeno al tajo. |
| `R-VIBRACION` | Exposicion a vibraciones mano-brazo o cuerpo entero. |
| `R-VIENTO` | Perdida de estabilidad o control por viento. |
| `R-VISIBILIDAD-REDUCIDA` | Falta de visibilidad por horario, polvo o condiciones meteorologicas. |

## Riesgos complementarios

| ID | Riesgo |
|---|---|
| `R-AGENTE-BIOLOGICO` | Exposicion a agentes biologicos en aguas, lodos, residuos o redes de saneamiento. |
| `R-APLASTAMIENTO` | Aplastamiento entre elementos, equipos, vehiculos o cargas. |
| `R-ASFIXIA` | Deficiencia de oxigeno o desplazamiento del aire respirable. |
| `R-CAIDA-CARGA-SUSPENDIDA` | Caida o balanceo de una carga durante operaciones de elevacion. |
| `R-CAIDA-OBJETOS` | Caida de herramientas, materiales o elementos desde altura o durante su manipulación. |
| `R-CARGA-MENTAL` | Fatiga o error por presion temporal, trafico intenso o coordinacion compleja. |
| `R-CONTACTO-CEMENTO` | Irritacion, quemadura o sensibilizacion por contacto con cemento, mortero u hormigon fresco. |
| `R-CORTE` | Corte por herramientas, aristas, chapas, discos o elementos rotos. |
| `R-DERMATITIS` | Afeccion cutanea por productos quimicos, hidrocarburos, humedad o contacto repetido. |
| `R-ELECTRICO` | Contacto electrico directo o indirecto con instalaciones, equipos o servicios enterrados. |
| `R-ESCASA-ILUMINACION` | Error, tropiezo o atropello debido a iluminacion insuficiente o deslumbramiento. |
| `R-EXPLOSION` | Explosion por atmosfera inflamable, combustible, recipiente a presion o productos incompatibles. |
| `R-GOLPE-OBJETOS` | Golpe contra objetos fijos, moviles, herramientas o materiales. |
| `R-HERRAMIENTA-PORTATIL` | Riesgo derivado del uso de herramientas manuales, electricas o neumaticas. |
| `R-HIPOTERMIA` | Exposicion a frio, humedad o viento con perdida de capacidad termorreguladora. |
| `R-IZADO-CARGAS` | Fallo de eslingas, utiles, enganches o maniobras de elevacion. |
| `R-MOVIMIENTOS-REPETITIVOS` | Trastorno musculoesqueletico por tareas repetitivas o ritmos sostenidos. |
| `R-POSTURA-FORZADA` | Sobrecarga musculoesqueletica por posturas mantenidas o acceso dificil. |
| `R-PRESION-HIDRAULICA` | Proyeccion o inyeccion de fluido por mangueras, equipos o circuitos presurizados. |
| `R-PINCHAZO` | Pinchazo por ferralla, residuos, herramientas o elementos punzantes. |
| `R-RADIACION-SOLAR` | Exposicion a radiacion ultravioleta y sus efectos en la piel y la vista. |
| `R-RESBALON` | Perdida de estabilidad por agua, lodos, emulsiones, grasas o material suelto. |
| `R-RETROCESO-MAQUINA` | Golpe o atropello durante marcha atras de vehiculos o maquinaria. |
| `R-SALPICADURA` | Contacto con salpicaduras de productos, mezcla caliente, morteros o fluidos. |
| `R-SOBREPRESION` | Rotura o descarga imprevista de recipientes, mangueras o equipos presurizados. |
| `R-TRABAJOS-NOCTURNOS` | Riesgo adicional derivado de horario nocturno o visibilidad limitada. |
| `R-VUELCO` | Vuelco de maquinaria, vehiculos, cargas o equipos por terreno, pendiente o maniobra. |

## Medidas preventivas

| ID | Medida |
|---|---|
| `MP-ACCESOS-SEGUROS` | Definir y mantener accesos y recorridos seguros. |
| `MP-CONTROL-IGNICION` | Eliminar fuentes de ignicion y disponer extincion adecuada. |
| `MP-CONTROL-MAQUINARIA` | Usar equipos autorizados, con mantenimiento y maniobras coordinadas. |
| `MP-CONTROL-METEOROLOGICO` | Comprobar condiciones meteorologicas y adoptar limitaciones. |
| `MP-CONTROL-TERMICO` | Planificar pausas, hidratacion, sombra y vigilancia ante calor. |
| `MP-ESTABILIDAD-EXCAVACION` | Evaluar taludes, entibacion, cargas proximas y acceso a excavaciones. |
| `MP-HIGIENE-QUIMICA` | Consultar fichas de seguridad, evitar exposicion y asegurar higiene. |
| `MP-HUMECTACION` | Aplicar humectacion, captacion o limpieza que reduzca el polvo. |
| `MP-ILUMINACION` | Asegurar iluminacion suficiente sin deslumbrar al trafico. |
| `MP-LOCALIZAR-SERVICIOS` | Identificar, consignar o proteger servicios antes de intervenir. |
| `MP-MANIPULACION-CARGAS` | Usar ayudas mecanicas y tecnicas seguras de manipulacion. |
| `MP-ORDEN-LIMPIEZA` | Retirar residuos y mantener las superficies transitables. |
| `MP-PERMISO-ESPACIO-CONFINADO` | Aplicar permiso de trabajo, medicion atmosferica y rescate especifico. |
| `MP-PROTEGER-DESNIVELES` | Eliminar, señalizar o proteger cambios de nivel y escalones. |
| `MP-PROTEGER-HUECOS` | Cubrir o cerrar huecos con sistemas resistentes e inmovilizados. |
| `MP-SEGREGACION` | Separar flujos de peatones, vehiculos y maquinaria. |
| `MP-SUSPENDER-TRABAJO` | Paralizar y reevaluar ante condiciones inseguras. |
| `MP-ZONA-EXCLUSION` | Mantener a las personas fuera de zonas de maniobra o proyeccion. |

## Protecciones colectivas

| ID | Proteccion |
|---|---|
| `PC-ACCESO-EXCAVACION` | Escalera o acceso seguro a excavacion. |
| `PC-BALIZAMIENTO` | Balizamiento visible y mantenido del tajo. |
| `PC-BARRERA-RIGIDA` | Barrera fisica estable contra acceso o caida. |
| `PC-ENTIBACION` | Sistema de sostenimiento definido segun excavacion. |
| `PC-EXTINTOR` | Medio de extincion adecuado y accesible. |
| `PC-ILUMINACION` | Iluminacion temporal segura. |
| `PC-PROTECCION-DESNIVELES` | Cerramiento, rampa o transicion segura de desniveles. |
| `PC-SENALIZACION` | Señalizacion temporal de obra y regulacion del trafico. |
| `PC-TAPA-RESISTENTE` | Tapa resistente, estable e inmovilizada. |
| `PC-VALLADO` | Valla o cerramiento movil continuo. |
| `PC-ZONA-EXCLUSION` | Delimitacion fisica de zona prohibida. |

## Equipos de proteccion individual

| ID | EPI |
|---|---|
| `EPI-ALTA-VISIBILIDAD` | Prenda de alta visibilidad adecuada a la zona de circulacion. |
| `EPI-AUDITIVO` | Proteccion auditiva seleccionada segun evaluacion de exposicion. |
| `EPI-CALZADO` | Calzado de seguridad con prestaciones adecuadas al tajo. |
| `EPI-CASCO` | Casco de proteccion cuando exista riesgo de golpe o caida de objetos. |
| `EPI-GUANTES` | Guantes de proteccion mecanica. |
| `EPI-GUANTES-QUIMICOS` | Guantes compatibles con el producto quimico utilizado. |
| `EPI-GUANTES-TERMICOS` | Guantes frente al contacto termico. |
| `EPI-OCULAR` | Gafas o pantalla contra proyecciones y salpicaduras. |
| `EPI-PROTECCION-SOLAR` | Proteccion frente a radiacion solar conforme a la evaluacion. |
| `EPI-RESPIRATORIO` | Proteccion respiratoria seleccionada para el contaminante y concentracion. |
| `EPI-ROPA-CALOR` | Ropa adecuada frente a calor y salpicaduras de mezcla caliente. |
| `EPI-ROPA-LLUVIA` | Ropa impermeable compatible con alta visibilidad. |

## Equipos y maquinaria

| ID | Equipo |
|---|---|
| `EQ-BARREDORA` | Barredora o equipo de limpieza mecanica. |
| `EQ-CAMION` | Camion de transporte o descarga. |
| `EQ-CARGADORA` | Pala cargadora o equipo equivalente. |
| `EQ-COMPACTADOR-MANUAL` | Bandeja vibrante, pisón u otro compactador manual. |
| `EQ-CORTE` | Cortadora, radial o equipo de corte con resguardos. |
| `EQ-DETECCION-GASES` | Equipo de medicion atmosferica para espacio confinado. |
| `EQ-ELEVACION` | Medio de elevacion y utiles de izado adecuados. |
| `EQ-EXCAVADORA` | Excavadora o retroexcavadora. |
| `EQ-EXTRACCION-TESTIGOS` | Equipo de corte y extraccion de testigos. |
| `EQ-EXTENDEDORA` | Extendedora de mezcla bituminosa. |
| `EQ-FRESADORA` | Fresadora de pavimento. |
| `EQ-HERRAMIENTA-MANUAL` | Herramientas manuales o portatiles. |
| `EQ-ILUMINACION-PORTATIL` | Equipo de iluminacion temporal. |
| `EQ-MAQUINA-MARCAJE` | Equipo de aplicacion de señalizacion horizontal. |
| `EQ-MARTILLO-DEMOLEDOR` | Martillo demoledor o equipo de demolicion. |
| `EQ-RODILLO-COMPACTADOR` | Rodillo o compactador autopropulsado. |
| `EQ-SENALIZACION-OBRA` | Señales, conos, paneles y elementos de balizamiento. |
