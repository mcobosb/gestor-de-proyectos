# Catalogos preventivos

## Riesgos

| ID | Riesgo |
|---|---|
| `R-ATROPELLO` | Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad. |
| `R-ATRAPAMIENTO` | Aprisionamiento de una parte del cuerpo entre órganos móviles, transmisiones o elementos de un equipo. Puede producir aplastamientos o amputaciones durante el uso, limpieza o mantenimiento; exige resguardos operativos y aislamiento seguro antes de intervenir. |
| `R-CAIDA-MISMO-NIVEL` | Pérdida de equilibrio sobre la superficie de trabajo por irregularidades, residuos, cables o derrames. Puede provocar golpes, esguinces y fracturas; se previene manteniendo recorridos despejados, superficies estables y un orden y limpieza continuos. |
| `R-CAIDA-DISTINTO-NIVEL` | Caída desde bordes, plataformas o accesos hacia huecos, excavaciones, pozos o registros. Sus consecuencias dependen de la altura y la superficie de impacto; requiere accesos seguros, tapas resistentes y protecciones colectivas adecuadas al desnivel. |
| `R-DERRUMBE` | Desprendimiento de tierras o pérdida de estabilidad de taludes, paredes de excavación o elementos próximos. Puede sepultar o golpear a las personas; deben evaluarse el terreno, agua, vibraciones y cargas cercanas antes de definir el sostenimiento. |
| `R-DESNIVEL` | Circulación insegura por escalones, bordes y cambios de cota, especialmente al transportar materiales o compartir paso con equipos. Puede originar tropiezos, caídas o pérdida de control; deben acondicionarse y protegerse las transiciones. |
| `R-ESPACIO-CONFINADO` | Trabajo en recintos de acceso limitado donde pueden acumularse contaminantes o faltar oxígeno, con evacuación difícil. Exige evaluación específica, control atmosférico, comunicación y rescate planificado; nunca debe improvisarse la entrada para auxiliar a otra persona. |
| `R-GOLPE-ATRAPAMIENTO` | Golpe, corte o aprisionamiento al mover tapas, bordillos, señales y otros materiales, especialmente durante su ajuste o descarga. Deben preverse puntos de agarre, apoyos estables, ayudas mecánicas y coordinación entre las personas que intervienen. |
| `R-HUMOS` | Inhalación de humos, vapores o aerosoles procedentes de motores, productos y mezclas bituminosas calientes. Puede causar irritación u otros daños respiratorios según su composición; se limitará la exposición mediante control en origen, ventilación y organización del trabajo. |
| `R-INCENDIO` | Combustión no controlada de combustibles, productos inflamables, residuos o equipos, favorecida por chispas y superficies calientes. Puede causar quemaduras e intoxicación por humo; exige controlar fuentes de ignición, almacenamiento, evacuación y medios de primera intervención. |
| `R-CALOR` | Carga térmica elevada por temperatura, radiación solar, humedad, esfuerzo físico o proximidad a materiales calientes. Puede provocar deshidratación, agotamiento o golpe de calor; requiere agua, pausas, recuperación térmica y adaptación de horarios y ritmos. |
| `R-LLUVIA` | Empeoramiento de adherencia, estabilidad del terreno y visibilidad por lluvia o acumulación de agua. Aumenta el riesgo de resbalón y de pérdida de control de vehículos; obliga a reorganizar o suspender las operaciones comprometidas. |
| `R-POLVO` | Inhalación de partículas generadas en fresado, corte, demolición o limpieza, con efectos dependientes del material y su composición. Se reducirá la emisión mediante captación, aspiración o humectación compatible, evitando el barrido en seco que genere exposición innecesaria. |
| `R-PROYECCION` | Impacto de fragmentos, virutas, partículas o microesferas despedidas durante corte, perforación, demolición o marcado. Puede lesionar ojos y piel; requiere resguardos, distancias de seguridad, zonas de exclusión y protección ocular adecuada al riesgo residual. |
| `R-QUEMADURA` | Lesión por contacto o salpicadura de mezclas bituminosas, ligantes, equipos o superficies calientes. Debe evitarse el contacto mediante herramientas y protección térmica apropiadas, manteniendo la temperatura técnicamente necesaria y aplicando el procedimiento de primeros auxilios. |
| `R-QUIMICO` | Exposición por inhalación, contacto cutáneo u ocular a pinturas, disolventes, emulsiones y otros productos. Puede causar irritación, quemaduras, sensibilización o intoxicación; exige ficha de datos de seguridad actualizada y control de incompatibilidades, ventilación e higiene. |
| `R-RUIDO` | Exposición al ruido de fresadoras, martillos, radiales, compactadores y otros equipos, con posible daño auditivo y dificultad para percibir avisos. Se evaluará cuando sea significativa, priorizando equipos menos ruidosos, mantenimiento y control del tiempo de exposición. |
| `R-SERVICIOS-AFECTADOS` | Contacto o daño accidental a redes eléctricas, de gas, agua, saneamiento o telecomunicaciones durante excavaciones y demoliciones. Puede producir electrocución, fugas, inundación o interrupciones; requiere información previa, localización y coordinación con los titulares. |
| `R-SOBREESFUERZO` | Sobrecarga física al levantar, transportar, empujar o colocar tapas, señales, bordillos, sacos y herramientas. Puede provocar lesiones musculares y lumbares; deben emplearse ayudas mecánicas, trabajo coordinado y una organización que limite la manipulación manual. |
| `R-TERCEROS` | Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información. |
| `R-VIBRACION` | Transmisión de vibraciones mano-brazo o de cuerpo entero por martillos, compactadores y maquinaria móvil. Puede causar trastornos vasculares, nerviosos o musculoesqueléticos; se considerarán valores del fabricante, uso real, firme, mantenimiento y tiempo de exposición. |
| `R-VIENTO` | Pérdida de estabilidad o control de cargas, señales, equipos y materiales por rachas de viento. Puede producir vuelcos, caídas y proyecciones; deben respetarse las limitaciones de los equipos y suspender las maniobras cuando no exista control seguro. |
| `R-VISIBILIDAD-REDUCIDA` | Dificultad para reconocer personas, obstáculos y señales por oscuridad, polvo, lluvia o deslumbramiento. Aumenta atropellos, colisiones y errores de maniobra; requiere iluminación sin deslumbramientos, señalización visible y reorganización del trabajo cuando resulte insuficiente. |

## Riesgos complementarios

| ID | Riesgo |
|---|---|
| `R-AGENTE-BIOLOGICO` | Contacto o inhalación de agentes presentes en aguas residuales, lodos, residuos y redes de saneamiento, incluidas salpicaduras y heridas contaminadas. Puede provocar infecciones; requiere higiene, control de aerosoles y protección conforme a la evaluación. |
| `R-APLASTAMIENTO` | Compresión del cuerpo entre vehículos, equipos, elementos constructivos o cargas, con posibles lesiones graves o mortales. Deben evitarse posiciones entre elementos móviles y fijos, asegurar apoyos y establecer zonas de exclusión durante las maniobras. |
| `R-ASFIXIA` | Insuficiencia de oxígeno respirable o desplazamiento del aire por gases en pozos, registros y recintos poco ventilados. Puede causar pérdida rápida de conciencia; exige evaluación atmosférica, procedimiento de acceso y rescate previsto, sin entradas improvisadas. |
| `R-CAIDA-CARGA-SUSPENDIDA` | Caída, desplazamiento o balanceo de una carga izada por fallo de sujeción, pérdida de estabilidad o maniobra inadecuada. Puede golpear o aplastar; requiere útiles adecuados, maniobras coordinadas y ausencia de personas bajo cargas suspendidas. |
| `R-CAIDA-OBJETOS` | Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas. |
| `R-CARGA-MENTAL` | Exigencia de atención elevada o sostenida por tráfico, presión temporal, alarmas y coordinación simultánea de tareas. Puede favorecer fatiga y errores; requiere instrucciones claras, pausas, reparto de responsabilidades y ritmos compatibles con una ejecución segura. |
| `R-CONTACTO-CEMENTO` | Contacto de piel u ojos con cemento, mortero u hormigón fresco, especialmente si queda retenido dentro de guantes, botas o ropa. Puede causar irritación, quemaduras y sensibilización; requiere evitar contacto prolongado e higiene inmediata adecuada. |
| `R-CORTE` | Lesión por contacto con filos, aristas, chapas, discos, herramientas o elementos rotos durante uso y manipulación. Deben mantenerse los resguardos, emplearse útiles adecuados y organizar el agarre y transporte evitando la exposición de manos y cuerpo. |
| `R-DERMATITIS` | Alteración de la piel por contacto repetido con productos químicos, hidrocarburos, humedad o materiales irritantes. Puede producir inflamación y sensibilización; se reducirá el contacto mediante sustitución, higiene y guantes compatibles con el agente y la tarea. |
| `R-ELECTRICO` | Contacto directo con partes en tensión o indirecto con masas accidentalmente energizadas, incluidas redes enterradas y equipos portátiles. Puede causar electrocución, quemaduras o caídas; requiere localizar servicios y aplicar aislamiento y procedimientos eléctricos autorizados. |
| `R-ESCASA-ILUMINACION` | Iluminación insuficiente, sombras o deslumbramientos que impiden distinguir desniveles, herramientas y personas. Favorece errores, tropiezos y atropellos; deben iluminarse puestos e itinerarios sin deslumbrar al tráfico ni crear zonas de contraste peligroso. |
| `R-EXPLOSION` | Liberación súbita de energía y presión por atmósferas inflamables, productos incompatibles o recipientes presurizados. Puede causar onda de presión, proyecciones y quemaduras; exige identificar sustancias y atmósferas peligrosas, controlar la ignición y aplicar procedimientos específicos. |
| `R-GOLPE-OBJETOS` | Impacto contra objetos fijos, herramientas, materiales o elementos en movimiento durante desplazamientos y operaciones de obra. Puede causar contusiones y heridas; requiere recorridos despejados, acopios estables y separación respecto a elementos móviles. |
| `R-HERRAMIENTA-PORTATIL` | Exposición a cortes, golpes, proyecciones, contactos eléctricos o atrapamientos al utilizar herramientas manuales, eléctricas y neumáticas. Deben seleccionarse según la tarea, conservar sus protecciones y comprobar el estado de útiles, cables y conexiones. |
| `R-HIPOTERMIA` | Pérdida de calor corporal por frío, humedad y viento, especialmente en trabajos prolongados o con ropa mojada. Puede reducir destreza y atención; requiere ropa adecuada, pausas protegidas y adaptación del tiempo de exposición. |
| `R-IZADO-CARGAS` | Pérdida de control en elevación por fallo de eslingas, enganches, útiles, apoyos o coordinación de maniobras. Puede ocasionar caída de cargas, golpes o vuelcos; exige medios adecuados, comprobaciones previas y personal formado y autorizado. |
| `R-MOVIMIENTOS-REPETITIVOS` | Repetición frecuente de los mismos movimientos de manos, brazos u otras articulaciones, especialmente con fuerza o recuperación insuficiente. Puede originar trastornos musculoesqueléticos; deben alternarse tareas y adecuarse herramientas, ritmos y pausas. |
| `R-POSTURA-FORZADA` | Mantenimiento de posiciones incómodas o extremas de espalda, cuello o extremidades durante trabajos a baja altura o de acceso difícil. Puede causar sobrecarga musculoesquelética; requiere adaptar el puesto, utilizar ayudas y alternar posturas y tareas. |
| `R-PRESION-HIDRAULICA` | Escape o inyección accidental de fluido a presión por rotura de mangueras, acoplamientos o circuitos hidráulicos. Puede provocar lesiones profundas y proyecciones; requiere mantenimiento y despresurización segura antes de intervenir, sin comprobar fugas con las manos. |
| `R-PINCHAZO` | Penetración de elementos punzantes como ferralla, alambres, residuos o herramientas en manos, pies u otras zonas del cuerpo. Puede causar heridas e infección; deben protegerse extremos, retirarse residuos y emplearse útiles y protección adecuados. |
| `R-RADIACION-SOLAR` | Exposición a radiación ultravioleta durante trabajos al aire libre, con posibles quemaduras y daños acumulativos en piel y ojos. Debe reducirse mediante sombra, organización horaria y protección personal adecuada, sin confundirla con el control del calor. |
| `R-RESBALON` | Pérdida de adherencia por agua, lodos, emulsiones, grasas o material suelto en superficies de paso y trabajo. Puede causar caídas y pérdida de control de equipos; requiere contener derrames, limpiar y acondicionar los recorridos. |
| `R-RETROCESO-MAQUINA` | Golpe o atropello durante la marcha atrás de vehículos o maquinaria por puntos ciegos o presencia de personas en la trayectoria. Se limitarán estas maniobras, se delimitará su recorrido y se dispondrá señalista cuando la visibilidad sea insuficiente. |
| `R-SALPICADURA` | Proyección de pequeñas cantidades de productos, morteros, fluidos o mezcla caliente sobre piel y ojos. Puede causar irritación, lesión química o quemadura térmica; deben controlarse la aplicación y las distancias, usando protección compatible con el producto. |
| `R-SOBREPRESION` | Aumento o liberación imprevista de presión en recipientes, mangueras y equipos, con posible rotura, latigazo o proyección de componentes. Requiere equipos adecuados e inspeccionados y aislamiento y descarga segura antes de realizar mantenimiento. |
| `R-TRABAJOS-NOCTURNOS` | Incremento de fatiga y disminución de atención y visibilidad durante trabajos nocturnos, especialmente junto a tráfico. Deben organizarse descansos, iluminación y señalización, comprobando la percepción de personas y obstáculos y la coordinación de maniobras. |
| `R-VUELCO` | Pérdida de estabilidad de maquinaria, vehículos, cargas o equipos por pendiente, terreno débil, proximidad a bordes o maniobras. Puede provocar aplastamientos y caídas; requiere comprobar apoyos, límites de uso y condiciones del recorrido. |

## Medidas preventivas

| ID | Medida |
|---|---|
| `MP-ACCESOS-SEGUROS` | Definir y mantener accesos y recorridos seguros. |
| `MP-CONTROL-IGNICION` | Alejar inflamables de llamas, chispas y superficies capaces de iniciar la combustión; controlar almacenamiento e incompatibilidades y disponer de extinción adecuada y accesible, sin sustituir el aviso temprano y la evacuación. |
| `MP-CONTROL-MAQUINARIA` | Usar equipos autorizados, con mantenimiento y maniobras coordinadas. |
| `MP-CONTROL-METEOROLOGICO` | Comprobar condiciones meteorologicas y adoptar limitaciones. |
| `MP-CONTROL-TERMICO` | Evaluar calor, radiación, humedad, esfuerzo, ropa y proximidad a materiales calientes. Garantizar agua, sombra, pausas y recuperación térmica; adaptar horarios y ritmos y vigilar síntomas de agotamiento, actuando según el procedimiento de emergencia. |
| `MP-ESTABILIDAD-EXCAVACION` | Evaluar taludes, entibacion, cargas proximas y acceso a excavaciones. |
| `MP-HIGIENE-QUIMICA` | Disponer de ficha de datos de seguridad actualizada antes del uso. Respetar incompatibilidades, almacenamiento, ventilación e higiene; mantener envases identificados, sin trasvases a recipientes de comida o bebida, y contener derrames evitando su llegada al saneamiento. |
| `MP-HUMECTACION` | Reducir el polvo en origen mediante captación, aspiración o humectación compatible con el trabajo. Evitar el barrido en seco cuando genere exposición innecesaria; recurrir a protección respiratoria adecuada solo si la evaluación identifica riesgo residual. |
| `MP-ILUMINACION` | Asegurar iluminacion suficiente sin deslumbrar al trafico. |
| `MP-LOCALIZAR-SERVICIOS` | Identificar, consignar o proteger servicios antes de intervenir. |
| `MP-MANIPULACION-CARGAS` | Usar ayudas mecanicas y tecnicas seguras de manipulacion. |
| `MP-ORDEN-LIMPIEZA` | Retirar residuos y mantener las superficies transitables. |
| `MP-PERMISO-ESPACIO-CONFINADO` | Aplicar permiso de trabajo, medicion atmosferica y rescate especifico. |
| `MP-PROTEGER-DESNIVELES` | Eliminar, señalizar o proteger cambios de nivel y escalones. |
| `MP-PROTEGER-HUECOS` | Cubrir o cerrar huecos con sistemas resistentes e inmovilizados. |
| `MP-SEGREGACION` | Separar flujos de peatones, vehiculos y maquinaria. |
| `MP-SUSPENDER-TRABAJO` | Paralizar y reevaluar ante condiciones inseguras. |
| `MP-ZONA-EXCLUSION` | Mantener a las personas fuera de zonas de maniobra o proyeccion. |

## Protecciones colectivas

| ID | Proteccion |
|---|---|
| `PC-ACCESO-EXCAVACION` | Escalera o acceso seguro a excavacion. |
| `PC-BALIZAMIENTO` | Balizamiento visible y mantenido del tajo. |
| `PC-BARRERA-RIGIDA` | Barrera fisica estable contra acceso o caida. |
| `PC-ENTIBACION` | Sistema de sostenimiento definido segun excavacion. |
| `PC-EXTINTOR` | Medio de extincion adecuado y accesible. |
| `PC-ILUMINACION` | Iluminacion temporal segura. |
| `PC-PROTECCION-DESNIVELES` | Cerramiento, rampa o transicion segura de desniveles. |
| `PC-SENALIZACION` | Señalizacion temporal de obra y regulacion del trafico. |
| `PC-TAPA-RESISTENTE` | Tapa resistente, estable e inmovilizada. |
| `PC-VALLADO` | Valla o cerramiento movil continuo. |
| `PC-ZONA-EXCLUSION` | Delimitacion fisica de zona prohibida. |

## Equipos de proteccion individual

| ID | EPI |
|---|---|
| `EPI-ALTA-VISIBILIDAD` | Prenda de alta visibilidad adecuada a la zona de circulacion. |
| `EPI-AUDITIVO` | Protector auditivo seleccionado según la exposición y con atenuación adecuada, sin aislar innecesariamente de señales de alarma o tráfico; compatible con los demás equipos de protección. |
| `EPI-CALZADO` | Calzado de seguridad con prestaciones adecuadas al tajo. |
| `EPI-CASCO` | Casco de proteccion cuando exista riesgo de golpe o caida de objetos. |
| `EPI-GUANTES` | Guantes de proteccion mecanica. |
| `EPI-GUANTES-QUIMICOS` | Guantes compatibles con el producto quimico utilizado. |
| `EPI-GUANTES-TERMICOS` | Guantes frente al contacto termico. |
| `EPI-OCULAR` | Gafas o pantalla contra proyecciones y salpicaduras. |
| `EPI-PROTECCION-SOLAR` | Proteccion frente a radiacion solar conforme a la evaluacion. |
| `EPI-RESPIRATORIO` | Protección respiratoria cuando la evaluación lo requiera, seleccionada según contaminante y concentración, ajuste al usuario y compatibilidad con otros EPI; no sustituye el control de la exposición en origen. |
| `EPI-ROPA-CALOR` | Ropa adecuada frente a calor y salpicaduras de mezcla caliente. |
| `EPI-ROPA-LLUVIA` | Ropa impermeable compatible con alta visibilidad. |

## Equipos y maquinaria

| ID | Equipo |
|---|---|
| `EQ-BARREDORA` | Barredora o equipo de limpieza mecanica. |
| `EQ-CAMION` | Camion de transporte o descarga. |
| `EQ-CARGADORA` | Pala cargadora o equipo equivalente. |
| `EQ-COMPACTADOR-MANUAL` | Bandeja vibrante, pisón u otro compactador manual. |
| `EQ-CORTE` | Cortadora, radial o equipo de corte con resguardos. |
| `EQ-DETECCION-GASES` | Equipo de medicion atmosferica para espacio confinado. |
| `EQ-ELEVACION` | Medio de elevacion y utiles de izado adecuados. |
| `EQ-EXCAVADORA` | Excavadora o retroexcavadora. |
| `EQ-EXTRACCION-TESTIGOS` | Equipo de corte y extraccion de testigos. |
| `EQ-EXTENDEDORA` | Extendedora de mezcla bituminosa. |
| `EQ-FRESADORA` | Fresadora de pavimento. |
| `EQ-HERRAMIENTA-MANUAL` | Herramientas manuales o portatiles. |
| `EQ-ILUMINACION-PORTATIL` | Equipo de iluminacion temporal. |
| `EQ-MAQUINA-MARCAJE` | Equipo de aplicacion de señalizacion horizontal. |
| `EQ-MARTILLO-DEMOLEDOR` | Martillo demoledor o equipo de demolicion. |
| `EQ-RODILLO-COMPACTADOR` | Rodillo o compactador autopropulsado. |
| `EQ-SENALIZACION-OBRA` | Señales, conos, paneles y elementos de balizamiento. |
