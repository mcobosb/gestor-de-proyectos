# Memoria general

## Objeto y alcance

El presente Estudio de Seguridad y Salud establece las previsiones preventivas para la ejecucion de `{{titulo_proyecto}}`, promovido por `{{entidad}}`, en `{{municipio}}` (`{{provincia}}`). Su objeto es servir de base al Plan de Seguridad y Salud del contratista, que debera adaptarlo al procedimiento, equipos, personal y secuencia de trabajo realmente previstos, sin reducir el nivel de proteccion definido.

La actuacion comprende `{{descripcion_obras}}`. El plazo previsto es `{{plazo_ejecucion}}` y la concurrencia maxima estimada es de `{{numero_trabajadores_punta}}` trabajadores.

## Datos y condicionantes

La obra se desarrollara en `{{emplazamiento}}`. Se tendran en cuenta especialmente:

- trafico y restricciones: `{{trafico_existente}}`;
- afeccion a terceros: `{{peatones_terceros}}`;
- servicios e interferencias: `{{servicios_afectados}}`;
- condiciones de terreno y desniveles: `{{condiciones_terreno}}`;
- condiciones ambientales previsibles: `{{condiciones_ambientales}}`.

Antes de cada tajo se verificaran los condicionantes reales y se implantaran las medidas correspondientes. Ningun trabajo se iniciara sin delimitacion, señalizacion, accesos seguros y coordinacion con las actividades concurrentes.

## Criterios preventivos generales

La prevencion se integrara en la planificacion y se aplicara conforme a los siguientes criterios:

1. Eliminar el riesgo desde el diseño o el procedimiento, cuando sea posible.
2. Priorizar medidas organizativas y protecciones colectivas frente a los EPI.
3. Segregar personas, vehiculos y maquinaria mediante itinerarios, zonas de exclusion y señalizacion.
4. Mantener el tajo ordenado, limpio y con accesos seguros.
5. Adaptar el trabajo a las condiciones meteorologicas, de visibilidad y de trafico.
6. Suspender y reevaluar los trabajos cuando aparezca un riesgo no previsto o cambien las condiciones de ejecucion.

## Aplicacion por unidades de obra

Las unidades incluidas en esta obra son: `{{unidades_obra}}`. Los codigos de sus partidas presupuestarias son: `{{unidades_obra_bcca}}`.

El generador aplicara `09_enlace_automatico_presupuesto.md` y el indice de `UNI/` para seleccionar las fichas ESS correspondientes. De ellas obtendra las referencias a riesgos, medidas, protecciones, EPI y equipos de `03_fichas_unidades_obra.md`, `04_catalogos_preventivos.md` y `08_matriz_riesgos_por_unidad.md`.

## Proteccion de terceros

La ocupacion de la via o de zonas accesibles al publico requerira una delimitacion fisica adecuada al riesgo, señalizacion temporal y mantenimiento de recorridos seguros. Se protegeran particularmente los huecos, excavaciones, maniobras de maquinaria, cargas, materiales calientes y zonas con riesgo de proyeccion.

No se utilizara cinta de balizamiento como unica medida cuando sea necesaria una barrera fisica resistente. Las medidas se ajustaran a la autorizacion de ocupacion, la regulacion del trafico y las instrucciones de la autoridad competente.

## Cierre de la memoria

Las medidas de este ESS se completaran y concretaran en el Plan de Seguridad y Salud, conforme a la evaluacion de riesgos de las empresas intervinientes y a las condiciones reales de `{{titulo_proyecto}}`.
