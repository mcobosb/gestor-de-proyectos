# Memoria descriptiva

## Criterios preventivos generales

Estos criterios se aplican a todas las partidas de la obra. La prevencion se integrara en la planificacion conforme a los siguientes principios:

1. Eliminar el riesgo desde el diseño o el procedimiento, cuando sea posible.
2. Priorizar la organizacion, la segregacion, los resguardos y las protecciones colectivas. Los EPI complementaran estas medidas frente al riesgo residual y se seleccionaran conforme a la evaluacion de riesgos, compatibilidad y condiciones de uso.
3. Segregar personas, vehiculos y maquinaria mediante itinerarios, zonas de exclusion y señalizacion.
4. Mantener el tajo ordenado, limpio y con accesos seguros.
5. Adaptar el trabajo a las condiciones meteorologicas, de visibilidad y de trafico.
6. Suspender y reevaluar los trabajos cuando aparezca un riesgo no previsto o cambien el procedimiento o las condiciones de ejecucion.

Ningun trabajo se iniciara sin las medidas preventivas previstas para su fase, la delimitacion, la señalizacion, los accesos seguros y la coordinacion con las actividades concurrentes. Antes de abrir cada tajo se comprobaran:

- autorizaciones, permisos y condiciones de ocupacion;
- señalizacion, balizamiento y desvios;
- accesos, acopios y proteccion de huecos;
- servicios afectados e interferencias;
- equipos de trabajo y EPI;
- condiciones meteorologicas, trafico, visibilidad y afeccion a terceros.

La siguiente tabla resume las situaciones previsibles y el criterio preventivo general. Su aplicacion se concretara segun los trabajos y condiciones reales, junto con la matriz y las fichas especificas de las unidades de obra.

Tabla 2. Grupos de riesgo, situaciones previsibles y criterios preventivos generales.

| GRUPO DE RIESGO | SITUACIONES PREVISIBLES | CRITERIO PREVENTIVO GENERAL |
|---|---|---|
| Tráfico y maquinaria móvil | Atropellos, golpes, colisiones, vuelcos, atrapamientos en maniobras y marcha atrás. | Separación física peatón-máquina, señalista cuando proceda, balizamiento, chaleco de alta visibilidad, rutas y maniobras planificadas. |
| Caídas | Caídas al mismo nivel por irregularidades, materiales o restos; caídas a distinto nivel en huecos, pozos y arquetas. | Orden y limpieza, tapas resistentes, vallado, pasarelas y señalización. |
| Proyecciones y partículas | Fresado, corte, demolición, barrido, perforación y marcado. | Resguardos, distancias, gafas/pantalla y control de polvo. |
| Ruido y vibraciones | Fresadora, martillos, compactadores, radiales y maquinaria pesada. | Selección de equipos, mantenimiento, limitación de exposición y protección auditiva cuando corresponda. |
| Térmicos | Mezcla bituminosa en caliente, superficies calientes, radiación solar y calor ambiental. | Distancias, ropa adecuada, guantes apropiados, hidratación, pausas y organización horaria según evaluación. |
| Químicos | Emulsiones, pinturas, disolventes o componentes de señalización y humos/vapores generados por productos. | Fichas de datos de seguridad, sustitución, ventilación, higiene, guantes/gafas adecuados y protección respiratoria solo cuando la evaluación lo requiera. |
| Sobreesfuerzos | Manipulación de tapas, señales, bordillos, sacos y herramientas. | Ayudas mecánicas, trabajo en equipo, límites de carga, técnica de manipulación. |
| Servicios urbanos | Contacto con canalizaciones o redes ocultas; inundación o fuga. | Información previa, localización, señalización, consignación/corte cuando proceda y coordinación con titulares. |
| Terceros | Entrada de peatones, residentes o vehículos al tajo. | Cerramiento/balizamiento continuo, itinerarios alternativos, información y control de accesos. |

## Delimitación y protección de terceros

Se evitarán daños a peatones, residentes, usuarios de las vías y propiedades próximas mediante el control de accesos y de las afecciones de la obra. Las medidas se adaptarán a los condicionantes de la Tabla 1, a cada fase de trabajo y a las autorizaciones de ocupación, sin presuponer cortes, desvíos o instalaciones no definidos para el proyecto.

### Accesos, cerramientos y protección física

Se señalizarán los accesos y se impedirá la entrada de personas ajenas a las zonas de trabajo, manteniendo pasos seguros para residentes, accesos autorizados y servicios de emergencia. Los cerramientos serán continuos, estables, visibles y sin aristas peligrosas; no crearán obstáculos ocultos ni reducirán la visibilidad.

Los huecos, arquetas y registros se cerrarán con tapas resistentes e inmovilizadas o con barreras físicas. Se protegerán las excavaciones, maniobras, cargas, materiales calientes y zonas de proyección. La cinta de balizamiento y la malla plástica solo servirán para delimitar cuando el riesgo lo permita: no sustituirán barreras resistentes frente a caídas, intrusión de vehículos u otros riesgos que las requieran.

### Señalización, desvíos e itinerarios alternativos

Los avisos y señales serán legibles, estables y correctamente orientados. Los soportes, elementos reflectantes y balizamiento luminoso se seleccionarán según la visibilidad y las condiciones de uso.

Cuando se afecte a vías públicas, los desvíos, estrechamientos y recorridos alternativos se implantarán conforme a la normativa aplicable y a las condiciones autorizadas por el titular de la vía y la autoridad competente. Se emplearán las señales de peligro, reglamentación, regulación manual, balizamiento y defensa que correspondan, manteniendo itinerarios peatonales accesibles y separados de las maniobras. La señalización se revisará al cambiar de fase y se retirará o adaptará cuando deje de ser necesaria.

### Vertidos, residuos y acopios

No se verterán tierras, escombros, lodos, lavados de hormigón o asfalto, aceites, pinturas, disolventes ni otros residuos a cauces, redes de drenaje o saneamiento, ni al terreno. Los efluentes se recogerán para su gestión y solo se admitirán vertidos expresamente autorizados cuando proceda.

Los productos y residuos se almacenarán identificados, con contención compatible con sus características y separados según su naturaleza. Se dispondrán recipientes suficientes en los tajos y zonas de descanso, evitando su dispersión; la retirada se realizará mediante los gestores que correspondan, conservando los justificantes en obra.

Los acopios y el estacionamiento de maquinaria no ocuparán cauces naturales ni obstruirán drenajes, pasos peatonales, accesos o recorridos de evacuación. Los derrames se atenderán conforme al apartado Emergencias y primeros auxilios, evitando su propagación.

### Polvo, humos, ruido y vibraciones

Se reducirá el polvo mediante captación, aspiración o humectación compatible con el trabajo; el riego de caminos se aplicará cuando resulte necesario, sin generar escorrentías, barro o pérdida de adherencia. Si existen silos o equipos con filtros, estos se mantendrán operativos.

No se quemarán residuos ni materiales para su eliminación en la obra. Se mantendrán motores y sistemas de escape y se evitará el funcionamiento innecesario al ralentí, especialmente junto a viviendas y pasos peatonales.

Se priorizarán equipos de menor emisión, mantenimiento y carcasas acústicas en su posición de servicio. Los trabajos ruidosos o con vibraciones se organizarán conforme a los horarios y límites aplicables, reduciendo las molestias al vecindario; los trabajos nocturnos requerirán las autorizaciones que correspondan.

### Iluminación y deslumbramientos

Los focos se orientarán y situarán para iluminar los puestos e itinerarios sin deslumbrar a conductores, peatones o viviendas próximas ni ocultar la señalización. La altura, potencia y ubicación se definirán según el tajo, sin imponer un modelo de torre o una dotación fija.

### Limpieza de viales y control del barro

Se evitará que ruedas y vehículos arrastren tierras, barro o restos a la vía pública. Cuando sea necesario se limpiarán ruedas y salidas, recogiendo los residuos y efluentes. Los depósitos sobre la calzada se retirarán con prontitud y con señalización y protección del trabajo, comprobando la adherencia y el drenaje, especialmente después de lluvias.

### Maquinaria y circulación

Las entradas, salidas y maniobras se coordinarán para evitar interferencias con peatones y tráfico, con señalista cuando la visibilidad lo requiera. Se comprobarán el estado de seguridad y la documentación exigible de los equipos conforme al pliego; los vehículos sujetos a inspección técnica deberán tenerla vigente.

### Información y seguimiento de las afecciones

Cuando se modifiquen accesos, itinerarios u horarios, se informará a los afectados y se mantendrá una vía de comunicación de incidencias. Se comprobarán periódicamente cerramientos, pasos, señalización, limpieza y afecciones al entorno, corrigiendo las deficiencias y adaptando las medidas a la evolución de la obra.

## Protecciones colectivas y equipos de protección individual

### Protecciones colectivas

Las protecciones se seleccionarán para cada fase y se implantarán antes de exponer a los trabajadores al riesgo. Se aplicarán los criterios de prioridad preventiva y de delimitación y protección de terceros de esta memoria, con los siguientes medios cuando resulten necesarios:

- Vallas y cerramientos estables para separar tajos, huecos y zonas incompatibles con el paso de personas.
- Conos, balizas, barreras, paneles y elementos luminosos adecuados a la ocupación y a la visibilidad.
- Tapas o cubriciones resistentes e inmovilizadas, y pasos o pasarelas estables con protección frente a caídas cuando corresponda.
- Topes o limitadores de aproximación en descargas próximas a desniveles, definidos según el equipo, el terreno y la maniobra.
- Extintores adecuados al riesgo en zonas de almacenamiento de combustibles, equipos calefactados y trabajos con fuentes de ignición.
- Señalización de obligación, prohibición, advertencia, salvamento y medios contra incendios, según la necesidad real.
- Iluminación auxiliar y balizamiento luminoso cuando la iluminación o visibilidad sean insuficientes.

Su disposición y resistencia se justificarán para el riesgo y se revisarán durante el uso; no se retirarán mientras persista la exposición sin una alternativa eficaz.

### Equipos de protección individual

Los EPI se seleccionarán a partir de la evaluación del puesto y de los riesgos residuales que no se hayan evitado mediante medidas técnicas, organizativas o colectivas. Se contará con la participación de los trabajadores, comprobando marcado CE y documentación exigibles, ajuste al usuario y compatibilidad entre equipos.

Se facilitarán instrucciones y formación para su uso, entrega individual cuando corresponda, conservación higiénica, revisión y reposición. Se mantendrá el registro de entrega y se exigirá su utilización en las tareas para las que se hayan definido. La relación siguiente es orientativa y no sustituye la selección específica para el proyecto.

Tabla 4. Equipos de protección individual: usos previsibles y criterios de selección.

| EPI | USOS PREVISIBLES | OBSERVACIONES |
|---|---|---|
| Calzado de seguridad | Trabajos en obra, según los riesgos del puesto y de la superficie de paso. | Suela antideslizante y prestaciones adecuadas frente a los riesgos mecánicos u otros identificados. |
| Ropa de alta visibilidad | Trabajos en calzada o en proximidad a tráfico y maquinaria. | Clase y características adecuadas a la exposición y a la visibilidad requerida. |
| Casco de seguridad | Riesgo de golpe, caída de objetos o exposición durante maniobras e izados. | Se exigirá cuando el riesgo lo justifique, sin imponerlo automáticamente en tareas ajenas a esa exposición. |
| Guantes mecánicos | Manipulación de señales, herramientas, tapas y materiales. | Selección según abrasión, corte, perforación y agarre; compatibles con la tarea y sin introducir riesgos de atrapamiento. |
| Guantes térmicos | Contacto con materiales, equipos o elementos calientes. | Prestaciones adecuadas a la temperatura y tiempo de contacto, compatibles con la destreza necesaria. |
| Guantes químicos | Uso de pinturas, resinas, catalizadores, disolventes y otros productos. | Material, resistencia y tiempo de uso según el producto, la ficha de datos de seguridad y la evaluación. |
| Gafas / pantalla facial | Fresado, corte, picado, barrido y aplicación de productos. | Protección frente a impactos o salpicaduras según la tarea; gafas y pantalla se combinarán cuando sea necesario. |
| Protectores auditivos | Operaciones y zonas con exposición significativa a ruido. | Selección según la evaluación, con atenuación adecuada y sin aislar innecesariamente de alarmas o tráfico. |
| Protección respiratoria | Polvo o sustancias cuya exposición no se controle suficientemente con medidas colectivas. | Se prescribirá solo cuando la evaluación lo requiera; tipo, filtro y ajuste según contaminante y condiciones de uso. |

### Señalización del centro de trabajo

La señalización advertirá de riesgos, prohibiciones y obligaciones, identificará salidas, primeros auxilios y medios contra incendios y apoyará las maniobras que lo requieran. No sustituirá las protecciones ni la formación de los trabajadores.

Las señales serán normalizadas para su finalidad y se seleccionarán según distancia de observación, iluminación, ubicación y condiciones de uso. Se evitarán mensajes contradictorios o acumulaciones que reduzcan su percepción; los textos auxiliares serán comprensibles. Se conservarán legibles y se retirarán o renovarán al variar el riesgo.

La cinta de delimitación solo se utilizará como balizamiento cuando sea suficiente para el riesgo; no reemplazará barreras o protección frente a caídas. La señalización que afecte al tráfico se ajustará a los criterios del apartado de protección de terceros y a las condiciones autorizadas.

### Orden y limpieza

Se mantendrán despejados puestos, accesos, escaleras e itinerarios. Los restos de fresado, envases, herramientas, tapas y señales fuera de uso se retirarán o acopiarán de forma estable, evitando tropiezos, sobrecargas y obstrucciones.

Se comprobará especialmente el orden en la implantación, los cambios de fase y el cierre de los tajos. No se reabrirá una calzada al tráfico mientras existan obstáculos, residuos o elementos susceptibles de ser proyectados por los vehículos; se verificará la restitución de los recorridos y se retirará la señalización que ya no proceda.

## Equipos de trabajo y organización de los tajos

### Utilización y mantenimiento de equipos

Las máquinas, herramientas, aparatos e instalaciones serán adecuados para el trabajo y utilizados por personal formado y autorizado cuando proceda. Antes de su puesta en servicio se comprobarán documentación exigible, mantenimiento, inspecciones, resguardos y dispositivos de seguridad; no se anularán sus protecciones.

Los ajustes, limpieza y reparaciones se efectuarán con las energías peligrosas aisladas y siguiendo las instrucciones del fabricante. Se retirarán de uso los equipos defectuosos y se registrarán las comprobaciones y correcciones necesarias. Los trabajos de especial riesgo se reservarán a las personas capacitadas para realizarlos.

### Almacenamiento y manipulación de materiales

Se definirán zonas de acopio y responsables de su control, con apoyos resistentes y nivelados, sin ocupar recorridos ni sobrecargar estructuras, bordes o terrenos. Se separarán materiales según estabilidad, compatibilidad y necesidades de manipulación, aplicando también las limitaciones de protección de cauces y accesos de esta memoria.

Los palés se apilarán conforme a las indicaciones del fabricante, sin mezclar cargas inestables o incompatibles. Las unidades parcialmente consumidas se asegurarán antes de moverlas. Los materiales sueltos se mantendrán contenidos; las piezas largas o susceptibles de rodar tendrán apoyos y calzos que impidan su desplazamiento.

La carga, descarga e izado se planificarán con útiles adecuados y personal capacitado, sin improvisar eslingados; se usarán puntos de suspensión y medios de reparto de cargas apropiados a la geometría y resistencia del material.

Si se emplean botellas de gases, se almacenarán aseguradas, en posición y condiciones indicadas por el suministrador, en zonas ventiladas y protegidas de golpes y calor. Se separarán por compatibilidad y se señalizarán sus riesgos, evitando fuentes de ignición y manteniendo accesibles los medios de emergencia.

### Iluminación de puestos y recorridos

Se garantizará iluminación adecuada a la tarea y a la circulación, especialmente en escaleras, cambios de nivel y puntos de maniobra, evitando sombras peligrosas y deslumbramientos. Los niveles se determinarán según las exigencias de cada zona y la normativa aplicable, sin adoptar valores genéricos para todos los trabajos.

Las luminarias y equipos portátiles serán aptos para el ambiente, humedad y exposición mecánica; se dispondrán de forma estable y con los cables protegidos. No se utilizarán llamas como alumbrado. Las condiciones eléctricas se definirán conforme al apartado de instalación provisional y las afecciones al exterior conforme al de protección de terceros.

### Circulación de personas y vehículos

Se definirán recorridos peatonales y de vehículos separados, con accesos, prioridades, limitaciones de velocidad y puntos de parada adecuados al tajo. Cuando no sea posible separar físicamente los flujos, se establecerán medidas de control y coordinación que eviten su coincidencia peligrosa.

Los pasos sobre zanjas y desniveles dispondrán de medios estables y protección frente a caídas; los accesos entre niveles serán seguros. Se protegerán los huecos y se señalizarán los obstáculos de altura limitada. Antes de admitir vehículos se comprobarán firme, pendientes, bordes y efectos de la lluvia; se protegerán cables y mangueras sin crear nuevos obstáculos y con gálibos adecuados a los equipos que deban circular.

Se evitará la presencia de personas en el radio de acción de la maquinaria y se limitará la marcha atrás, con señalista cuando la visibilidad sea insuficiente. Los reguladores de paso mantendrán comunicación eficaz; no se improvisarán cortes de tráfico ni se fijará un número de accesos sin justificarlo. Las ocupaciones y la reapertura de vías se realizarán conforme a las autorizaciones y a la comprobación de las medidas de seguridad.
