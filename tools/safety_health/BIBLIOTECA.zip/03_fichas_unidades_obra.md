# Fichas de unidades de obra

Cada ficha se activa mediante su identificador en `{{unidades_obra}}`. Las referencias entre corchetes se resuelven en `04_catalogos_preventivos.md`.

## UO-IMPLANTACION - Implantacion y preparacion de tajos

| Campo | Contenido |
|---|---|
| Descripcion | Delimitacion del tajo, señalizacion, acopios, accesos e implantacion de medios auxiliares. |
| Riesgos | `R-ATROPELLO`, `R-CAIDA-MISMO-NIVEL`, `R-TERCEROS`, `R-SOBREESFUERZO` |
| Medidas | `MP-SEGREGACION`, `MP-ORDEN-LIMPIEZA`, `MP-ACCESOS-SEGUROS` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-VALLADO`, `PC-SENALIZACION` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-CALZADO`, `EPI-CASCO`, `EPI-GUANTES` |
| Equipos | `EQ-SENALIZACION-OBRA`, `EQ-HERRAMIENTA-MANUAL` |

## UO-DESMONTAJE - Desmontaje de mobiliario y elementos existentes

| Campo | Contenido |
|---|---|
| Riesgos | `R-GOLPE-ATRAPAMIENTO`, `R-PROYECCION`, `R-SOBREESFUERZO`, `R-ATROPELLO` |
| Medidas | `MP-ZONA-EXCLUSION`, `MP-MANIPULACION-CARGAS`, `MP-SEGREGACION` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-VALLADO` |
| EPI | `EPI-CASCO`, `EPI-GUANTES`, `EPI-CALZADO`, `EPI-OCULAR`, `EPI-ALTA-VISIBILIDAD` |
| Equipos | `EQ-HERRAMIENTA-MANUAL`, `EQ-ELEVACION` |

## UO-FRESADO - Fresado de pavimentos

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-ATRAPAMIENTO`, `R-RUIDO`, `R-VIBRACION`, `R-POLVO`, `R-PROYECCION`, `R-DESNIVEL` |
| Medidas | `MP-SEGREGACION`, `MP-HUMECTACION`, `MP-CONTROL-MAQUINARIA`, `MP-PROTEGER-DESNIVELES` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-SENALIZACION`, `PC-PROTECCION-DESNIVELES` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-AUDITIVO`, `EPI-OCULAR`, `EPI-RESPIRATORIO`, `EPI-CALZADO` |
| Equipos | `EQ-FRESADORA`, `EQ-BARREDORA`, `EQ-CAMION` |

## UO-ARQUETAS - Adaptacion de registros, pozos, imbornales y arquetas

| Campo | Contenido |
|---|---|
| Riesgos | `R-CAIDA-DISTINTO-NIVEL`, `R-GOLPE-ATRAPAMIENTO`, `R-PROYECCION`, `R-SOBREESFUERZO`, `R-ATROPELLO` |
| Medidas | `MP-PROTEGER-HUECOS`, `MP-MANIPULACION-CARGAS`, `MP-SEGREGACION` |
| Protecciones colectivas | `PC-BARRERA-RIGIDA`, `PC-TAPA-RESISTENTE`, `PC-SENALIZACION` |
| EPI | `EPI-CASCO`, `EPI-GUANTES`, `EPI-CALZADO`, `EPI-OCULAR`, `EPI-RESPIRATORIO` |
| Equipos | `EQ-CORTE`, `EQ-ELEVACION`, `EQ-HERRAMIENTA-MANUAL` |

## UO-SANEAMIENTO - Conexiones de saneamiento e imbornales

| Campo | Contenido |
|---|---|
| Riesgos | `R-CAIDA-DISTINTO-NIVEL`, `R-DERRUMBE`, `R-SERVICIOS-AFECTADOS`, `R-ATROPELLO`, `R-ESPACIO-CONFINADO` |
| Medidas | `MP-PROTEGER-HUECOS`, `MP-ESTABILIDAD-EXCAVACION`, `MP-LOCALIZAR-SERVICIOS`, `MP-PERMISO-ESPACIO-CONFINADO` |
| Protecciones colectivas | `PC-BARRERA-RIGIDA`, `PC-ENTIBACION`, `PC-ACCESO-EXCAVACION` |
| EPI | `EPI-CASCO`, `EPI-CALZADO`, `EPI-GUANTES`, `EPI-ALTA-VISIBILIDAD` |
| Equipos | `EQ-EXCAVADORA`, `EQ-ELEVACION`, `EQ-DETECCION-GASES` |

La referencia `R-ESPACIO-CONFINADO` solo se activa tras verificar que concurren sus condiciones y existe procedimiento especifico de entrada y rescate.

## UO-DEMOLICION - Saneado de blandones y demoliciones localizadas

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-PROYECCION`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-DESNIVEL` |
| Medidas | `MP-ZONA-EXCLUSION`, `MP-HUMECTACION`, `MP-PROTEGER-DESNIVELES`, `MP-CONTROL-MAQUINARIA` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-PROTECCION-DESNIVELES`, `PC-SENALIZACION` |
| EPI | `EPI-CASCO`, `EPI-OCULAR`, `EPI-AUDITIVO`, `EPI-RESPIRATORIO`, `EPI-CALZADO` |
| Equipos | `EQ-MARTILLO-DEMOLEDOR`, `EQ-EXCAVADORA`, `EQ-COMPACTADOR-MANUAL` |

## UO-ASFALTO - Transporte, extendido y compactacion de mezcla bituminosa

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-ATRAPAMIENTO`, `R-QUEMADURA`, `R-CALOR`, `R-HUMOS`, `R-RUIDO`, `R-VIBRACION` |
| Medidas | `MP-SEGREGACION`, `MP-CONTROL-MAQUINARIA`, `MP-CONTROL-TERMICO`, `MP-HIGIENE-QUIMICA` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-SENALIZACION`, `PC-ZONA-EXCLUSION` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-CALZADO`, `EPI-GUANTES-TERMICOS`, `EPI-ROPA-CALOR`, `EPI-AUDITIVO` |
| Equipos | `EQ-CAMION`, `EQ-EXTENDEDORA`, `EQ-RODILLO-COMPACTADOR` |

## UO-SENALIZACION-H - Barrido, premarcaje y señalizacion horizontal

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-POLVO`, `R-QUIMICO`, `R-INCENDIO`, `R-QUEMADURA` |
| Medidas | `MP-SEGREGACION`, `MP-HIGIENE-QUIMICA`, `MP-CONTROL-IGNICION`, `MP-HUMECTACION` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-SENALIZACION`, `PC-EXTINTOR` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-GUANTES-QUIMICOS`, `EPI-OCULAR`, `EPI-RESPIRATORIO` |
| Equipos | `EQ-BARREDORA`, `EQ-MAQUINA-MARCAJE` |

## UO-SENALIZACION-V - Instalacion de señalizacion vertical

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-SERVICIOS-AFECTADOS`, `R-GOLPE-ATRAPAMIENTO`, `R-SOBREESFUERZO`, `R-VIENTO` |
| Medidas | `MP-SEGREGACION`, `MP-LOCALIZAR-SERVICIOS`, `MP-MANIPULACION-CARGAS`, `MP-CONTROL-METEOROLOGICO` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-SENALIZACION` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-GUANTES`, `EPI-CALZADO`, `EPI-CASCO` |
| Equipos | `EQ-HERRAMIENTA-MANUAL`, `EQ-ELEVACION` |

## UO-RESIDUOS - Gestion de residuos, carga y transporte

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-CAIDA-MISMO-NIVEL`, `R-GOLPE-ATRAPAMIENTO`, `R-QUIMICO` |
| Medidas | `MP-ORDEN-LIMPIEZA`, `MP-ZONA-EXCLUSION`, `MP-HIGIENE-QUIMICA` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-SENALIZACION` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-GUANTES`, `EPI-CALZADO`, `EPI-OCULAR` |
| Equipos | `EQ-CAMION`, `EQ-CARGADORA` |

## UO-CALIDAD - Control de calidad y toma de testigos

| Campo | Contenido |
|---|---|
| Riesgos | `R-ATROPELLO`, `R-PROYECCION`, `R-RUIDO`, `R-VIBRACION`, `R-POLVO` |
| Medidas | `MP-SEGREGACION`, `MP-ZONA-EXCLUSION`, `MP-HUMECTACION` |
| Protecciones colectivas | `PC-BALIZAMIENTO`, `PC-SENALIZACION` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-OCULAR`, `EPI-AUDITIVO`, `EPI-RESPIRATORIO`, `EPI-CALZADO` |
| Equipos | `EQ-EXTRACCION-TESTIGOS` |

## UO-METEOROLOGIA - Trabajos con meteorologia adversa o visibilidad reducida

| Campo | Contenido |
|---|---|
| Riesgos | `R-CALOR`, `R-LLUVIA`, `R-VIENTO`, `R-VISIBILIDAD-REDUCIDA` |
| Medidas | `MP-CONTROL-METEOROLOGICO`, `MP-SUSPENDER-TRABAJO`, `MP-ILUMINACION` |
| Protecciones colectivas | `PC-SENALIZACION`, `PC-ILUMINACION` |
| EPI | `EPI-ALTA-VISIBILIDAD`, `EPI-ROPA-LLUVIA`, `EPI-PROTECCION-SOLAR` |
| Equipos | `EQ-ILUMINACION-PORTATIL` |
