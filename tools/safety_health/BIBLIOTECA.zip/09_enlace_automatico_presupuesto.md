# Enlace automatico entre presupuesto y ESS

## Finalidad

Este documento define como transformar las partidas de un presupuesto en las fichas ESS que deben incorporarse al documento. La biblioteca de partida es `UNI/`; su registro de resolucion es `UNI/INDICE_FICHAS_ESS.md`.

La referencia de codigos de esta version es `BCCA2023_V02.bc3`. El sistema tambien admite presupuestos con codigos propios mediante clasificacion por descripcion, siempre marcada para revision tecnica.

## Entrada minima

Cada partida importada debe incluir:

| Campo | Descripcion |
|---|---|
| `codigo_partida` | Codigo BCCA o codigo propio del presupuesto. |
| `unidad` | Unidad de medicion. |
| `descripcion` | Texto completo de la partida. |
| `medicion` | Cantidad presupuestada. |
| `capitulo` | Codigo y descripcion del capitulo, si existe. |

En un archivo BC3 se extraeran conceptos y descomposiciones de las lineas `~C` y `~D`; no se clasificara una partida solo por el titulo del capitulo.

## Resolucion

Para cada partida:

1. Normalizar `codigo_partida` a mayusculas y eliminar espacios.
2. Leer `UNI/INDICE_FICHAS_ESS.md`.
3. Buscar todos los prefijos que sean inicio del codigo de partida.
4. Seleccionar la ficha ESS del prefijo mas largo; si varias fichas tienen la misma prioridad, incluirlas todas.
5. Leer la ficha y acumular sus `UO-*`, riesgos, medidas, protecciones, EPI, equipos y validaciones.
6. Incorporar una sola vez `UNI/CONDICIONES_GENERALES_ESS.md`.
7. Resolver los identificadores de unidad mediante `03_fichas_unidades_obra.md`, `04_catalogos_preventivos.md` y `08_matriz_riesgos_por_unidad.md`.
8. Consolidar los resultados de todas las partidas, eliminando duplicados.

El resultado genera automaticamente `{{unidades_obra_bcca}}` y `{{unidades_obra}}`; ninguno de ambos campos se completa manualmente.

## Fallback para codigos propios o no clasificados

Si ninguna ficha coincide con el codigo, normalizar `descripcion` a minusculas sin tildes y aplicar una clasificacion provisional:

| Palabras o expresiones | Unidad ESS provisional |
|---|---|
| `fresad` | `UO-FRESADO` |
| `mezcla bitumin`, `aglomerado asfalt`, `hormigon asfalt` o `extendido de asfalt` | `UO-ASFALTO` |
| `demolicion`, `levantado de pavimento`, `saneado de firme` o `blandon` | `UO-DEMOLICION` |
| `arqueta`, `pozo`, `imbornal`, `sumidero`, `alcantarillado`, `saneamiento` o `zanja` | `UO-SANEAMIENTO` |
| `senalizacion horizontal`, `pintura vial`, `premarcaje`, `marca vial` o `microesfera` | `UO-SENALIZACION-H` |
| `senalizacion vertical`, `senal de trafico`, `poste de senal` o `cartel vertical` | `UO-SENALIZACION-V` |
| `residuo`, `contenedor`, `gestor`, `vertedero`, `carga y transporte` o `valorizacion` | `UO-RESIDUOS` |
| `testigo`, `extraccion de muestra`, `perforacion de control` o `ensayo de firme` | `UO-CALIDAD` |

El motor debe registrar `[VALIDAR] Partida sin ficha ESS BCCA: {{codigo_partida}}` cuando aplique este fallback o cuando no exista ninguna coincidencia.

## Limites de la automatizacion

El codigo de presupuesto permite seleccionar la ficha de partida, pero no sustituye la evaluacion de riesgos. No se asignara automaticamente una entrada en espacio confinado, un EPI concreto frente a contaminantes o una medida de control higienico sin comprobar los equipos, productos y condiciones reales de ejecucion.
