# Objeto y alcance

El presente {{tipo_estudio}} establece las previsiones preventivas para la ejecucion de `{{titulo_proyecto}}`, promovido por `{{entidad}}`, en `{{municipio}}` (`{{provincia}}`). Su objeto es servir de base al Plan de Seguridad y Salud del contratista, que debera adaptarlo al procedimiento, equipos, personal y secuencia de trabajo realmente previstos, sin reducir el nivel de proteccion definido.

La actuacion comprende `{{descripcion_obras}}`. El plazo previsto es `{{plazo_ejecucion}}` y la concurrencia maxima prevista es de `{{numero_trabajadores_punta}}`.

{{justificacion_estudio}}

## Identificacion

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{titulo_proyecto}}` | Denominación del proyecto | Si |
| `{{tipo_actuacion}}` | Tipologia de obra | Si |
| `{{entidad}}` | Promotor | Si |
| `{{municipio}}` | Municipio | Si |
| `{{provincia}}` | Provincia | Si |
| `{{comunidad_autonoma}}` | Comunidad autonoma | Si |
| `{{emplazamiento}}` | Direccion, viales o ambito de actuacion | Si |
| `{{autor_estudio}}` | Técnico/s redactor/es | Si |
| `{{fecha_documento}}` | Fecha de emision | Si |

## Magnitudes y planificacion

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{presupuesto_ejecucion_material}}` | PEM | Si |
| `{{presupuesto_licitacion}}` | PEC (con IVA) | Si |
| `{{presupuesto_seguridad_salud}}` | Importe de seguridad y salud | No |
| `{{plazo_ejecucion}}` | Duración prevista del proyecto | Si |
| `{{numero_trabajadores_punta}}` | Maximo simultaneo previsto | Si |
| `{{superficie_actuacion}}` | Superficie (m²) | No |
| `{{fecha_inicio_prevista}}` | Fecha o condicion de inicio | No |

## Condicionantes externos

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{trafico_existente}}` | Tráfico | No |
| `{{peatones_terceros}}` | Peatones y terceros | No |
| `{{servicios_afectados}}` | Servicios afectados | No |
| `{{condiciones_terreno}}` | Terreno | No |
| `{{condiciones_ambientales}}` | Condiciones ambientales | No |
| `{{instalaciones_provisionales}}` | Instalaciones provisionales | No |
| `{{coordinador_seguridad_salud}}` | Coordinación de seguridad y salud | No |

## Riesgos

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{medios_auxiliares}}` | Medios auxiliares | No |
| `{{maquinaria_empleada}}` | Maquinaria empleada | No |
| `{{riesgos_detectados}}` | Riesgos detectados | Si |
| `{{medidas_preventivas}}` | Medidas preventivas | Si |
| `{{centros_asistenciales_resumen}}` | Centros asistenciales, dirección y teléfonos de interés | Si |

## Datos pendientes

Cuando una variable obligatoria no este disponible, el documento debe indicar:

> [VALIDAR] Falta definir `{{nombre_variable}}`. Debera concretarse antes de la aprobacion del Plan de Seguridad y Salud.

No se deben inventar mediciones, ubicaciones de protecciones, itinerarios de evacuacion, dotaciones de EPI ni condiciones de trafico.

La relacion automatica entre `{{partidas_presupuesto}}`, `{{unidades_obra}}` y los contenidos preventivos se define en `09_enlace_automatico_presupuesto.md`.
