"""
## Registro de cambios
- Versión: 2 | Autor: Biblioteca distribuida con el programa | Fecha: 24/11/2026 | Cambio: Corrección ortográfica de tildes.
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Objeto y alcance

El presente {{tipo_estudio}} establece las previsiones preventivas para la ejecución de `{{titulo_proyecto}}`, promovido por `{{entidad}}`, en `{{municipio}}` (`{{provincia}}`). Su objeto es servir de base al Plan de Seguridad y Salud del contratista, que deberá adaptarlo al procedimiento, equipos, personal y secuencia de trabajo realmente previstos, sin reducir el nivel de protección definido.

La actuación comprende `{{descripcion_obras}}`. El plazo previsto es `{{plazo_ejecucion}}` y la concurrencia máxima prevista es de `{{numero_trabajadores_punta}}`.

{{justificacion_estudio}}

## Identificación

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{titulo_proyecto}}` | Denominación del proyecto | Sí |
| `{{tipo_actuacion}}` | Tipología de obra | Sí |
| `{{entidad}}` | Promotor | Sí |
| `{{municipio}}` | Municipio | Sí |
| `{{provincia}}` | Provincia | Sí |
| `{{comunidad_autonoma}}` | Comunidad autónoma | Sí |
| `{{emplazamiento}}` | Dirección, viales o ámbito de actuación | Sí |
| `{{autor_estudio}}` | Técnico/s redactor/es | Sí |
| `{{fecha_documento}}` | Fecha de emisión | Sí |

## Magnitudes y planificación

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{presupuesto_ejecucion_material}}` | PEM | Sí |
| `{{presupuesto_licitacion}}` | PEC (con IVA) | Sí |
| `{{presupuesto_seguridad_salud}}` | Importe de seguridad y salud | No |
| `{{plazo_ejecucion}}` | Duración prevista del proyecto | Sí |
| `{{numero_trabajadores_punta}}` | Máximo simultáneo previsto | Sí |
| `{{superficie_actuacion}}` | Superficie (m²) | No |
| `{{fecha_inicio_prevista}}` | Fecha o condición de inicio | No |

## Condicionantes externos

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{trafico_existente}}` | Tráfico | No |
| `{{peatones_terceros}}` | Peatones y terceros | No |
| `{{servicios_afectados}}` | Servicios afectados | No |
| `{{condiciones_terreno}}` | Terreno | No |
| `{{condiciones_ambientales}}` | Condiciones ambientales | No |
| `{{instalaciones_provisionales}}` | Instalaciones provisionales | No |
| `{{coordinador_seguridad_salud}}` | Coordinación de seguridad y salud | No |

## Riesgos

| Variable | Aspecto del proyecto | Obligatoria |
|---|---|---|
| `{{medios_auxiliares}}` | Medios auxiliares | No |
| `{{maquinaria_empleada}}` | Maquinaria empleada | No |
| `{{riesgos_detectados}}` | Riesgos detectados | Sí |
| `{{medidas_preventivas}}` | Medidas preventivas | Sí |
| `{{centros_asistenciales_resumen}}` | Centros asistenciales, dirección y teléfonos de interés | Sí |

## Datos pendientes

Cuando una variable obligatoria no esté disponible, el documento debe indicar:

> [VALIDAR] Falta definir `{{nombre_variable}}`. Deberá concretarse antes de la aprobación del Plan de Seguridad y Salud.

No se deben inventar mediciones, ubicaciones de protecciones, itinerarios de evacuación, dotaciones de EPI ni condiciones de tráfico.

La vinculación de las partidas con las fichas preventivas se realiza por sus códigos BCCA conforme al índice de la biblioteca. Las unidades sin ficha específica se identifican en la tabla resumen del capítulo 3 para completar su evaluación.
