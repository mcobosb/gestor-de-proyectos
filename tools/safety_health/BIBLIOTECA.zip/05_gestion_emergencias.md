# Instalaciones provisionales y emergencias

## Instalaciones y organización del tajo

Las instalaciones provisionales previstas son `{{instalaciones_provisionales}}`. Se implantarán sin invadir recorridos de evacuación, zonas de maniobra ni itinerarios peatonales y se mantendrán en condiciones de orden, limpieza, iluminación y salubridad adecuadas.

El Plan de Seguridad y Salud definirá su implantación y dimensionará los servicios según el personal máximo simultáneo y la duración de la Tabla 1, la distribución real de los tajos y los medios del contratista. Se garantizarán agua potable, aseos y medios higiénicos suficientes, acceso a servicios en condiciones adecuadas, zona de pausas y recuperación y vestuarios u otras dependencias cuando correspondan.

Las comprobaciones de apertura de cada tajo se realizarán conforme al apartado Criterios preventivos generales de la memoria.

## Instalación eléctrica provisional, si fuese necesaria

Los cuadros, conexiones y equipos serán adecuados para obra y para su emplazamiento, con protección frente a intemperie, sobreintensidades y contactos eléctricos. Las masas y equipos que lo requieran dispondrán de puesta a tierra y de las protecciones correspondientes.

Los cables se protegerán frente a tráfico, aplastamiento, aristas, agua y zonas de paso. No se admitirán empalmes improvisados, conductores desnudos ni bases deterioradas. Las reparaciones quedarán a cargo de personal competente, con desconexión y consignación cuando proceda.

Se comprobará la instalación antes del uso y tras modificaciones o incidencias. Al finalizar la jornada se dejarán seguros los circuitos y equipos, desconectando los que no deban permanecer en servicio sin anular funciones de seguridad necesarias.

## Emergencias y primeros auxilios

Se comprobarán los datos y teléfonos de los centros asistenciales de referencia (Tabla 1) antes del inicio, manteniendo visibles los contactos, el aviso al 112 y la información de localización y acceso de cada tajo. Se garantizará la entrada de los recursos de emergencia.

Se dispondrá de botiquín portátil accesible en el tajo o en un vehículo de apoyo próximo, con contenido adecuado, revisado periódicamente y tras cada uso, controlando reposiciones y caducidades. Se designarán responsables y personal formado para el aviso y la primera asistencia, con cobertura acorde a la organización de los trabajos.

### Actuación en caso de accidente

- Proteger la zona y evitar un segundo accidente, especialmente frente a tráfico y maquinaria.
- Detener y asegurar los equipos implicados cuando pueda hacerse sin exponerse.
- Avisar a emergencias indicando emplazamiento, punto de acceso, naturaleza del accidente y número de afectados.
- Prestar primeros auxilios únicamente dentro de la capacitación disponible; no mover a una persona accidentada salvo peligro inminente.
- Facilitar la llegada de los servicios externos y conservar la zona cuando sea necesario para la investigación y compatible con el auxilio.
- Comunicar e investigar el accidente o incidente conforme al sistema preventivo de la empresa.

### Incendio y derrames

Los combustibles e inflamables se conservarán en recipientes cerrados e identificados, con ventilación y separación de incompatibles y fuentes de ignición según su ficha de seguridad. Se prohibirá fumar donde exista ese riesgo. Los repostajes se realizarán con los equipos detenidos y conforme a las instrucciones del fabricante, previendo la contención de fugas y derrames.

En almacenamientos, maquinaria y trabajos con fuentes de ignición se dispondrán medios de extinción accesibles, con tipo, eficacia, número y emplazamiento adecuados al riesgo y a la normativa aplicable. Se mantendrán despejados y revisados. La intervención inicial se limitará a personal formado, con salida segura y sin exposición a humos ni riesgos adicionales; los extintores no sustituyen la necesidad de evacuación y aviso temprano.

Los trabajos de soldadura o corte, cuando existan, requerirán controlar combustibles, proyecciones y zonas próximas, mediante el procedimiento y autorización que correspondan. No se iniciarán si existen atmósferas inflamables u otras condiciones incompatibles con una ejecución segura, y se comprobará la zona tras finalizar.

Ante un incendio, fuga o derrame se interrumpirá el trabajo, se avisará y se delimitará la zona, eliminando fuentes de ignición solo cuando sea seguro. Se impedirá que el vertido alcance imbornales o cauces y se aplicará el procedimiento de la ficha de seguridad, con medios de contención compatibles. Los absorbentes y residuos contaminados se recogerán y gestionarán según su naturaleza.

### Trabajos en espacios confinados

Si resultan aplicables, requerirán procedimiento específico, control atmosférico, comunicación permanente y plan de rescate con medios y personal previstos. No se admitira la entrada para rescate improvisado.
