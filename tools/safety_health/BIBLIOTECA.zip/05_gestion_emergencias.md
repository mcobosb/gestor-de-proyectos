# Gestion preventiva, emergencias y seguimiento

## Instalaciones y organizacion del tajo

Las instalaciones provisionales previstas son `{{instalaciones_provisionales}}`. Se implantaran de forma que no invadan recorridos de evacuacion, zonas de maniobra ni itinerarios peatonales. Deberan mantenerse en condiciones de orden, limpieza, iluminacion y salubridad adecuadas.

Antes de abrir cada tajo se realizara una comprobacion de:

- autorizaciones y condiciones de ocupacion;
- señalizacion, balizamiento y desvios;
- accesos, acopios y proteccion de huecos;
- servicios afectados;
- equipos de trabajo y EPI;
- condiciones meteorologicas, trafico y visibilidad.

## Emergencias y primeros auxilios

El centro asistencial de referencia es `{{centro_asistencial}}`. Se mantendran visibles los telefonos de emergencia y se garantizara el acceso de los servicios de emergencia al tajo.

En caso de accidente se protegera el lugar, se avisara a emergencias, se prestara la primera asistencia dentro de la capacitacion disponible y se facilitara el acceso de los recursos externos. No se movera a una persona accidentada salvo peligro inminente.

Ante incendio, derrame o fuga se interrumpira el trabajo, se eliminara la fuente de ignicion cuando pueda hacerse con seguridad, se delimitara la zona y se aplicara el procedimiento y la ficha de seguridad del producto. Los extintores no sustituyen la necesidad de evacuacion y aviso temprano.

Las operaciones en espacios confinados, si resultan aplicables, requeriran procedimiento especifico, control atmosferico, comunicacion permanente y plan de rescate. No se admitira la entrada para rescate improvisado.

## Coordinacion y seguimiento

La organizacion preventiva se coordinara entre `{{entidad}}`, el contratista, los subcontratistas, los trabajadores autonomos y `{{coordinador_seguridad_salud}}`, cuando proceda.

El contratista realizara inspecciones iniciales y periodicas de los tajos, registrando deficiencias, responsables, plazos de correccion y cierre de las acciones. Los cambios de procedimiento, equipos o fases se evaluaran antes de aplicarse.

## Documentacion disponible

Se mantendra disponible, en soporte adecuado al tajo:

- Plan de Seguridad y Salud aprobado y sus modificaciones;
- libro de incidencias cuando sea exigible;
- evaluaciones de riesgos, procedimientos y coordinacion de actividades empresariales;
- acreditaciones de formacion e informacion;
- autorizaciones de operadores y documentacion de equipos;
- registros de entrega de EPI;
- fichas de datos de seguridad de productos;
- autorizaciones, permisos y planes especiales requeridos;
- inspecciones y registros de correccion de deficiencias.

## Trabajos posteriores

Las futuras operaciones de mantenimiento, apertura de registros, reparacion de pavimentos o señalizacion requeriran una nueva valoracion de su afeccion al trafico, terceros, servicios existentes y condiciones de trabajo. Se aplicaran las fichas y catalogos de este sistema que resulten pertinentes, adaptados a la intervencion concreta.
