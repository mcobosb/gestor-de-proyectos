"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Pliego de condiciones

## Condiciones de naturaleza facultativa

El presente Pliego establece las obligaciones de los agentes intervinientes y las condiciones de aplicación, control y abono de las medidas preventivas. Se interpretará conjuntamente con la Memoria del Documento I y con los restantes documentos del proyecto, sin sustituir las responsabilidades que corresponden a cada empresa.

El contratista atenderá las instrucciones preventivas de la Dirección Facultativa y del coordinador dentro de sus respectivas competencias. Las órdenes y su cumplimiento se documentarán, sin trasladar a estos técnicos la organización empresarial ni la ejecución material de las medidas preventivas.

### Promotor

El promotor cumplirá las obligaciones que le atribuye el Real Decreto 1627/1997, incluida la incorporación del presente Estudio al proyecto y la designación de los técnicos y coordinadores que resulten preceptivos. Facilitará la información disponible sobre las condiciones del emplazamiento y las interferencias que deban considerarse en la organización preventiva.

La designación de coordinadores no eximirá al promotor de sus responsabilidades. Cuando no sea necesaria la designación de coordinador durante la ejecución, las funciones que reglamentariamente correspondan serán asumidas por la Dirección Facultativa.

### Contratista

Cada contratista elaborará su Plan de Seguridad y Salud analizando, estudiando, desarrollando y complementando este Estudio en función de su sistema de ejecución y de la evaluación de los riesgos. Antes de iniciar los trabajos deberá disponer de la aprobación que corresponda y de los medios necesarios para implantarlo.

En particular, deberá:

- Implantar y mantener las medidas del Plan y hacerlas cumplir a su personal, subcontratistas y trabajadores autónomos dentro de sus respectivas obligaciones.
- Garantizar la formación y la información preventiva, la entrega y utilización de los EPI y la adecuación de la maquinaria y los equipos.
- Organizar la coordinación de actividades empresariales, establecer responsables y mantener disponible la documentación exigible.
- Comunicar los cambios de procedimiento, equipos, fases o condiciones que puedan afectar a la seguridad y tramitar las modificaciones del Plan cuando proceda.
- Verificar las condiciones de delimitación, accesos, circulación y protección de terceros definidas en la Memoria y desarrolladas en el Plan.

Las protecciones se conservarán operativas mientras exista el riesgo y se repondrán inmediatamente si se desplazan, deterioran o resultan insuficientes. No se autorizará una actividad mientras falten las condiciones de seguridad necesarias para realizarla.

Los equipos se utilizarán y mantendrán conforme a sus instrucciones y a los requisitos aplicables. Los productos químicos se manejarán de acuerdo con su etiquetado y sus fichas de datos de seguridad. Las exposiciones a polvo, humos, ruido, vibraciones, calor y radiación solar se evaluarán y controlarán mediante medidas técnicas y organizativas, dando prioridad a la protección colectiva antes de recurrir al EPI.

El contratista y los subcontratistas responderán de la correcta ejecución de las medidas preventivas previstas en el Plan en los términos del artículo 11.2 del Real Decreto 1627/1997, incluidas las obligaciones que les correspondan respecto de sus trabajadores y de los autónomos contratados.

### Subcontratistas y trabajadores autónomos

Los subcontratistas y los trabajadores autónomos cumplirán las disposiciones preventivas que les resulten aplicables, las instrucciones de coordinación, el Plan de Seguridad y Salud y las obligaciones específicas del sector de la construcción.

Antes de incorporarse al tajo, conocerán los riesgos e interferencias que les afecten, los accesos autorizados, las medidas de emergencia y los procedimientos de trabajo. Comunicarán las circunstancias que puedan generar nuevos riesgos para otras empresas o personas y participarán en los medios de coordinación establecidos, sin que estos sustituyan sus obligaciones propias.

### Coordinador de Seguridad y Salud durante la ejecución

El coordinador será un técnico competente integrado en la Dirección Facultativa y designado por el promotor, conforme al artículo 2.1.f del Real Decreto 1627/1997. La función podrá recaer en un técnico que ejerza otras funciones de dirección de la obra si reúne la competencia exigible y cuenta con la designación correspondiente.

El coordinador ejercerá las funciones que le atribuye el Real Decreto 1627/1997, entre ellas la coordinación de los principios generales de prevención y de las actividades para la aplicación coherente de los principios preventivos. Coordinará las acciones y funciones de control de la aplicación correcta de los métodos de trabajo y adoptará las medidas necesarias para que solo las personas autorizadas accedan a la obra.

La aprobación del Plan de Seguridad y Salud y de sus modificaciones se efectuará en los términos del citado real decreto. Cuando no sea necesaria la designación de coordinador, estas funciones corresponderán a la Dirección Facultativa en los supuestos reglamentarios. En las obras de las Administraciones públicas, la aprobación corresponderá a la Administración pública que haya adjudicado la obra, previo informe del coordinador o, cuando no sea preceptivo, de la Dirección Facultativa.

La Dirección Facultativa y el coordinador podrán requerir, dentro de sus competencias, la corrección de las situaciones inseguras y actuarán ante riesgos graves e inminentes conforme a la normativa aplicable. Sus actuaciones no liberarán al contratista ni a los restantes intervinientes de sus responsabilidades.

Las dudas sobre la aplicación preventiva del Plan se trasladarán al coordinador o, cuando proceda, a la Dirección Facultativa. Las cuestiones de proyecto, ejecución y valoración se resolverán por los agentes competentes conforme al proyecto y al contrato; la designación como coordinador no atribuye por sí sola facultades para modificar precios ni obligaciones contractuales.

### Recursos preventivos

La presencia de recursos preventivos se determinará conforme al artículo 32 bis de la Ley 31/1995, al artículo 22 bis del Real Decreto 39/1997 y a las especialidades de las obras de construcción. El Plan identificará las actividades y situaciones en que resulte preceptiva, la forma de presencia y vigilancia, y las personas asignadas por cada contratista, que deberán contar con capacitación suficiente y medios adecuados.

Se contemplarán, cuando concurran los supuestos normativos:

- Operaciones sucesivas o simultáneas cuya concurrencia agrave o modifique los riesgos y haga necesario controlar la aplicación correcta de los métodos de trabajo.
- Trabajos con riesgos especiales, incluidos los del anexo II del Real Decreto 1627/1997, y los procesos peligrosos aplicables: caídas de altura especialmente graves, sepultamiento o hundimiento, espacios confinados y riesgo de ahogamiento por inmersión, sin perjuicio de sus disposiciones específicas.
- La presencia requerida por la Inspección de Trabajo y Seguridad Social por las condiciones de trabajo detectadas.

En las máquinas anteriores a la exigencia de declaración CE se atenderá al supuesto específico del artículo 22 bis.1.b.3 del Real Decreto 39/1997; su antigüedad no implica por sí sola la obligación de presencia. Esta vigilancia no permitirá utilizar equipos inadecuados ni sustituirá su adecuación al Real Decreto 1215/1997.

El Plan concretará tajos, ubicación segura, cobertura y colaboración entre recursos. Permanecerán durante todo el tiempo en que se mantenga la situación que determine su presencia y podrán ser identificados por los trabajadores. No se asignarán tareas incompatibles con la vigilancia necesaria.

La vigilancia comprobará el cumplimiento y la eficacia de las medidas, su adecuación a los riesgos y la aparición de circunstancias no previstas. Ante deficiencias, los recursos preventivos efectuarán las indicaciones necesarias para su corrección inmediata y las comunicarán al empresario para que adopte las medidas oportunas, sin sustituir las funciones de coordinación ni las obligaciones de la línea de mando.

Si las medidas están ausentes, son insuficientes o inadecuadas, el empresario actuará de inmediato y actualizará la planificación preventiva y, cuando proceda, la evaluación de riesgos y el Plan. Las modificaciones de este último se someterán al procedimiento de aprobación antes de aplicar el nuevo sistema de trabajo.

### Vigilancia de la salud

La empresa garantizará la vigilancia de la salud de sus trabajadores en función de los riesgos inherentes a su trabajo, en los términos del artículo 22 de la Ley 31/1995 y de la normativa específica. Se respetará el consentimiento del trabajador y las excepciones legalmente previstas, con el informe previo de los representantes de los trabajadores cuando corresponda.

La documentación médica será confidencial y la gestionará el servicio sanitario competente. Al empresario y a los responsables de prevención se comunicarán únicamente las conclusiones sobre aptitud o necesidad de introducir o mejorar medidas preventivas en los términos legalmente establecidos. No se fija una periodicidad médica genérica ajena a la evaluación de riesgos.

### Plan de Seguridad y Salud

Antes del inicio de la obra, cada contratista elaborará un Plan de Seguridad y Salud en el que se analicen, estudien, desarrollen y complementen las previsiones de este Estudio en función de su propio sistema de ejecución. El Plan deberá estar aprobado antes del comienzo de los trabajos, mediante el procedimiento del artículo 7 del Real Decreto 1627/1997.

El Plan concretará los responsables, procedimientos, medios, fases, mediciones y planos necesarios. Como mínimo, definirá, según las características reales de la obra:

- La secuencia de tajos y fases, su duración y las interferencias con actividades simultáneas; cuando se actúe sobre varios viales o zonas, su orden de intervención.
- El número máximo simultáneo de trabajadores, la organización de las cuadrillas y los responsables de cada actividad.
- La implantación de instalaciones provisionales, servicios higiénicos, accesos y medios de primeros auxilios.
- La relación real de maquinaria, equipos y medios auxiliares, sus condiciones de utilización y sus comprobaciones.
- Los procedimientos de ejecución de las unidades de obra y de las operaciones de especial riesgo; cuando proceda, los de fresado, extendido, compactación y señalización.
- Los esquemas de circulación, desvíos y protección peatonal, coordinados con las administraciones y titulares competentes y, cuando corresponda, con la Policía Local.
- Las zonas de acopio, carga, descarga y espera de vehículos, evitando interferencias con trabajadores y terceros.
- Los procedimientos de emergencia, los medios de comunicación y los centros asistenciales de referencia, previa comprobación de sus datos.
- Los medios de coordinación empresarial y la presencia de recursos preventivos en las actividades en que resulte exigible.
- Las protecciones, señalización y EPI necesarios, sus condiciones de implantación, mantenimiento y retirada, y las cantidades y criterios de medición que correspondan.

Las alternativas preventivas que se propongan se justificarán técnicamente en los términos reglamentarios, sin disminuir los niveles de protección previstos. La aprobación del Plan no sustituye la evaluación de riesgos de las empresas ni exime de implantar las medidas efectivas.

#### Acta o resolución de aprobación del Plan

La aprobación del Plan y de sus modificaciones quedará acreditada documentalmente antes de aplicar los trabajos o procedimientos afectados. En las obras que no sean de las Administraciones públicas, aprobará el coordinador de Seguridad y Salud durante la ejecución o, cuando no sea preceptiva su designación, la Dirección Facultativa. En las obras de las Administraciones públicas, la aprobación corresponderá a la Administración pública que haya adjudicado la obra, previo informe del coordinador o, cuando no sea preceptivo, de la Dirección Facultativa.

El acta, informe o resolución que corresponda identificará la obra, el contratista, la versión y fecha del Plan, el técnico u órgano interviniente, el alcance de la aprobación y la fecha y firma. Se conservará con el Plan aprobado y se mantendrá disponible en obra. No se establece un visado colegial obligatorio general del acta de aprobación; se atenderá al régimen de visado aplicable, conforme al Real Decreto 1000/2010, y a las exigencias contractuales que procedan, sin confundir el visado con la aprobación del Plan.

#### Comunicación de apertura del centro de trabajo

Cada empresario que tenga la condición de contratista efectuará la comunicación de apertura del centro de trabajo ante la autoridad laboral competente antes del comienzo de sus trabajos, conforme al Real Decreto 1627/1997 y a la Orden TIN/1071/2010. El promotor facilitará los datos necesarios y velará por el cumplimiento de esta obligación; los subcontratistas no presentarán esta comunicación por el mero hecho de actuar como tales.

La comunicación contendrá los datos de la empresa, del centro de trabajo y de su actividad, producción o almacenamiento, así como los datos específicos de la obra, agentes, plazos, previsión de trabajadores, subcontratación y trabajos de especial riesgo exigidos por el modelo oficial. Se adjuntarán el Plan de Seguridad y Salud y su aprobación cuando sean exigibles; cuando no resulte exigible el Plan, se aportará la evaluación de riesgos correspondiente.

La comunicación se expondrá en lugar visible de la obra y se mantendrá actualizada. Los cambios no identificados inicialmente se comunicarán a la autoridad laboral en el plazo de diez días desde que se produzcan, conforme a la citada orden. El justificante de presentación y sus actualizaciones se conservarán con la documentación preventiva.

#### Modificaciones y situaciones no previstas

Cuando durante la ejecución aparezcan circunstancias, servicios, sistemas de trabajo o riesgos no previstos, el contratista los evaluará antes de continuar la actividad afectada, adoptará las medidas inmediatas necesarias y propondrá el procedimiento preventivo correspondiente.

Si los cambios implican una modificación del Plan de Seguridad y Salud, se tramitará su aprobación antes de aplicar el nuevo sistema de trabajo. Se actualizarán los procedimientos, planos, mediciones e instrucciones afectados y se informará a las empresas y trabajadores intervinientes.

Ante una situación de riesgo grave e inminente se actuará conforme a la normativa aplicable, con interrupción de los trabajos afectados cuando proceda. No se reanudarán hasta disponer de condiciones seguras y de las autorizaciones que resulten exigibles.

### Libros y control documental

Las observaciones, órdenes y comunicaciones preventivas se documentarán de forma que pueda comprobarse su recepción, seguimiento y cierre. Se identificarán las deficiencias, las medidas correctoras, sus responsables y los plazos, sin demorar las actuaciones inmediatas que requiera la seguridad.

El Plan aprobado y sus modificaciones, los registros de coordinación, las acreditaciones exigibles, los registros de entrega de EPI y la documentación de equipos y productos estarán disponibles en obra en los términos descritos en el Documento I. Las versiones sustituidas se identificarán para evitar la aplicación de instrucciones obsoletas.

La documentación de empresas y personal se comprobará por los medios vigentes que resulten legal o contractualmente exigibles, actualizando las incorporaciones y bajas. Se limitará a las acreditaciones necesarias de contratación, situación de Seguridad Social, formación y autorizaciones, con acceso restringido y sin recopilar datos personales ajenos a su finalidad. No se impone el uso de modelos de cotización o libros derogados ni una entrega mensual indiscriminada de copias.

#### Libro de Incidencias

En cada centro de trabajo existirá un Libro de Incidencias habilitado al efecto, con hojas por duplicado, para el control y seguimiento del Plan de Seguridad y Salud, conforme al artículo 13 del Real Decreto 1627/1997. Lo facilitará el colegio profesional al que pertenezca el técnico que haya aprobado el Plan o, en las obras de las Administraciones públicas, la Oficina de Supervisión de Proyectos u órgano equivalente.

Permanecerá siempre en la obra, en poder del coordinador de Seguridad y Salud durante la ejecución o, cuando no sea necesaria su designación, de la Dirección Facultativa. Tendrán acceso y podrán efectuar anotaciones relacionadas con su finalidad la Dirección Facultativa, los contratistas, subcontratistas y trabajadores autónomos, las personas u órganos con responsabilidades preventivas en las empresas intervinientes, los representantes de los trabajadores y los técnicos de los órganos especializados de las Administraciones públicas competentes.

Las anotaciones se notificarán al contratista afectado y a los representantes de sus trabajadores. Cuando se refieran al incumplimiento de advertencias u observaciones previamente anotadas, o al supuesto de paralización regulado en el artículo 14 del citado real decreto, se remitirá copia a la Inspección de Trabajo y Seguridad Social en el plazo de veinticuatro horas. Se indicará si se trata de una nueva observación o de la reiteración de una anterior, sin perjuicio de las demás comunicaciones exigibles.

#### Libro de Órdenes y Asistencias

Se dispondrá del Libro de Órdenes y Asistencias o del registro equivalente que corresponda al régimen de la obra. La Dirección Facultativa dejará constancia de las visitas, incidencias y órdenes de su competencia, con identificación, fecha, destinatario y seguimiento de su cumplimiento. El contratista atenderá las instrucciones que le correspondan, sin que este registro sustituya al Libro de Incidencias, a la aprobación del Plan ni a las comunicaciones legalmente exigibles.

#### Diligencias de la Inspección de Trabajo y Seguridad Social

No se exigirá adquirir ni habilitar un nuevo Libro de Visitas. Las actuaciones inspectoras se documentarán mediante las diligencias previstas en la Ley 23/2015 y en la Orden ESS/1452/2016, de 10 de junio. La empresa conservará cada diligencia recibida a disposición de la Inspección durante cinco años desde su expedición, con constancia de los requerimientos, plazos y medidas adoptadas. Los libros y diligencias anteriores se conservarán durante los plazos que legalmente les resulten aplicables.

#### Libro de Subcontratación

Cada contratista dispondrá de un Libro de Subcontratación en los términos del artículo 8 de la Ley 32/2006 y del Real Decreto 1109/2007, habilitado por la autoridad laboral competente antes de subcontratar y mantenido en la obra. Se reflejarán por orden cronológico las subcontrataciones, sus niveles y empresas comitentes, el objeto de los trabajos, responsables, entrega de la parte del Plan que corresponda, instrucciones de coordinación y autorizaciones excepcionales de la Dirección Facultativa cuando procedan.

Tendrán acceso al libro:

- El promotor, la Dirección Facultativa y el coordinador de Seguridad y Salud durante la ejecución.
- Las empresas y los trabajadores autónomos intervinientes en la obra.
- Los técnicos y delegados de prevención.
- La autoridad laboral y los representantes de los trabajadores de las empresas intervinientes.

El libro se mantendrá actualizado y se conservará conforme a su normativa específica. Su existencia no sustituye la acreditación de las empresas, el control de los niveles permitidos ni la documentación de coordinación.

### Control de la efectividad

El contratista establecerá un sistema documentado para comprobar el grado de cumplimiento y la eficacia del Plan de Seguridad y Salud, registrar los resultados y corregir las deficiencias. El seguimiento atenderá a las condiciones reales de cada fase y no se limitará a contabilizar accidentes.

El Plan concretará los responsables, la periodicidad y los modelos de registro, adaptados a los medios de la empresa. Las modificaciones de los criterios que afecten al Plan se incorporarán a este y se someterán al procedimiento de aprobación del artículo 7 del Real Decreto 1627/1997, sin reducir el nivel de protección previsto.

#### Cuadro de control y seguimiento

Antes del comienzo de los trabajos se preparará un cuadro esquemático de control, que se cumplimentará periódicamente y se revisará ante cambios de fase, procedimientos o condiciones de trabajo. Por cada concepto se identificarán la obra, fecha, tajo, persona que comprueba, requisito examinado, resultado, medida correctora, responsable, plazo y verificación del cierre.

Se marcará una «X» en la casilla de deficiencias cuando se detecte un incumplimiento. Los conceptos conformes, no aplicables y no comprobados se identificarán de forma diferenciada: una casilla vacía no acreditará conformidad. El resumen indicará el número de deficiencias y el número total de conceptos efectivamente examinados, sin incluir como conformes los no aplicables o pendientes de comprobación.

Las deficiencias que impliquen riesgo grave e inminente exigirán la actuación inmediata y, cuando proceda, la paralización del trabajo afectado; no se esperará al siguiente control periódico para corregirlas.

#### Índices de control

El seguimiento incluirá los indicadores siguientes para un mismo período y ámbito de personal. Se conservarán los datos de origen y se documentarán los criterios utilizados, de modo que los resultados sean comparables. A estos efectos, A será el número de accidentes en jornada con baja; T, el número medio de trabajadores expuestos; H, las horas efectivamente trabajadas; y J, las jornadas perdidas asociadas a esos accidentes conforme al criterio estadístico documentado.

- Índice de incidencia (I.I.): accidentes en jornada con baja por cada cien trabajadores de plantilla media. I.I. = (A / T) x 100.
- Índice de frecuencia (I.F.): accidentes en jornada con baja por cada millón de horas trabajadas. I.F. = (A / H) x 1.000.000.
- Índice de gravedad (I.G.): jornadas perdidas por cada mil horas trabajadas. I.G. = (J / H) x 1.000.
- Duración media de las incapacidades (D.M.I.): jornadas perdidas por cada accidente en jornada con baja. D.M.I. = J / A.

El índice de incidencia anterior se expresa por cien trabajadores para este control interno; si se utiliza otra base en estadísticas oficiales, se indicará expresamente y no se compararán directamente valores de distinta base. Los accidentes de otro ámbito, como los ocurridos al ir o volver del trabajo, se registrarán separadamente y no se mezclarán con los numeradores definidos.

Cuando el denominador de un indicador sea cero, se consignará «No calculable» y su motivo. La ausencia de datos se distinguirá de un valor cero; en particular, sin accidentes con baja no se calculará la duración media de las incapacidades. Los índices no sustituyen la investigación de accidentes, las comprobaciones preventivas ni las comunicaciones obligatorias.

#### Partes de accidentes e investigación

Se podrán utilizar modelos normalizados del contratista siempre que recojan, de forma ordenada y con el acceso restringido que corresponda:

- Identificación de la obra, empresa, fecha, hora y tajo del accidente.
- Identificación de la persona accidentada, categoría profesional y oficio, con los datos necesarios para la investigación y las comunicaciones exigibles.
- Descripción de la actividad, circunstancias, equipos y condiciones del lugar, y consecuencias aparentes, sin sustituir el diagnóstico sanitario.
- Causas y factores técnicos, organizativos y humanos contrastados, diferenciando los hechos comprobados de las hipótesis.
- Lugar, persona y forma de prestación de los primeros auxilios, así como el centro de traslado u hospitalización cuando proceda.
- Identificación de los testigos y constancia de sus versiones.

El parte se completará con un informe de investigación que explique cómo podría haberse evitado el accidente, las medidas y órdenes inmediatas, responsables, plazos y comprobación de su eficacia. Se respetarán los modelos y plazos de notificación legalmente exigibles. La información personal y sanitaria se tratará con confidencialidad y se limitará a la necesaria para cada finalidad.

#### Partes de deficiencias y comprobación del cierre

Cada parte identificará la obra, fecha, tajo y autor de la observación, describirá la deficiencia y el riesgo asociado e incluirá el estudio de mejora o medida correctora propuesta. Se indicarán la prioridad, las medidas provisionales de protección, el responsable de corregirla y el plazo de ejecución.

El cierre exigirá registrar la corrección realizada, su fecha y la persona que haya comprobado su implantación y eficacia. Las deficiencias persistentes o reiteradas se comunicarán por los cauces previstos en el Plan y, cuando corresponda, se anotarán en el Libro de Incidencias; el archivo del parte no sustituirá la corrección efectiva.

### Consulta y participación de los trabajadores

El empresario consultará con la debida antelación a los trabajadores o a sus representantes sobre la organización preventiva, los procedimientos, los equipos, la formación y las medidas que afecten a su seguridad y salud. El contratista facilitará a los representantes una copia del Plan y de sus modificaciones para su conocimiento y seguimiento, conforme al artículo 16 del Real Decreto 1627/1997. Podrán presentar por escrito sugerencias y alternativas razonadas, sin que ello sustituya la aprobación exigible.

#### Delegados de Prevención

Se designarán conforme al artículo 35 de la Ley 31/1995 y a los sistemas válidamente previstos en la negociación colectiva. Su número se determinará en el ámbito representativo correspondiente, con las reglas legales de cómputo de plantilla y contratación temporal, no únicamente a partir de la punta de personal prevista para esta obra.

Ejercerán las competencias del artículo 36: colaborar en la mejora preventiva, promover la cooperación de los trabajadores, ser consultados y vigilar el cumplimiento de la normativa. Podrán acompañar las comprobaciones preventivas e inspectoras, acceder a la documentación necesaria con sus límites de confidencialidad, visitar los tajos y proponer mejoras. Cuando no proceda constituir Comité de Seguridad y Salud por no alcanzar el mínimo legal, ejercerán sus competencias en los términos de la ley.

El empresario facilitará los medios y la formación necesarios y respetará las garantías y el sigilo profesional del artículo 37. Estas funciones de representación no sustituyen al servicio de prevención, al recurso preventivo ni a los responsables empresariales de ejecución y mantenimiento.

#### Comité de Seguridad y Salud

Se constituirá en las empresas o centros de trabajo que cuenten con cincuenta o más trabajadores, conforme al artículo 38 de la Ley 31/1995. No se deducirá su obligatoriedad exclusivamente de sumar trabajadores de distintas empresas presentes en la obra ni de la estimación de personal de este Estudio.

Será paritario: lo integrarán los delegados de prevención y el empresario o sus representantes en igual número. Participarán con voz y sin voto los delegados sindicales y los responsables técnicos de prevención no incluidos en su composición; otros trabajadores cualificados y técnicos externos podrán participar en los términos legales.

Se reunirá trimestralmente y siempre que lo solicite alguna de sus representaciones. Participará en la elaboración, puesta en práctica y evaluación de los planes y programas preventivos, promoverá mejoras y conocerá las condiciones de trabajo y los daños para proponer correcciones, conforme al artículo 39. Se dejará constancia de las reuniones y del seguimiento de los acuerdos.

En la concurrencia de empresas se coordinará la participación mediante reuniones conjuntas de comités, delegados y empresarios u otras medidas adecuadas, sin sustituir los órganos representativos que correspondan a cada empresa.

### Obligaciones de los trabajadores

Conforme al artículo 29 de la Ley 31/1995, cada trabajador velará, según sus posibilidades, formación e instrucciones recibidas, por su propia seguridad y por la de las personas a las que pueda afectar su actividad. En particular, deberá:

- Utilizar adecuadamente máquinas, herramientas, sustancias, medios de transporte y demás equipos, atendiendo a sus riesgos e instrucciones.
- Utilizar correctamente las protecciones colectivas y los EPI facilitados.
- No anular ni poner fuera de funcionamiento los dispositivos de seguridad y utilizarlos correctamente.
- Informar de inmediato al superior y a los responsables preventivos de las situaciones que razonablemente puedan entrañar riesgos para la seguridad o la salud.
- Contribuir al cumplimiento de las obligaciones establecidas por la autoridad competente.
- Cooperar con el empresario para mantener condiciones de trabajo seguras.

El incumplimiento tendrá las consecuencias laborales o disciplinarias que legalmente correspondan, sin establecer sanciones automáticas en este Pliego. Estas obligaciones no reducirán el deber de protección del empresario ni los derechos de información, formación y actuación ante riesgos graves e inminentes.

## Condiciones de naturaleza técnica

Se establecen las condiciones de los materiales, protecciones, equipos y medios auxiliares destinados a la prevención y al bienestar durante la obra. Sus características, instalación, utilización y conservación se ajustarán a las prescripciones específicas del proyecto, al Plan aprobado, a las instrucciones del fabricante y a la normativa aplicable al producto y al trabajo. La selección responderá a los riesgos y condiciones reales, sin extender a toda obra pliegos ajenos a su tipología.

<!-- ESS-TECH-REVIEW -->

### De los medios de protección

Las protecciones se seleccionarán a partir de la evaluación de riesgos y de las condiciones de cada unidad de obra, dando prioridad a la eliminación del riesgo y a la protección colectiva. El Plan de Seguridad y Salud definirá su implantación, utilización, mantenimiento y retirada, de acuerdo con las instrucciones del fabricante y las referencias UNE aplicables del capítulo 2, sin considerar que el listado general obliga a emplear todos los equipos.

#### Medios de protección colectiva

Se instalarán antes de comenzar los trabajos para los que sean necesarias y se mantendrán operativas mientras exista el riesgo. El montaje, uso, modificación y retirada no crearán riesgos adicionales; cuando sea preciso desmontarlas temporalmente, se implantarán previamente medidas alternativas de eficacia equivalente.

Se comprobarán la resistencia, estabilidad, fijación, compatibilidad y adecuación al uso previsto. Los elementos deteriorados, deformados, contaminados, fuera de su vida útil o con tolerancias inadmisibles o sometidos a solicitaciones que puedan comprometer su eficacia se retirarán de servicio para su evaluación y sustitución cuando corresponda. No se reutilizarán sin haber comprobado sus condiciones de seguridad.

El contratista organizará las revisiones por personal competente antes del uso, con la periodicidad definida en el Plan y por el fabricante, y después de modificaciones, impactos, fenómenos meteorológicos u otras circunstancias que puedan afectar a su seguridad. Se registrarán las comprobaciones y correcciones. La consulta y participación de los delegados de prevención no sustituirá la responsabilidad del empresario de implantar y mantener las protecciones.

#### Medios de protección individual

El empresario determinará los EPI necesarios frente a los riesgos residuales y los suministrará gratuitamente, con talla, ajuste, ergonomía y prestaciones adecuadas a cada persona y tarea. No generarán riesgos adicionales ni molestias innecesarias y serán compatibles cuando deban utilizarse simultáneamente.

Se comprobarán el marcado CE en el soporte que legalmente corresponda, la documentación de conformidad y las instrucciones exigibles conforme al régimen aplicable, incluido el Reglamento (UE) 2016/425 y el Real Decreto 773/1997.

La información del fabricante estará disponible en la lengua exigible y será comprensible para los usuarios. Incluirá, según corresponda, identificación del fabricante, uso previsto, riesgos cubiertos, clase o prestaciones, ajustes, compatibilidades, accesorios y repuestos, límites de utilización, limpieza, almacenamiento, mantenimiento, revisiones y caducidad o vida útil. Antes del uso se facilitarán información, formación y entrenamiento cuando sea necesario.

Los EPI se destinarán, en principio, al uso personal y se utilizarán para las funciones previstas. Si excepcionalmente fueran compartidos, se adoptarán las medidas de higiene y desinfección necesarias. El empresario organizará su mantenimiento y reposición; los trabajadores los cuidarán e informarán de inmediato de defectos o daños, sin trasladar la responsabilidad empresarial al delegado de prevención.

Se sustituirán cuando estén deteriorados, hayan agotado su vida útil, no garanticen las prestaciones exigidas o hayan sufrido solicitaciones que requieran su retirada según el fabricante. Los equipos pendientes de revisión se identificarán y separarán para impedir su uso.

La protección respiratoria no sustituirá de forma ordinaria las medidas técnicas viables de control del polvo, vapores o humos en origen. Cuando sea necesaria, se seleccionará para el contaminante y la exposición evaluada, con el ajuste y las limitaciones correspondientes.

Cuando se requiera ropa de alta visibilidad, se mantendrá limpia y con prestaciones de visibilidad y retrorreflexión suficientes, respetando las instrucciones y los límites de lavado y reposición del fabricante.

<!-- ESS-TECH:barriers -->
#### Vallas, barreras y cerramientos móviles

- Las vallas, barreras y cerramientos serán estables frente a los empujes y acciones previsibles y no presentarán aristas ni elementos salientes peligrosos.
- Se dispondrán de forma continua cuando deban impedir el acceso a huecos, excavaciones o zonas de maquinaria. Su montaje y retirada se realizarán sin exponer a los operarios a riesgos adicionales no controlados.
- La cinta de balizamiento no será la única protección cuando se necesite una barrera física resistente frente a caídas o acceso a maquinaria.
- La implantación no reducirá peligrosamente la visibilidad del tráfico ni creará obstáculos ocultos; se revisará después de desplazamientos, impactos o cambios de fase.
<!-- /ESS-TECH -->

<!-- ESS-TECH:openings -->
#### Protección de huecos, arquetas y registros

- Las tapas provisionales resistirán las cargas previsibles, incluidas las de vehículos cuando puedan alcanzarlas, y quedarán inmovilizadas frente a desplazamientos accidentales.
- Cuando el hueco deba permanecer abierto se instalará una barrera rígida, resistente y suficientemente separada del borde. La apertura se limitará al tiempo necesario y no se abandonará el hueco sin protección.
- Los huecos en calzada se protegerán mediante una solución compatible con el tráfico autorizado; si no puede garantizarse su seguridad, se cerrará o desviará el tramo afectado.
- La manipulación de tapas, el acceso y los trabajos en el interior se efectuarán con los medios y procedimientos específicos previstos en el Plan, sin que cubrir el hueco sustituya esas medidas.
<!-- /ESS-TECH -->

<!-- ESS-TECH:access -->
#### Pasos provisionales y accesos

- Las pasarelas y pasos provisionales serán estables, resistentes a las cargas previstas, antideslizantes y de anchura suficiente para sus usuarios, respetando las condiciones de accesibilidad aplicables.
- Cuando exista riesgo de caída lateral se instalará protección colectiva adecuada; se comprobarán los apoyos, fijaciones y encuentros para evitar vuelcos, resaltes y desplazamientos.
- Se conservarán libres de materiales, cables y obstáculos los accesos a portales, viviendas y demás destinos que deban permanecer operativos.
- Los pasos se revisarán antes de habilitarlos y después de cambios de fase o circunstancias que puedan afectar a su seguridad.
<!-- /ESS-TECH -->

### De la maquinaria y equipos


Los equipos utilizados serán adecuados a la tarea y se mantendrán conforme al Real Decreto 1215/1997 y a las instrucciones del fabricante. Dispondrán de la documentación, comprobaciones y revisiones exigibles según su régimen de comercialización y uso.

Los resguardos, paradas, alarmas, avisadores e iluminación se conservarán operativos. Solo manejará los equipos personal designado, formado y, cuando proceda, autorizado. Antes del uso se comprobará su estado y se comunicarán los defectos; los que comprometan la seguridad obligarán a inmovilizar e identificar el equipo hasta su corrección.

La limpieza, mantenimiento y desatasco se realizarán con los movimientos peligrosos detenidos, las energías aisladas o controladas y las cargas o elementos elevados asegurados. Se impedirá la puesta en marcha intempestiva y se aplicará el procedimiento de consignación correspondiente.

<!-- ESS-TECH:mobile -->
#### Maquinaria móvil y vehículos

- Antes de cada fase se definirán rutas, accesos, zonas de espera y maniobra, separando vehículos y personas y comprobando la capacidad del terreno y las interferencias.
- La velocidad será compatible con el personal, la visibilidad, el estado del firme y las restricciones del emplazamiento.
- Se evitará la marcha atrás; si resulta imprescindible y la visibilidad es insuficiente, se utilizarán medios auxiliares adecuados o un señalista, sin que ello permita invadir una zona no controlada.
- Se impedirá la presencia de personas en radios de giro, puntos ciegos y zonas de atrapamiento. El operador detendrá la maniobra si pierde las condiciones de seguridad o la comunicación necesaria.
- El estacionamiento se realizará con el equipo inmovilizado, en posición estable y con los accesorios apoyados cuando proceda, evitando desplazamientos o usos no autorizados.
<!-- /ESS-TECH -->

<!-- ESS-TECH:paving -->
#### Equipos de extendido y compactación

- Los órganos móviles accesibles estarán protegidos y no se limpiarán ni desatascarán durante su movimiento.
- Se controlará la proximidad entre camión, extendedora, equipos de compactación y personal de apoyo, con zonas de exclusión y comunicación entre operadores.
- Las plataformas, accesos y peldaños se mantendrán libres de betún, combustible, barro y otros materiales que produzcan resbalones o incendios.
- Los rodillos y compactadores no trabajarán en bordes, pendientes o terrenos que comprometan su estabilidad; se respetarán los límites del fabricante.
- Cuando se empleen materiales calientes, se controlarán las superficies y salpicaduras, los humos y los accesos, sin permitir pasos de terceros por la zona de trabajo.
<!-- /ESS-TECH -->

<!-- ESS-TECH:cutting -->
#### Equipos de corte, demolición y compactación manual

- Los discos, útiles y accesorios serán compatibles con la máquina, el material y la velocidad de giro y se comprobarán antes de utilizarlos.
- Se conservarán resguardos, empuñaduras y mandos de seguridad; no se bloquearán ni anularán sus funciones.
- Se reducirá el polvo en origen mediante captación, aporte de agua u otras soluciones adecuadas a la tarea y compatibles con la seguridad eléctrica y las instrucciones del equipo.
- La exposición a ruido y vibraciones se limitará mediante selección de equipos, mantenimiento y organización del trabajo, incluidas pausas o rotación cuando lo exija la evaluación.
- Se delimitará la zona frente a proyecciones y acceso de terceros; los cambios de útiles, ajustes y desatascos se realizarán con las energías controladas.
<!-- /ESS-TECH -->

<!-- ESS-TECH:lifting -->
#### Elevación de cargas

- Se definirán la carga, su peso, centro de gravedad, recorrido y capacidad del equipo en la configuración real; no se superarán sus límites ni los de los accesorios.
- Cuando se emplee camión grúa u otro equipo con estabilizadores, se apoyarán sobre terreno firme y adecuado, utilizando placas de reparto cuando sean necesarias y respetando las condiciones de nivelación del fabricante.
- Los accesorios de elevación serán adecuados, estarán identificados y revisados y se retirarán si presentan daños o no puede comprobarse su capacidad.
- No se sobrevolarán personas ni zonas abiertas al público con cargas suspendidas. Se controlará el área de maniobra y se evitará la proximidad peligrosa a líneas eléctricas y otros obstáculos.
- Las maniobras sin visibilidad suficiente serán dirigidas por señalista con comunicación acordada. Se detendrán cuando se pierda la comunicación o existan condiciones ambientales incompatibles con la seguridad.
<!-- /ESS-TECH -->

### Sobre señalización, balizamiento y protección de terceros


La señalización advertirá y organizará los riesgos residuales, sin sustituir las protecciones físicas, la segregación de tráficos ni las medidas técnicas y organizativas necesarias. Se adaptará a las fases reales y se mantendrá durante la existencia del riesgo.

Cuando se afecten vías o espacios públicos, el Plan definirá la implantación y sus cambios con los titulares y autoridades competentes y, cuando corresponda, con la Policía Local, respetando las autorizaciones y condiciones del emplazamiento.

<!-- ESS-TECH:signage -->
#### Señalización temporal de obras

- La señalización temporal será coherente, visible, legible y suficiente para anticipar el peligro; se instalará antes de ocupar la calzada o la zona afectada.
- Las señales, balizas y elementos de delimitación se mantendrán limpios, estables y visibles, con las prestaciones necesarias para las condiciones de iluminación.
- Se retirarán o cubrirán los elementos que dejen de ser aplicables y se resolverán las contradicciones con la señalización existente.
- Las zonas de maquinaria se separarán de peatones mediante barreras o itinerarios protegidos.
- En trabajos móviles o de corta duración, la señalización acompañará al tajo de forma planificada, sin dejar zonas desprotegidas durante su traslado.
<!-- /ESS-TECH -->

<!-- ESS-TECH:signallers -->
#### Señalistas

Se utilizarán señalistas cuando las maniobras carezcan de visibilidad suficiente, exista circulación alternativa que lo requiera, las entradas o salidas de vehículos impliquen riesgo para terceros o así lo establezca la organización del tráfico.

- Tendrán formación e instrucciones para su función y se situarán en lugar visible y protegido, fuera de las trayectorias y zonas de atrapamiento.
- Utilizarán ropa de alta visibilidad y señales comprensibles, con un código de comunicación conocido por operadores y señalistas.
- No realizarán simultáneamente tareas que reduzcan su atención. Se evitarán órdenes contradictorias y se identificará quién dirige cada maniobra.
- Si se pierde la visibilidad, la comunicación o el control de la zona, se detendrá la maniobra hasta restablecer condiciones seguras.
<!-- /ESS-TECH -->

<!-- ESS-TECH:pedestrians -->
#### Peatones, residentes y accesos

- Los itinerarios provisionales serán continuos, señalizados y accesibles conforme a las condiciones aplicables; se evitarán cambios bruscos y pasos por radios de giro de maquinaria.
- Si se afecta un paso peatonal, se habilitará una alternativa protegida y señalizada o se gestionará el cruce mediante un procedimiento seguro.
- Los accesos a viviendas, garajes y comercios se coordinarán con la secuencia de obra y se comunicarán las afecciones y alternativas; no se improvisarán pasos sobre materiales calientes o superficies inestables.
- Los trabajos que generen un riesgo inmediato en una entrada o cruce se interrumpirán durante el paso de terceros, manteniendo el control del resto del tajo.
<!-- /ESS-TECH -->

### Instalaciones provisionales de salud y confort

El contratista dispondrá las instalaciones higiénicas y de bienestar necesarias antes de su utilización y las mantendrá durante la obra, conforme al anexo IV del Real Decreto 1627/1997 y al convenio colectivo aplicable. El Plan justificará su ubicación, capacidad, dotaciones, superficies y alturas en función del número máximo de trabajadores que coincidan, los turnos, la actividad, la duración de la obra y las necesidades de accesibilidad e intimidad, respetando los mínimos exigibles.

Los locales tendrán estabilidad, accesos seguros, ventilación, iluminación, temperatura y condiciones de humedad adecuadas al uso. Los suelos serán seguros y no resbaladizos y los revestimientos permitirán la limpieza y desinfección, con resistencia a la humedad donde proceda. El contratista asegurará la limpieza diaria y siempre que sea necesaria, el suministro de agua, los consumibles de higiene y la retirada de residuos.

Las soluciones compartidas o concertadas solo se admitirán si se justifica su disponibilidad efectiva, proximidad, capacidad y cumplimiento de las condiciones exigibles; no bastará con presuponer la existencia de establecimientos próximos.

#### Vestuarios

Cuando deba utilizarse ropa especial de trabajo se dispondrán vestuarios de fácil acceso, con espacio suficiente, asientos y taquillas o compartimentos individuales bajo llave. Se permitirá el secado de la ropa cuando sea necesario y su separación de la ropa de calle y efectos personales si existen sustancias peligrosas, humedad o suciedad.

Cuando no sean necesarios vestuarios conforme a la normativa aplicable, cada trabajador dispondrá de un espacio para guardar bajo llave su ropa y objetos personales. La dotación y organización garantizarán la intimidad y el uso separado que corresponda.

#### Aseos, lavabos y duchas

Se dispondrán lavabos suficientes, adecuados y próximos a los puestos de trabajo y vestuarios, con agua corriente y caliente cuando resulte necesario, jabón y medios higiénicos de secado. Se preverán recipientes para los residuos y se repondrán los consumibles.

Cuando el tipo de actividad, la salubridad o las disposiciones aplicables lo requieran, habrá duchas apropiadas y en número suficiente, con agua corriente fría y caliente, dimensiones que permitan asearse sin obstáculos y condiciones de intimidad. La comunicación con los vestuarios será fácil y segura; se organizarán instalaciones separadas para hombres y mujeres o una utilización por separado.

#### Retretes

Se dispondrán en número suficiente y de fácil acceso, próximos a las zonas de trabajo y a los locales de descanso e higiene. Las cabinas garantizarán intimidad, ventilación, espacio de uso y puertas con cierre interior; se dotarán de papel higiénico, portarrollos, recipientes de residuos y lavabos próximos.

Se resolverán el abastecimiento y la evacuación sanitaria sin contaminar las zonas de comida o descanso. Cuando no sea posible la conexión al saneamiento, se preverán sistemas sanitarios autónomos adecuados, con limpieza, vaciado y gestión de los efluentes. No se admitirán vertidos incontrolados ni instalaciones que incumplan las condiciones de higiene exigibles.

#### Comedores, cocina y locales de descanso

Se habilitarán instalaciones para comer y, cuando corresponda, preparar o calentar alimentos en condiciones seguras, separadas de los tajos y de las fuentes de contaminación. Dispondrán de mesas y asientos suficientes, superficies y utensilios que puedan limpiarse, agua potable y medios adecuados de conservación, calentamiento y recogida de residuos según el uso previsto.

Los locales de descanso serán de fácil acceso, tendrán dimensiones suficientes, asientos con respaldo y condiciones térmicas adecuadas. Se preverá el acondicionamiento necesario en función del clima y del uso. No se permitirá preparar comidas mediante fuego, brasas o barbacoas fuera de los lugares expresamente previstos y acondicionados para ello.

La capacidad se revisará si cambia la plantilla simultánea o la organización de los turnos, manteniendo las dotaciones mínimas y las condiciones de uso exigibles.

## Condiciones de naturaleza económica

Salvo pacto en contrario, una vez al mes, la constructora redactará la valoración de las partidas que en materia de seguridad se hubiesen realizado en la obra. La valoración se hará conforme al Plan de Seguridad y de acuerdo con los precios contratados por el Promotor, siendo dicha valoración visada y aprobada por la Dirección Facultativa o la coordinación de Seguridad y Salud en fase de ejecución de las obras, sin este requisito no podrá ser abonada por el Promotor.

El abono de las certificaciones expuestas anteriormente se hará conforme se estipule en el contrato de obra.

En caso de ejecutar en obra unidades no previstas en principio, se definirán total y correctamente las mismas y se les adjudicará el precio correspondiente, procediéndose a su abono tal y como se indica en los apartados anteriores.

En caso de plantearse una revisión de precios, el Contratista comunicará esta proposición al Promotor, por escrito, habiendo obtenido la aprobación previa de la Dirección Facultativa o la coordinación de Seguridad y Salud en fase de ejecución de las obras.

### Certificación de medidas de Seguridad y Salud

Las unidades de Seguridad y Salud que integren las mediciones y el presupuesto se certificarán conforme a su medición real, a sus condiciones de abono y a los criterios económicos del proyecto y del contrato. Su comprobación atenderá a la efectiva implantación, mantenimiento y disponibilidad de los medios previstos, evitando duplicidades de medición o abono.

El presupuesto de Seguridad y Salud actualmente integrado en el presupuesto general asciende a {{presupuesto_seguridad_salud}}. Esta cifra corresponde a las partidas preventivas incorporadas al presupuesto y no sustituye la revisión de sus cantidades y condiciones reales de utilización. Cuando sea exigible el presupuesto del Estudio conforme al artículo 5 del Real Decreto 1627/1997, se comprobará que las mediciones detalladas, los precios y la valoración de todas las unidades preventivas necesarias queden definidos y sean coherentes con el resto de sus documentos.

Las medidas exigibles por la normativa o por el Plan no podrán dejar de implantarse por insuficiencia o agotamiento de una partida presupuestaria. Las diferencias de medición o las necesidades no previstas se tramitarán por el procedimiento contractual que corresponda, sin condicionar a su resolución la protección inmediata de las personas.

### Régimen económico del contrato

El marco de las relaciones económicas para la ejecución, abono y recepción se establecerá en el pliego general o particular del proyecto y en el contrato entre promotor y contratista. En las obras de las Administraciones públicas se estará, además, a la legislación de contratos del sector público. Según el régimen y las prestaciones contratadas, quedarán definidos:

- Las fianzas y garantías exigibles.
- Los precios básicos y unitarios, el Presupuesto de Ejecución Material (PEM), los precios contradictorios y el procedimiento para tramitar reclamaciones de aumento de precios.
- Las reglas de medición, aplicación de precios y revisión de los precios contratados, con sus requisitos y límites.
- El tratamiento económico de los acopios y, cuando se contraten, de los trabajos por administración.
- La valoración, certificación y abono de los trabajos, con la documentación justificativa correspondiente.
- Las indemnizaciones mutuas que procedan y las retenciones en concepto de garantía.
- Los plazos de ejecución, el Plan de Obra y las consecuencias contractuales de sus modificaciones.
- La recepción, las comprobaciones y la liquidación económica y final de la obra.

No se fijan en este Estudio porcentajes de fianza, retenciones, indemnizaciones ni revisiones automáticas de precios ajenos al contrato. La intervención técnica preventiva no atribuye por sí sola competencia para aprobar precios, modificaciones contractuales o pagos: se tramitarán las autorizaciones del promotor u órgano de contratación que correspondan, sin demorar la implantación de medidas necesarias para proteger a las personas.
