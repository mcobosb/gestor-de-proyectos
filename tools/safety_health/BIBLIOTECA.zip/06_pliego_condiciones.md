# Pliego de condiciones

## Disposiciones generales

Seran de aplicacion las disposiciones vigentes que correspondan a los trabajos, productos, equipos y condiciones reales de la obra. Como minimo se consideraran la Ley 31/1995 de Prevencion de Riesgos Laborales, el RD 39/1997, el RD 1627/1997, el RD 171/2004, el RD 1215/1997, el RD 773/1997, el RD 485/1997, el RD 487/1997, el RD 614/2001, el RD 374/2001, el RD 286/2006 y el RD 1311/2005, junto con la normativa de trafico, ordenanzas y autorizaciones aplicables.

La relacion normativa no exime de aplicar cualquier disposicion especifica vigente. Cuando concurran varias exigencias, se adoptara la solucion compatible que proporcione el nivel de proteccion exigible.

## Condiciones de ejecución

Los criterios preventivos, las comprobaciones previas y las condiciones de delimitacion, proteccion de terceros y accesos se establecen de forma conjunta en la Memoria general y son exigibles durante la ejecucion.

Las protecciones se conservaran operativas mientras exista el riesgo y se repondran inmediatamente si se desplazan, deterioran o resultan insuficientes.

## Maquinaria, herramientas y productos

Los requisitos de uso y mantenimiento de los equipos y de circulacion interna se desarrollan en el apartado Equipos de trabajo y organizacion de los tajos de la memoria y seran exigibles durante la ejecucion. El contratista verificara su cumplimiento antes de autorizar los trabajos.

Los productos quimicos se utilizaran conforme a su ficha de datos de seguridad. Las exposiciones a polvo, humos, ruido, vibraciones, calor y radiacion solar se evaluaran y controlaran mediante medidas tecnicas y organizativas antes de recurrir al EPI.

## Organización preventiva y control

El contratista desarrollara este ESS en su Plan de Seguridad y Salud, conforme a la evaluacion de riesgos de las empresas intervinientes y a las condiciones reales de la obra, definiendo responsables, procedimientos, medios, fases, mediciones y planos necesarios. Cualquier modificacion que introduzca riesgos no contemplados requerira evaluacion previa y, cuando corresponda, modificacion y aprobacion del Plan.

La Direccion Facultativa y el Coordinador de Seguridad y Salud podran requerir la correccion de situaciones inseguras dentro de sus competencias, sin perjuicio de las obligaciones propias de cada empresa interviniente.
