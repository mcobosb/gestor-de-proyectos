# Pliego de condiciones

## Disposiciones generales

Seran de aplicacion las disposiciones vigentes que correspondan a los trabajos, productos, equipos y condiciones reales de la obra. Como minimo se consideraran la Ley 31/1995 de Prevencion de Riesgos Laborales, el RD 39/1997, el RD 1627/1997, el RD 171/2004, el RD 1215/1997, el RD 773/1997, el RD 485/1997, el RD 487/1997, el RD 614/2001, el RD 374/2001, el RD 286/2006 y el RD 1311/2005, junto con la normativa de trafico, ordenanzas y autorizaciones aplicables.

La relacion normativa no exime de aplicar cualquier disposicion especifica vigente. Cuando concurran varias exigencias, se adoptara la solucion compatible que proporcione el nivel de proteccion exigible.

## Condiciones de ejecucion

Ningun trabajo comenzara sin medidas preventivas implantadas para la fase correspondiente. Las protecciones se conservaran operativas mientras exista el riesgo y se repondran inmediatamente si se desplazan, deterioran o resultan insuficientes.

Los riesgos se eliminaran o reduciran prioritariamente mediante diseño, organizacion, segregacion, resguardos y protecciones colectivas. Los EPI complementaran estas medidas frente al riesgo residual y se seleccionaran conforme a la evaluacion de riesgos, compatibilidad y condiciones de uso.

## Protecciones, señalizacion y accesos

Las vallas, barreras y cerramientos seran estables, visibles y adecuados al riesgo. No tendran aristas peligrosas ni se colocaran de forma que creen obstaculos ocultos o reduzcan peligrosamente la visibilidad.

Los huecos, arquetas y registros se cerraran con tapas resistentes e inmovilizadas o con barreras fisicas. La cinta de balizamiento no sera la unica proteccion ante caidas a distinto nivel, acceso a maquinaria u otros riesgos que requieran una barrera resistente.

La señalizacion temporal se adaptara a la ocupacion, visibilidad, trafico y normativa aplicable. Se mantendran recorridos seguros para peatones, residentes y accesos autorizados.

## Maquinaria, herramientas y productos

Los equipos de trabajo seran adecuados, mantenidos, inspeccionados y utilizados por personal formado y autorizado cuando proceda. Los resguardos y dispositivos de seguridad permaneceran operativos.

Las maniobras de maquinaria movil se planificaran para evitar personas en su radio de accion. La marcha atras se limitara y se apoyara con señalista cuando la visibilidad resulte insuficiente.

Los productos quimicos se utilizaran conforme a su ficha de datos de seguridad. Las exposiciones a polvo, humos, ruido, vibraciones, calor y radiacion solar se evaluaran y controlaran mediante medidas tecnicas y organizativas antes de recurrir al EPI.

## Organizacion preventiva y control

El contratista desarrollara este ESS en su Plan de Seguridad y Salud, definiendo responsables, procedimientos, medios, fases, mediciones y planos necesarios. Cualquier modificacion que introduzca riesgos no contemplados requerira evaluacion previa y, cuando corresponda, modificacion y aprobacion del Plan.

La Direccion Facultativa y el Coordinador de Seguridad y Salud podran requerir la correccion de situaciones inseguras dentro de sus competencias, sin perjuicio de las obligaciones propias de cada empresa interviniente.
