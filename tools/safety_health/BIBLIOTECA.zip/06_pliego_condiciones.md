# Pliego de condiciones

## Organización preventiva, coordinación y obligaciones

El presente Pliego establece las obligaciones de los agentes intervinientes y las condiciones de aplicación, control y abono de las medidas preventivas. Se interpretará conjuntamente con la Memoria del Documento I y con los restantes documentos del proyecto, sin sustituir las responsabilidades que corresponden a cada empresa.

### Promotor

El promotor cumplirá las obligaciones que le atribuye el Real Decreto 1627/1997, incluida la incorporación del presente Estudio al proyecto y la designación de los técnicos y coordinadores que resulten preceptivos. Facilitará la información disponible sobre las condiciones del emplazamiento y las interferencias que deban considerarse en la organización preventiva.

La designación de coordinadores no eximirá al promotor de sus responsabilidades. Cuando no sea necesaria la designación de coordinador durante la ejecución, las funciones que reglamentariamente correspondan serán asumidas por la Dirección Facultativa.

### Contratista

Cada contratista elaborará su Plan de Seguridad y Salud analizando, estudiando, desarrollando y complementando este Estudio en función de su sistema de ejecución y de la evaluación de los riesgos. Antes de iniciar los trabajos deberá disponer de la aprobación que corresponda y de los medios necesarios para implantarlo.

En particular, deberá:

- Implantar y mantener las medidas del Plan y hacerlas cumplir a su personal, subcontratistas y trabajadores autónomos dentro de sus respectivas obligaciones.
- Garantizar la formación y la información preventiva, la entrega y utilización de los EPI y la adecuación de la maquinaria y los equipos.
- Organizar la coordinación de actividades empresariales, establecer responsables y mantener disponible la documentación exigible.
- Comunicar los cambios de procedimiento, equipos, fases o condiciones que puedan afectar a la seguridad y tramitar las modificaciones del Plan cuando proceda.
- Verificar las condiciones de delimitación, accesos, circulación y protección de terceros definidas en la Memoria y desarrolladas en el Plan.

Las protecciones se conservarán operativas mientras exista el riesgo y se repondrán inmediatamente si se desplazan, deterioran o resultan insuficientes. No se autorizará una actividad mientras falten las condiciones de seguridad necesarias para realizarla.

Los equipos se utilizarán y mantendrán conforme a sus instrucciones y a los requisitos aplicables. Los productos químicos se manejarán de acuerdo con su etiquetado y sus fichas de datos de seguridad. Las exposiciones a polvo, humos, ruido, vibraciones, calor y radiación solar se evaluarán y controlarán mediante medidas técnicas y organizativas, dando prioridad a la protección colectiva antes de recurrir al EPI.

### Subcontratistas y trabajadores autónomos

Los subcontratistas y los trabajadores autónomos cumplirán las disposiciones preventivas que les resulten aplicables, las instrucciones de coordinación, el Plan de Seguridad y Salud y las obligaciones específicas del sector de la construcción.

Antes de incorporarse al tajo, conocerán los riesgos e interferencias que les afecten, los accesos autorizados, las medidas de emergencia y los procedimientos de trabajo. Comunicarán las circunstancias que puedan generar nuevos riesgos para otras empresas o personas y participarán en los medios de coordinación establecidos, sin que estos sustituyan sus obligaciones propias.

### Coordinador de Seguridad y Salud durante la ejecución

El coordinador ejercerá las funciones que le atribuye el Real Decreto 1627/1997, entre ellas la coordinación de los principios generales de prevención y de las actividades para la aplicación coherente de los principios preventivos. Coordinará las acciones y funciones de control de la aplicación correcta de los métodos de trabajo y adoptará las medidas necesarias para que solo las personas autorizadas accedan a la obra.

La aprobación del Plan de Seguridad y Salud y de sus modificaciones se efectuará en los términos del citado real decreto. Cuando no sea necesaria la designación de coordinador, estas funciones corresponderán a la Dirección Facultativa en los supuestos reglamentarios. En las obras de las Administraciones públicas, la aprobación corresponderá a la Administración pública que haya adjudicado la obra, previo informe del coordinador o, cuando no sea preceptivo, de la Dirección Facultativa.

La Dirección Facultativa y el coordinador podrán requerir, dentro de sus competencias, la corrección de las situaciones inseguras y actuarán ante riesgos graves e inminentes conforme a la normativa aplicable. Sus actuaciones no liberarán al contratista ni a los restantes intervinientes de sus responsabilidades.

### Recursos preventivos

La presencia de recursos preventivos se determinará conforme a la normativa aplicable y a la evaluación de los trabajos. El Plan identificará las actividades y situaciones en que resulte preceptiva, la forma de presencia y vigilancia, y las personas asignadas por cada contratista, que deberán contar con capacitación suficiente y medios adecuados.

La vigilancia comprobará el cumplimiento y la eficacia de las medidas, su adecuación a los riesgos y la aparición de circunstancias no previstas. Ante deficiencias, los recursos preventivos efectuarán las indicaciones necesarias para su corrección inmediata y las comunicarán al empresario para que adopte las medidas oportunas, sin sustituir las funciones de coordinación ni las obligaciones de la línea de mando.

### Vigilancia de la salud

La empresa garantizará la vigilancia de la salud de sus trabajadores en función de los riesgos inherentes a su trabajo, en los términos del artículo 22 de la Ley 31/1995 y de la normativa específica. Se respetará el consentimiento del trabajador y las excepciones legalmente previstas, con el informe previo de los representantes de los trabajadores cuando corresponda.

La documentación médica será confidencial y la gestionará el servicio sanitario competente. Al empresario y a los responsables de prevención se comunicarán únicamente las conclusiones sobre aptitud o necesidad de introducir o mejorar medidas preventivas en los términos legalmente establecidos. No se fija una periodicidad médica genérica ajena a la evaluación de riesgos.

## Plan de Seguridad y Salud, control y certificación

La planificación de la ejecución, la comprobación de las medidas y su valoración económica deberán mantenerse coherentes durante toda la obra. La documentación permitirá comprobar qué medidas se han previsto, cómo se implantan y qué cambios han sido aprobados.

### Plan de Seguridad y Salud

Antes del inicio de la obra, cada contratista elaborará un Plan de Seguridad y Salud en el que se analicen, estudien, desarrollen y complementen las previsiones de este Estudio en función de su propio sistema de ejecución. El Plan deberá estar aprobado antes del comienzo de los trabajos, mediante el procedimiento del Real Decreto 1627/1997 indicado en el capítulo anterior.

El Plan concretará los responsables, procedimientos, medios, fases, mediciones y planos necesarios. Como mínimo, definirá, según las características reales de la obra:

- La secuencia de tajos y fases, su duración y las interferencias con actividades simultáneas; cuando se actúe sobre varios viales o zonas, su orden de intervención.
- El número máximo simultáneo de trabajadores, la organización de las cuadrillas y los responsables de cada actividad.
- La implantación de instalaciones provisionales, servicios higiénicos, accesos y medios de primeros auxilios.
- La relación real de maquinaria, equipos y medios auxiliares, sus condiciones de utilización y sus comprobaciones.
- Los procedimientos de ejecución de las unidades de obra y de las operaciones de especial riesgo; cuando proceda, los de fresado, extendido, compactación y señalización.
- Los esquemas de circulación, desvíos y protección peatonal, coordinados con las administraciones y titulares competentes y, cuando corresponda, con la Policía Local.
- Las zonas de acopio, carga, descarga y espera de vehículos, evitando interferencias con trabajadores y terceros.
- Los procedimientos de emergencia, los medios de comunicación y los centros asistenciales de referencia, previa comprobación de sus datos.
- Los medios de coordinación empresarial y la presencia de recursos preventivos en las actividades en que resulte exigible.
- Las protecciones, señalización y EPI necesarios, sus condiciones de implantación, mantenimiento y retirada, y las cantidades y criterios de medición que correspondan.

Las alternativas preventivas que se propongan se justificarán técnicamente en los términos reglamentarios, sin disminuir los niveles de protección previstos. La aprobación del Plan no sustituye la evaluación de riesgos de las empresas ni exime de implantar las medidas efectivas.

### Libro de incidencias y control documental

Se dispondrá y utilizará el Libro de Incidencias en los supuestos, con los intervinientes y con el alcance previstos reglamentariamente. Permanecerá en la obra bajo la custodia que corresponda, y las anotaciones, notificaciones y comunicaciones se tramitarán conforme al Real Decreto 1627/1997.

Las observaciones, órdenes y comunicaciones preventivas se documentarán de forma que pueda comprobarse su recepción, seguimiento y cierre. Se identificarán las deficiencias, las medidas correctoras, sus responsables y los plazos, sin demorar las actuaciones inmediatas que requiera la seguridad.

El Plan aprobado y sus modificaciones, los registros de coordinación, las acreditaciones exigibles, los registros de entrega de EPI y la documentación de equipos y productos estarán disponibles en obra en los términos descritos en el Documento I. Las versiones sustituidas se identificarán para evitar la aplicación de instrucciones obsoletas.

### Certificación de medidas de Seguridad y Salud

Las unidades de Seguridad y Salud que integren las mediciones y el presupuesto se certificarán conforme a su medición real, a sus condiciones de abono y a los criterios económicos del proyecto y del contrato. Su comprobación atenderá a la efectiva implantación, mantenimiento y disponibilidad de los medios previstos, evitando duplicidades de medición o abono.

El presupuesto de Seguridad y Salud actualmente integrado en el presupuesto general asciende a {{presupuesto_seguridad_salud}}. Esta cifra corresponde a las partidas preventivas incorporadas al presupuesto y no sustituye la revisión de sus cantidades y condiciones reales de utilización. Cuando sea exigible el presupuesto del Estudio conforme al artículo 5 del Real Decreto 1627/1997, se comprobará que las mediciones detalladas, los precios y la valoración de todas las unidades preventivas necesarias queden definidos y sean coherentes con el resto de sus documentos.

Las medidas exigibles por la normativa o por el Plan no podrán dejar de implantarse por insuficiencia o agotamiento de una partida presupuestaria. Las diferencias de medición o las necesidades no previstas se tramitarán por el procedimiento contractual que corresponda, sin condicionar a su resolución la protección inmediata de las personas.

### Modificaciones y situaciones no previstas

Cuando durante la ejecución aparezcan circunstancias, servicios, sistemas de trabajo o riesgos no previstos, el contratista los evaluará antes de continuar la actividad afectada, adoptará las medidas inmediatas necesarias y propondrá el procedimiento preventivo correspondiente.

Si los cambios implican una modificación del Plan de Seguridad y Salud, se tramitará su aprobación antes de aplicar el nuevo sistema de trabajo. Se actualizarán los procedimientos, planos, mediciones e instrucciones afectados y se informará a las empresas y trabajadores intervinientes.

Ante una situación de riesgo grave e inminente se actuará conforme a la normativa aplicable, con interrupción de los trabajos afectados cuando proceda. No se reanudarán hasta disponer de condiciones seguras y de las autorizaciones que resulten exigibles.
