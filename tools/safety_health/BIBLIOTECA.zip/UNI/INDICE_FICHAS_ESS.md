"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Índice de fichas de Seguridad y Salud

Las fichas utilizan la clasificación BCCA y las carpetas de la biblioteca PPTP. Se selecciona el prefijo coincidente más largo y se incluye cada ficha una sola vez. Las familias generales 15CP y 15CR se conservan en su carpeta BCCA, sin inventar fichas específicas para cada variante. Las unidades sin correspondencia se muestran expresamente como pendientes; no se clasifican por similitud de su descripción.

| Prefijo BCCA | Ámbito | Ficha ESS | Uso |
|---|---|---|---|
| `01UPP` | Retirada de pavimentos | [01UPP](./01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_URBANIZACIONES/01UP_PAVIMENTACIONES/01UPP-Retirada de pavimentos.md) | Ficha preventiva específica. |
| `15APA` | Imbornales y arquetas de saneamiento | [15APA](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/15APA-Imbornales y arquetas de saneamiento.md) | Ficha preventiva específica. |
| `15APP` | Pozos de registro de saneamiento | [15APP](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/15APP-Pozos de registro de saneamiento.md) | Ficha preventiva específica. |
| `15ASS` | Sumideros | [15ASS](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/15ASS-Sumideros.md) | Ficha preventiva específica. |
| `15ASW` | Sumideros - Varios | [15ASW](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/15ASW-Sumideros - Varios.md) | Ficha preventiva específica. |
| `15CP` | Pinturas y marcas viales | [15CP](./15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACIÓN/15CP_PINTURAS/15CP-Pinturas y marcas viales.md) | Ficha preventiva específica. |
| `15CR` | Rótulos, placas y señales | [15CR](./15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACIÓN/15CR_RÓTULOS_Y_PLACAS/15CR-Rótulos, placas y señales.md) | Ficha preventiva específica. |
| `15PCC` | Mezcla bituminosa en caliente | [15PCC](./15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/15PCC-Mezcla bituminosa en caliente.md) | Ficha preventiva específica. |
| `17RB` | Residuos bituminosos | [17RB](./17_GESTIÓN_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RB_RESIDUOS_BITUMINOSOS/17RB-Residuos bituminosos - Común.md) | Ficha preventiva específica. |
| `17RRBN` | Correspondencia anterior: Residuos bituminosos | [17RB](./17_GESTIÓN_DE_RESIDUOS/17R_RESIDUOS_MEZCLADOS/17RB_RESIDUOS_BITUMINOSOS/17RB-Residuos bituminosos - Común.md) | Revisar el código de la partida; no modificar automáticamente el presupuesto. |
| `18CEE` | Ensayos de escolleras | [18CEE](./18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18C_CIMENTACIÓN/18CE_ESCOLLERAS/18CEE-Escolleras.md) | Ficha preventiva específica. |
| `18HHI` | Ensayos del hormigón in situ | [18HHI](./18_CONTROL_DE_CALIDAD_PRUEBAS_Y_ENSAYOS/18H_ESTRUCTURAS_DE_HORMIGÓN/18HH_HORMIGÓN/18HHI-Hormigón - Insitu.md) | Ficha preventiva específica. |
