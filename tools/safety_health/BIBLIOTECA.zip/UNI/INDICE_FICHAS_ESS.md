# Indice de fichas ESS

Este indice es el registro de resolucion automatica entre una partida de presupuesto y su ficha ESS. El software debe comparar `codigo_partida` con la columna **Prefijo BCCA**, seleccionar todas las coincidencias y usar la ficha de prefijo mas largo como ficha tecnica principal.

Las condiciones de [CONDICIONES_GENERALES_ESS.md](./CONDICIONES_GENERALES_ESS.md) se incorporan una sola vez por documento. Las fichas complementan esas condiciones; no las sustituyen.

| Prefijo BCCA | Ambito | Ficha ESS | Uso |
|---|---|---|---|
| `01UPP` | Demolicion de pavimentos | [FICHA_ESS_01UPP.md](./01_DEMOLICIONES_Y_TRABAJOS_PREVIOS/01U_PAVIMENTOS_Y_ELEMENTOS_URBANOS/01UPP_DEMOLICION_DE_PAVIMENTOS/FICHA_ESS_01UPP.md) | Aplicar a partidas de demolicion de pavimento. |
| `15PCC` | Calzadas asfalticas | [FICHA_ESS_15PCC.md](./15_URBANIZACIONES/15P_PAVIMENTACIONES/15PC_CALZADAS/FICHA_ESS_15PCC.md) | Aplicar a capas asfalticas, extendido y compactacion. |
| `15APA` | Arquetas | [FICHA_ESS_15APA.md](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/FICHA_ESS_15APA.md) | Aplicar a arquetas de paso, sifonicas y similares. |
| `15APP` | Pozos de registro | [FICHA_ESS_15APP.md](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AP_POZOS_Y_ARQUETAS/FICHA_ESS_15APP.md) | Aplicar a pozos y sus adaptaciones. |
| `15ASS` | Sumideros | [FICHA_ESS_15ASS.md](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/FICHA_ESS_15ASS.md) | Aplicar a sumideros e imbornales. |
| `15ASW` | Sumideros varios | [FICHA_ESS_15ASW.md](./15_URBANIZACIONES/15A_ALCANTARILLADO/15AS_SUMIDEROS/FICHA_ESS_15ASW.md) | Aplicar a unidades alternativas de imbornales. |
| `15CP` | Pinturas y marcas viales | [FICHA_ESS_15CP.md](./15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACION/15CP_PINTURAS/FICHA_ESS_15CP.md) | Aplicar a señalizacion horizontal. |
| `15CR` | Rotulos, placas y señales | [FICHA_ESS_15CR.md](./15_URBANIZACIONES/15C_INDICADORES_DE_CIRCULACION/15CR_ROTULOS_Y_PLACAS/FICHA_ESS_15CR.md) | Aplicar a señalizacion vertical. |
| `17RRBN` | Residuos de mezcla bituminosa | [FICHA_ESS_17RRBN.md](./17_GESTION_DE_RESIDUOS/17RRBN_RESIDUOS_DE_MEZCLA_BITUMINOSA/FICHA_ESS_17RRBN.md) | Aplicar a retirada, contenedor y transporte de residuos bituminosos. |
| `18CEE` | Ensayos de control | [FICHA_ESS_18CEE.md](./18_CONTROL_DE_CALIDAD/18CEE_ENSAYOS_DE_CONTROL/FICHA_ESS_18CEE.md) | Aplicar a extraccion y ensayo de testigos. |
| `18HHI` | Inspeccion y testigos | [FICHA_ESS_18HHI.md](./18_CONTROL_DE_CALIDAD/18HHI_EXTRACCION_DE_TESTIGOS/FICHA_ESS_18HHI.md) | Aplicar a extraccion, examen y rotura de testigos. |

Si no existe un prefijo en este indice, el software aplicara las reglas de descripcion de `09_enlace_automatico_presupuesto.md` y anotara la partida como pendiente de clasificacion.
