# Ensayos del hormigón in situ

## Definición y alcance

Comprende los ensayos del hormigón in situ, incluidas las comprobaciones con esclerómetro o ultrasonidos, extracción de testigos y pruebas de carga cuando estén previstas. Se aplicarán únicamente las medidas de las operaciones contratadas.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-TERCEROS, R-PROYECCION, R-POLVO, R-RUIDO, R-VIBRACION, R-HERRAMIENTA-PORTATIL, R-ELECTRICO, R-CAIDA-MISMO-NIVEL, R-POSTURA-FORZADA, R-CAIDA-DISTINTO-NIVEL, R-CAIDA-OBJETOS, R-DERRUMBE.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Cada ensayo se organizará como un tajo delimitado, coordinado con la obra y sin presencia de terceros en la zona de riesgo (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Antes de perforar se localizarán servicios y elementos que no deban afectarse. Se comprobarán apoyo, resguardos y conexiones del equipo; el polvo y las proyecciones se controlarán en origen (MP-LOCALIZAR-SERVICIOS, MP-CONTROL-MAQUINARIA, MP-HUMECTACION).
- Los huecos se protegerán o repararán antes de retirar la delimitación. Las pruebas de carga requerirán un procedimiento específico con control de estabilidad, acceso y criterios de interrupción (MP-PROTEGER-HUECOS, MP-ACCESOS-SEGUROS, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-PROTECCION-DESNIVELES: Protección de bordes y cambios de cota, con transiciones seguras.

Se protegerán los desniveles cuando exista exposición. Las pruebas de carga tendrán una zona de exclusión definida en su procedimiento.

### Equipos de protección individual

- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-AUDITIVO: Protección auditiva seleccionada según la exposición, compatible con la percepción de avisos y alarmas.
- EPI-RESPIRATORIO: Protección respiratoria solo cuando la exposición residual lo requiera, seleccionada según contaminante, concentración y ajuste al usuario; no sustituye el control en origen.
- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.

La protección auditiva, respiratoria y de alta visibilidad se utilizará cuando la exposición lo requiera. El acceso en altura se resolverá de manera específica.

### Equipos de trabajo

- EQ-EXTRACCION-TESTIGOS: Equipo de extracción de testigos, únicamente cuando se contrate esta operación.

Se emplearán los equipos del ensayo concreto, comprobados según el fabricante. Los esclerómetros, ultrasonidos y equipos de carga se verificarán por separado.

## Validación

Se confirmarán ensayo, ubicación, resistencia y estabilidad del elemento, servicios afectados, alimentación y acceso. Para perforaciones se comprobará la reposición del hueco; para pruebas de carga, el procedimiento y sus límites de seguridad. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
