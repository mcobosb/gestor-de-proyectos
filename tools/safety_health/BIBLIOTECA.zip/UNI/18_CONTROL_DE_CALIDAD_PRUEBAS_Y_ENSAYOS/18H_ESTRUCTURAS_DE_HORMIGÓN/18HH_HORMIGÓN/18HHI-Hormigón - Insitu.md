# Ensayos del hormigón in situ

Clasificación BCCA: 18 / 18H / 18HH / 18HHI.

## Definición y alcance

Comprende los ensayos del hormigón in situ, incluidas las comprobaciones con esclerómetro o ultrasonidos, extracción de testigos y pruebas de carga cuando estén previstas. Se aplicarán únicamente las medidas de las operaciones contratadas.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.
- R-PROYECCION: Impacto de fragmentos, virutas, partículas o microesferas despedidas durante corte, perforación, demolición o marcado. Puede lesionar ojos y piel; requiere resguardos, distancias de seguridad, zonas de exclusión y protección ocular adecuada al riesgo residual.
- R-POLVO: Inhalación de partículas generadas en fresado, corte, demolición o limpieza, con efectos dependientes del material y su composición. Se reducirá la emisión mediante captación, aspiración o humectación compatible, evitando el barrido en seco que genere exposición innecesaria.
- R-RUIDO: Exposición al ruido de fresadoras, martillos, radiales, compactadores y otros equipos, con posible daño auditivo y dificultad para percibir avisos. Se evaluará cuando sea significativa, priorizando equipos menos ruidosos, mantenimiento y control del tiempo de exposición.
- R-VIBRACION: Transmisión de vibraciones mano-brazo o de cuerpo entero por martillos, compactadores y maquinaria móvil. Puede causar trastornos vasculares, nerviosos o musculoesqueléticos; se considerarán valores del fabricante, uso real, firme, mantenimiento y tiempo de exposición.
- R-HERRAMIENTA-PORTATIL: Exposición a cortes, golpes, proyecciones, contactos eléctricos o atrapamientos al utilizar herramientas manuales, eléctricas y neumáticas. Deben seleccionarse según la tarea, conservar sus protecciones y comprobar el estado de útiles, cables y conexiones.
- R-ELECTRICO: Contacto directo con partes en tensión o indirecto con masas accidentalmente energizadas, incluidas redes enterradas y equipos portátiles. Puede causar electrocución, quemaduras o caídas; requiere localizar servicios y aplicar aislamiento y procedimientos eléctricos autorizados.
- R-CAIDA-MISMO-NIVEL: Pérdida de equilibrio sobre la superficie de trabajo por irregularidades, residuos, cables o derrames. Puede provocar golpes, esguinces y fracturas; se previene manteniendo recorridos despejados, superficies estables y un orden y limpieza continuos.
- R-POSTURA-FORZADA: Mantenimiento de posiciones incómodas o extremas de espalda, cuello o extremidades durante trabajos a baja altura o de acceso difícil. Puede causar sobrecarga musculoesquelética; requiere adaptar el puesto, utilizar ayudas y alternar posturas y tareas.
- R-CAIDA-DISTINTO-NIVEL: Caída desde bordes, plataformas o accesos hacia huecos, excavaciones, pozos o registros. Sus consecuencias dependen de la altura y la superficie de impacto; requiere accesos seguros, tapas resistentes y protecciones colectivas adecuadas al desnivel.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-DERRUMBE: Desprendimiento de tierras o pérdida de estabilidad de taludes, paredes de excavación o elementos próximos. Puede sepultar o golpear a las personas; deben evaluarse el terreno, agua, vibraciones y cargas cercanas antes de definir el sostenimiento.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Cada ensayo se organizará como un tajo delimitado, coordinado con la obra y sin presencia de terceros en la zona de riesgo (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Antes de perforar se localizarán servicios y elementos que no deban afectarse. Se comprobarán apoyo, resguardos y conexiones del equipo; el polvo y las proyecciones se controlarán en origen (MP-LOCALIZAR-SERVICIOS, MP-CONTROL-MAQUINARIA, MP-HUMECTACION).
- Los huecos se protegerán o repararán antes de retirar la delimitación. Las pruebas de carga requerirán un procedimiento específico con control de estabilidad, acceso y criterios de interrupción (MP-PROTEGER-HUECOS, MP-ACCESOS-SEGUROS, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

Se preverán PC-BALIZAMIENTO, PC-SENALIZACION y PC-PROTECCION-DESNIVELES cuando exista exposición. Las pruebas de carga tendrán una zona de exclusión definida en su procedimiento.

### Equipos de protección individual

Se seleccionarán EPI-CALZADO y EPI-OCULAR, con EPI-AUDITIVO, EPI-RESPIRATORIO y EPI-ALTA-VISIBILIDAD cuando la exposición lo requiera. El acceso en altura se resolverá de manera específica.

### Equipos de trabajo

Se emplearán los equipos del ensayo concreto, comprobados según el fabricante. EQ-EXTRACCION-TESTIGOS solo se preverá cuando se contrate esa operación; esclerómetros, ultrasonidos y equipos de carga se verificarán por separado.

### Validación

Se confirmarán ensayo, ubicación, resistencia y estabilidad del elemento, servicios afectados, alimentación y acceso. Para perforaciones se comprobará la reposición del hueco; para pruebas de carga, el procedimiento y sus límites de seguridad. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
