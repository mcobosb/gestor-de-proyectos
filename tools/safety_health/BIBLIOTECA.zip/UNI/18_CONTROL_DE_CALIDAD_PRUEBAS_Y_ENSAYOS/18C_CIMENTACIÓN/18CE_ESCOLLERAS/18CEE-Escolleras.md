"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Ensayos de escolleras

## Definición y alcance

Comprende la toma y reducción de muestras de escollera y los ensayos de sus propiedades. Se diferenciarán la toma de muestras en obra o cantera de las operaciones de laboratorio; los riesgos se ajustarán a cada emplazamiento y equipo.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-TERCEROS, R-CAIDA-MISMO-NIVEL, R-CAIDA-OBJETOS, R-SOBREESFUERZO, R-GOLPE-ATRAPAMIENTO, R-PROYECCION, R-POLVO, R-RUIDO, R-QUIMICO, R-ELECTRICO.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se coordinará el muestreo con la explotación o el tajo, fuera del radio de maquinaria y de acopios inestables (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Las muestras se obtendrán y transportarán con ayudas adecuadas, evitando la manipulación de bloques inestables y el levantamiento de cargas excesivas (MP-MANIPULACION-CARGAS, MP-ACCESOS-SEGUROS).
- En preparación y ensayo se utilizarán resguardos, control de polvo y procedimientos de limpieza seguros. Los reactivos, cuando existan, se utilizarán según su ficha de seguridad (MP-CONTROL-MAQUINARIA, MP-HUMECTACION, MP-HIGIENE-QUIMICA, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-ZONA-EXCLUSION: Delimitación física de las zonas en las que no debe permanecer personal.

Se aplicarán en el muestreo; los equipos de laboratorio conservarán sus resguardos y captación.

### Equipos de protección individual

- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-GUANTES: Guantes adecuados a la manipulación de materiales y a los riesgos mecánicos.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-AUDITIVO: Protección auditiva seleccionada según la exposición, compatible con la percepción de avisos y alarmas.
- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.

La alta visibilidad se empleará ante tráfico o maquinaria; la protección química o respiratoria dependerá de la exposición evaluada.

### Equipos de trabajo

- EQ-HERRAMIENTA-MANUAL: Herramientas manuales o portátiles adecuadas a la tarea y en buen estado.
- EQ-ELEVACION: Medio de elevación y útiles de izado adecuados al peso y a la geometría de las piezas.

Se utilizarán los útiles de muestreo, preparación y ensayo previstos por el laboratorio, comprobando resguardos y mantenimiento. Las herramientas manuales y los medios de elevación solo se incorporarán cuando sean necesarios para la muestra.

## Validación

Se confirmarán lugar de muestreo, estabilidad del acopio, masa de las muestras y ensayos concretos. No se asignará automáticamente extracción de testigos de pavimento a esta familia, que corresponde al control de escolleras. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
