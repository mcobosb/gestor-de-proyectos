# Ensayos de escolleras

Clasificación BCCA: 18 / 18C / 18CE / 18CEE.

## Definición y alcance

Comprende la toma y reducción de muestras de escollera y los ensayos de sus propiedades. Se diferenciarán la toma de muestras en obra o cantera de las operaciones de laboratorio; los riesgos se ajustarán a cada emplazamiento y equipo.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.
- R-CAIDA-MISMO-NIVEL: Pérdida de equilibrio sobre la superficie de trabajo por irregularidades, residuos, cables o derrames. Puede provocar golpes, esguinces y fracturas; se previene manteniendo recorridos despejados, superficies estables y un orden y limpieza continuos.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-SOBREESFUERZO: Sobrecarga física al levantar, transportar, empujar o colocar tapas, señales, bordillos, sacos y herramientas. Puede provocar lesiones musculares y lumbares; deben emplearse ayudas mecánicas, trabajo coordinado y una organización que limite la manipulación manual.
- R-GOLPE-ATRAPAMIENTO: Golpe, corte o aprisionamiento al mover tapas, bordillos, señales y otros materiales, especialmente durante su ajuste o descarga. Deben preverse puntos de agarre, apoyos estables, ayudas mecánicas y coordinación entre las personas que intervienen.
- R-PROYECCION: Impacto de fragmentos, virutas, partículas o microesferas despedidas durante corte, perforación, demolición o marcado. Puede lesionar ojos y piel; requiere resguardos, distancias de seguridad, zonas de exclusión y protección ocular adecuada al riesgo residual.
- R-POLVO: Inhalación de partículas generadas en fresado, corte, demolición o limpieza, con efectos dependientes del material y su composición. Se reducirá la emisión mediante captación, aspiración o humectación compatible, evitando el barrido en seco que genere exposición innecesaria.
- R-RUIDO: Exposición al ruido de fresadoras, martillos, radiales, compactadores y otros equipos, con posible daño auditivo y dificultad para percibir avisos. Se evaluará cuando sea significativa, priorizando equipos menos ruidosos, mantenimiento y control del tiempo de exposición.
- R-QUIMICO: Exposición por inhalación, contacto cutáneo u ocular a pinturas, disolventes, emulsiones y otros productos. Puede causar irritación, quemaduras, sensibilización o intoxicación; exige ficha de datos de seguridad actualizada y control de incompatibilidades, ventilación e higiene.
- R-ELECTRICO: Contacto directo con partes en tensión o indirecto con masas accidentalmente energizadas, incluidas redes enterradas y equipos portátiles. Puede causar electrocución, quemaduras o caídas; requiere localizar servicios y aplicar aislamiento y procedimientos eléctricos autorizados.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se coordinará el muestreo con la explotación o el tajo, fuera del radio de maquinaria y de acopios inestables (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Las muestras se obtendrán y transportarán con ayudas adecuadas, evitando la manipulación de bloques inestables y el levantamiento de cargas excesivas (MP-MANIPULACION-CARGAS, MP-ACCESOS-SEGUROS).
- En preparación y ensayo se utilizarán resguardos, control de polvo y procedimientos de limpieza seguros. Los reactivos, cuando existan, se utilizarán según su ficha de seguridad (MP-CONTROL-MAQUINARIA, MP-HUMECTACION, MP-HIGIENE-QUIMICA, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

Se preverán PC-BALIZAMIENTO, PC-SENALIZACION y PC-ZONA-EXCLUSION en el muestreo; los equipos de laboratorio conservarán sus resguardos y captación.

### Equipos de protección individual

Se seleccionarán EPI-CALZADO, EPI-GUANTES, EPI-OCULAR y EPI-AUDITIVO según la operación. EPI-ALTA-VISIBILIDAD se empleará ante tráfico o maquinaria; la protección química o respiratoria dependerá de la exposición evaluada.

### Equipos de trabajo

Se utilizarán los útiles de muestreo, preparación y ensayo previstos por el laboratorio, comprobando resguardos y mantenimiento. EQ-HERRAMIENTA-MANUAL o EQ-ELEVACION solo se incorporarán cuando sean necesarios para la muestra.

### Validación

Se confirmarán lugar de muestreo, estabilidad del acopio, masa de las muestras y ensayos concretos. No se asignará automáticamente extracción de testigos de pavimento a esta familia, que corresponde al control de escolleras. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
