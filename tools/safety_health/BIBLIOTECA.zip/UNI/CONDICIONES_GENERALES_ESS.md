# Condiciones generales de seguridad y salud

Estas condiciones se aplican a todas las partidas incluidas en el ESS y se emiten una sola vez.

## Criterios generales

Los riesgos se eliminaran o reduciran mediante la planificacion, la organizacion del trabajo, la segregacion de circulaciones, los resguardos y las protecciones colectivas antes de recurrir al EPI. Ningun trabajo se iniciara sin que las medidas previstas para su fase se encuentren implantadas.

## Comprobaciones previas

Antes de cada tajo se verificaran delimitacion, señalizacion, accesos, acopios, servicios afectados, equipos, condiciones meteorologicas y afeccion a terceros. La modificacion de un procedimiento o la aparicion de un riesgo no previsto obligara a detener y reevaluar los trabajos.

## Aplicacion de fichas

Cada ficha ESS identifica riesgos, medidas, protecciones, EPI y equipos caracteristicos de una familia de partidas. Sus referencias se resuelven en `03_fichas_unidades_obra.md`, `04_catalogos_preventivos.md` y `08_matriz_riesgos_por_unidad.md`. La seleccion definitiva se confirmara en el Plan de Seguridad y Salud.
