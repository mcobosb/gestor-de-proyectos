"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Unidades de obra y fichas preventivas

Este capítulo relaciona todas las unidades del presupuesto con sus riesgos y medidas preventivas y desarrolla las fichas específicas disponibles. La tabla identifica la partida y la ficha BCCA que le corresponde; sus referencias preventivas enlazan con las definiciones del catálogo. A continuación se incluyen las fichas una sola vez, ordenadas por la clasificación y estructura de carpetas utilizadas en PPTP. Las unidades sin ficha específica se señalan expresamente como pendientes de completar y no deben entenderse evaluadas por la mera inclusión en el resumen.
