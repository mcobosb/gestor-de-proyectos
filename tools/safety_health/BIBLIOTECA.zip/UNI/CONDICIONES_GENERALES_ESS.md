# Condiciones generales de seguridad y salud


Las unidades incluidas en esta obra son: `{{unidades_obra}}`. Los codigos de sus partidas presupuestarias son: `{{unidades_obra_bcca}}`.

Los criterios comunes y las comprobaciones previas se recogen en el apartado Criterios preventivos generales de la memoria descriptiva y no se repiten en cada ficha.

El enlace con el presupuesto se realiza conforme a `09_enlace_automatico_presupuesto.md` y al indice de `UNI/`. Cada ficha ESS identifica riesgos, medidas, protecciones, EPI y equipos caracteristicos de una familia de partidas; sus referencias se resuelven en `03_fichas_unidades_obra.md`, `04_catalogos_preventivos.md` y `08_matriz_riesgos_por_unidad.md`. La seleccion definitiva se confirmara en el Plan de Seguridad y Salud, con el alcance establecido en el pliego.
