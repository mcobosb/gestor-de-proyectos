# Demolicion de pavimentos

**Clasificacion:** `01UPP`. **Capitulo:** demoliciones y trabajos previos. **Unidad ESS:** `UO-DEMOLICION`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a partidas de levantado o demolicion de pavimentos, especialmente cuando se empleen fresadora, retroexcavadora, martillo demoledor, corte o carga mecanica.

## Riesgos

`R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-ATRAPAMIENTO`, `R-PROYECCION`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-DESNIVEL`, `R-CAIDA-MISMO-NIVEL`, `R-CAIDA-OBJETOS` y `R-TERCEROS`.

## Medidas preventivas

Delimitar el tajo y establecer un circuito de maquinaria y retirada de material. Mantener fuera de la zona de trabajo a peatones y personal ajeno. Controlar el polvo mediante humectacion u otro sistema compatible, proteger los desniveles generados y retirar el material de forma progresiva.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO`, `PC-SENALIZACION` y `PC-PROTECCION-DESNIVELES`. Dotar los EPI definidos en la evaluacion, incluyendo `EPI-ALTA-VISIBILIDAD`, `EPI-CALZADO`, `EPI-OCULAR`, `EPI-AUDITIVO` y, cuando proceda, `EPI-RESPIRATORIO`. Los equipos caracteristicos son `EQ-FRESADORA`, `EQ-EXCAVADORA`, `EQ-MARTILLO-DEMOLEDOR` y `EQ-CAMION`.

## Validaciones

Confirmar medios de demolicion, exposicion a polvo y ruido, itinerario de camiones y proteccion de los cambios de nivel antes de iniciar la unidad.
