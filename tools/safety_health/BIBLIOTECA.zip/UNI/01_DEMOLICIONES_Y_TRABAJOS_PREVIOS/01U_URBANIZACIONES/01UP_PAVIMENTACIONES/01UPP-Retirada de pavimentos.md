# Retirada de pavimentos

Clasificación BCCA: 01 / 01U / 01UP / 01UPP.

## Definición y alcance

Comprende el levantado o la demolición de pavimentos y la retirada del material resultante. El procedimiento se adaptará al material, espesor, medios de corte o demolición y proximidad de tráfico, servicios y construcciones que deban conservarse.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-RETROCESO-MAQUINA: Golpe o atropello durante la marcha atrás de vehículos o maquinaria por puntos ciegos o presencia de personas en la trayectoria. Se limitarán estas maniobras, se delimitará su recorrido y se dispondrá señalista cuando la visibilidad sea insuficiente.
- R-ATRAPAMIENTO: Aprisionamiento de una parte del cuerpo entre órganos móviles, transmisiones o elementos de un equipo. Puede producir aplastamientos o amputaciones durante el uso, limpieza o mantenimiento; exige resguardos operativos y aislamiento seguro antes de intervenir.
- R-PROYECCION: Impacto de fragmentos, virutas, partículas o microesferas despedidas durante corte, perforación, demolición o marcado. Puede lesionar ojos y piel; requiere resguardos, distancias de seguridad, zonas de exclusión y protección ocular adecuada al riesgo residual.
- R-POLVO: Inhalación de partículas generadas en fresado, corte, demolición o limpieza, con efectos dependientes del material y su composición. Se reducirá la emisión mediante captación, aspiración o humectación compatible, evitando el barrido en seco que genere exposición innecesaria.
- R-RUIDO: Exposición al ruido de fresadoras, martillos, radiales, compactadores y otros equipos, con posible daño auditivo y dificultad para percibir avisos. Se evaluará cuando sea significativa, priorizando equipos menos ruidosos, mantenimiento y control del tiempo de exposición.
- R-VIBRACION: Transmisión de vibraciones mano-brazo o de cuerpo entero por martillos, compactadores y maquinaria móvil. Puede causar trastornos vasculares, nerviosos o musculoesqueléticos; se considerarán valores del fabricante, uso real, firme, mantenimiento y tiempo de exposición.
- R-DESNIVEL: Circulación insegura por escalones, bordes y cambios de cota, especialmente al transportar materiales o compartir paso con equipos. Puede originar tropiezos, caídas o pérdida de control; deben acondicionarse y protegerse las transiciones.
- R-CAIDA-MISMO-NIVEL: Pérdida de equilibrio sobre la superficie de trabajo por irregularidades, residuos, cables o derrames. Puede provocar golpes, esguinces y fracturas; se previene manteniendo recorridos despejados, superficies estables y un orden y limpieza continuos.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Antes de comenzar se delimitará el tajo y se separarán peatones y maquinaria, definiendo la carga y retirada del material sin interferencias (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Se identificarán las redes existentes y se mantendrá una distancia segura de los órganos de corte y demolición; los equipos se utilizarán conforme a sus instrucciones (MP-LOCALIZAR-SERVICIOS, MP-CONTROL-MAQUINARIA).
- El polvo se reducirá mediante captación o humectación compatible con el trabajo. Los desniveles se protegerán desde su aparición y los restos se retirarán de forma progresiva (MP-HUMECTACION, MP-PROTEGER-DESNIVELES, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

Se dispondrán PC-BALIZAMIENTO, PC-SENALIZACION y PC-PROTECCION-DESNIVELES según el riesgo; el balizamiento no sustituirá una barrera resistente cuando sea necesaria.

### Equipos de protección individual

Se seleccionarán EPI-ALTA-VISIBILIDAD, EPI-CALZADO, EPI-OCULAR y EPI-AUDITIVO. EPI-RESPIRATORIO se utilizará solo ante exposición residual que lo justifique.

### Equipos de trabajo

Podrán emplearse EQ-FRESADORA, EQ-EXCAVADORA, EQ-MARTILLO-DEMOLEDOR, EQ-CORTE y EQ-CAMION; se comprobarán resguardos, mantenimiento y coordinación de maniobras.

### Validación

Antes del inicio se confirmarán el método de demolición, los servicios afectados, la exposición a polvo, ruido y vibraciones, el recorrido de camiones y la protección de los cambios de nivel. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
