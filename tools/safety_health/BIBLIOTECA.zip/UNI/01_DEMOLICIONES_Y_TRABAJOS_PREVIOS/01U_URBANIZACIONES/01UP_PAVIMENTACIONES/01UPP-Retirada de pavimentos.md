# Retirada de pavimentos

## Definición y alcance

Comprende el levantado o la demolición de pavimentos y la retirada del material resultante. El procedimiento se adaptará al material, espesor, medios de corte o demolición y proximidad de tráfico, servicios y construcciones que deban conservarse.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-RETROCESO-MAQUINA, R-ATRAPAMIENTO, R-PROYECCION, R-POLVO, R-RUIDO, R-VIBRACION, R-DESNIVEL, R-CAIDA-MISMO-NIVEL, R-CAIDA-OBJETOS, R-TERCEROS.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Antes de comenzar se delimitará el tajo y se separarán peatones y maquinaria, definiendo la carga y retirada del material sin interferencias (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Se identificarán las redes existentes y se mantendrá una distancia segura de los órganos de corte y demolición; los equipos se utilizarán conforme a sus instrucciones (MP-LOCALIZAR-SERVICIOS, MP-CONTROL-MAQUINARIA).
- El polvo se reducirá mediante captación o humectación compatible con el trabajo. Los desniveles se protegerán desde su aparición y los restos se retirarán de forma progresiva (MP-HUMECTACION, MP-PROTEGER-DESNIVELES, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-PROTECCION-DESNIVELES: Protección de bordes y cambios de cota, con transiciones seguras.

El balizamiento no sustituirá una barrera resistente cuando sea necesaria.

### Equipos de protección individual

- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-AUDITIVO: Protección auditiva seleccionada según la exposición, compatible con la percepción de avisos y alarmas.
- EPI-RESPIRATORIO: Protección respiratoria solo cuando la exposición residual lo requiera, seleccionada según contaminante, concentración y ajuste al usuario; no sustituye el control en origen.

La selección se ajustará a la exposición real a proyecciones, ruido y polvo.

### Equipos de trabajo

- EQ-FRESADORA: Fresadora de pavimento, con control de accesos a sus órganos de trabajo.
- EQ-EXCAVADORA: Excavadora o retroexcavadora adecuada al espacio y a las condiciones del terreno.
- EQ-MARTILLO-DEMOLEDOR: Equipo de demolición adecuado al material, con sus protecciones operativas.
- EQ-CORTE: Equipo de corte con resguardos y útiles adecuados al material.
- EQ-CAMION: Camión de transporte o descarga, con maniobras coordinadas.

Se comprobarán los resguardos, el mantenimiento y la coordinación de maniobras.

## Validación

Antes del inicio se confirmarán el método de demolición, los servicios afectados, la exposición a polvo, ruido y vibraciones, el recorrido de camiones y la protección de los cambios de nivel. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
