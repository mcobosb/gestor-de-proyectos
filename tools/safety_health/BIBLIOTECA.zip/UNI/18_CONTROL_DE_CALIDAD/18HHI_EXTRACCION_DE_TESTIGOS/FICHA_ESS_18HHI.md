# Extraccion de testigos

**Clasificacion:** `18HHI`. **Capitulo:** control de calidad. **Unidad ESS:** `UO-CALIDAD`. [Indice de fichas](../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a la extraccion de testigos, su examen y, cuando corresponda, su rotura o ensayo posterior.

## Riesgos

`R-ATROPELLO`, `R-TERCEROS`, `R-PROYECCION`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-HERRAMIENTA-PORTATIL`, `R-ELECTRICO`, `R-CAIDA-MISMO-NIVEL` y `R-POSTURA-FORZADA`.

## Medidas preventivas

Señalizar y balizar el punto de perforacion antes de colocar el equipo. Comprobar la estabilidad del apoyo, el estado de las protecciones del equipo y la seguridad de las conexiones. Una vez extraido el testigo, reparar o proteger el hueco antes de retirar la delimitacion.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO` y `PC-SENALIZACION`. Utilizar `EPI-ALTA-VISIBILIDAD`, `EPI-OCULAR`, `EPI-AUDITIVO`, `EPI-CALZADO` y la proteccion respiratoria necesaria. El equipo caracteristico es `EQ-EXTRACCION-TESTIGOS`.

## Validaciones

Confirmar que la perforacion no afecta a servicios, que el tajo se mantiene segregado y que se ha previsto la reposicion del pavimento.
