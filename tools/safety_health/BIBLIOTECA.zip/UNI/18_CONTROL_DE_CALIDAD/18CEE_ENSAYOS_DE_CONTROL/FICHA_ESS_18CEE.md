# Ensayos de control

**Clasificacion:** `18CEE`. **Capitulo:** control de calidad. **Unidad ESS:** `UO-CALIDAD`. [Indice de fichas](../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a ensayos de materiales y firme que requieran extraccion, corte, perforacion, manipulacion de muestras o equipos portatiles.

## Riesgos

`R-ATROPELLO`, `R-TERCEROS`, `R-PROYECCION`, `R-POLVO`, `R-RUIDO`, `R-VIBRACION`, `R-HERRAMIENTA-PORTATIL`, `R-ELECTRICO`, `R-CAIDA-MISMO-NIVEL` y `R-POSTURA-FORZADA`.

## Medidas preventivas

Tratar cada ensayo como un tajo independiente: delimitar el punto de trabajo, controlar la afeccion al trafico y mantener a terceros fuera de la zona de proyeccion. Verificar el estado del equipo y proteger o reparar inmediatamente los huecos generados.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO` y `PC-SENALIZACION`. Utilizar `EPI-ALTA-VISIBILIDAD`, `EPI-OCULAR`, `EPI-AUDITIVO`, `EPI-CALZADO` y la proteccion respiratoria que proceda. El equipo caracteristico es `EQ-EXTRACCION-TESTIGOS`.

## Validaciones

Confirmar ubicacion del ensayo, equipo empleado, conexion electrica si existe, proteccion frente al trafico y tratamiento del hueco resultante.
