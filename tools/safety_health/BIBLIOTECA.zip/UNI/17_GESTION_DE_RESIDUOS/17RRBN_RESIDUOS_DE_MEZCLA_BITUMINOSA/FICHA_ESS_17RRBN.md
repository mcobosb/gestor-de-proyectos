# Residuos de mezcla bituminosa

**Clasificacion:** `17RRBN`. **Capitulo:** gestion de residuos. **Unidad ESS:** `UO-RESIDUOS`. [Indice de fichas](../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a partidas de retirada, carga, contenedor, transporte y entrega a gestor de residuos de mezcla bituminosa.

## Riesgos

`R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-APLASTAMIENTO`, `R-CAIDA-MISMO-NIVEL`, `R-RESBALON`, `R-PINCHAZO`, `R-CORTE`, `R-QUIMICO`, `R-DERMATITIS`, `R-CAIDA-OBJETOS` y `R-TERCEROS`.

## Medidas preventivas

Acopiar los residuos de forma estable, evitando invadir itinerarios o zonas de maniobra. Coordinar la carga con los movimientos de vehiculos y prohibir la permanencia bajo cucharas o cargas. Identificar y segregar los residuos y los envases contaminados conforme a la normativa aplicable.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO` y `PC-SENALIZACION`. Utilizar `EPI-ALTA-VISIBILIDAD`, `EPI-GUANTES`, `EPI-CALZADO` y `EPI-OCULAR`. Podran requerirse `EQ-CAMION` y `EQ-CARGADORA`.

## Validaciones

Confirmar clasificacion del residuo, caracterizacion cuando proceda, gestor de destino, sistema de carga y condiciones de transporte.
