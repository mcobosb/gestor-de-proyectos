# Residuos bituminosos

## Definición y alcance

Comprende la retirada, carga, almacenamiento temporal y transporte de residuos bituminosos. Se confirmará su caracterización y peligrosidad; esta ficha no autoriza a tratar como residuo no peligroso un material de composición desconocida.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-RETROCESO-MAQUINA, R-APLASTAMIENTO, R-CAIDA-MISMO-NIVEL, R-RESBALON, R-PINCHAZO, R-CORTE, R-QUIMICO, R-DERMATITIS, R-CAIDA-OBJETOS, R-TERCEROS.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Los residuos se acopiarán de forma estable sin invadir itinerarios ni zonas de maniobra (MP-ORDEN-LIMPIEZA, MP-SEGREGACION).
- La carga se coordinará con los movimientos de vehículos, impidiendo la presencia de personas bajo cucharas o cargas (MP-CONTROL-MAQUINARIA, MP-ZONA-EXCLUSION).
- Se identificarán y separarán los materiales y envases contaminados. Se evitarán derrames y se controlará el polvo durante la manipulación (MP-HIGIENE-QUIMICA, MP-HUMECTACION).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.

El cerramiento y la contención serán adecuados a los residuos y a la proximidad de terceros.

### Equipos de protección individual

- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.
- EPI-GUANTES: Guantes adecuados a la manipulación de materiales y a los riesgos mecánicos.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.

Las prestaciones químicas y respiratorias se determinarán según la caracterización del residuo y la exposición.

### Equipos de trabajo

- EQ-CAMION: Camión de transporte o descarga, con maniobras coordinadas.
- EQ-CARGADORA: Equipo de carga adecuado al material y a la estabilidad de la zona de trabajo.

Se comprobarán la estabilidad de la zona de carga y la sujeción y cubrición necesarias para el transporte.

## Validación

Se confirmarán clasificación, caracterización cuando proceda, gestor de destino y condiciones de carga y transporte. Los códigos anteriores de la familia 17RRBN requieren comprobar su correspondencia con la clasificación BCCA 17RB. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
