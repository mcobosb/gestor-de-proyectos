# Residuos bituminosos

Clasificación BCCA: 17 / 17R / 17RB.

## Definición y alcance

Comprende la retirada, carga, almacenamiento temporal y transporte de residuos bituminosos. Se confirmará su caracterización y peligrosidad; esta ficha no autoriza a tratar como residuo no peligroso un material de composición desconocida.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-RETROCESO-MAQUINA: Golpe o atropello durante la marcha atrás de vehículos o maquinaria por puntos ciegos o presencia de personas en la trayectoria. Se limitarán estas maniobras, se delimitará su recorrido y se dispondrá señalista cuando la visibilidad sea insuficiente.
- R-APLASTAMIENTO: Compresión del cuerpo entre vehículos, equipos, elementos constructivos o cargas, con posibles lesiones graves o mortales. Deben evitarse posiciones entre elementos móviles y fijos, asegurar apoyos y establecer zonas de exclusión durante las maniobras.
- R-CAIDA-MISMO-NIVEL: Pérdida de equilibrio sobre la superficie de trabajo por irregularidades, residuos, cables o derrames. Puede provocar golpes, esguinces y fracturas; se previene manteniendo recorridos despejados, superficies estables y un orden y limpieza continuos.
- R-RESBALON: Pérdida de adherencia por agua, lodos, emulsiones, grasas o material suelto en superficies de paso y trabajo. Puede causar caídas y pérdida de control de equipos; requiere contener derrames, limpiar y acondicionar los recorridos.
- R-PINCHAZO: Penetración de elementos punzantes como ferralla, alambres, residuos o herramientas en manos, pies u otras zonas del cuerpo. Puede causar heridas e infección; deben protegerse extremos, retirarse residuos y emplearse útiles y protección adecuados.
- R-CORTE: Lesión por contacto con filos, aristas, chapas, discos, herramientas o elementos rotos durante uso y manipulación. Deben mantenerse los resguardos, emplearse útiles adecuados y organizar el agarre y transporte evitando la exposición de manos y cuerpo.
- R-QUIMICO: Exposición por inhalación, contacto cutáneo u ocular a pinturas, disolventes, emulsiones y otros productos. Puede causar irritación, quemaduras, sensibilización o intoxicación; exige ficha de datos de seguridad actualizada y control de incompatibilidades, ventilación e higiene.
- R-DERMATITIS: Alteración de la piel por contacto repetido con productos químicos, hidrocarburos, humedad o materiales irritantes. Puede producir inflamación y sensibilización; se reducirá el contacto mediante sustitución, higiene y guantes compatibles con el agente y la tarea.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Los residuos se acopiarán de forma estable sin invadir itinerarios ni zonas de maniobra (MP-ORDEN-LIMPIEZA, MP-SEGREGACION).
- La carga se coordinará con los movimientos de vehículos, impidiendo la presencia de personas bajo cucharas o cargas (MP-CONTROL-MAQUINARIA, MP-ZONA-EXCLUSION).
- Se identificarán y separarán los materiales y envases contaminados. Se evitarán derrames y se controlará el polvo durante la manipulación (MP-HIGIENE-QUIMICA, MP-HUMECTACION).

### Protecciones colectivas

Se preverán PC-BALIZAMIENTO y PC-SENALIZACION, con cerramiento y contención adecuados a los residuos y a la proximidad de terceros.

### Equipos de protección individual

Se seleccionarán EPI-ALTA-VISIBILIDAD, EPI-GUANTES, EPI-CALZADO y EPI-OCULAR. Las prestaciones químicas y respiratorias se determinarán según la caracterización y exposición.

### Equipos de trabajo

Podrán requerirse EQ-CAMION y EQ-CARGADORA. Se comprobarán la estabilidad de la zona de carga y la sujeción y cubrición necesarias para el transporte.

### Validación

Se confirmarán clasificación, caracterización cuando proceda, gestor de destino y condiciones de carga y transporte. Los códigos anteriores de la familia 17RRBN requieren comprobar su correspondencia con la clasificación BCCA 17RB. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
