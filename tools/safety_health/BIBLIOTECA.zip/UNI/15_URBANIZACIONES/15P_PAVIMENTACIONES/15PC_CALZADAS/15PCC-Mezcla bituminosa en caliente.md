"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Mezcla bituminosa en caliente

## Definición y alcance

Comprende el transporte, la descarga, el extendido y la compactación de mezclas bituminosas en caliente para calzadas. Se coordinarán los movimientos de camiones, extendedora, compactadores y personal a pie.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-RETROCESO-MAQUINA, R-ATRAPAMIENTO, R-APLASTAMIENTO, R-VUELCO, R-QUEMADURA, R-SALPICADURA, R-CALOR, R-HUMOS, R-RUIDO, R-VIBRACION, R-RADIACION-SOLAR.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se definirá un circuito de aproximación, descarga y salida, con maniobras coordinadas y sin personal entre camión y extendedora (MP-SEGREGACION, MP-CONTROL-MAQUINARIA, MP-ZONA-EXCLUSION).
- Se mantendrán distancias respecto a los órganos móviles y a la mezcla caliente. Se evitará la permanencia innecesaria en humos y se comprobarán las condiciones de uso del producto (MP-HIGIENE-QUIMICA).
- Se garantizarán agua, pausas y recuperación térmica, adaptando horarios y ritmos al esfuerzo, calor ambiental y temperatura de los materiales (MP-CONTROL-TERMICO, MP-CONTROL-METEOROLOGICO).
- Se mantendrán estables los bordes y despejados los recorridos, sin reabrir al tráfico hasta comprobar las condiciones de seguridad (MP-PROTEGER-DESNIVELES, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-ZONA-EXCLUSION: Delimitación física de las zonas en las que no debe permanecer personal.

La implantación se ajustará al tajo y a la proximidad del tráfico.

### Equipos de protección individual

- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-GUANTES-TERMICOS: Guantes adecuados a la temperatura de contacto y a la manipulación de mezcla caliente.
- EPI-ROPA-CALOR: Ropa adecuada frente al calor y a las salpicaduras de mezcla caliente.
- EPI-AUDITIVO: Protección auditiva seleccionada según la exposición, compatible con la percepción de avisos y alarmas.

La ropa y los guantes se adaptarán a la temperatura de contacto y a la tarea; la protección auditiva, a la exposición.

### Equipos de trabajo

- EQ-CAMION: Camión de transporte o descarga, con maniobras coordinadas.
- EQ-EXTENDEDORA: Extendedora de mezcla bituminosa, con resguardos y zonas de aproximación controladas.
- EQ-RODILLO-COMPACTADOR: Rodillo compactador con visibilidad y dispositivos de aviso comprobados.

Se verificarán la visibilidad, los avisos, los resguardos y las zonas de aproximación.

## Validación

Se confirmarán la temperatura de empleo, el circuito de vehículos, la descarga, la visibilidad de las maniobras y las medidas frente al estrés térmico antes del extendido. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
