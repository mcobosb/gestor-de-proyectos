# Mezcla bituminosa en caliente

Clasificación BCCA: 15 / 15P / 15PC / 15PCC.

## Definición y alcance

Comprende el transporte, la descarga, el extendido y la compactación de mezclas bituminosas en caliente para calzadas. Se coordinarán los movimientos de camiones, extendedora, compactadores y personal a pie.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-RETROCESO-MAQUINA: Golpe o atropello durante la marcha atrás de vehículos o maquinaria por puntos ciegos o presencia de personas en la trayectoria. Se limitarán estas maniobras, se delimitará su recorrido y se dispondrá señalista cuando la visibilidad sea insuficiente.
- R-ATRAPAMIENTO: Aprisionamiento de una parte del cuerpo entre órganos móviles, transmisiones o elementos de un equipo. Puede producir aplastamientos o amputaciones durante el uso, limpieza o mantenimiento; exige resguardos operativos y aislamiento seguro antes de intervenir.
- R-APLASTAMIENTO: Compresión del cuerpo entre vehículos, equipos, elementos constructivos o cargas, con posibles lesiones graves o mortales. Deben evitarse posiciones entre elementos móviles y fijos, asegurar apoyos y establecer zonas de exclusión durante las maniobras.
- R-VUELCO: Pérdida de estabilidad de maquinaria, vehículos, cargas o equipos por pendiente, terreno débil, proximidad a bordes o maniobras. Puede provocar aplastamientos y caídas; requiere comprobar apoyos, límites de uso y condiciones del recorrido.
- R-QUEMADURA: Lesión por contacto o salpicadura de mezclas bituminosas, ligantes, equipos o superficies calientes. Debe evitarse el contacto mediante herramientas y protección térmica apropiadas, manteniendo la temperatura técnicamente necesaria y aplicando el procedimiento de primeros auxilios.
- R-SALPICADURA: Proyección de pequeñas cantidades de productos, morteros, fluidos o mezcla caliente sobre piel y ojos. Puede causar irritación, lesión química o quemadura térmica; deben controlarse la aplicación y las distancias, usando protección compatible con el producto.
- R-CALOR: Carga térmica elevada por temperatura, radiación solar, humedad, esfuerzo físico o proximidad a materiales calientes. Puede provocar deshidratación, agotamiento o golpe de calor; requiere agua, pausas, recuperación térmica y adaptación de horarios y ritmos.
- R-HUMOS: Inhalación de humos, vapores o aerosoles procedentes de motores, productos y mezclas bituminosas calientes. Puede causar irritación u otros daños respiratorios según su composición; se limitará la exposición mediante control en origen, ventilación y organización del trabajo.
- R-RUIDO: Exposición al ruido de fresadoras, martillos, radiales, compactadores y otros equipos, con posible daño auditivo y dificultad para percibir avisos. Se evaluará cuando sea significativa, priorizando equipos menos ruidosos, mantenimiento y control del tiempo de exposición.
- R-VIBRACION: Transmisión de vibraciones mano-brazo o de cuerpo entero por martillos, compactadores y maquinaria móvil. Puede causar trastornos vasculares, nerviosos o musculoesqueléticos; se considerarán valores del fabricante, uso real, firme, mantenimiento y tiempo de exposición.
- R-RADIACION-SOLAR: Exposición a radiación ultravioleta durante trabajos al aire libre, con posibles quemaduras y daños acumulativos en piel y ojos. Debe reducirse mediante sombra, organización horaria y protección personal adecuada, sin confundirla con el control del calor.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se definirá un circuito de aproximación, descarga y salida, con maniobras coordinadas y sin personal entre camión y extendedora (MP-SEGREGACION, MP-CONTROL-MAQUINARIA, MP-ZONA-EXCLUSION).
- Se mantendrán distancias respecto a los órganos móviles y a la mezcla caliente. Se evitará la permanencia innecesaria en humos y se comprobarán las condiciones de uso del producto (MP-HIGIENE-QUIMICA).
- Se garantizarán agua, pausas y recuperación térmica, adaptando horarios y ritmos al esfuerzo, calor ambiental y temperatura de los materiales (MP-CONTROL-TERMICO, MP-CONTROL-METEOROLOGICO).
- Se mantendrán estables los bordes y despejados los recorridos, sin reabrir al tráfico hasta comprobar las condiciones de seguridad (MP-PROTEGER-DESNIVELES, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

Se utilizarán PC-BALIZAMIENTO, PC-SENALIZACION y PC-ZONA-EXCLUSION según la implantación del tajo y la proximidad del tráfico.

### Equipos de protección individual

Se seleccionarán EPI-ALTA-VISIBILIDAD, EPI-CALZADO, EPI-GUANTES-TERMICOS, EPI-ROPA-CALOR y EPI-AUDITIVO según la exposición. La ropa y los guantes se adaptarán a la temperatura de contacto y a la tarea.

### Equipos de trabajo

Los equipos previsibles son EQ-CAMION, EQ-EXTENDEDORA y EQ-RODILLO-COMPACTADOR. Se verificarán visibilidad, avisos, resguardos y zonas de aproximación.

### Validación

Se confirmarán la temperatura de empleo, el circuito de vehículos, la descarga, la visibilidad de las maniobras y las medidas frente al estrés térmico antes del extendido. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
