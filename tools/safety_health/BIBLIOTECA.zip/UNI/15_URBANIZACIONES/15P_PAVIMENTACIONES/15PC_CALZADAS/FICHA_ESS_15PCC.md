# Calzadas asfalticas

**Clasificacion:** `15PCC`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-ASFALTO`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a partidas de calzada con mezcla asfaltica, aglomerado asfaltico o mezcla bituminosa, incluyendo transporte, descarga, extendido y compactacion.

## Riesgos

`R-ATROPELLO`, `R-RETROCESO-MAQUINA`, `R-ATRAPAMIENTO`, `R-APLASTAMIENTO`, `R-VUELCO`, `R-QUEMADURA`, `R-SALPICADURA`, `R-CALOR`, `R-HUMOS`, `R-RUIDO`, `R-VIBRACION` y `R-RADIACION-SOLAR`.

## Medidas preventivas

Definir un circuito de aproximacion, descarga y salida de camiones. Prohibir la permanencia entre camion y extendedora. Mantener distancia de los organos moviles y de la mezcla caliente. Organizar pausas, hidratacion y vigilancia de la carga termica cuando las condiciones ambientales lo requieran.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO`, `PC-SENALIZACION` y `PC-ZONA-EXCLUSION`. Utilizar `EPI-ALTA-VISIBILIDAD`, `EPI-CALZADO`, `EPI-GUANTES-TERMICOS`, `EPI-ROPA-CALOR` y `EPI-AUDITIVO`, conforme a la evaluacion. Los equipos caracteristicos son `EQ-CAMION`, `EQ-EXTENDEDORA` y `EQ-RODILLO-COMPACTADOR`.

## Validaciones

Confirmar temperatura de empleo, circuito de vehiculos, procedimiento de descarga, visibilidad de maniobras y medidas frente al estres termico.
