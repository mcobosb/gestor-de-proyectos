# Pinturas y marcas viales

Clasificación BCCA: 15 / 15C / 15CP.

## Definición y alcance

Comprende la aplicación de marcas longitudinales y transversales, pasos de peatones y símbolos, con sus pinturas, resinas, microesferas y productos auxiliares. Se diferenciarán los productos en frío de las aplicaciones que requieran calentamiento.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.
- R-QUIMICO: Exposición por inhalación, contacto cutáneo u ocular a pinturas, disolventes, emulsiones y otros productos. Puede causar irritación, quemaduras, sensibilización o intoxicación; exige ficha de datos de seguridad actualizada y control de incompatibilidades, ventilación e higiene.
- R-DERMATITIS: Alteración de la piel por contacto repetido con productos químicos, hidrocarburos, humedad o materiales irritantes. Puede producir inflamación y sensibilización; se reducirá el contacto mediante sustitución, higiene y guantes compatibles con el agente y la tarea.
- R-SALPICADURA: Proyección de pequeñas cantidades de productos, morteros, fluidos o mezcla caliente sobre piel y ojos. Puede causar irritación, lesión química o quemadura térmica; deben controlarse la aplicación y las distancias, usando protección compatible con el producto.
- R-INCENDIO: Combustión no controlada de combustibles, productos inflamables, residuos o equipos, favorecida por chispas y superficies calientes. Puede causar quemaduras e intoxicación por humo; exige controlar fuentes de ignición, almacenamiento, evacuación y medios de primera intervención.
- R-EXPLOSION: Liberación súbita de energía y presión por atmósferas inflamables, productos incompatibles o recipientes presurizados. Puede causar onda de presión, proyecciones y quemaduras; exige identificar sustancias y atmósferas peligrosas, controlar la ignición y aplicar procedimientos específicos.
- R-QUEMADURA: Lesión por contacto o salpicadura de mezclas bituminosas, ligantes, equipos o superficies calientes. Debe evitarse el contacto mediante herramientas y protección térmica apropiadas, manteniendo la temperatura técnicamente necesaria y aplicando el procedimiento de primeros auxilios.
- R-POLVO: Inhalación de partículas generadas en fresado, corte, demolición o limpieza, con efectos dependientes del material y su composición. Se reducirá la emisión mediante captación, aspiración o humectación compatible, evitando el barrido en seco que genere exposición innecesaria.
- R-RADIACION-SOLAR: Exposición a radiación ultravioleta durante trabajos al aire libre, con posibles quemaduras y daños acumulativos en piel y ojos. Debe reducirse mediante sombra, organización horaria y protección personal adecuada, sin confundirla con el control del calor.
- R-POSTURA-FORZADA: Mantenimiento de posiciones incómodas o extremas de espalda, cuello o extremidades durante trabajos a baja altura o de acceso difícil. Puede causar sobrecarga musculoesquelética; requiere adaptar el puesto, utilizar ayudas y alternar posturas y tareas.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- El tajo permanecerá segregado del tráfico hasta alcanzar el curado o la resistencia necesarios para su reapertura (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Antes del uso se consultarán las fichas de datos de seguridad y se comprobarán ventilación, incompatibilidades y condiciones de almacenamiento (MP-HIGIENE-QUIMICA).
- Se eliminarán las fuentes de ignición cuando existan inflamables y se controlarán derrames, polvo y dispersión de microesferas (MP-CONTROL-IGNICION, MP-HUMECTACION, MP-ORDEN-LIMPIEZA).
- Se adaptarán horarios, pausas y condiciones de aplicación al calor, viento y visibilidad, suspendiendo la operación si no puede mantenerse la seguridad (MP-CONTROL-TERMICO, MP-CONTROL-METEOROLOGICO, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

Se utilizarán PC-BALIZAMIENTO y PC-SENALIZACION para delimitar el trabajo. Se dispondrá de PC-EXTINTOR cuando lo justifiquen los productos o los equipos calefactados.

### Equipos de protección individual

Se seleccionarán EPI-ALTA-VISIBILIDAD, EPI-GUANTES-QUIMICOS y EPI-OCULAR. La necesidad y características de EPI-RESPIRATORIO y de protección térmica se determinarán a partir del producto, la aplicación y la exposición real.

### Equipos de trabajo

Podrán emplearse EQ-MAQUINA-MARCAJE y EQ-BARREDORA. Se comprobarán los circuitos de producto, resguardos y dispositivos de calentamiento que existan.

### Validación

Se confirmarán los productos, la compatibilidad de los EPI, las condiciones de aplicación, el tiempo de curado y la afección al tráfico antes de autorizar la reapertura. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
