# Pinturas y marcas viales

## Definición y alcance

Comprende la aplicación de marcas longitudinales y transversales, pasos de peatones y símbolos, con sus pinturas, resinas, microesferas y productos auxiliares. Se diferenciarán los productos en frío de las aplicaciones que requieran calentamiento.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-TERCEROS, R-QUIMICO, R-DERMATITIS, R-SALPICADURA, R-INCENDIO, R-EXPLOSION, R-QUEMADURA, R-POLVO, R-RADIACION-SOLAR, R-POSTURA-FORZADA.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- El tajo permanecerá segregado del tráfico hasta alcanzar el curado o la resistencia necesarios para su reapertura (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Antes del uso se consultarán las fichas de datos de seguridad y se comprobarán ventilación, incompatibilidades y condiciones de almacenamiento (MP-HIGIENE-QUIMICA).
- Se eliminarán las fuentes de ignición cuando existan inflamables y se controlarán derrames, polvo y dispersión de microesferas (MP-CONTROL-IGNICION, MP-HUMECTACION, MP-ORDEN-LIMPIEZA).
- Se adaptarán horarios, pausas y condiciones de aplicación al calor, viento y visibilidad, suspendiendo la operación si no puede mantenerse la seguridad (MP-CONTROL-TERMICO, MP-CONTROL-METEOROLOGICO, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-EXTINTOR: Medio de extinción adecuado y accesible cuando lo justifiquen los productos o los equipos calefactados.

La delimitación se mantendrá durante la aplicación y hasta que pueda reabrirse el paso con seguridad.

### Equipos de protección individual

- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.
- EPI-GUANTES-QUIMICOS: Guantes compatibles con el producto y las condiciones de aplicación.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-RESPIRATORIO: Protección respiratoria solo cuando la exposición residual lo requiera, seleccionada según contaminante, concentración y ajuste al usuario; no sustituye el control en origen.

La necesidad y características de la protección respiratoria y térmica se determinarán a partir del producto, la aplicación y la exposición real.

### Equipos de trabajo

- EQ-MAQUINA-MARCAJE: Equipo de aplicación de marcas viales, con circuitos de producto y dispositivos de calentamiento revisados.
- EQ-BARREDORA: Equipo de limpieza mecánica, con control de la dispersión de polvo.

Se comprobarán los circuitos de producto, los resguardos y los dispositivos de calentamiento que existan.

## Validación

Se confirmarán los productos, la compatibilidad de los EPI, las condiciones de aplicación, el tiempo de curado y la afección al tráfico antes de autorizar la reapertura. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
