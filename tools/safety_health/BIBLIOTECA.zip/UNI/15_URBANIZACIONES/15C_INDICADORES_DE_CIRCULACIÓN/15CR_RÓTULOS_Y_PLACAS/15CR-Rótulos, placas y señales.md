"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Rótulos, placas y señales

## Definición y alcance

Comprende el montaje o la sustitución de señales verticales, placas, postes, soportes, cimentaciones y elementos auxiliares de señalización. Se adaptará la operación al peso, superficie expuesta y ubicación del elemento.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-ATROPELLO, R-TERCEROS, R-SERVICIOS-AFECTADOS, R-ELECTRICO, R-GOLPE-ATRAPAMIENTO, R-CORTE, R-CAIDA-OBJETOS, R-IZADO-CARGAS, R-CAIDA-CARGA-SUSPENDIDA, R-SOBREESFUERZO, R-VIENTO.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se delimitará el punto de trabajo antes de perforar, excavar o montar el soporte y se separará de la circulación (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Se localizarán los servicios y se protegerán los huecos mientras estén abiertos (MP-LOCALIZAR-SERVICIOS, MP-PROTEGER-HUECOS).
- El izado o la manipulación se planificará con útiles adecuados y sin personas bajo las piezas. Se comprobarán el apriete y la estabilidad antes de retirar el balizamiento (MP-MANIPULACION-CARGAS, MP-CONTROL-MAQUINARIA).
- Se tendrán en cuenta el viento y la visibilidad; se suspenderá el montaje cuando no pueda controlarse la pieza (MP-CONTROL-METEOROLOGICO, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

- PC-BALIZAMIENTO: Delimitación visible del tajo, mantenida durante los trabajos.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-BARRERA-RIGIDA: Barrera física estable que impida el acceso o la caída a la zona de riesgo.

Se dispondrá barrera rígida cuando deba impedirse el acceso a la excavación o a una zona de montaje.

### Equipos de protección individual

- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.
- EPI-CASCO: Casco de protección frente a golpes y caída de objetos.
- EPI-GUANTES: Guantes adecuados a la manipulación de materiales y a los riesgos mecánicos.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.

Los trabajos en altura requerirán una selección específica de acceso y protección, si resultan necesarios.

### Equipos de trabajo

- EQ-HERRAMIENTA-MANUAL: Herramientas manuales o portátiles adecuadas a la tarea y en buen estado.
- EQ-CORTE: Equipo de corte con resguardos y útiles adecuados al material.
- EQ-ELEVACION: Medio de elevación y útiles de izado adecuados al peso y a la geometría de las piezas.

Los útiles de sujeción serán compatibles con la geometría y resistencia del elemento.

## Validación

Se confirmarán el método de cimentación, los servicios, el peso y superficie de la señal, las condiciones de viento y los medios de izado o acceso. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
