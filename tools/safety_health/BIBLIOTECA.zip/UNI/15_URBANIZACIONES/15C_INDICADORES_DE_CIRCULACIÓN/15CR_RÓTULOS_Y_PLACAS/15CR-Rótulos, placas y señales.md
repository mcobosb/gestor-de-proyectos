# Rótulos, placas y señales

Clasificación BCCA: 15 / 15C / 15CR.

## Definición y alcance

Comprende el montaje o la sustitución de señales verticales, placas, postes, soportes, cimentaciones y elementos auxiliares de señalización. Se adaptará la operación al peso, superficie expuesta y ubicación del elemento.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.
- R-SERVICIOS-AFECTADOS: Contacto o daño accidental a redes eléctricas, de gas, agua, saneamiento o telecomunicaciones durante excavaciones y demoliciones. Puede producir electrocución, fugas, inundación o interrupciones; requiere información previa, localización y coordinación con los titulares.
- R-ELECTRICO: Contacto directo con partes en tensión o indirecto con masas accidentalmente energizadas, incluidas redes enterradas y equipos portátiles. Puede causar electrocución, quemaduras o caídas; requiere localizar servicios y aplicar aislamiento y procedimientos eléctricos autorizados.
- R-GOLPE-ATRAPAMIENTO: Golpe, corte o aprisionamiento al mover tapas, bordillos, señales y otros materiales, especialmente durante su ajuste o descarga. Deben preverse puntos de agarre, apoyos estables, ayudas mecánicas y coordinación entre las personas que intervienen.
- R-CORTE: Lesión por contacto con filos, aristas, chapas, discos, herramientas o elementos rotos durante uso y manipulación. Deben mantenerse los resguardos, emplearse útiles adecuados y organizar el agarre y transporte evitando la exposición de manos y cuerpo.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-IZADO-CARGAS: Pérdida de control en elevación por fallo de eslingas, enganches, útiles, apoyos o coordinación de maniobras. Puede ocasionar caída de cargas, golpes o vuelcos; exige medios adecuados, comprobaciones previas y personal formado y autorizado.
- R-CAIDA-CARGA-SUSPENDIDA: Caída, desplazamiento o balanceo de una carga izada por fallo de sujeción, pérdida de estabilidad o maniobra inadecuada. Puede golpear o aplastar; requiere útiles adecuados, maniobras coordinadas y ausencia de personas bajo cargas suspendidas.
- R-SOBREESFUERZO: Sobrecarga física al levantar, transportar, empujar o colocar tapas, señales, bordillos, sacos y herramientas. Puede provocar lesiones musculares y lumbares; deben emplearse ayudas mecánicas, trabajo coordinado y una organización que limite la manipulación manual.
- R-VIENTO: Pérdida de estabilidad o control de cargas, señales, equipos y materiales por rachas de viento. Puede producir vuelcos, caídas y proyecciones; deben respetarse las limitaciones de los equipos y suspender las maniobras cuando no exista control seguro.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se delimitará el punto de trabajo antes de perforar, excavar o montar el soporte y se separará de la circulación (MP-SEGREGACION, MP-ZONA-EXCLUSION).
- Se localizarán los servicios y se protegerán los huecos mientras estén abiertos (MP-LOCALIZAR-SERVICIOS, MP-PROTEGER-HUECOS).
- El izado o la manipulación se planificará con útiles adecuados y sin personas bajo las piezas. Se comprobarán el apriete y la estabilidad antes de retirar el balizamiento (MP-MANIPULACION-CARGAS, MP-CONTROL-MAQUINARIA).
- Se tendrán en cuenta el viento y la visibilidad; se suspenderá el montaje cuando no pueda controlarse la pieza (MP-CONTROL-METEOROLOGICO, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

Se preverán PC-BALIZAMIENTO, PC-SENALIZACION y PC-BARRERA-RIGIDA cuando deba impedirse el acceso a la excavación o a una zona de montaje.

### Equipos de protección individual

Se seleccionarán EPI-ALTA-VISIBILIDAD, EPI-CASCO, EPI-GUANTES, EPI-OCULAR y EPI-CALZADO según los riesgos. Los trabajos en altura requerirán una selección específica de acceso y protección, si resultan necesarios.

### Equipos de trabajo

Podrán requerirse EQ-HERRAMIENTA-MANUAL, EQ-CORTE y EQ-ELEVACION, con útiles de sujeción compatibles con la geometría y resistencia del elemento.

### Validación

Se confirmarán el método de cimentación, los servicios, el peso y superficie de la señal, las condiciones de viento y los medios de izado o acceso. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
