# Señales y carteles verticales

**Clasificacion:** `15CR`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-SENALIZACION-V`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a señales verticales, placas, postes, soportes, cimentaciones y elementos auxiliares de señalizacion.

## Riesgos

`R-ATROPELLO`, `R-TERCEROS`, `R-SERVICIOS-AFECTADOS`, `R-ELECTRICO`, `R-GOLPE-ATRAPAMIENTO`, `R-CORTE`, `R-CAIDA-OBJETOS`, `R-IZADO-CARGAS`, `R-CAIDA-CARGA-SUSPENDIDA`, `R-SOBREESFUERZO` y `R-VIENTO`.

## Medidas preventivas

Delimitar el punto de trabajo antes de perforar, excavar o montar el soporte. Verificar los servicios enterrados y planificar el izado o manipulacion de señales de gran dimension. Mantener el balizamiento hasta comprobar el apriete y la estabilidad del soporte.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO` y `PC-SENALIZACION`. Utilizar `EPI-ALTA-VISIBILIDAD`, `EPI-CASCO`, `EPI-GUANTES` y `EPI-CALZADO`. Podran requerirse `EQ-HERRAMIENTA-MANUAL` y `EQ-ELEVACION`.

## Validaciones

Confirmar metodo de cimentacion, servicios afectados, peso y superficie de la señal, condiciones de viento y necesidad de izado.
