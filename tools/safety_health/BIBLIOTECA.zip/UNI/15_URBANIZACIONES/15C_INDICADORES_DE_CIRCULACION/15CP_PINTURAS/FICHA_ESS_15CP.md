# Pinturas y marcas viales

**Clasificacion:** `15CP`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-SENALIZACION-H`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a pinturas, marcas longitudinales y transversales, pasos de peatones, simbolos, microesferas y productos auxiliares para señalizacion horizontal.

## Riesgos

`R-ATROPELLO`, `R-TERCEROS`, `R-QUIMICO`, `R-DERMATITIS`, `R-SALPICADURA`, `R-INCENDIO`, `R-EXPLOSION`, `R-QUEMADURA`, `R-POLVO`, `R-RADIACION-SOLAR` y `R-POSTURA-FORZADA`.

## Medidas preventivas

Mantener el tajo segregado hasta que la marca alcance las condiciones de curado requeridas. Consultar las fichas de datos de seguridad de pinturas, resinas, catalizadores, diluyentes y productos de limpieza. Eliminar fuentes de ignicion cuando se utilicen productos inflamables y controlar la dispersion de microesferas y polvo.

## Protecciones, EPI y equipos

Aplicar `PC-BALIZAMIENTO`, `PC-SENALIZACION` y `PC-EXTINTOR`. Utilizar `EPI-ALTA-VISIBILIDAD`, `EPI-GUANTES-QUIMICOS`, `EPI-OCULAR` y la proteccion respiratoria definida por la evaluacion. Los equipos caracteristicos son `EQ-MAQUINA-MARCAJE` y `EQ-BARREDORA`.

## Validaciones

Confirmar productos empleados, compatibilidad de EPI, condiciones de aplicacion, tiempo de curado y afeccion al trafico.
