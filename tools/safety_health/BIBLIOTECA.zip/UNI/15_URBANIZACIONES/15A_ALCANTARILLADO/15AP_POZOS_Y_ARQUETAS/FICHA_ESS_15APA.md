# Arquetas de saneamiento

**Clasificacion:** `15APA`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-ARQUETAS`, `UO-SANEAMIENTO`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a arquetas de paso, sifonicas y otras arquetas de saneamiento, incluidas sus excavaciones, tapas, marcos, conexiones y reposiciones.

## Riesgos

`R-CAIDA-DISTINTO-NIVEL`, `R-DERRUMBE`, `R-GOLPE-ATRAPAMIENTO`, `R-CAIDA-OBJETOS`, `R-SERVICIOS-AFECTADOS`, `R-ELECTRICO`, `R-SOBREESFUERZO`, `R-CONTACTO-CEMENTO`, `R-ATROPELLO` y `R-TERCEROS`.

## Medidas preventivas

Identificar los servicios antes de excavar. Proteger el hueco desde su apertura mediante tapa resistente o barrera rigida. Mantener acopios alejados del borde, comprobar la estabilidad de la excavacion y usar medios adecuados para tapas, marcos y piezas prefabricadas.

## Protecciones, EPI y equipos

Aplicar `PC-BARRERA-RIGIDA`, `PC-TAPA-RESISTENTE`, `PC-ACCESO-EXCAVACION` y `PC-SENALIZACION`. Utilizar `EPI-CASCO`, `EPI-CALZADO`, `EPI-GUANTES`, `EPI-OCULAR` y `EPI-ALTA-VISIBILIDAD`. Podran requerirse `EQ-EXCAVADORA`, `EQ-ELEVACION` y `EQ-HERRAMIENTA-MANUAL`.

## Validaciones

Confirmar profundidad, estabilidad, servicios existentes, necesidad de entibacion y forma de manipulacion de las piezas.
