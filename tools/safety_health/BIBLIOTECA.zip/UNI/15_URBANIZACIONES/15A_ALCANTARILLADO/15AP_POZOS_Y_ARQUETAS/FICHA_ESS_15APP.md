# Pozos de registro

**Clasificacion:** `15APP`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-ARQUETAS`, `UO-SANEAMIENTO`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a ejecucion, recrecido, reparacion o adaptacion de pozos de registro y sus elementos de acceso.

## Riesgos

`R-CAIDA-DISTINTO-NIVEL`, `R-DERRUMBE`, `R-CAIDA-OBJETOS`, `R-ASFIXIA`, `R-ESPACIO-CONFINADO`, `R-AGENTE-BIOLOGICO`, `R-SERVICIOS-AFECTADOS`, `R-ATROPELLO` y `R-IZADO-CARGAS`.

## Medidas preventivas

Mantener el perimetro cerrado y proteger el hueco de inmediato. Verificar los servicios y la estabilidad antes de intervenir. No acceder al pozo hasta determinar si sus caracteristicas lo califican como espacio confinado; en tal caso, aplicar el procedimiento de entrada, medicion atmosferica y rescate especifico.

## Protecciones, EPI y equipos

Aplicar `PC-BARRERA-RIGIDA`, `PC-TAPA-RESISTENTE`, `PC-ACCESO-EXCAVACION` y, cuando proceda, `PC-ENTIBACION`. Utilizar los EPI definidos por la evaluacion. Podran requerirse `EQ-DETECCION-GASES` y `EQ-ELEVACION`.

## Validaciones

Confirmar profundidad, atmosfera interior, acceso, plan de rescate y necesidad de entibacion antes de cualquier entrada.
