# Imbornales y arquetas de saneamiento

Clasificación BCCA: 15 / 15A / 15AP / 15APA.

## Definición y alcance

Comprende la ejecución, sustitución o adaptación de arquetas e imbornales de saneamiento, con sus excavaciones, tapas, marcos, conexiones y reposiciones. La ficha se ajustará a la profundidad, los materiales y las condiciones de la red.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-CAIDA-DISTINTO-NIVEL: Caída desde bordes, plataformas o accesos hacia huecos, excavaciones, pozos o registros. Sus consecuencias dependen de la altura y la superficie de impacto; requiere accesos seguros, tapas resistentes y protecciones colectivas adecuadas al desnivel.
- R-DERRUMBE: Desprendimiento de tierras o pérdida de estabilidad de taludes, paredes de excavación o elementos próximos. Puede sepultar o golpear a las personas; deben evaluarse el terreno, agua, vibraciones y cargas cercanas antes de definir el sostenimiento.
- R-GOLPE-ATRAPAMIENTO: Golpe, corte o aprisionamiento al mover tapas, bordillos, señales y otros materiales, especialmente durante su ajuste o descarga. Deben preverse puntos de agarre, apoyos estables, ayudas mecánicas y coordinación entre las personas que intervienen.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-SERVICIOS-AFECTADOS: Contacto o daño accidental a redes eléctricas, de gas, agua, saneamiento o telecomunicaciones durante excavaciones y demoliciones. Puede producir electrocución, fugas, inundación o interrupciones; requiere información previa, localización y coordinación con los titulares.
- R-ELECTRICO: Contacto directo con partes en tensión o indirecto con masas accidentalmente energizadas, incluidas redes enterradas y equipos portátiles. Puede causar electrocución, quemaduras o caídas; requiere localizar servicios y aplicar aislamiento y procedimientos eléctricos autorizados.
- R-SOBREESFUERZO: Sobrecarga física al levantar, transportar, empujar o colocar tapas, señales, bordillos, sacos y herramientas. Puede provocar lesiones musculares y lumbares; deben emplearse ayudas mecánicas, trabajo coordinado y una organización que limite la manipulación manual.
- R-CONTACTO-CEMENTO: Contacto de piel u ojos con cemento, mortero u hormigón fresco, especialmente si queda retenido dentro de guantes, botas o ropa. Puede causar irritación, quemaduras y sensibilización; requiere evitar contacto prolongado e higiene inmediata adecuada.
- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se identificarán y localizarán los servicios antes de excavar. Se comprobarán la estabilidad del terreno, las cargas próximas al borde y la necesidad de sostenimiento (MP-LOCALIZAR-SERVICIOS, MP-ESTABILIDAD-EXCAVACION).
- El hueco quedará protegido desde su apertura y se dispondrá un acceso seguro, sin invadir recorridos de terceros (MP-PROTEGER-HUECOS, MP-ACCESOS-SEGUROS, MP-SEGREGACION).
- Las tapas, marcos y piezas prefabricadas se moverán con ayudas adecuadas. Se limitará el polvo y se mantendrán despejados los apoyos y recorridos (MP-MANIPULACION-CARGAS, MP-HUMECTACION, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

Se preverán PC-BARRERA-RIGIDA, PC-TAPA-RESISTENTE, PC-ACCESO-EXCAVACION y PC-SENALIZACION. Se añadirá PC-ENTIBACION cuando lo requiera la estabilidad del terreno.

### Equipos de protección individual

Se seleccionarán EPI-CASCO, EPI-CALZADO, EPI-GUANTES, EPI-OCULAR y EPI-ALTA-VISIBILIDAD según los riesgos de la operación. Las prestaciones de los guantes se adaptarán al contacto con cemento y a la manipulación de piezas.

### Equipos de trabajo

Podrán requerirse EQ-EXCAVADORA, EQ-ELEVACION y EQ-HERRAMIENTA-MANUAL. Se comprobarán su adecuación al espacio disponible y los útiles para manipular las piezas.

### Validación

Se confirmarán profundidad, estabilidad, servicios, posible exposición a aguas residuales y forma de manipulación de las piezas. Si se prevé una entrada en un recinto, se determinará previamente si requiere procedimiento de espacio confinado. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
