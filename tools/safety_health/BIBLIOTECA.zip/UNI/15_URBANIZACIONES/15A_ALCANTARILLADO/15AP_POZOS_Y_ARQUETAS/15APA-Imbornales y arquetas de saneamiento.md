# Imbornales y arquetas de saneamiento

## Definición y alcance

Comprende la ejecución, sustitución o adaptación de arquetas e imbornales de saneamiento, con sus excavaciones, tapas, marcos, conexiones y reposiciones. La ficha se ajustará a la profundidad, los materiales y las condiciones de la red.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-CAIDA-DISTINTO-NIVEL, R-DERRUMBE, R-GOLPE-ATRAPAMIENTO, R-CAIDA-OBJETOS, R-SERVICIOS-AFECTADOS, R-ELECTRICO, R-SOBREESFUERZO, R-CONTACTO-CEMENTO, R-ATROPELLO, R-TERCEROS.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se identificarán y localizarán los servicios antes de excavar. Se comprobarán la estabilidad del terreno, las cargas próximas al borde y la necesidad de sostenimiento (MP-LOCALIZAR-SERVICIOS, MP-ESTABILIDAD-EXCAVACION).
- El hueco quedará protegido desde su apertura y se dispondrá un acceso seguro, sin invadir recorridos de terceros (MP-PROTEGER-HUECOS, MP-ACCESOS-SEGUROS, MP-SEGREGACION).
- Las tapas, marcos y piezas prefabricadas se moverán con ayudas adecuadas. Se limitará el polvo y se mantendrán despejados los apoyos y recorridos (MP-MANIPULACION-CARGAS, MP-HUMECTACION, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

- PC-BARRERA-RIGIDA: Barrera física estable que impida el acceso o la caída a la zona de riesgo.
- PC-TAPA-RESISTENTE: Cierre resistente, estable e inmovilizado del hueco.
- PC-ACCESO-EXCAVACION: Acceso estable y seguro a la excavación.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.
- PC-ENTIBACION: Sostenimiento definido según la profundidad, el terreno y las cargas próximas, cuando lo requiera la estabilidad.

Las protecciones y el acceso se mantendrán operativos mientras exista el riesgo.

### Equipos de protección individual

- EPI-CASCO: Casco de protección frente a golpes y caída de objetos.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-GUANTES: Guantes adecuados a la manipulación de materiales y a los riesgos mecánicos.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.

Las prestaciones de los guantes se adaptarán también al contacto con cemento y a la manipulación de piezas.

### Equipos de trabajo

- EQ-EXCAVADORA: Excavadora o retroexcavadora adecuada al espacio y a las condiciones del terreno.
- EQ-ELEVACION: Medio de elevación y útiles de izado adecuados al peso y a la geometría de las piezas.
- EQ-HERRAMIENTA-MANUAL: Herramientas manuales o portátiles adecuadas a la tarea y en buen estado.

Se comprobarán la adecuación al espacio disponible y los útiles para manipular las piezas.

## Validación

Se confirmarán profundidad, estabilidad, servicios, posible exposición a aguas residuales y forma de manipulación de las piezas. Si se prevé una entrada en un recinto, se determinará previamente si requiere procedimiento de espacio confinado. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
