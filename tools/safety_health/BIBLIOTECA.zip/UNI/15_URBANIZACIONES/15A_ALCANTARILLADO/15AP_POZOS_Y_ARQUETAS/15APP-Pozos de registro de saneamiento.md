# Pozos de registro de saneamiento

Clasificación BCCA: 15 / 15A / 15AP / 15APP.

## Definición y alcance

Comprende la ejecución, el recrecido, la reparación o la adaptación de pozos de registro y de sus elementos de acceso. La entrada al pozo es una operación diferenciada que no queda autorizada por la mera selección de esta ficha.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-CAIDA-DISTINTO-NIVEL: Caída desde bordes, plataformas o accesos hacia huecos, excavaciones, pozos o registros. Sus consecuencias dependen de la altura y la superficie de impacto; requiere accesos seguros, tapas resistentes y protecciones colectivas adecuadas al desnivel.
- R-DERRUMBE: Desprendimiento de tierras o pérdida de estabilidad de taludes, paredes de excavación o elementos próximos. Puede sepultar o golpear a las personas; deben evaluarse el terreno, agua, vibraciones y cargas cercanas antes de definir el sostenimiento.
- R-CAIDA-OBJETOS: Caída de herramientas, materiales o elementos desde altura, bordes, acopios o durante su manipulación. Puede causar golpes y lesiones craneales; deben asegurarse las piezas, estabilizar los acopios y delimitar las zonas inferiores expuestas.
- R-ASFIXIA: Insuficiencia de oxígeno respirable o desplazamiento del aire por gases en pozos, registros y recintos poco ventilados. Puede causar pérdida rápida de conciencia; exige evaluación atmosférica, procedimiento de acceso y rescate previsto, sin entradas improvisadas.
- R-ESPACIO-CONFINADO: Trabajo en recintos de acceso limitado donde pueden acumularse contaminantes o faltar oxígeno, con evacuación difícil. Exige evaluación específica, control atmosférico, comunicación y rescate planificado; nunca debe improvisarse la entrada para auxiliar a otra persona.
- R-AGENTE-BIOLOGICO: Contacto o inhalación de agentes presentes en aguas residuales, lodos, residuos y redes de saneamiento, incluidas salpicaduras y heridas contaminadas. Puede provocar infecciones; requiere higiene, control de aerosoles y protección conforme a la evaluación.
- R-SERVICIOS-AFECTADOS: Contacto o daño accidental a redes eléctricas, de gas, agua, saneamiento o telecomunicaciones durante excavaciones y demoliciones. Puede producir electrocución, fugas, inundación o interrupciones; requiere información previa, localización y coordinación con los titulares.
- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-IZADO-CARGAS: Pérdida de control en elevación por fallo de eslingas, enganches, útiles, apoyos o coordinación de maniobras. Puede ocasionar caída de cargas, golpes o vuelcos; exige medios adecuados, comprobaciones previas y personal formado y autorizado.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se mantendrá cerrado el perímetro y protegido el hueco, con acceso estable y sin permanencia bajo piezas suspendidas (MP-PROTEGER-HUECOS, MP-ACCESOS-SEGUROS, MP-ZONA-EXCLUSION).
- Se verificarán las redes y la estabilidad antes de intervenir; los acopios y equipos se separarán del borde (MP-LOCALIZAR-SERVICIOS, MP-ESTABILIDAD-EXCAVACION).
- No se accederá al pozo hasta evaluar su atmósfera y determinar si constituye un espacio confinado. Cuando lo sea, se exigirá permiso, comunicación, vigilancia exterior y rescate planificado; no se permitirá el rescate improvisado (MP-PERMISO-ESPACIO-CONFINADO, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

Se dispondrán PC-BARRERA-RIGIDA, PC-TAPA-RESISTENTE y PC-ACCESO-EXCAVACION, con PC-ENTIBACION cuando proceda. Los medios de rescate se definirán en el procedimiento específico de entrada.

### Equipos de protección individual

Se seleccionarán EPI-CASCO, EPI-CALZADO, EPI-GUANTES y EPI-ALTA-VISIBILIDAD según la tarea. Los equipos respiratorios, anticaídas o de rescate que resulten necesarios se determinarán específicamente; no se sustituirán por EPI genéricos.

### Equipos de trabajo

Podrán requerirse EQ-DETECCION-GASES, EQ-ELEVACION y EQ-HERRAMIENTA-MANUAL. Los equipos de medición se comprobarán conforme a sus instrucciones antes del uso.

### Validación

Antes de cualquier entrada se confirmarán profundidad, atmósfera, estabilidad, acceso, comunicaciones, vigilancia y medios de rescate. Se documentará la decisión sobre espacio confinado y se comprobará la compatibilidad con la red en servicio. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
