"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Pozos de registro de saneamiento

## Definición y alcance

Comprende la ejecución, el recrecido, la reparación o la adaptación de pozos de registro y de sus elementos de acceso. La entrada al pozo es una operación diferenciada que no queda autorizada por la mera selección de esta ficha.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-CAIDA-DISTINTO-NIVEL, R-DERRUMBE, R-CAIDA-OBJETOS, R-ASFIXIA, R-ESPACIO-CONFINADO, R-AGENTE-BIOLOGICO, R-SERVICIOS-AFECTADOS, R-ATROPELLO, R-IZADO-CARGAS.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se mantendrá cerrado el perímetro y protegido el hueco, con acceso estable y sin permanencia bajo piezas suspendidas (MP-PROTEGER-HUECOS, MP-ACCESOS-SEGUROS, MP-ZONA-EXCLUSION).
- Se verificarán las redes y la estabilidad antes de intervenir; los acopios y equipos se separarán del borde (MP-LOCALIZAR-SERVICIOS, MP-ESTABILIDAD-EXCAVACION).
- No se accederá al pozo hasta evaluar su atmósfera y determinar si constituye un espacio confinado. Cuando lo sea, se exigirá permiso, comunicación, vigilancia exterior y rescate planificado; no se permitirá el rescate improvisado (MP-PERMISO-ESPACIO-CONFINADO, MP-SUSPENDER-TRABAJO).

### Protecciones colectivas

- PC-BARRERA-RIGIDA: Barrera física estable que impida el acceso o la caída a la zona de riesgo.
- PC-TAPA-RESISTENTE: Cierre resistente, estable e inmovilizado del hueco.
- PC-ACCESO-EXCAVACION: Acceso estable y seguro a la excavación.
- PC-ENTIBACION: Sostenimiento definido según la profundidad, el terreno y las cargas próximas, cuando lo requiera la estabilidad.

Los medios de rescate se definirán en el procedimiento específico de entrada.

### Equipos de protección individual

- EPI-CASCO: Casco de protección frente a golpes y caída de objetos.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-GUANTES: Guantes adecuados a la manipulación de materiales y a los riesgos mecánicos.
- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.

Los equipos respiratorios, anticaídas o de rescate que resulten necesarios se determinarán específicamente; no se sustituirán por EPI genéricos.

### Equipos de trabajo

- EQ-DETECCION-GASES: Equipo de medición atmosférica comprobado conforme a sus instrucciones antes del uso.
- EQ-ELEVACION: Medio de elevación y útiles de izado adecuados al peso y a la geometría de las piezas.
- EQ-HERRAMIENTA-MANUAL: Herramientas manuales o portátiles adecuadas a la tarea y en buen estado.

La medición atmosférica y los medios de elevación no sustituyen el permiso, la vigilancia exterior ni el rescate planificado cuando se trate de un espacio confinado.

## Validación

Antes de cualquier entrada se confirmarán profundidad, atmósfera, estabilidad, acceso, comunicaciones, vigilancia y medios de rescate. Se documentará la decisión sobre espacio confinado y se comprobará la compatibilidad con la red en servicio. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
