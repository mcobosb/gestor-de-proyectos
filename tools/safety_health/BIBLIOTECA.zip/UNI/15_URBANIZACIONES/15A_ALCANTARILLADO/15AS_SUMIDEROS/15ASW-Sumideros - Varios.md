"""
## Registro de cambios
- Versión: 1 | Autor: Biblioteca distribuida con el programa | Fecha: 18/11/2026 | Cambio: Incorporación del registro; autoría y fechas anteriores no documentadas.
"""
# Sumideros - Varios

## Definición y alcance

Comprende las variantes de sumideros e imbornales no cubiertas por una partida más específica. Se identificarán material, geometría, conexión y procedimiento antes de aplicar las previsiones de esta ficha.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

R-CAIDA-DISTINTO-NIVEL, R-DERRUMBE, R-SERVICIOS-AFECTADOS, R-ATROPELLO, R-APLASTAMIENTO, R-SOBREESFUERZO, R-CONTACTO-CEMENTO, R-TERCEROS.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se segregará el punto de trabajo de la circulación y se identificarán las redes antes de excavar (MP-SEGREGACION, MP-LOCALIZAR-SERVICIOS).
- Se comprobará la estabilidad de la excavación y se mantendrá protegido el hueco hasta colocar la rejilla, el marco o la tapa definitiva (MP-ESTABILIDAD-EXCAVACION, MP-PROTEGER-HUECOS).
- Los elementos prefabricados se manipularán con medios adecuados, manteniendo los acopios fuera del borde y los recorridos despejados (MP-MANIPULACION-CARGAS, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

- PC-BARRERA-RIGIDA: Barrera física estable que impida el acceso o la caída a la zona de riesgo.
- PC-TAPA-RESISTENTE: Cierre resistente, estable e inmovilizado del hueco.
- PC-SENALIZACION: Señalización temporal de obra y regulación de la circulación afectada.

El cierre se mantendrá mientras el hueco pueda originar una caída.

### Equipos de protección individual

- EPI-CASCO: Casco de protección frente a golpes y caída de objetos.
- EPI-CALZADO: Calzado de seguridad con prestaciones adecuadas a la superficie y a los riesgos del tajo.
- EPI-GUANTES: Guantes adecuados a la manipulación de materiales y a los riesgos mecánicos.
- EPI-OCULAR: Gafas o pantalla de protección frente a proyecciones y salpicaduras, según la operación.
- EPI-ALTA-VISIBILIDAD: Prenda de alta visibilidad adecuada a la circulación y maquinaria presentes.

Las prestaciones se adaptarán a las piezas y a los productos utilizados.

### Equipos de trabajo

- EQ-EXCAVADORA: Excavadora o retroexcavadora adecuada al espacio y a las condiciones del terreno.
- EQ-ELEVACION: Medio de elevación y útiles de izado adecuados al peso y a la geometría de las piezas.
- EQ-HERRAMIENTA-MANUAL: Herramientas manuales o portátiles adecuadas a la tarea y en buen estado.

Se comprobará que los útiles permiten sujetar las rejillas sin colocar las manos bajo la carga.

## Validación

Se comprobarán la variante concreta, su profundidad, los servicios afectados, el peso de las piezas y los medios de colocación. La denominación «varios» no exime de completar la evaluación del procedimiento real. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
