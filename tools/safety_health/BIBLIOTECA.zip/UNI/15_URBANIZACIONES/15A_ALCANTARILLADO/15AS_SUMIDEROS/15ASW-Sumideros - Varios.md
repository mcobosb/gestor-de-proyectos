# Sumideros - Varios

Clasificación BCCA: 15 / 15A / 15AS / 15ASW.

## Definición y alcance

Comprende las variantes de sumideros e imbornales no cubiertas por una partida más específica. Se identificarán material, geometría, conexión y procedimiento antes de aplicar las previsiones de esta ficha.

## Riesgos detectados

Se consideran las siguientes situaciones previsibles, cuya presencia y exposición deberán confirmarse con el procedimiento real de trabajo:

- R-CAIDA-DISTINTO-NIVEL: Caída desde bordes, plataformas o accesos hacia huecos, excavaciones, pozos o registros. Sus consecuencias dependen de la altura y la superficie de impacto; requiere accesos seguros, tapas resistentes y protecciones colectivas adecuadas al desnivel.
- R-DERRUMBE: Desprendimiento de tierras o pérdida de estabilidad de taludes, paredes de excavación o elementos próximos. Puede sepultar o golpear a las personas; deben evaluarse el terreno, agua, vibraciones y cargas cercanas antes de definir el sostenimiento.
- R-SERVICIOS-AFECTADOS: Contacto o daño accidental a redes eléctricas, de gas, agua, saneamiento o telecomunicaciones durante excavaciones y demoliciones. Puede producir electrocución, fugas, inundación o interrupciones; requiere información previa, localización y coordinación con los titulares.
- R-ATROPELLO: Impacto de vehículos o maquinaria móvil sobre trabajadores a pie, especialmente en maniobras, accesos y zonas compartidas. Puede causar lesiones graves por golpe o arrollamiento; requiere separar recorridos y controlar los puntos sin visibilidad.
- R-APLASTAMIENTO: Compresión del cuerpo entre vehículos, equipos, elementos constructivos o cargas, con posibles lesiones graves o mortales. Deben evitarse posiciones entre elementos móviles y fijos, asegurar apoyos y establecer zonas de exclusión durante las maniobras.
- R-SOBREESFUERZO: Sobrecarga física al levantar, transportar, empujar o colocar tapas, señales, bordillos, sacos y herramientas. Puede provocar lesiones musculares y lumbares; deben emplearse ayudas mecánicas, trabajo coordinado y una organización que limite la manipulación manual.
- R-CONTACTO-CEMENTO: Contacto de piel u ojos con cemento, mortero u hormigón fresco, especialmente si queda retenido dentro de guantes, botas o ropa. Puede causar irritación, quemaduras y sensibilización; requiere evitar contacto prolongado e higiene inmediata adecuada.
- R-TERCEROS: Entrada o proximidad de peatones, residentes y vehículos ajenos a la obra respecto a tajos, huecos y maniobras. Puede ocasionar golpes, atropellos o caídas; exige cerramiento continuo, itinerarios alternativos y control de accesos e información.

## Medidas preventivas

Las medidas se aplicarán antes de iniciar la operación y se mantendrán durante su ejecución, adaptadas a la evaluación del tajo:

- Se segregará el punto de trabajo de la circulación y se identificarán las redes antes de excavar (MP-SEGREGACION, MP-LOCALIZAR-SERVICIOS).
- Se comprobará la estabilidad de la excavación y se mantendrá protegido el hueco hasta colocar la rejilla, el marco o la tapa definitiva (MP-ESTABILIDAD-EXCAVACION, MP-PROTEGER-HUECOS).
- Los elementos prefabricados se manipularán con medios adecuados, manteniendo los acopios fuera del borde y los recorridos despejados (MP-MANIPULACION-CARGAS, MP-ORDEN-LIMPIEZA).

### Protecciones colectivas

Se preverán PC-BARRERA-RIGIDA, PC-TAPA-RESISTENTE y PC-SENALIZACION. El cierre se mantendrá mientras el hueco pueda originar una caída.

### Equipos de protección individual

Se seleccionarán EPI-CASCO, EPI-CALZADO, EPI-GUANTES, EPI-OCULAR y EPI-ALTA-VISIBILIDAD, con prestaciones adecuadas a las piezas y productos utilizados.

### Equipos de trabajo

Podrán requerirse EQ-EXCAVADORA, EQ-ELEVACION y EQ-HERRAMIENTA-MANUAL. Se comprobará que los útiles permiten sujetar las rejillas sin colocar las manos bajo la carga.

### Validación

Se comprobarán la variante concreta, su profundidad, los servicios afectados, el peso de las piezas y los medios de colocación. La denominación «varios» no exime de completar la evaluación del procedimiento real. El contratista documentará estas comprobaciones y desarrollará las medidas en el Plan de Seguridad y Salud antes de ejecutar la unidad; cualquier cambio exigirá revisar su adecuación.
