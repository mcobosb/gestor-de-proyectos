# Sumideros e imbornales varios

**Clasificacion:** `15ASW`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-SANEAMIENTO`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a las variantes de imbornales y sumideros no cubiertas por una partida mas especifica.

## Riesgos y medidas

Se aplican los riesgos, medidas preventivas, protecciones, EPI, equipos y validaciones de [FICHA_ESS_15ASS.md](./FICHA_ESS_15ASS.md), adaptados al material, profundidad, conexion y procedimiento real de la partida.
