# Sumideros e imbornales

**Clasificacion:** `15ASS`. **Capitulo:** urbanizaciones. **Unidad ESS:** `UO-SANEAMIENTO`. [Indice de fichas](../../../INDICE_FICHAS_ESS.md). [Condiciones generales](../../../CONDICIONES_GENERALES_ESS.md).

## Alcance

Aplicable a ejecucion, sustitucion o adaptacion de sumideros, imbornales, rejillas y sus conexiones inmediatas.

## Riesgos

`R-CAIDA-DISTINTO-NIVEL`, `R-DERRUMBE`, `R-SERVICIOS-AFECTADOS`, `R-ATROPELLO`, `R-APLASTAMIENTO`, `R-SOBREESFUERZO`, `R-CONTACTO-CEMENTO` y `R-TERCEROS`.

## Medidas preventivas

Segregar el punto de trabajo de la circulacion, identificar las redes existentes y mantener protegido el hueco hasta la instalacion de la rejilla, marco o tapa definitiva. Manipular los elementos prefabricados con el medio adecuado y mantener los acopios fuera del borde.

## Protecciones, EPI y equipos

Aplicar `PC-BARRERA-RIGIDA`, `PC-TAPA-RESISTENTE` y `PC-SENALIZACION`. Utilizar `EPI-CASCO`, `EPI-CALZADO`, `EPI-GUANTES` y `EPI-ALTA-VISIBILIDAD`. Podran requerirse `EQ-EXCAVADORA` y `EQ-ELEVACION`.

## Validaciones

Confirmar profundidad de la excavacion, servicios afectados, estabilidad y peso de los elementos a colocar.
